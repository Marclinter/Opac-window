# Fixed75

## Cargo workspace profile cleanup

- Moved release profile settings out of `guard/Cargo.toml` because Cargo ignores member-crate profiles when the crate is part of a workspace.
- Added the workspace-level release profile in the root `Cargo.toml`.
- Added a package-specific release override for `opac_guard` with `opt-level = "z"`, `codegen-units = 1`, and `strip = true`.
- Kept `lto = true` and `panic = "abort"` at the workspace release level, where Cargo supports them.
- Updated `build.rs` to build the embedded Guard through the workspace package target (`cargo build --package opac_guard --release`), so the same workspace profile is used.

## Validation intent

This release is intended to remove Cargo's warning:
`profiles for the non root package will be ignored, specify profiles at the workspace root`.

No application behavior or Guard security behavior was intentionally changed.
