# UI / Drag Changes - fixed36

- Internal right-drag can now return files or folders directly to the immutable vault root by releasing anywhere inside the tree frame that is not a folder row or the explicit root row.
- The root remains a valid drop destination but is never a draggable source.
- Nested folder connectors now extend through an expanded folder row so the parent-to-child vertical segment meets the first child without a visible gap.
- File connector geometry is unchanged for leaf rows, preserving alignment with the file icon column.
