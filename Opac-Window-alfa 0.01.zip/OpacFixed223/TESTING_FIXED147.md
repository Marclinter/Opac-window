# Fixed147 - regresion de vista previa de vídeo

Se corrigió la lectura de fotogramas RGB32 de Media Foundation para respetar el stride real por fila. Los búferes 2D usan `IMF2DBuffer::Lock2D`, incluido el caso de imágenes bottom-up con stride negativo. Como fallback, los búferes lineales usan `MF_MT_DEFAULT_STRIDE` y copian fila por fila.

También se añadieron regresiones unitarias para padding de stride positivo y para orientación con stride negativo.

La lógica de arranque A/V introducida en Fixed146 se conserva: el audio permanece pausado hasta que existe el primer fotograma de vídeo.

OPAC Guard no fue modificado.
