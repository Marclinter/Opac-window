# Fixed151

Se incorpora una revisión de coherencia de chunks en la ruta de cifrado paralelo. Los resultados de workers se ordenan por índice antes de escribir, se comprueba que cada resultado conserve la huella del chunk de origen y, antes de publicar el temporal como `.opac`, se recorre el framing final para comprobar la secuencia 0..N-1, el marcador de último chunk, tamaños y ausencia de datos sobrantes.

No se modificó OPAC Guard.

La revisión final del temporal no solo comprueba 0..N-1 y los tamaños: vuelve a autenticar cada chunk con su índice, nonce y AAD, descartando inmediatamente el plaintext resultante. Si la secuencia o la asociación de un ciphertext no coincide, el temporal se elimina y nunca se renombra al archivo final. La ordenación de los resultados de workers antes de escribir corrige explícitamente finalizaciones como 1-3-2.
