# Fixed82 — validación del Guard

La separación del Guard mantiene una única implementación en `guard/src/lib.rs`; `guard/src/main.rs` es solo el ejecutable mínimo.

Para ejecutar únicamente la suite del Guard en Windows:

```powershell
cargo test -p opac_guard --all-targets
```

Para ejecutar todo el workspace:

```powershell
cargo test --workspace --all-targets
```

La salida esperada del Guard debe mostrar primero los tests unitarios de `opac_guard` y después una ejecución separada para `tests/guard_public_api.rs`. El ejecutable `guard/src/main.rs` no contiene lógica de seguridad ni tests propios: solo delega a `opac_guard::main_entry()`.

Las advertencias `dead_code` de Fixed81 sobre `guard_is_active` y `validate_configured_roots_for_profile` se han eliminado retirando APIs internas sin consumidores. No se han sustituido por `allow(dead_code)` ni por llamadas artificiales desde tests.


> Fixed84 añade pruebas específicas de firma por comando y un modelo de excepciones temporales por operación. Consulta `TESTING_FIXED83.md`.
