use ed25519_dalek::Verifier;
use uuid::Uuid;

#[test]
fn guard_binary_entrypoint_is_not_runnable_without_service_mode() {
    let args = vec!["opac_guard".to_owned()];
    #[cfg(windows)]
    assert_eq!(opac_guard::main_entry(&args), 2);
    #[cfg(not(windows))]
    assert_eq!(opac_guard::main_entry(&args), 1);
}

#[test]
fn guard_public_config_signature_roundtrip_and_tamper_detection() {
    let profile_id = Uuid::from_u128(0x1234);
    let root = std::env::temp_dir().join(format!(
        "opac_guard_public_signature_{}",
        profile_id.simple()
    ));
    std::fs::create_dir_all(&root).expect("test root must be created");
    let roots = vec![root.clone()];
    let private_key = [91u8; 32];
    let (public_key, signature) =
        opac_guard::guard_config_signature(profile_id, &roots, &private_key)
            .expect("signature generation must succeed");
    let message = opac_guard::guard_config_message(profile_id, &roots, &public_key)
        .expect("message generation must succeed");
    let verifier = ed25519_dalek::VerifyingKey::from_bytes(&public_key)
        .expect("generated public key must be valid");
    verifier
        .verify(&message, &ed25519_dalek::Signature::from_bytes(&signature))
        .expect("signature must verify");

    let altered_root = root.parent().unwrap().join("altered-root");
    std::fs::create_dir_all(&altered_root).expect("altered test root must be created");
    let altered_roots = vec![altered_root.clone()];
    let altered_message = opac_guard::guard_config_message(profile_id, &altered_roots, &public_key)
        .expect("altered message must be serializable");
    assert!(
        verifier
            .verify(
                &altered_message,
                &ed25519_dalek::Signature::from_bytes(&signature)
            )
            .is_err()
    );
    let _ = std::fs::remove_dir_all(root.parent().unwrap());
}
