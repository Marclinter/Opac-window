#![cfg_attr(windows, windows_subsystem = "windows")]

fn main() {
    std::process::exit(opac_guard::main_entry(
        &std::env::args().collect::<Vec<_>>(),
    ));
}
