//! OPAC Guard: servicio Windows ligero que mantiene protegidos los artefactos
//! cifrados de Opac Window mediante handles sin compartir escritura ni borrado.
//!
//! La GUI configura el servicio y se comunica con él mediante IPC autenticado.
//! El Guard no recibe contraseñas, PINs, Vault Keys ni plaintext, y no lee el
//! contenido de los archivos protegidos.

#[cfg(all(windows, target_env = "msvc", not(target_feature = "crt-static")))]
compile_error!(
    "OPAC Guard requires the static MSVC CRT; build Windows/MSVC targets with target-feature=+crt-static"
);

use std::path::PathBuf;
use uuid::Uuid;

const GUARD_CONFIG_DOMAIN: &[u8] = b"OPAC-GUARD-CONFIG-V1";
const GUARD_UNINSTALL_DOMAIN: &[u8] = b"OPAC-GUARD-UNINSTALL-V1";

/// Construye de forma determinista el material que se firma al instalar un
/// Guard. Solo contiene identificadores publicos y rutas normalizadas.
pub fn guard_config_message(
    profile_id: Uuid,
    roots: &[PathBuf],
    public_key: &[u8; 32],
) -> Result<Vec<u8>, String> {
    if roots.is_empty() || roots.len() > 128 {
        return Err("numero de raices no valido".to_owned());
    }
    let mut normalized = Vec::with_capacity(roots.len());
    for root in roots {
        if root.as_os_str().is_empty() {
            continue;
        }
        let canonical = std::fs::canonicalize(root)
            .map_err(|error| format!("no se pudo resolver la raiz del Guard: {error}"))?;
        normalized.push(canonical);
    }
    if normalized.is_empty() || normalized.len() > 128 {
        return Err("numero de raices no valido".to_owned());
    }
    normalized.sort_by_key(|a| a.to_string_lossy().to_ascii_lowercase());
    normalized.dedup_by(|a, b| {
        a.to_string_lossy()
            .eq_ignore_ascii_case(&b.to_string_lossy())
    });
    let mut data = Vec::with_capacity(64 + normalized.len() * 64);
    data.extend_from_slice(GUARD_CONFIG_DOMAIN);
    data.extend_from_slice(profile_id.as_bytes());
    data.extend_from_slice(public_key);
    data.extend_from_slice(&(normalized.len() as u32).to_le_bytes());
    for root in normalized {
        let bytes = root.to_string_lossy().as_bytes().to_vec();
        if bytes.is_empty() || bytes.len() > 32 * 1024 {
            return Err("ruta del Guard invalida".to_owned());
        }
        data.extend_from_slice(&(bytes.len() as u32).to_le_bytes());
        data.extend_from_slice(&bytes);
    }
    Ok(data)
}

pub fn guard_config_signature(
    profile_id: Uuid,
    roots: &[PathBuf],
    private_key: &[u8; 32],
) -> Result<([u8; 32], [u8; 64]), String> {
    use ed25519_dalek::{Signer, SigningKey};
    let signing = SigningKey::from_bytes(private_key);
    let public = signing.verifying_key().to_bytes();
    let message = guard_config_message(profile_id, roots, &public)?;
    Ok((public, signing.sign(&message).to_bytes()))
}

fn guard_uninstall_message(profile_id: Uuid, nonce: &[u8; 32]) -> Vec<u8> {
    let mut data = Vec::with_capacity(GUARD_UNINSTALL_DOMAIN.len() + 48);
    data.extend_from_slice(GUARD_UNINSTALL_DOMAIN);
    data.extend_from_slice(profile_id.as_bytes());
    data.extend_from_slice(nonce);
    data
}

pub fn guard_uninstall_signature(
    profile_id: Uuid,
    private_key: &[u8; 32],
    nonce: &[u8; 32],
) -> [u8; 64] {
    use ed25519_dalek::{Signer, SigningKey};
    SigningKey::from_bytes(private_key)
        .sign(&guard_uninstall_message(profile_id, nonce))
        .to_bytes()
}

/// Indica si queda cualquier estado administrativo del Guard asociado al perfil.
pub fn guard_storage_exists(profile_id: Uuid) -> bool {
    #[cfg(windows)]
    {
        windows_guard::guard_storage_exists(profile_id)
    }
    #[cfg(not(windows))]
    {
        let _ = profile_id;
        false
    }
}

#[cfg(test)]
mod shared_guard_tests {
    use super::*;
    use ed25519_dalek::Verifier;
    use uuid::Uuid;

    #[test]
    fn guard_config_signature_roundtrip_and_tamper_detection() {
        let profile = Uuid::new_v4();
        let root = std::env::temp_dir().join(format!(
            "opac_guard_signature_roundtrip_{}",
            profile.simple()
        ));
        std::fs::create_dir_all(&root).unwrap();
        let roots = vec![root.clone()];
        let private = [42u8; 32];
        let (public, signature) = guard_config_signature(profile, &roots, &private).unwrap();
        let message = guard_config_message(profile, &roots, &public).unwrap();
        let verifier = ed25519_dalek::VerifyingKey::from_bytes(&public).unwrap();
        verifier
            .verify(&message, &ed25519_dalek::Signature::from_bytes(&signature))
            .unwrap();
        let mut tampered = message;
        tampered.push(0);
        assert!(
            verifier
                .verify(&tampered, &ed25519_dalek::Signature::from_bytes(&signature))
                .is_err()
        );
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn guard_entrypoint_requires_explicit_service_mode() {
        let args = vec!["opac_guard".to_owned()];
        #[cfg(windows)]
        assert_eq!(windows_guard::main_entry(&args), 2);
        #[cfg(not(windows))]
        assert_eq!(non_windows::main_entry(&args), 1);
    }

    #[test]
    fn guard_config_signature_uses_canonical_roots() {
        let profile = Uuid::new_v4();
        let private = [17u8; 32];
        let base = std::env::temp_dir();
        let alias = base.join(format!("opac_guard_signature_{}", profile.simple()));
        std::fs::create_dir_all(&alias).unwrap();
        let relativeish = alias.join(".");
        let (public, signature) =
            guard_config_signature(profile, &[relativeish], &private).unwrap();
        let canonical = std::fs::canonicalize(&alias).unwrap();
        let message = guard_config_message(profile, &[canonical], &public).unwrap();
        let verifier = ed25519_dalek::VerifyingKey::from_bytes(&public).unwrap();
        verifier
            .verify(&message, &ed25519_dalek::Signature::from_bytes(&signature))
            .unwrap();
        let _ = std::fs::remove_dir(&alias);
    }

    #[test]
    fn uninstall_signature_is_bound_to_profile_and_nonce() {
        let profile_a = Uuid::new_v4();
        let profile_b = Uuid::new_v4();
        let nonce = [7u8; 32];
        let private = [42u8; 32];
        let signing = ed25519_dalek::SigningKey::from_bytes(&private);
        let public = signing.verifying_key();
        let signature = guard_uninstall_signature(profile_a, &private, &nonce);
        public
            .verify(
                &guard_uninstall_message(profile_a, &nonce),
                &ed25519_dalek::Signature::from_bytes(&signature),
            )
            .unwrap();
        assert!(
            public
                .verify(
                    &guard_uninstall_message(profile_b, &nonce),
                    &ed25519_dalek::Signature::from_bytes(&signature),
                )
                .is_err()
        );
    }
}

#[cfg(windows)]
mod windows_guard {
    use ed25519_dalek::{Signature, Verifier, VerifyingKey};
    use std::fs::{self, OpenOptions};
    use std::io::{self, Write};
    use std::path::{Path, PathBuf};
    use std::process::Command;
    use std::sync::atomic::{AtomicBool, AtomicIsize, Ordering};
    use std::sync::mpsc::{self, Receiver, Sender};
    use std::thread::{self, JoinHandle};
    use std::time::{Duration, Instant};

    use uuid::Uuid;
    use windows_sys::Win32::Foundation::{
        CloseHandle, ERROR_BROKEN_PIPE, ERROR_IO_PENDING, ERROR_NO_DATA, ERROR_PIPE_CONNECTED,
        GetLastError, HANDLE, INVALID_HANDLE_VALUE, LocalFree, WAIT_OBJECT_0,
    };
    use windows_sys::Win32::Security::Authorization::{
        ConvertSidToStringSidW, ConvertStringSecurityDescriptorToSecurityDescriptorW,
        SDDL_REVISION_1,
    };
    use windows_sys::Win32::Security::{
        GetTokenInformation, SECURITY_ATTRIBUTES, TOKEN_QUERY, TOKEN_USER, TokenUser,
    };
    use windows_sys::Win32::Storage::FileSystem::{
        BY_HANDLE_FILE_INFORMATION, CreateFileW, FILE_ATTRIBUTE_REPARSE_POINT,
        FILE_FLAG_BACKUP_SEMANTICS, FILE_FLAG_FIRST_PIPE_INSTANCE, FILE_FLAG_OPEN_REPARSE_POINT,
        FILE_FLAG_OVERLAPPED, FILE_LIST_DIRECTORY, FILE_NOTIFY_CHANGE_DIR_NAME,
        FILE_NOTIFY_CHANGE_FILE_NAME, FILE_NOTIFY_CHANGE_LAST_WRITE, FILE_NOTIFY_CHANGE_SIZE,
        FILE_SHARE_DELETE, FILE_SHARE_READ, FILE_SHARE_WRITE, GetFileInformationByHandle,
        OPEN_EXISTING, PIPE_ACCESS_DUPLEX, ReadDirectoryChangesW, ReadFile,
    };
    use windows_sys::Win32::System::IO::{CancelIoEx, GetOverlappedResult, OVERLAPPED};
    use windows_sys::Win32::System::Pipes::{
        ConnectNamedPipe, CreateNamedPipeW, DisconnectNamedPipe, GetNamedPipeClientProcessId,
        PIPE_READMODE_BYTE, PIPE_REJECT_REMOTE_CLIENTS, PIPE_TYPE_BYTE, PIPE_WAIT,
    };
    use windows_sys::Win32::System::Services::{
        CloseServiceHandle, OpenSCManagerW, OpenServiceW, QueryServiceStatus,
        RegisterServiceCtrlHandlerW, SERVICE_ACCEPT_SHUTDOWN, SERVICE_ACCEPT_STOP,
        SERVICE_CONTROL_SHUTDOWN, SERVICE_CONTROL_STOP, SERVICE_QUERY_STATUS, SERVICE_RUNNING,
        SERVICE_START_PENDING, SERVICE_STATUS, SERVICE_STATUS_HANDLE, SERVICE_STOPPED,
        SERVICE_TABLE_ENTRYW, SERVICE_WIN32_OWN_PROCESS, SetServiceStatus,
        StartServiceCtrlDispatcherW,
    };
    use windows_sys::Win32::System::Threading::{
        CreateEventW, GetCurrentProcess, GetExitCodeProcess, INFINITE, OpenProcess,
        OpenProcessToken, PROCESS_QUERY_LIMITED_INFORMATION, ResetEvent, SetEvent,
        WaitForMultipleObjects,
    };

    const SERVICE_NAME_PREFIX: &str = "OpacGuard-";
    const SERVICE_DISPLAY_NAME: &str = "OPAC Guard";
    const CONFIG_MAGIC: &[u8; 5] = b"OPAG3";
    const MAX_ROOTS: usize = 128;
    const MAX_PATH_BYTES: usize = 32 * 1024;
    const MAX_SID_CHARS: usize = 184;
    const MAX_FRAME_BYTES: usize = 8 * 1024 * 1024;
    const MAX_ACTIVE_RELEASES: usize = 8;
    const _: () = assert!(MAX_ACTIVE_RELEASES > 1);

    const CMD_LOCK: u8 = 2;
    const CMD_QUIT: u8 = 3;
    const CMD_RELEASE_PATH: u8 = 4;
    const CMD_REPROTECT_PATH: u8 = 7;
    const CMD_ACK: u8 = 12;
    const CMD_NACK: u8 = 13;
    const CMD_CHALLENGE: u8 = 10;
    const CMD_AUTH: u8 = 11;
    const GUARD_IPC_DOMAIN: &[u8] = b"OPAC-GUARD-IPC-V1";

    static SERVICE_STOP_REQUESTED: AtomicBool = AtomicBool::new(false);
    static CURRENT_PIPE: AtomicIsize = AtomicIsize::new(-1);

    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub enum GuardServiceStatus {
        Missing,
        Stopped,
        Running,
        Other(u32),
        Unavailable(u32),
    }

    #[derive(Debug)]
    pub struct GuardClient {
        tx: Option<Sender<ClientCommand>>,
    }

    #[derive(Debug)]
    enum ClientCommand {
        Locked {
            response: Sender<Result<(), String>>,
        },
        ReleasePath {
            path: PathBuf,
            response: Sender<Result<(), String>>,
        },
        ReprotectPath {
            path: PathBuf,
            response: Sender<Result<(), String>>,
        },
    }

    impl GuardClient {
        pub fn start(profile_id: Uuid, _locked: bool, signing_key: [u8; 32]) -> Self {
            let (tx, rx) = mpsc::channel();
            let started = thread::Builder::new()
                .name("opac-guard-client".to_owned())
                .spawn(move || client_loop(profile_id, rx, signing_key))
                .is_ok();
            Self {
                tx: started.then_some(tx),
            }
        }

        /// Deja libre temporalmente la ruta exacta para una operacion iniciada
        /// por OPAC. Si es un archivo, solo se libera ese archivo; si es un
        /// directorio, se libera ese subarbol. Nunca se libera la raiz completa.
        pub fn set_path_in_use(&self, path: PathBuf) -> Result<(), String> {
            self.request_path_command(path)
        }

        /// Vuelve a proteger una ruta y espera confirmacion del servicio.
        pub fn set_path_protected(&self, path: PathBuf) -> Result<(), String> {
            let (response_tx, response_rx) = mpsc::channel();
            let tx = self
                .tx
                .as_ref()
                .ok_or_else(|| "el canal de OPAC Guard ya no esta disponible".to_owned())?;
            tx.send(ClientCommand::ReprotectPath {
                path,
                response: response_tx,
            })
            .map_err(|_| "no se pudo solicitar al Guard la reproteccion de la ruta".to_owned())?;
            response_rx
                .recv_timeout(Duration::from_secs(15))
                .map_err(|_| {
                    "OPAC Guard no confirmo la reproteccion de la ruta a tiempo".to_owned()
                })?
        }

        fn request_path_command(&self, path: PathBuf) -> Result<(), String> {
            let (response_tx, response_rx) = mpsc::channel();
            let tx = self
                .tx
                .as_ref()
                .ok_or_else(|| "el canal de OPAC Guard ya no esta disponible".to_owned())?;
            tx.send(ClientCommand::ReleasePath {
                path,
                response: response_tx,
            })
            .map_err(|_| "no se pudo solicitar al Guard la liberacion de la ruta".to_owned())?;
            response_rx
                .recv_timeout(Duration::from_secs(15))
                .map_err(|_| {
                    "OPAC Guard no confirmo la liberacion de la ruta a tiempo".to_owned()
                })?
        }

        pub fn set_locked(&self) -> Result<(), String> {
            let (response_tx, response_rx) = mpsc::channel();
            let tx = self
                .tx
                .as_ref()
                .ok_or_else(|| "el canal de OPAC Guard ya no esta disponible".to_owned())?;
            tx.send(ClientCommand::Locked {
                response: response_tx,
            })
            .map_err(|_| "no se pudo solicitar el rearme completo del Guard".to_owned())?;
            response_rx
                .recv_timeout(Duration::from_secs(15))
                .map_err(|_| "OPAC Guard no confirmo el rearme completo a tiempo".to_owned())?
        }

        pub fn shutdown(&mut self) {
            // No bloquear el hilo que controla la GUI esperando al cliente IPC.
            // El cierre del Sender hace que client_loop salga en cuanto termina
            // su espera actual (<= 1 s si el pipe no esta conectado, <= 500 ms
            // cuando ya esta conectado). Al cerrar la tuberia, el servicio Guard
            // interpreta la desconexion como el fin de la sesion y rearma todas
            // las excepciones. El JoinHandle se deja caer deliberadamente para
            // que la interfaz nunca quede bloqueada por un pipe detenido.
            let _ = self.tx.take();
        }
    }

    impl Drop for GuardClient {
        fn drop(&mut self) {
            self.shutdown();
        }
    }

    #[derive(Debug, Default)]
    struct InstallArgs {
        roots: Vec<PathBuf>,
        profile_id: Option<String>,
        user_sid: Option<String>,
        public_key: Option<String>,
        config_signature: Option<String>,
        uninstall_nonce: Option<String>,
        uninstall_signature: Option<String>,
        admin_result: Option<String>,
        admin_result_fallback: Option<String>,
    }

    pub fn main_entry(args: &[String]) -> i32 {
        match args.get(1).map(String::as_str) {
            Some("--service") => run_service(args),
            _ => {
                eprintln!("OPAC Guard: modo de ejecucion no disponible directamente.");
                2
            }
        }
    }

    pub fn service_status(profile_id: Uuid) -> GuardServiceStatus {
        service_status_for_profile(&profile_id)
    }

    fn request_service_stop() {
        SERVICE_STOP_REQUESTED.store(true, Ordering::SeqCst);
        let raw = CURRENT_PIPE.load(Ordering::SeqCst);
        if raw != -1 && raw != 0 {
            unsafe {
                let _ = DisconnectNamedPipe(raw as HANDLE);
            }
        }
    }

    fn service_status_for_profile(profile_id: &Uuid) -> GuardServiceStatus {
        const ERROR_SERVICE_DOES_NOT_EXIST_CODE: u32 = 1060;

        unsafe {
            let manager = OpenSCManagerW(
                std::ptr::null(),
                std::ptr::null(),
                windows_sys::Win32::System::Services::SC_MANAGER_CONNECT,
            );
            if manager.is_null() {
                return GuardServiceStatus::Unavailable(GetLastError());
            }

            let name = wide(&service_name_for_profile(profile_id));
            let service = OpenServiceW(manager, name.as_ptr(), SERVICE_QUERY_STATUS);
            if service.is_null() {
                let error = GetLastError();
                CloseServiceHandle(manager);
                if error == ERROR_SERVICE_DOES_NOT_EXIST_CODE {
                    return GuardServiceStatus::Missing;
                }
                return GuardServiceStatus::Unavailable(error);
            }

            let mut status = SERVICE_STATUS::default();
            let ok = QueryServiceStatus(service, &mut status);
            let error = if ok == 0 { Some(GetLastError()) } else { None };
            CloseServiceHandle(service);
            CloseServiceHandle(manager);

            if let Some(error) = error {
                return GuardServiceStatus::Unavailable(error);
            }
            if status.dwCurrentState == SERVICE_RUNNING {
                GuardServiceStatus::Running
            } else if status.dwCurrentState == SERVICE_STOPPED {
                GuardServiceStatus::Stopped
            } else {
                GuardServiceStatus::Other(status.dwCurrentState)
            }
        }
    }

    pub fn install_service_elevated(
        profile_id: Uuid,
        roots: &[PathBuf],
        public_key: [u8; 32],
        config_signature: [u8; 64],
    ) -> Result<(), String> {
        let exe = std::env::current_exe()
            .map_err(|error| format!("no se pudo determinar el ejecutable de OPAC: {error}"))?;
        let user_sid = current_user_sid()?;
        let result_path = admin_result_path(profile_id, "install")?;
        let fallback_path = admin_result_fallback_path(profile_id, "install");
        prepare_admin_result_fallback(&fallback_path)?;
        let mut args = vec![
            "--install-guard".to_owned(),
            "--profile-id".to_owned(),
            profile_id.to_string(),
            "--user-sid".to_owned(),
            user_sid,
            "--public-key".to_owned(),
            hex_encode(&public_key),
            "--config-signature".to_owned(),
            hex_encode(&config_signature),
            "--admin-result".to_owned(),
            result_path.to_string_lossy().into_owned(),
            "--admin-result-fallback".to_owned(),
            fallback_path.to_string_lossy().into_owned(),
        ];
        for root in roots {
            args.push("--root".to_owned());
            args.push(root.to_string_lossy().into_owned());
        }
        let exit_code = match run_elevated(&exe, &args, Duration::from_secs(60)) {
            Ok(code) => code,
            Err(error) => {
                let _ = fs::remove_file(&result_path);
                return Err(error);
            }
        };
        let result = read_admin_result(&result_path).or_else(|| read_admin_result(&fallback_path));
        let _ = fs::remove_file(&result_path);
        let _ = fs::remove_file(&fallback_path);
        if exit_code != 0 {
            return Err(result.unwrap_or_else(|| {
                format!("el instalador elevado de OPAC Guard terminó con código {exit_code}")
            }));
        }
        wait_for_service_state(profile_id, GuardServiceStatus::Running, 15)
    }

    pub fn current_user_sid() -> Result<String, String> {
        unsafe {
            let mut token: HANDLE = std::ptr::null_mut();
            if OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &mut token) == 0 {
                return Err(format!(
                    "no se pudo abrir el token del usuario: {}",
                    io::Error::last_os_error()
                ));
            }

            let mut needed = 0u32;
            let _ = GetTokenInformation(token, TokenUser, std::ptr::null_mut(), 0, &mut needed);
            if needed == 0 {
                CloseHandle(token);
                return Err(format!(
                    "no se pudo consultar el SID del usuario: {}",
                    io::Error::last_os_error()
                ));
            }

            let words = (needed as usize).div_ceil(std::mem::size_of::<usize>());
            let mut buffer = vec![0usize; words.max(1)];
            if GetTokenInformation(
                token,
                TokenUser,
                buffer.as_mut_ptr().cast(),
                needed,
                &mut needed,
            ) == 0
            {
                CloseHandle(token);
                return Err(format!(
                    "no se pudo leer el SID del usuario: {}",
                    io::Error::last_os_error()
                ));
            }

            let token_user = &*buffer.as_ptr().cast::<TOKEN_USER>();
            if token_user.User.Sid.is_null() {
                CloseHandle(token);
                return Err("el token del usuario no contiene un SID valido".to_owned());
            }

            let mut text = std::ptr::null_mut();
            if ConvertSidToStringSidW(token_user.User.Sid, &mut text) == 0 || text.is_null() {
                CloseHandle(token);
                return Err(format!(
                    "no se pudo convertir el SID del usuario: {}",
                    io::Error::last_os_error()
                ));
            }

            let mut len = 0usize;
            while *text.add(len) != 0 && len <= MAX_SID_CHARS {
                len += 1;
            }
            let sid = if len <= MAX_SID_CHARS {
                String::from_utf16_lossy(std::slice::from_raw_parts(text, len))
            } else {
                String::new()
            };
            LocalFree(text.cast());
            CloseHandle(token);

            if sid.starts_with("S-1-") {
                Ok(sid)
            } else {
                Err("el SID del usuario no tiene un formato valido".to_owned())
            }
        }
    }

    pub fn uninstall_service_elevated(
        profile_id: Uuid,
        private_key: [u8; 32],
    ) -> Result<(), String> {
        let exe = std::env::current_exe()
            .map_err(|error| format!("no se pudo determinar el ejecutable de OPAC: {error}"))?;
        let nonce = random_nonce();
        let signature = super::guard_uninstall_signature(profile_id, &private_key, &nonce);
        let result_path = admin_result_path(profile_id, "uninstall")?;
        let fallback_path = admin_result_fallback_path(profile_id, "uninstall");
        prepare_admin_result_fallback(&fallback_path)?;
        let user_sid = current_user_sid()?;
        let exit_code = match run_elevated(
            &exe,
            &[
                "--uninstall-guard".to_owned(),
                "--profile-id".to_owned(),
                profile_id.to_string(),
                "--user-sid".to_owned(),
                user_sid,
                "--uninstall-nonce".to_owned(),
                hex_encode(&nonce),
                "--uninstall-signature".to_owned(),
                hex_encode(&signature),
                "--admin-result".to_owned(),
                result_path.to_string_lossy().into_owned(),
                "--admin-result-fallback".to_owned(),
                fallback_path.to_string_lossy().into_owned(),
            ],
            Duration::from_secs(180),
        ) {
            Ok(code) => code,
            Err(error) => {
                let _ = fs::remove_file(&result_path);
                return Err(error);
            }
        };
        let result = read_admin_result(&result_path).or_else(|| read_admin_result(&fallback_path));
        let _ = fs::remove_file(&result_path);
        let _ = fs::remove_file(&fallback_path);
        if exit_code != 0 {
            return Err(result.unwrap_or_else(|| {
                format!("el desinstalador elevado de OPAC Guard terminó con código {exit_code}")
            }));
        }
        wait_for_service_state(profile_id, GuardServiceStatus::Missing, 15)
    }

    #[repr(C)]
    struct ShellExecuteInfoW {
        cb_size: u32,
        f_mask: u32,
        hwnd: *mut std::ffi::c_void,
        lp_verb: *const u16,
        lp_file: *const u16,
        lp_parameters: *const u16,
        lp_directory: *const u16,
        n_show: i32,
        h_inst_app: *mut std::ffi::c_void,
        lp_id_list: *mut std::ffi::c_void,
        lp_class: *const u16,
        hkey_class: *mut std::ffi::c_void,
        dw_hot_key: u32,
        h_icon_or_monitor: *mut std::ffi::c_void,
        h_process: HANDLE,
    }

    const SEE_MASK_NOCLOSEPROCESS: u32 = 0x00000040;
    const SEE_MASK_NOASYNC: u32 = 0x00000100;
    const SW_SHOWNORMAL: i32 = 1;
    const STILL_ACTIVE: u32 = 259;

    #[link(name = "shell32")]
    unsafe extern "system" {
        fn ShellExecuteExW(lp_exec_info: *mut ShellExecuteInfoW) -> i32;
    }

    fn run_elevated(exe: &Path, args: &[String], max_duration: Duration) -> Result<i32, String> {
        let verb = wide("runas");
        let file = wide(&exe.to_string_lossy());
        let parameters = args
            .iter()
            .map(|arg| windows_quote_arg(arg))
            .collect::<Vec<_>>()
            .join(" ");
        let parameters = wide(&parameters);
        let mut info = ShellExecuteInfoW {
            cb_size: std::mem::size_of::<ShellExecuteInfoW>() as u32,
            f_mask: SEE_MASK_NOCLOSEPROCESS | SEE_MASK_NOASYNC,
            hwnd: std::ptr::null_mut(),
            lp_verb: verb.as_ptr(),
            lp_file: file.as_ptr(),
            lp_parameters: parameters.as_ptr(),
            lp_directory: std::ptr::null(),
            n_show: SW_SHOWNORMAL,
            h_inst_app: std::ptr::null_mut(),
            lp_id_list: std::ptr::null_mut(),
            lp_class: std::ptr::null(),
            hkey_class: std::ptr::null_mut(),
            dw_hot_key: 0,
            h_icon_or_monitor: std::ptr::null_mut(),
            h_process: std::ptr::null_mut(),
        };
        let launched = unsafe { ShellExecuteExW(&mut info) };
        if launched == 0 {
            return Err(format!(
                "Windows no pudo iniciar la operación elevada: {}",
                io::Error::last_os_error()
            ));
        }
        if info.h_process.is_null() || info.h_process == INVALID_HANDLE_VALUE {
            return Err("Windows inició la operación elevada pero no devolvió un identificador de proceso; no se puede confirmar el resultado.".to_owned());
        }

        let deadline = Instant::now() + max_duration;
        loop {
            let mut exit_code = 0u32;
            let ok = unsafe { GetExitCodeProcess(info.h_process, &mut exit_code) };
            if ok == 0 {
                unsafe {
                    CloseHandle(info.h_process);
                }
                return Err(format!(
                    "no se pudo consultar el resultado de la operación elevada: {}",
                    io::Error::last_os_error()
                ));
            }
            if exit_code != STILL_ACTIVE {
                unsafe {
                    CloseHandle(info.h_process);
                }
                return Ok(exit_code as i32);
            }
            if Instant::now() >= deadline {
                unsafe {
                    CloseHandle(info.h_process);
                }
                return Err(format!(
                    "Windows no terminó la operación elevada dentro del tiempo esperado (más de {} segundos).",
                    max_duration.as_secs()
                ));
            }
            thread::sleep(Duration::from_millis(100));
        }
    }

    fn admin_result_path(profile_id: Uuid, operation: &str) -> Result<PathBuf, String> {
        Ok(guard_admin_root()?.join("results").join(format!(
            "opac_guard_{operation}_{}_{}.result",
            profile_id.simple(),
            Uuid::new_v4().simple()
        )))
    }

    // Canal de diagnostico de respaldo creado por el proceso no elevado.
    // Su contenido no se usa para decidir si el Guard se instalo/desinstalo;
    // el codigo de salida y el estado real del servicio son la autoridad.
    fn admin_result_fallback_path(profile_id: Uuid, operation: &str) -> PathBuf {
        std::env::temp_dir().join(format!(
            "opac_guard_{operation}_{}_{}.result",
            profile_id.simple(),
            Uuid::new_v4().simple()
        ))
    }

    fn prepare_admin_result_fallback(path: &Path) -> Result<(), String> {
        let filename = path
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or_default();
        if !path.is_absolute()
            || !filename.starts_with("opac_guard_")
            || !filename.ends_with(".result")
        {
            return Err("la ruta de diagnostico de respaldo no es valida".to_owned());
        }
        if path_entry_exists(path).map_err(|error| {
            format!("no se pudo inspeccionar el diagnostico de respaldo: {error}")
        })? {
            ensure_safe_file(path).map_err(|error| {
                format!("el diagnostico de respaldo existente no es seguro: {error}")
            })?;
            remove_file_if_exists(path).map_err(|error| {
                format!("no se pudo limpiar el diagnostico de respaldo anterior: {error}")
            })?;
        }
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(path)
            .map_err(|error| format!("no se pudo crear el diagnostico de respaldo: {error}"))?;
        file.write_all(b"PENDING").map_err(|error| {
            format!("no se pudo inicializar el diagnostico de respaldo: {error}")
        })?;
        file.flush()
            .map_err(|error| format!("no se pudo finalizar el diagnostico de respaldo: {error}"))?;
        file.sync_all().map_err(|error| {
            format!("no se pudo sincronizar el diagnostico de respaldo: {error}")
        })?;
        Ok(())
    }

    fn write_admin_result_fallback(path: Option<&str>, result: Result<(), &str>) {
        let Some(path) = path else {
            return;
        };
        let path = Path::new(path);
        let filename = path
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or_default();
        if !path.is_absolute()
            || !filename.starts_with("opac_guard_")
            || !filename.ends_with(".result")
        {
            return;
        }
        let Ok(metadata) = fs::symlink_metadata(path) else {
            return;
        };
        let attrs = std::os::windows::fs::MetadataExt::file_attributes(&metadata);
        if metadata.file_type().is_symlink()
            || attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0
            || !metadata.is_file()
        {
            return;
        }
        let text = match result {
            Ok(()) => "OK".to_owned(),
            Err(error) => format!("ERROR:{error}"),
        };
        if let Ok(mut file) = OpenOptions::new().write(true).truncate(true).open(path) {
            let _ = file.write_all(text.as_bytes());
            let _ = file.flush();
            let _ = file.sync_all();
        }
    }

    fn read_admin_result(path: &Path) -> Option<String> {
        let text = fs::read_to_string(path).ok()?;
        let text = text.trim();
        if text.is_empty() || text == "OK" || text == "PENDING" {
            None
        } else if let Some(message) = text.strip_prefix("ERROR:") {
            Some(message.trim().to_owned())
        } else {
            Some(text.to_owned())
        }
    }

    fn prepare_admin_result_storage(path: &Path, user_sid: &str) -> Result<(), String> {
        if !user_sid.starts_with("S-1-") || user_sid.len() > MAX_SID_CHARS {
            return Err(
                "el SID del usuario para el resultado administrativo no es valido".to_owned(),
            );
        }
        let results_dir = guard_admin_root()?.join("results");
        fs::create_dir_all(&results_dir).map_err(|error| {
            format!("no se pudo crear el almacenamiento de resultados administrativos: {error}")
        })?;
        let guard_root = guard_admin_root()?;
        for candidate in [guard_root.clone(), results_dir.clone()] {
            let metadata = fs::symlink_metadata(&candidate).map_err(|error| {
                format!("no se pudo inspeccionar el almacenamiento administrativo: {error}")
            })?;
            let attrs = std::os::windows::fs::MetadataExt::file_attributes(&metadata);
            if metadata.file_type().is_symlink()
                || attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0
                || !metadata.is_dir()
            {
                return Err("el almacenamiento de resultados administrativos contiene un punto de reanalisis no permitido".to_owned());
            }
            secure_guard_storage(&candidate).map_err(|error| {
                format!(
                    "no se pudieron asegurar las ACL del almacenamiento administrativo: {error}"
                )
            })?;
        }
        // La raiz `guard` permanece inaccesible al usuario, pero necesitamos
        // permitirle atravesarla para poder leer el resultado de su propia
        // operacion elevada. No concedemos listado ni escritura en esa raiz.
        let traverse = hidden_command(system32_tool("icacls.exe"))
            .arg(&guard_root)
            .args(["/grant", &format!("*{user_sid}:(X)")])
            .status()
            .map_err(|error| {
                format!(
                    "no se pudo conceder acceso de recorrido al resultado administrativo: {error}"
                )
            })?;
        if !traverse.success() {
            return Err(
                "no se pudo conceder acceso de recorrido al resultado administrativo".to_owned(),
            );
        }
        let dir_read = hidden_command(system32_tool("icacls.exe"))
            .arg(&results_dir)
            .args(["/grant", &format!("*{user_sid}:(RX)")])
            .status()
            .map_err(|error| format!("no se pudo conceder lectura del directorio de resultados administrativos: {error}"))?;
        if !dir_read.success() {
            return Err(
                "no se pudo conceder lectura del directorio de resultados administrativos"
                    .to_owned(),
            );
        }
        let parent = path.parent().ok_or_else(|| {
            "la ruta del resultado administrativo no tiene directorio padre".to_owned()
        })?;
        let parent_canonical = fs::canonicalize(parent).map_err(|error| {
            format!("no se pudo resolver el directorio del resultado administrativo: {error}")
        })?;
        let results_canonical = fs::canonicalize(&results_dir).map_err(|error| {
            format!("no se pudo resolver el almacenamiento de resultados administrativos: {error}")
        })?;
        if !path_eq(&parent_canonical, &results_canonical) {
            return Err(
                "la ruta del resultado administrativo queda fuera del almacenamiento protegido"
                    .to_owned(),
            );
        }
        let filename = path
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or_default();
        if !filename.starts_with("opac_guard_") || !filename.ends_with(".result") {
            return Err("el nombre del resultado administrativo no es valido".to_owned());
        }
        if path_entry_exists(path).unwrap_or(false) {
            ensure_safe_file(path).map_err(|error| {
                format!("el resultado administrativo existente no es seguro: {error}")
            })?;
            remove_file_if_exists(path).map_err(|error| {
                format!("no se pudo reemplazar el resultado administrativo anterior: {error}")
            })?;
        }
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(path)
            .map_err(|error| {
                format!("no se pudo crear el resultado administrativo protegido: {error}")
            })?;
        file.write_all(b"PENDING").map_err(|error| {
            format!("no se pudo inicializar el resultado administrativo: {error}")
        })?;
        file.flush().map_err(|error| {
            format!("no se pudo finalizar el resultado administrativo: {error}")
        })?;
        file.sync_all().map_err(|error| {
            format!("no se pudo sincronizar el resultado administrativo: {error}")
        })?;
        drop(file);
        secure_guard_file(path).map_err(|error| {
            format!("no se pudieron asegurar las ACL del resultado administrativo: {error}")
        })?;
        let grant = hidden_command(system32_tool("icacls.exe"))
            .arg(path)
            .args(["/grant", &format!("*{user_sid}:(R)")])
            .status()
            .map_err(|error| {
                format!(
                    "no se pudo conceder lectura al usuario del resultado administrativo: {error}"
                )
            })?;
        if !grant.success() {
            return Err(
                "no se pudo conceder lectura al usuario del resultado administrativo".to_owned(),
            );
        }
        Ok(())
    }

    fn write_admin_result(path: Option<&str>, user_sid: Option<&str>, result: Result<(), &str>) {
        let (Some(path), Some(user_sid)) = (path, user_sid) else {
            return;
        };
        let path = Path::new(path);
        if prepare_admin_result_storage(path, user_sid).is_err() {
            return;
        }
        let text = match result {
            Ok(()) => "OK".to_owned(),
            Err(error) => format!("ERROR:{error}"),
        };
        let Ok(mut file) = OpenOptions::new().write(true).truncate(true).open(path) else {
            return;
        };
        let _ = file.write_all(text.as_bytes());
        let _ = file.flush();
        let _ = file.sync_all();
    }

    fn wait_for_service_state(
        profile_id: Uuid,
        expected: GuardServiceStatus,
        seconds: u64,
    ) -> Result<(), String> {
        let attempts = seconds.saturating_mul(20).max(1);
        let mut last = GuardServiceStatus::Missing;
        for _ in 0..attempts {
            last = service_status_for_profile(&profile_id);
            if last == expected {
                return Ok(());
            }
            thread::sleep(Duration::from_millis(50));
        }
        Err(match expected {
            GuardServiceStatus::Running => match last {
                GuardServiceStatus::Missing => {
                    "El Guard elevado terminó, pero Windows no muestra el servicio instalado."
                        .to_owned()
                }
                GuardServiceStatus::Stopped => {
                    let details = service_stop_details(&profile_id)
                        .map(|(win32, specific)| {
                            format!(" (Win32={}, específico={})", win32, specific)
                        })
                        .unwrap_or_default();
                    format!(
                        "El Guard se instaló, pero el servicio quedó detenido{}. Revisa el error del servicio en Administración de servicios de Windows.",
                        details
                    )
                }
                GuardServiceStatus::Other(state) => format!(
                    "El Guard se instaló, pero el servicio no llegó a ejecutarse (estado {state})."
                ),
                GuardServiceStatus::Unavailable(error) => format!(
                    "Windows no permitió consultar el servicio de OPAC Guard (error Win32 {error})."
                ),
                GuardServiceStatus::Running => unreachable!(),
            },
            GuardServiceStatus::Missing => format!(
                "El servicio de OPAC Guard no terminó de desinstalarse (estado final: {last:?})."
            ),
            GuardServiceStatus::Unavailable(error) => format!(
                "Windows no permitió consultar el servicio de OPAC Guard (error Win32 {error})."
            ),
            _ => format!("Windows no alcanzó el estado solicitado para OPAC Guard: {expected:?}."),
        })
    }

    fn service_stop_details(profile_id: &Uuid) -> Option<(u32, u32)> {
        unsafe {
            let manager = OpenSCManagerW(
                std::ptr::null(),
                std::ptr::null(),
                windows_sys::Win32::System::Services::SC_MANAGER_CONNECT,
            );
            if manager.is_null() {
                return None;
            }
            let name = wide(&service_name_for_profile(profile_id));
            let service = OpenServiceW(manager, name.as_ptr(), SERVICE_QUERY_STATUS);
            if service.is_null() {
                CloseServiceHandle(manager);
                return None;
            }
            let mut status = SERVICE_STATUS::default();
            let ok = QueryServiceStatus(service, &mut status);
            CloseServiceHandle(service);
            CloseServiceHandle(manager);
            if ok == 0 || status.dwCurrentState != SERVICE_STOPPED {
                None
            } else {
                Some((status.dwWin32ExitCode, status.dwServiceSpecificExitCode))
            }
        }
    }

    pub fn handle_embedded_admin_command(args: &[String], guard_bytes: &[u8]) -> Option<i32> {
        match args.get(1).map(String::as_str) {
            Some("--install-guard") => {
                let parsed = parse_install_args(&args[2..]);
                let profile_id = parsed.profile_id.as_deref().and_then(parse_profile_id);
                match profile_id {
                    Some(profile_id) => {
                        let user_sid = parsed.user_sid.clone();
                        match install_service_from_embedded(
                            guard_bytes,
                            parsed.roots,
                            profile_id,
                            user_sid,
                            parsed.public_key,
                            parsed.config_signature,
                        ) {
                            Ok(()) => {
                                write_admin_result(
                                    parsed.admin_result.as_deref(),
                                    parsed.user_sid.as_deref(),
                                    Ok(()),
                                );
                                write_admin_result_fallback(
                                    parsed.admin_result_fallback.as_deref(),
                                    Ok(()),
                                );
                                Some(0)
                            }
                            Err(error) => {
                                write_admin_result(
                                    parsed.admin_result.as_deref(),
                                    parsed.user_sid.as_deref(),
                                    Err(error.as_str()),
                                );
                                write_admin_result_fallback(
                                    parsed.admin_result_fallback.as_deref(),
                                    Err(error.as_str()),
                                );
                                eprintln!("OPAC Guard: {error}");
                                Some(1)
                            }
                        }
                    }
                    None => Some(2),
                }
            }
            Some("--uninstall-guard") => {
                let parsed = parse_install_args(&args[2..]);
                let profile_id = parsed.profile_id.as_deref().and_then(parse_profile_id);
                match profile_id {
                    Some(profile_id) => match uninstall_service(
                        profile_id,
                        parsed.uninstall_nonce,
                        parsed.uninstall_signature,
                    ) {
                        Ok(()) => {
                            write_admin_result(
                                parsed.admin_result.as_deref(),
                                parsed.user_sid.as_deref(),
                                Ok(()),
                            );
                            write_admin_result_fallback(
                                parsed.admin_result_fallback.as_deref(),
                                Ok(()),
                            );
                            Some(0)
                        }
                        Err(error) => {
                            write_admin_result(
                                parsed.admin_result.as_deref(),
                                parsed.user_sid.as_deref(),
                                Err(error.as_str()),
                            );
                            write_admin_result_fallback(
                                parsed.admin_result_fallback.as_deref(),
                                Err(error.as_str()),
                            );
                            eprintln!("OPAC Guard: {error}");
                            Some(1)
                        }
                    },
                    None => Some(2),
                }
            }
            _ => None,
        }
    }

    #[repr(C)]
    #[derive(Clone, Copy)]
    struct Guid {
        data1: u32,
        data2: u16,
        data3: u16,
        data4: [u8; 8],
    }

    // FOLDERID_ProgramData from Known Folders.
    const FOLDERID_PROGRAM_DATA: Guid = Guid {
        data1: 0x62AB5D82,
        data2: 0xFDC1,
        data3: 0x4DC3,
        data4: [0xA9, 0xDD, 0x07, 0x0D, 0x1D, 0x49, 0x5D, 0x97],
    };
    const COINIT_MULTITHREADED: u32 = 0x0;
    const RPC_E_CHANGED_MODE: i32 = -2147417850i32;

    #[link(name = "shell32")]
    unsafe extern "system" {
        fn SHGetKnownFolderPath(
            rfid: *const Guid,
            flags: u32,
            token: HANDLE,
            path: *mut *mut u16,
        ) -> i32;
    }

    #[link(name = "ole32")]
    unsafe extern "system" {
        fn CoInitializeEx(reserved: *mut std::ffi::c_void, coinit: u32) -> i32;
        fn CoUninitialize();
        fn CoTaskMemFree(ptr: *mut std::ffi::c_void);
    }

    #[link(name = "kernel32")]
    unsafe extern "system" {
        fn GetSystemDirectoryW(buffer: *mut u16, size: u32) -> u32;
    }

    fn known_folder_program_data() -> Result<PathBuf, String> {
        unsafe {
            let init_result = CoInitializeEx(std::ptr::null_mut(), COINIT_MULTITHREADED);
            if init_result < 0 && init_result != RPC_E_CHANGED_MODE {
                return Err(format!(
                    "no se pudo inicializar COM para localizar ProgramData (HRESULT 0x{:08X})",
                    init_result as u32
                ));
            }
            let should_uninitialize = init_result >= 0;

            let mut raw = std::ptr::null_mut();
            let hr =
                SHGetKnownFolderPath(&FOLDERID_PROGRAM_DATA, 0, std::ptr::null_mut(), &mut raw);
            if hr < 0 || raw.is_null() {
                if !raw.is_null() {
                    CoTaskMemFree(raw.cast());
                }
                if should_uninitialize {
                    CoUninitialize();
                }
                return Err(format!(
                    "no se pudo determinar la carpeta ProgramData de Windows (HRESULT 0x{:08X})",
                    hr as u32
                ));
            }

            let mut len = 0usize;
            while *raw.add(len) != 0 {
                len += 1;
                if len > 32768 {
                    CoTaskMemFree(raw.cast());
                    if should_uninitialize {
                        CoUninitialize();
                    }
                    return Err("la ruta de ProgramData supera el limite admitido".to_owned());
                }
            }
            let text = String::from_utf16_lossy(std::slice::from_raw_parts(raw, len));
            CoTaskMemFree(raw.cast());
            if should_uninitialize {
                CoUninitialize();
            }
            if text.is_empty() {
                return Err("Windows devolvio una ruta ProgramData vacia".to_owned());
            }
            Ok(PathBuf::from(text))
        }
    }

    fn guard_admin_root() -> Result<PathBuf, String> {
        known_folder_program_data().map(|root| root.join("OpacWindow").join("guard"))
    }

    fn guard_binary_path(profile_id: &Uuid) -> Result<PathBuf, String> {
        Ok(guard_admin_root()?
            .join("profiles")
            .join(profile_id.simple().to_string())
            .join("opac_guard.exe"))
    }

    pub(super) fn guard_storage_exists(profile_id: Uuid) -> bool {
        let Ok(root) = guard_admin_root()
            .map(|base| base.join("profiles").join(profile_id.simple().to_string()))
        else {
            return true;
        };
        if path_entry_exists(&root).unwrap_or(true) {
            return true;
        }
        !matches!(
            service_status_for_profile(&profile_id),
            GuardServiceStatus::Missing
        )
    }

    fn validate_roots_for_profile(profile_id: &Uuid, roots: &[PathBuf]) -> Result<(), String> {
        if roots.len() != 1 {
            return Err(
                "OPAC Guard debe proteger exactamente la raiz del perfil de OPAC que lo activo"
                    .to_owned(),
            );
        }
        let root = &roots[0];
        let metadata = fs::symlink_metadata(root)
            .map_err(|error| format!("la raiz del perfil no se puede inspeccionar: {error}"))?;
        let attrs = std::os::windows::fs::MetadataExt::file_attributes(&metadata);
        if metadata.file_type().is_symlink()
            || attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0
            || !metadata.is_dir()
        {
            return Err("la raiz del perfil no es un directorio normal de Windows".to_owned());
        }
        let canonical = fs::canonicalize(root)
            .map_err(|error| format!("no se pudo resolver la raiz del perfil: {error}"))?;
        let expected_leaf = profile_id.simple().to_string();
        let actual_leaf = canonical
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or_default();
        let parent_name = canonical
            .parent()
            .and_then(Path::file_name)
            .and_then(|name| name.to_str())
            .unwrap_or_default();
        if !actual_leaf.eq_ignore_ascii_case(&expected_leaf)
            || !parent_name.eq_ignore_ascii_case("profiles")
        {
            return Err(format!(
                "la raiz del Guard no coincide con la estructura del perfil {}: {}",
                profile_id,
                root.display()
            ));
        }
        Ok(())
    }

    fn validate_configured_roots(roots: &[PathBuf]) -> Result<(), String> {
        if roots.len() != 1 || roots[0].as_os_str().is_empty() {
            return Err(
                "la configuracion del Guard debe contener exactamente una raiz de perfil"
                    .to_owned(),
            );
        }
        Ok(())
    }

    fn install_service_from_embedded(
        guard_bytes: &[u8],
        roots: Vec<PathBuf>,
        profile_id: Uuid,
        user_sid: Option<String>,
        public_key_hex: Option<String>,
        config_signature_hex: Option<String>,
    ) -> Result<(), String> {
        if guard_bytes.len() < 2 || &guard_bytes[..2] != b"MZ" {
            return Err("el ejecutable OPAC Guard embebido no es valido".to_owned());
        }
        let user_sid = user_sid
            .filter(|sid| sid.starts_with("S-1-") && sid.len() <= MAX_SID_CHARS)
            .ok_or_else(|| {
                "falta un SID de Windows valido para asegurar el canal del Guard".to_owned()
            })?;
        let roots = canonicalize_install_roots(roots)
            .map_err(|error| format!("[validacion de rutas] {error}"))?;
        validate_roots_for_profile(&profile_id, &roots)
            .map_err(|error| format!("[validacion del perfil] {error}"))?;
        let public_key: [u8; 32] = decode_hex_array(
            public_key_hex
                .as_deref()
                .ok_or_else(|| "falta la clave publica de OPAC Guard".to_owned())?,
        )?;
        let config_signature: [u8; 64] = decode_hex_array(
            config_signature_hex
                .as_deref()
                .ok_or_else(|| "falta la firma de configuracion de OPAC Guard".to_owned())?,
        )?;

        let service_name = service_name_for_profile(&profile_id);
        let guard_path = guard_binary_path(&profile_id)?;
        let Some(guard_parent) = guard_path.parent() else {
            return Err("no se pudo determinar el directorio del ejecutable del Guard".to_owned());
        };
        secure_guard_storage_tree(guard_parent).map_err(|error| {
            format!(
                "[almacenamiento administrativo] no se pudieron asegurar las ACL del Guard: {error}"
            )
        })?;

        remove_existing_service(&profile_id, &service_name)
            .map_err(|error| format!("[servicio anterior] {error}"))?;

        let temp = guard_path.with_extension("exe.new");
        remove_file_if_exists(&temp).map_err(|error| {
            format!("no se pudo limpiar el ejecutable temporal anterior del Guard: {error}")
        })?;
        {
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&temp)
                .map_err(|error| format!("no se pudo materializar OPAC Guard: {error}"))?;
            file.write_all(guard_bytes)
                .map_err(|error| format!("no se pudo escribir OPAC Guard: {error}"))?;
            file.flush().map_err(|error| {
                format!("no se pudo finalizar la escritura de OPAC Guard: {error}")
            })?;
            file.sync_all()
                .map_err(|error| format!("no se pudo sincronizar OPAC Guard: {error}"))?;
        }
        remove_file_if_exists(&guard_path).map_err(|error| {
            format!("no se pudo reemplazar el ejecutable anterior de OPAC Guard: {error}")
        })?;
        fs::rename(&temp, &guard_path)
            .map_err(|error| format!("no se pudo publicar OPAC Guard: {error}"))?;

        save_config(&profile_id, &roots, public_key, config_signature).map_err(|error| {
            format!("[configuracion] no se pudo guardar la configuracion del Guard: {error}")
        })?;

        let bin_path = format!(
            "\"{}\" --service --profile-id {} --user-sid {}",
            guard_path.display(),
            profile_id,
            user_sid
        );
        let create_args = vec![
            "create".to_owned(),
            service_name.clone(),
            "binPath=".to_owned(),
            bin_path,
            "start=".to_owned(),
            "auto".to_owned(),
            "DisplayName=".to_owned(),
            SERVICE_DISPLAY_NAME.to_owned(),
            "obj=".to_owned(),
            "LocalSystem".to_owned(),
        ];
        run_sc_args(&create_args)
            .map_err(|error| format!("[SCM] no se pudo crear el servicio: {error}"))?;

        let _ = sc_command([
            "description",
            &service_name,
            "Protege exclusivamente los archivos cifrados del usuario de OPAC que activo este Guard.",
        ]);
        let _ = sc_command([
            "failure",
            &service_name,
            "reset=",
            "86400",
            "actions=",
            "restart/5000/restart/15000/restart/60000",
        ]);
        run_sc_args(&["start".to_owned(), service_name]).map_err(|error| {
            format!(
                "[arranque del servicio] el servicio se instalo pero no pudo iniciarse: {error}"
            )
        })?;
        Ok(())
    }

    fn remove_existing_service(profile_id: &Uuid, service_name: &str) -> Result<(), String> {
        let initial = service_status_for_profile(profile_id);
        match initial {
            GuardServiceStatus::Missing => return Ok(()),
            GuardServiceStatus::Unavailable(error) => {
                return Err(format!(
                    "Windows no puede consultar el servicio anterior de OPAC Guard (error Win32 {error})."
                ));
            }
            GuardServiceStatus::Running | GuardServiceStatus::Other(_) => {
                if !sc_command(["stop", service_name]) {
                    let state = service_status_for_profile(profile_id);
                    if !matches!(
                        state,
                        GuardServiceStatus::Stopped | GuardServiceStatus::Missing
                    ) {
                        return Err(format!(
                            "Windows no pudo detener el servicio anterior de OPAC Guard: {state:?}."
                        ));
                    }
                }
            }
            GuardServiceStatus::Stopped => {}
        }

        for _ in 0..300 {
            match service_status_for_profile(profile_id) {
                GuardServiceStatus::Missing | GuardServiceStatus::Stopped => break,
                GuardServiceStatus::Unavailable(error) => {
                    return Err(format!(
                        "Windows no puede comprobar la detencion del servicio anterior de OPAC Guard (error Win32 {error})."
                    ));
                }
                GuardServiceStatus::Running | GuardServiceStatus::Other(_) => {
                    thread::sleep(Duration::from_millis(100));
                }
            }
        }

        let state = service_status_for_profile(profile_id);
        if matches!(
            state,
            GuardServiceStatus::Running | GuardServiceStatus::Other(_)
        ) {
            return Err(format!(
                "El servicio anterior de OPAC Guard sigue activo y no puede sustituirse: {state:?}."
            ));
        }
        if let GuardServiceStatus::Unavailable(error) = state {
            return Err(format!(
                "Windows no puede gestionar el servicio anterior de OPAC Guard (error Win32 {error})."
            ));
        }

        if !matches!(state, GuardServiceStatus::Missing) {
            match run_sc_args(&["delete".to_owned(), service_name.to_owned()]) {
                Ok(()) => {}
                Err(error) => {
                    if !matches!(
                        service_status_for_profile(profile_id),
                        GuardServiceStatus::Missing
                    ) {
                        return Err(format!(
                            "Windows no pudo eliminar el servicio anterior de OPAC Guard: {error}"
                        ));
                    }
                }
            }
        }

        for _ in 0..300 {
            match service_status_for_profile(profile_id) {
                GuardServiceStatus::Missing => return Ok(()),
                GuardServiceStatus::Unavailable(error) => {
                    return Err(format!(
                        "Windows no puede comprobar la eliminacion del servicio anterior de OPAC Guard (error Win32 {error})."
                    ));
                }
                GuardServiceStatus::Stopped
                | GuardServiceStatus::Running
                | GuardServiceStatus::Other(_) => {
                    thread::sleep(Duration::from_millis(100));
                }
            }
        }
        Err("El servicio anterior de OPAC Guard sigue marcado para eliminacion y Windows no lo libero a tiempo.".to_owned())
    }

    fn uninstall_service(
        profile_id: Uuid,
        nonce_hex: Option<String>,
        signature_hex: Option<String>,
    ) -> Result<(), String> {
        let nonce: [u8; 32] = decode_hex_array(
            nonce_hex
                .as_deref()
                .ok_or_else(|| "falta la prueba criptografica de desactivacion".to_owned())?,
        )?;
        let signature: [u8; 64] = decode_hex_array(
            signature_hex
                .as_deref()
                .ok_or_else(|| "falta la firma de desactivacion".to_owned())?,
        )?;
        let public_key = load_public_key(&profile_id).ok_or_else(|| {
            "no existe una configuracion autentica de OPAC Guard para este perfil".to_owned()
        })?;
        let verifier = VerifyingKey::from_bytes(&public_key)
            .map_err(|_| "la clave publica del Guard no es valida".to_owned())?;
        verifier
            .verify(
                &super::guard_uninstall_message(profile_id, &nonce),
                &Signature::from_bytes(&signature),
            )
            .map_err(|_| {
                "la autorizacion criptografica de desactivacion no es valida".to_owned()
            })?;
        let service_name = service_name_for_profile(&profile_id);
        remove_existing_service(&profile_id, &service_name)
            .map_err(|error| format!("[servicio] {error}"))?;

        let config = config_path(&profile_id).map_err(|error| {
            format!("no se pudo determinar el almacenamiento administrativo del Guard: {error}")
        })?;
        for path in config_candidate_paths(&profile_id)? {
            remove_file_if_exists(&path).map_err(|error| {
                format!("no se pudo eliminar la configuracion del Guard: {error}")
            })?;
        }

        let guard_path = guard_binary_path(&profile_id)?;
        let temp_guard = guard_path.with_extension("exe.new");
        remove_file_if_exists(&guard_path).map_err(|error| {
            format!("no se pudo eliminar el ejecutable materializado del Guard: {error}")
        })?;
        remove_file_if_exists(&temp_guard).map_err(|error| {
            format!("no se pudo limpiar el ejecutable temporal del Guard: {error}")
        })?;

        if let Some(parent) = config.parent() {
            remove_dir_if_empty(parent).map_err(|error| {
                format!("no se pudo limpiar el almacenamiento administrativo del Guard: {error}")
            })?;
        }
        Ok(())
    }

    fn path_entry_exists(path: &Path) -> io::Result<bool> {
        match fs::symlink_metadata(path) {
            Ok(_) => Ok(true),
            Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(false),
            Err(error) => Err(error),
        }
    }

    fn ensure_safe_file(path: &Path) -> io::Result<()> {
        let metadata = fs::symlink_metadata(path)?;
        let attrs = std::os::windows::fs::MetadataExt::file_attributes(&metadata);
        if metadata.file_type().is_symlink()
            || attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0
            || !metadata.is_file()
        {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "el archivo del Guard no es un archivo normal y seguro",
            ));
        }
        Ok(())
    }

    fn remove_file_if_exists(path: &Path) -> io::Result<()> {
        match fs::remove_file(path) {
            Ok(()) => Ok(()),
            Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
            Err(error) => Err(error),
        }
    }

    fn remove_dir_if_empty(path: &Path) -> io::Result<()> {
        match fs::remove_dir(path) {
            Ok(()) => Ok(()),
            Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
            Err(error) => Err(error),
        }
    }

    fn system32_directory() -> Result<PathBuf, String> {
        let mut buffer = vec![0u16; 260];
        loop {
            let len =
                unsafe { GetSystemDirectoryW(buffer.as_mut_ptr(), buffer.len() as u32) } as usize;
            if len == 0 {
                return Err(format!(
                    "no se pudo determinar System32 de Windows: {}",
                    io::Error::last_os_error()
                ));
            }
            if len < buffer.len() {
                return Ok(PathBuf::from(String::from_utf16_lossy(&buffer[..len])));
            }
            buffer.resize(len + 1, 0);
        }
    }

    /// Lanza una herramienta de consola de Windows (icacls, sc) sin crear una
    /// ventana de consola. Sin esto, cada llamada desde un proceso GUI muestra un
    /// cmd que aparece y desaparece al instante.
    fn hidden_command(program: impl AsRef<std::ffi::OsStr>) -> Command {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        let mut command = Command::new(program);
        command.creation_flags(CREATE_NO_WINDOW);
        command
    }

    fn system32_tool(name: &str) -> PathBuf {
        system32_directory()
            .map(|dir| dir.join(name))
            .unwrap_or_else(|_| PathBuf::from(r"C:\Windows\System32").join(name))
    }

    fn sc_command<const N: usize>(args: [&str; N]) -> bool {
        hidden_command(system32_tool("sc.exe"))
            .args(args)
            .status()
            .is_ok_and(|status| status.success())
    }

    fn run_sc_args(args: &[String]) -> Result<(), String> {
        let output = hidden_command(system32_tool("sc.exe"))
            .args(args)
            .output()
            .map_err(|error| error.to_string())?;
        if output.status.success() {
            Ok(())
        } else {
            let message = String::from_utf8_lossy(&output.stderr).trim().to_owned();
            Err(if message.is_empty() {
                String::from_utf8_lossy(&output.stdout).trim().to_owned()
            } else {
                message
            })
        }
    }

    fn canonicalize_install_roots(roots: Vec<PathBuf>) -> Result<Vec<PathBuf>, String> {
        if roots.len() != 1 {
            return Err(
                "OPAC Guard debe recibir exactamente una raiz de perfil durante la instalacion"
                    .to_owned(),
            );
        }
        let mut canonical = Vec::with_capacity(roots.len());
        for root in roots {
            if root.as_os_str().is_empty() {
                return Err("la raiz del perfil del Guard esta vacia".to_owned());
            }
            let resolved = fs::canonicalize(&root).map_err(|error| {
                format!("no se pudo resolver la raiz del perfil del Guard: {error}")
            })?;
            canonical.push(resolved);
        }
        Ok(canonical)
    }

    fn normalize_roots(mut roots: Vec<PathBuf>) -> Vec<PathBuf> {
        roots.retain(|root| !root.as_os_str().is_empty());
        for root in &mut roots {
            *root = fs::canonicalize(&*root).unwrap_or_else(|_| root.clone());
        }
        roots.sort_by_key(|a| a.to_string_lossy().to_ascii_lowercase());
        roots.dedup_by(|a, b| {
            a.to_string_lossy()
                .eq_ignore_ascii_case(&b.to_string_lossy())
        });

        let mut normalized = Vec::with_capacity(roots.len());
        for root in roots {
            if normalized
                .iter()
                .any(|parent: &PathBuf| path_within_root(&root, parent))
            {
                continue;
            }
            normalized.retain(|child: &PathBuf| !path_within_root(child, &root));
            normalized.push(root);
            if normalized.len() >= MAX_ROOTS {
                break;
            }
        }
        normalized
    }

    fn parse_install_args(args: &[String]) -> InstallArgs {
        let mut parsed = InstallArgs::default();
        let mut index = 0;
        while index < args.len() {
            match args[index].as_str() {
                "--root" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.roots.push(PathBuf::from(value));
                        index += 2;
                        continue;
                    }
                }
                "--profile-id" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.profile_id = Some(value.clone());
                        index += 2;
                        continue;
                    }
                }
                "--user-sid" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.user_sid = Some(value.clone());
                        index += 2;
                        continue;
                    }
                }
                "--public-key" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.public_key = Some(value.clone());
                        index += 2;
                        continue;
                    }
                }
                "--config-signature" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.config_signature = Some(value.clone());
                        index += 2;
                        continue;
                    }
                }
                "--uninstall-nonce" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.uninstall_nonce = Some(value.clone());
                        index += 2;
                        continue;
                    }
                }
                "--uninstall-signature" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.uninstall_signature = Some(value.clone());
                        index += 2;
                        continue;
                    }
                }
                "--admin-result" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.admin_result = Some(value.clone());
                        index += 2;
                        continue;
                    }
                }
                "--admin-result-fallback" => {
                    if let Some(value) = args.get(index + 1) {
                        parsed.admin_result_fallback = Some(value.clone());
                        index += 2;
                        continue;
                    }
                }
                _ => {}
            }
            index += 1;
        }
        parsed
    }

    fn parse_profile_id(value: &str) -> Option<Uuid> {
        Uuid::parse_str(value).ok()
    }

    fn service_name_for_profile(profile_id: &Uuid) -> String {
        format!("{SERVICE_NAME_PREFIX}{}", profile_id.simple())
    }

    fn pipe_name_for_profile(profile_id: &Uuid) -> String {
        format!(r"\\.\pipe\OpacGuard-{}", profile_id.simple())
    }

    fn config_path(profile_id: &Uuid) -> Result<PathBuf, String> {
        Ok(guard_admin_root()?
            .join("profiles")
            .join(profile_id.simple().to_string())
            .join("roots.bin"))
    }

    fn config_candidate_paths(profile_id: &Uuid) -> Result<[PathBuf; 3], String> {
        let primary = config_path(profile_id)?;
        Ok([
            primary.clone(),
            primary.with_extension("bin.new"),
            primary.with_extension("bin.bak"),
        ])
    }

    fn workers_cover_roots(root_count: usize, worker_count: usize) -> bool {
        root_count > 0 && root_count == worker_count
    }

    #[derive(Debug, Clone)]
    struct GuardConfig {
        public_key: [u8; 32],
        roots: Vec<PathBuf>,
    }

    fn config_message(
        profile_id: Uuid,
        roots: &[PathBuf],
        public_key: &[u8; 32],
    ) -> Result<Vec<u8>, String> {
        super::guard_config_message(profile_id, roots, public_key)
    }

    fn encode_config(
        profile_id: &Uuid,
        roots: &[PathBuf],
        public_key: [u8; 32],
        signature: [u8; 64],
    ) -> io::Result<Vec<u8>> {
        let message = config_message(*profile_id, roots, &public_key)
            .map_err(|error| io::Error::new(io::ErrorKind::InvalidInput, error))?;
        let expected = Signature::from_bytes(&signature);
        let verifier = VerifyingKey::from_bytes(&public_key)
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "clave publica invalida"))?;
        verifier.verify(&message, &expected).map_err(|_| {
            io::Error::new(
                io::ErrorKind::InvalidData,
                "firma de configuracion invalida",
            )
        })?;

        let mut data = Vec::with_capacity(5 + 16 + 32 + 64 + 4 + roots.len() * 64);
        data.extend_from_slice(CONFIG_MAGIC);
        data.extend_from_slice(profile_id.as_bytes());
        data.extend_from_slice(&public_key);
        data.extend_from_slice(&signature);
        data.extend_from_slice(&(roots.len() as u32).to_le_bytes());
        for root in roots {
            let bytes = root.to_string_lossy().as_bytes().to_vec();
            if bytes.is_empty() || bytes.len() > MAX_PATH_BYTES {
                return Err(io::Error::new(io::ErrorKind::InvalidInput, "ruta invalida"));
            }
            data.extend_from_slice(&(bytes.len() as u32).to_le_bytes());
            data.extend_from_slice(&bytes);
        }
        Ok(data)
    }

    fn save_config(
        profile_id: &Uuid,
        roots: &[PathBuf],
        public_key: [u8; 32],
        signature: [u8; 64],
    ) -> io::Result<()> {
        let data = encode_config(profile_id, roots, public_key, signature)?;
        let path = config_path(profile_id).map_err(io::Error::other)?;
        if let Some(parent) = path.parent() {
            secure_guard_storage_tree(parent)?;
        }
        let temp = path.with_extension("bin.new");
        let backup = path.with_extension("bin.bak");

        remove_file_if_exists(&temp)?;
        {
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&temp)?;
            file.write_all(&data)?;
            file.flush()?;
            file.sync_all()?;
        }
        remove_file_if_exists(&backup)?;
        if path_entry_exists(&path)? {
            ensure_safe_file(&path)?;
            fs::rename(&path, &backup)?;
        }
        if let Err(error) = fs::rename(&temp, &path) {
            if !path.exists() && backup.exists() {
                let _ = fs::rename(&backup, &path);
            }
            let _ = fs::remove_file(&temp);
            return Err(error);
        }
        let _ = fs::remove_file(&backup);
        Ok(())
    }

    fn load_config(profile_id: &Uuid) -> Option<GuardConfig> {
        let candidates = config_candidate_paths(profile_id).ok()?;
        for (index, path) in candidates.iter().enumerate() {
            let Ok(data) = fs::read(path) else {
                continue;
            };
            let Some(config) = parse_config(&data, profile_id) else {
                continue;
            };
            if index != 0 {
                let primary = &candidates[0];
                let temp = primary.with_extension("bin.recover");
                if fs::write(&temp, &data).is_ok() && fs::rename(&temp, primary).is_ok() {
                    let _ = fs::remove_file(&candidates[1]);
                    let _ = fs::remove_file(&candidates[2]);
                } else {
                    let _ = fs::remove_file(&temp);
                }
            }
            return Some(config);
        }
        None
    }

    fn parse_config(data: &[u8], expected_profile_id: &Uuid) -> Option<GuardConfig> {
        let min = CONFIG_MAGIC.len() + 16 + 32 + 64 + 4;
        if data.len() < min || &data[..CONFIG_MAGIC.len()] != CONFIG_MAGIC {
            return None;
        }
        let mut offset = CONFIG_MAGIC.len();
        let mut id_bytes = [0u8; 16];
        id_bytes.copy_from_slice(&data[offset..offset + 16]);
        offset += 16;
        let profile_id = Uuid::from_bytes(id_bytes);
        if &profile_id != expected_profile_id {
            return None;
        }
        let mut public_key = [0u8; 32];
        public_key.copy_from_slice(&data[offset..offset + 32]);
        offset += 32;
        let mut signature = [0u8; 64];
        signature.copy_from_slice(&data[offset..offset + 64]);
        offset += 64;
        let count = u32::from_le_bytes(data[offset..offset + 4].try_into().ok()?) as usize;
        offset += 4;
        if count != 1 || count > MAX_ROOTS {
            return None;
        }
        let mut roots = Vec::with_capacity(count);
        for _ in 0..count {
            if offset + 4 > data.len() {
                return None;
            }
            let len = u32::from_le_bytes(data[offset..offset + 4].try_into().ok()?) as usize;
            offset += 4;
            if len == 0 || len > MAX_PATH_BYTES || offset + len > data.len() {
                return None;
            }
            let text = std::str::from_utf8(&data[offset..offset + len]).ok()?;
            roots.push(PathBuf::from(text));
            offset += len;
        }
        if offset != data.len() || validate_configured_roots(&roots).is_err() {
            return None;
        }
        let message = config_message(profile_id, &roots, &public_key).ok()?;
        let verifier = VerifyingKey::from_bytes(&public_key).ok()?;
        verifier
            .verify(&message, &Signature::from_bytes(&signature))
            .ok()?;
        Some(GuardConfig { public_key, roots })
    }

    fn load_roots(profile_id: &Uuid) -> Vec<PathBuf> {
        load_config(profile_id)
            .map(|config| config.roots)
            .unwrap_or_default()
    }

    fn load_public_key(profile_id: &Uuid) -> Option<[u8; 32]> {
        load_config(profile_id).map(|config| config.public_key)
    }

    fn secure_guard_storage(dir: &Path) -> io::Result<()> {
        let path = dir.to_string_lossy().to_string();
        let system = r#"*S-1-5-18:(OI)(CI)F"#;
        let admin = r#"*S-1-5-32-544:(OI)(CI)F"#;
        let status = hidden_command(system32_tool("icacls.exe"))
            .arg(&path)
            .args(["/inheritance:r", "/grant:r", system, admin])
            .status()?;
        if !status.success() {
            return Err(io::Error::other(
                "no se pudieron asegurar las ACL del almacenamiento de OPAC Guard",
            ));
        }
        Ok(())
    }

    fn secure_guard_file(path: &Path) -> io::Result<()> {
        let path = path.to_string_lossy().to_string();
        let system = r#"*S-1-5-18:F"#;
        let admin = r#"*S-1-5-32-544:F"#;
        let status = hidden_command(system32_tool("icacls.exe"))
            .arg(&path)
            .args(["/inheritance:r", "/grant:r", system, admin])
            .status()?;
        if !status.success() {
            return Err(io::Error::other(
                "no se pudieron asegurar las ACL del archivo de OPAC Guard",
            ));
        }
        Ok(())
    }

    fn secure_guard_storage_tree(dir: &Path) -> io::Result<()> {
        let base = guard_admin_root().map_err(io::Error::other)?;
        let profiles = base.join("profiles");

        // Resolver ambos lados con la misma estrategia. En Windows,
        // canonicalize() puede devolver rutas con el prefijo \\?\\, mientras que
        // un descendiente que todavía no existe no puede canonicalizarse y se
        // queda con la forma normal C:\\. Compararlas directamente provocaba
        // falsos "fuera del almacenamiento" durante la primera instalacion de
        // un perfil cuando `profiles` ya existia.
        let profiles_abs = canonical_path_for_match(&profiles).ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::NotFound,
                "no se pudo resolver de forma segura el almacenamiento de perfiles del Guard",
            )
        })?;
        let requested = canonical_path_for_match(dir).ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::NotFound,
                "no se pudo resolver de forma segura la ruta del Guard",
            )
        })?;

        if !path_within_root(&requested, &profiles_abs) || path_eq(&requested, &profiles_abs) {
            return Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "la ruta del Guard queda fuera del almacenamiento administrado",
            ));
        }

        fs::create_dir_all(&requested)?;
        for path in [&base, &profiles, &requested] {
            fs::create_dir_all(path)?;
            let metadata = fs::symlink_metadata(path)?;
            let attrs = std::os::windows::fs::MetadataExt::file_attributes(&metadata);
            if metadata.file_type().is_symlink()
                || attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0
                || !metadata.is_dir()
            {
                return Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    "el almacenamiento administrativo del Guard contiene un punto de reanálisis no permitido",
                ));
            }
            secure_guard_storage(path)?;
        }
        Ok(())
    }

    fn random_nonce() -> [u8; 32] {
        let mut value = [0u8; 32];
        for chunk in value.as_chunks_mut::<16>().0 {
            chunk.copy_from_slice(Uuid::new_v4().as_bytes());
        }
        value
    }

    fn client_auth_message(profile_id: Uuid, nonce: &[u8; 32]) -> Vec<u8> {
        let mut data = Vec::with_capacity(GUARD_IPC_DOMAIN.len() + 48);
        data.extend_from_slice(GUARD_IPC_DOMAIN);
        data.extend_from_slice(profile_id.as_bytes());
        data.extend_from_slice(nonce);
        data
    }

    fn client_command_message(
        profile_id: Uuid,
        session_nonce: &[u8; 32],
        command: u8,
        sequence: u64,
        payload: &[u8],
    ) -> Vec<u8> {
        let mut data =
            Vec::with_capacity(GUARD_IPC_DOMAIN.len() + 16 + 32 + 1 + 8 + 4 + payload.len());
        data.extend_from_slice(GUARD_IPC_DOMAIN);
        data.extend_from_slice(profile_id.as_bytes());
        data.extend_from_slice(session_nonce);
        data.push(command);
        data.extend_from_slice(&sequence.to_le_bytes());
        data.extend_from_slice(&(payload.len() as u32).to_le_bytes());
        data.extend_from_slice(payload);
        data
    }

    fn encode_signed_command(
        profile_id: Uuid,
        session_nonce: &[u8; 32],
        command: u8,
        sequence: u64,
        payload: &[u8],
        signing_key: &[u8; 32],
    ) -> Vec<u8> {
        let signing = ed25519_dalek::SigningKey::from_bytes(signing_key);
        let signature = ed25519_dalek::Signer::sign(
            &signing,
            &client_command_message(profile_id, session_nonce, command, sequence, payload),
        );
        let mut frame_payload = Vec::with_capacity(8 + payload.len() + 64);
        frame_payload.extend_from_slice(&sequence.to_le_bytes());
        frame_payload.extend_from_slice(payload);
        frame_payload.extend_from_slice(&signature.to_bytes());
        frame_payload
    }

    fn decode_signed_command(payload: &[u8]) -> Option<(u64, &[u8], [u8; 64])> {
        if payload.len() < 8 + 64 {
            return None;
        }
        let sequence = u64::from_le_bytes(payload[..8].try_into().ok()?);
        let split = payload.len() - 64;
        let command_payload = &payload[8..split];
        let signature: [u8; 64] = payload[split..].try_into().ok()?;
        Some((sequence, command_payload, signature))
    }

    fn client_loop(profile_id: Uuid, rx: Receiver<ClientCommand>, signing_key: [u8; 32]) {
        let pipe_name = pipe_name_for_profile(&profile_id);
        let mut pipe: Option<std::fs::File> = None;
        let mut session_nonce: Option<[u8; 32]> = None;
        let mut command_sequence = 0u64;
        loop {
            if pipe.is_none() {
                match OpenOptions::new().read(true).write(true).open(&pipe_name) {
                    Ok(mut candidate) => {
                        if let Ok(nonce) =
                            authenticate_guard_pipe(&mut candidate, profile_id, &signing_key)
                        {
                            pipe = Some(candidate);
                            session_nonce = Some(nonce);
                            command_sequence = 0;
                        }
                    }
                    Err(_) => {
                        match rx.recv_timeout(Duration::from_millis(1000)) {
                            Ok(command) => apply_client_command(
                                command,
                                &mut pipe,
                                profile_id,
                                &signing_key,
                                session_nonce.as_ref(),
                                &mut command_sequence,
                            ),
                            Err(mpsc::RecvTimeoutError::Disconnected) => break,
                            Err(mpsc::RecvTimeoutError::Timeout) => continue,
                        }
                        continue;
                    }
                }
            }

            match rx.recv_timeout(Duration::from_millis(500)) {
                Ok(command) => apply_client_command(
                    command,
                    &mut pipe,
                    profile_id,
                    &signing_key,
                    session_nonce.as_ref(),
                    &mut command_sequence,
                ),
                Err(mpsc::RecvTimeoutError::Disconnected) => break,
                Err(mpsc::RecvTimeoutError::Timeout) => {}
            }
        }
        drop(pipe);
    }

    fn apply_client_command(
        command: ClientCommand,
        pipe: &mut Option<std::fs::File>,
        profile_id: Uuid,
        signing_key: &[u8; 32],
        session_nonce: Option<&[u8; 32]>,
        sequence: &mut u64,
    ) {
        match command {
            ClientCommand::Locked { response } => {
                let result = send_command_without_path_and_wait_for_ack(
                    pipe,
                    CMD_LOCK,
                    profile_id,
                    signing_key,
                    session_nonce,
                    sequence,
                );
                let _ = response.send(result);
            }
            ClientCommand::ReleasePath { path, response } => {
                let result = send_path_and_wait_for_ack(
                    pipe,
                    CMD_RELEASE_PATH,
                    &path,
                    profile_id,
                    signing_key,
                    session_nonce,
                    sequence,
                );
                let _ = response.send(result);
            }
            ClientCommand::ReprotectPath { path, response } => {
                let result = send_path_and_wait_for_ack(
                    pipe,
                    CMD_REPROTECT_PATH,
                    &path,
                    profile_id,
                    signing_key,
                    session_nonce,
                    sequence,
                );
                let _ = response.send(result);
            }
        }
    }

    fn send_path_and_wait_for_ack(
        pipe: &mut Option<std::fs::File>,
        command: u8,
        path: &Path,
        profile_id: Uuid,
        signing_key: &[u8; 32],
        session_nonce: Option<&[u8; 32]>,
        sequence: &mut u64,
    ) -> Result<(), String> {
        let payload = encode_path_payload(path).map_err(|error| error.to_string())?;
        let result = send_signed_command(
            pipe,
            command,
            &payload,
            profile_id,
            signing_key,
            session_nonce,
            sequence,
        )
        .and_then(|_| {
            let Some(file) = pipe.as_mut() else {
                return Err("OPAC Guard no esta conectado al servicio".to_owned());
            };
            read_command_ack(file)
        });
        if result.is_err() {
            *pipe = None;
            *sequence = 0;
        }
        result
    }

    fn send_command_without_path_and_wait_for_ack(
        pipe: &mut Option<std::fs::File>,
        command: u8,
        profile_id: Uuid,
        signing_key: &[u8; 32],
        session_nonce: Option<&[u8; 32]>,
        sequence: &mut u64,
    ) -> Result<(), String> {
        let result = send_signed_command(
            pipe,
            command,
            &[],
            profile_id,
            signing_key,
            session_nonce,
            sequence,
        )
        .and_then(|_| {
            let Some(file) = pipe.as_mut() else {
                return Err("OPAC Guard no esta conectado al servicio".to_owned());
            };
            read_command_ack(file)
        });
        if result.is_err() {
            *pipe = None;
            *sequence = 0;
        }
        result
    }

    fn send_signed_command(
        pipe: &mut Option<std::fs::File>,
        command: u8,
        payload: &[u8],
        profile_id: Uuid,
        signing_key: &[u8; 32],
        session_nonce: Option<&[u8; 32]>,
        sequence: &mut u64,
    ) -> Result<(), String> {
        let Some(file) = pipe.as_mut() else {
            return Err("OPAC Guard no esta conectado al servicio".to_owned());
        };
        let Some(session_nonce) = session_nonce else {
            return Err("OPAC Guard no ha autenticado la sesion IPC".to_owned());
        };
        let frame_payload = encode_signed_command(
            profile_id,
            session_nonce,
            command,
            *sequence,
            payload,
            signing_key,
        );
        send_frame(file, command, &frame_payload).map_err(|error| error.to_string())?;
        *sequence = (*sequence)
            .checked_add(1)
            .ok_or_else(|| "secuencia de comandos agotada".to_owned())?;
        Ok(())
    }

    fn encode_path_payload(path: &Path) -> io::Result<Vec<u8>> {
        let text = path.to_string_lossy();
        let bytes = text.as_bytes();
        if bytes.is_empty() || bytes.len() > MAX_PATH_BYTES {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "ruta invalida"));
        }
        Ok(bytes.to_vec())
    }

    fn read_command_ack(file: &mut std::fs::File) -> Result<(), String> {
        let Some((command, payload)) = read_frame_file(file) else {
            return Err(
                "el servicio del Guard cerro el canal antes de confirmar la operacion".to_owned(),
            );
        };
        match command {
            CMD_ACK if payload.is_empty() => Ok(()),
            CMD_NACK => Err(String::from_utf8(payload)
                .unwrap_or_else(|_| "OPAC Guard rechazo la operacion".to_owned())),
            _ => Err("respuesta inesperada del servicio de OPAC Guard".to_owned()),
        }
    }

    fn send_frame(file: &mut std::fs::File, command: u8, payload: &[u8]) -> io::Result<()> {
        if payload.len() > MAX_FRAME_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "payload demasiado grande",
            ));
        }
        file.write_all(&[command])?;
        file.write_all(&(payload.len() as u32).to_le_bytes())?;
        file.write_all(payload)?;
        file.flush()
    }

    struct GuardedFile(HANDLE);

    impl Drop for GuardedFile {
        fn drop(&mut self) {
            unsafe {
                if !self.0.is_null() && self.0 != INVALID_HANDLE_VALUE {
                    CloseHandle(self.0);
                }
            }
        }
    }

    struct Protection {
        stop_event: HANDLE,
        workers: Vec<JoinHandle<()>>,
    }

    impl Drop for Protection {
        fn drop(&mut self) {
            unsafe {
                if !self.stop_event.is_null() && self.stop_event != INVALID_HANDLE_VALUE {
                    let _ = SetEvent(self.stop_event);
                }
            }
            for worker in self.workers.drain(..) {
                let _ = worker.join();
            }
            unsafe {
                if !self.stop_event.is_null() && self.stop_event != INVALID_HANDLE_VALUE {
                    CloseHandle(self.stop_event);
                }
            }
        }
    }

    fn arm_protection(roots: &[PathBuf], released: &[ReleaseTarget]) -> Option<Protection> {
        let stop_event = unsafe { CreateEventW(std::ptr::null(), 1, 0, std::ptr::null()) };
        if stop_event.is_null() {
            return None;
        }

        let roots = normalize_roots(roots.to_vec());
        let root_count = roots.len();
        if roots.is_empty() {
            unsafe {
                CloseHandle(stop_event);
            }
            return None;
        }
        for root in &roots {
            let preflight = scan_root(root, released);
            if preflight.directory_failed || !preflight.retry_paths.is_empty() {
                unsafe {
                    CloseHandle(stop_event);
                }
                return None;
            }
        }
        let mut workers = Vec::new();
        for root in roots {
            // windows_sys::HANDLE is a raw pointer and therefore not `Send`; carry the
            // stop event as an integer across the thread boundary and reconstruct it
            // inside the worker. The handle remains owned by `Protection`.
            let event_raw = stop_event as isize;
            let released_for_root = released.to_vec();
            match thread::Builder::new()
                .name("opac-guard-root".to_owned())
                .spawn(move || watch_root(root, released_for_root, event_raw as HANDLE))
            {
                Ok(worker) => workers.push(worker),
                Err(_) => {
                    unsafe {
                        let _ = SetEvent(stop_event);
                    }
                    for worker in workers {
                        let _ = worker.join();
                    }
                    unsafe {
                        CloseHandle(stop_event);
                    }
                    return None;
                }
            }
        }
        if !workers_cover_roots(root_count, workers.len()) {
            unsafe {
                CloseHandle(stop_event);
            }
            return None;
        }
        Some(Protection {
            stop_event,
            workers,
        })
    }

    struct ScanResult {
        guarded: Vec<GuardedFile>,
        retry_paths: Vec<PathBuf>,
        directory_failed: bool,
    }

    struct DirectoryWatcher {
        handle: HANDLE,
        event: HANDLE,
        overlapped: OVERLAPPED,
        buffer: Vec<u8>,
    }

    impl Drop for DirectoryWatcher {
        fn drop(&mut self) {
            unsafe {
                let _ = CancelIoEx(self.handle, &self.overlapped);
                let mut transferred = 0u32;
                let _ = GetOverlappedResult(self.handle, &self.overlapped, &mut transferred, 1);
                if !self.event.is_null() && self.event != INVALID_HANDLE_VALUE {
                    CloseHandle(self.event);
                }
                if !self.handle.is_null() && self.handle != INVALID_HANDLE_VALUE {
                    CloseHandle(self.handle);
                }
            }
        }
    }

    fn watch_root(root: PathBuf, released: Vec<ReleaseTarget>, stop_event: HANDLE) {
        // Arm the notification before scanning so changes during the initial
        // enumeration cannot fall into an unobserved scan/watch window.
        let Some(mut watcher) = create_directory_watcher(&root) else {
            request_service_stop();
            return;
        };
        if arm_directory_watcher(&mut watcher).is_err() {
            request_service_stop();
            return;
        }

        let initial = scan_root(&root, &released);
        if initial.directory_failed || !initial.retry_paths.is_empty() {
            request_service_stop();
            return;
        }
        let mut guarded = initial.guarded;

        loop {
            match wait_for_directory_change(stop_event, &watcher) {
                WatchOutcome::Stop => break,
                WatchOutcome::Changed => {
                    // Re-arm first so changes that occur during the scan remain
                    // pending for the next wait.
                    if arm_directory_watcher(&mut watcher).is_err() {
                        request_service_stop();
                        break;
                    }
                    let next = scan_root(&root, &released);
                    if next.directory_failed || !next.retry_paths.is_empty() {
                        request_service_stop();
                        break;
                    }
                    guarded = next.guarded;
                }
                WatchOutcome::Error => {
                    request_service_stop();
                    break;
                }
            }
        }
        drop(guarded);
    }

    enum WatchOutcome {
        Stop,
        Changed,
        Error,
    }

    fn create_directory_watcher(root: &Path) -> Option<DirectoryWatcher> {
        let wide_root = wide(&root.to_string_lossy());
        let handle = unsafe {
            CreateFileW(
                wide_root.as_ptr(),
                FILE_LIST_DIRECTORY,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                std::ptr::null(),
                OPEN_EXISTING,
                FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED | FILE_FLAG_OPEN_REPARSE_POINT,
                std::ptr::null_mut(),
            )
        };
        if handle == INVALID_HANDLE_VALUE || handle.is_null() {
            return None;
        }
        let event = unsafe { CreateEventW(std::ptr::null(), 1, 0, std::ptr::null()) };
        if event.is_null() || event == INVALID_HANDLE_VALUE {
            unsafe {
                CloseHandle(handle);
            }
            return None;
        }
        let mut overlapped: OVERLAPPED = unsafe { std::mem::zeroed() };
        overlapped.hEvent = event;
        Some(DirectoryWatcher {
            handle,
            event,
            overlapped,
            buffer: vec![0u8; 64 * 1024],
        })
    }

    fn arm_directory_watcher(watcher: &mut DirectoryWatcher) -> Result<(), ()> {
        unsafe {
            if ResetEvent(watcher.event) == 0 {
                return Err(());
            }
            let ok = ReadDirectoryChangesW(
                watcher.handle,
                watcher.buffer.as_mut_ptr().cast(),
                watcher.buffer.len() as u32,
                1,
                FILE_NOTIFY_CHANGE_FILE_NAME
                    | FILE_NOTIFY_CHANGE_DIR_NAME
                    | FILE_NOTIFY_CHANGE_SIZE
                    | FILE_NOTIFY_CHANGE_LAST_WRITE,
                std::ptr::null_mut(),
                &mut watcher.overlapped,
                None,
            );
            if ok != 0 || GetLastError() == ERROR_IO_PENDING {
                Ok(())
            } else {
                Err(())
            }
        }
    }

    fn wait_for_directory_change(stop_event: HANDLE, watcher: &DirectoryWatcher) -> WatchOutcome {
        let handles = [stop_event, watcher.event];
        let result = unsafe { WaitForMultipleObjects(2, handles.as_ptr(), 0, INFINITE) };
        if result == WAIT_OBJECT_0 {
            unsafe {
                let _ = CancelIoEx(watcher.handle, &watcher.overlapped);
                let mut transferred = 0u32;
                let _ =
                    GetOverlappedResult(watcher.handle, &watcher.overlapped, &mut transferred, 1);
            }
            WatchOutcome::Stop
        } else if result == WAIT_OBJECT_0 + 1 {
            let mut transferred = 0u32;
            let ok = unsafe {
                GetOverlappedResult(watcher.handle, &watcher.overlapped, &mut transferred, 0)
            };
            if ok != 0 {
                WatchOutcome::Changed
            } else {
                WatchOutcome::Error
            }
        } else {
            WatchOutcome::Error
        }
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    enum ReleaseKind {
        File,
        Tree,
    }

    #[derive(Debug, Clone)]
    struct ReleaseTarget {
        path: PathBuf,
        kind: ReleaseKind,
    }

    fn scan_root(root: &Path, released: &[ReleaseTarget]) -> ScanResult {
        let mut result = ScanResult {
            guarded: Vec::new(),
            retry_paths: Vec::new(),
            directory_failed: false,
        };
        scan_dir(root, released, &mut result);
        result
    }

    fn scan_dir(dir: &Path, released: &[ReleaseTarget], result: &mut ScanResult) {
        if !is_released_tree(dir, released) {
            if let Some(handle) = open_protected_dir(dir) {
                result.guarded.push(GuardedFile(handle));
            } else {
                result.directory_failed = true;
            }
        }
        let Ok(entries) = fs::read_dir(dir) else {
            result.directory_failed = true;
            return;
        };
        for entry in entries {
            let Ok(entry) = entry else {
                result.directory_failed = true;
                return;
            };
            let path = entry.path();
            let Ok(metadata) = fs::symlink_metadata(&path) else {
                result.directory_failed = true;
                return;
            };
            let attrs = std::os::windows::fs::MetadataExt::file_attributes(&metadata);
            if attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0 {
                // Reparse points are deliberately outside Guard's traversal
                // policy. Seeing one under a protected profile is treated as a
                // fail-closed condition rather than silently leaving it outside
                // the protection set.
                result.directory_failed = true;
                return;
            }
            if metadata.is_dir() {
                if !is_released_tree(&path, released) {
                    scan_dir(&path, released, result);
                }
            } else if is_protected_file(&path) {
                if is_released_file(&path, released) || is_released_tree(&path, released) {
                    continue;
                }
                if let Some(handle) = open_protected(&path) {
                    result.guarded.push(GuardedFile(handle));
                } else {
                    result.retry_paths.push(path);
                }
            }
        }
    }

    fn is_released_file(path: &Path, released: &[ReleaseTarget]) -> bool {
        released
            .iter()
            .any(|target| target.kind == ReleaseKind::File && path_eq(&target.path, path))
    }

    fn is_released_tree(path: &Path, released: &[ReleaseTarget]) -> bool {
        released.iter().any(|target| {
            target.kind == ReleaseKind::Tree
                && (path_eq(&target.path, path) || path_within_root(path, &target.path))
        })
    }

    fn path_eq(left: &Path, right: &Path) -> bool {
        left == right
            || left
                .to_string_lossy()
                .eq_ignore_ascii_case(&right.to_string_lossy())
    }

    fn path_within_root(path: &Path, root: &Path) -> bool {
        if path_eq(path, root) {
            return true;
        }
        let path_text = path
            .to_string_lossy()
            .replace('/', "\\")
            .to_ascii_lowercase();
        let root_text = root
            .to_string_lossy()
            .replace('/', "\\")
            .trim_end_matches('\\')
            .to_ascii_lowercase();
        !root_text.is_empty() && path_text.starts_with(&(root_text + "\\"))
    }

    fn canonical_existing_path(path: &Path) -> Option<PathBuf> {
        let metadata = fs::symlink_metadata(path).ok()?;
        let attrs = std::os::windows::fs::MetadataExt::file_attributes(&metadata);
        if attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0 {
            return None;
        }
        fs::canonicalize(path).ok()
    }

    fn canonical_path_for_match(path: &Path) -> Option<PathBuf> {
        if fs::symlink_metadata(path).is_ok() {
            return canonical_existing_path(path);
        }

        let mut base = path.to_path_buf();
        let mut missing = Vec::new();

        while fs::symlink_metadata(&base).is_err() {
            let name = base.file_name()?.to_os_string();
            missing.push(name);
            if !base.pop() {
                return None;
            }
        }

        let mut resolved = canonical_existing_path(&base)?;
        for component in missing.iter().rev() {
            resolved.push(component);
        }
        Some(resolved)
    }

    fn validate_releasable_path(path: &Path, roots: &[PathBuf]) -> Result<ReleaseTarget, String> {
        if validate_configured_roots(roots).is_err() {
            return Err("la configuracion de raices del Guard no es valida".to_owned());
        }
        let metadata =
            fs::symlink_metadata(path).map_err(|_| "la ruta solicitada ya no existe".to_owned())?;
        let attrs = std::os::windows::fs::MetadataExt::file_attributes(&metadata);
        if attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0 {
            return Err("el Guard no permite liberar reparse points".to_owned());
        }
        let is_dir = metadata.is_dir();
        if !is_dir && !is_protected_file(path) {
            return Err(
                "la ruta solicitada no es un archivo cifrado protegido por OPAC".to_owned(),
            );
        }
        let candidate = canonical_existing_path(path)
            .ok_or_else(|| "no se pudo normalizar de forma segura la ruta solicitada".to_owned())?;
        let canonical_roots: Vec<PathBuf> = roots
            .iter()
            .filter_map(|root| canonical_existing_path(root))
            .collect();
        if canonical_roots.len() != roots.len() {
            return Err("la configuracion del Guard contiene una raiz que no se pudo normalizar de forma segura".to_owned());
        }
        let within_profile = canonical_roots
            .iter()
            .any(|root| path_within_root(&candidate, root));
        if !within_profile {
            return Err(
                "la ruta solicitada esta fuera del perfil protegido por este Guard".to_owned(),
            );
        }
        if canonical_roots.iter().any(|root| path_eq(&candidate, root)) {
            return Err("el Guard nunca permite liberar la raiz completa del perfil".to_owned());
        }
        let kind = if is_dir {
            ReleaseKind::Tree
        } else {
            ReleaseKind::File
        };
        Ok(ReleaseTarget {
            path: candidate,
            kind,
        })
    }

    fn is_protected_file(path: &Path) -> bool {
        path.file_name()
            .and_then(|name| name.to_str())
            .is_some_and(|name| {
                name.eq_ignore_ascii_case("keystore.opks")
                    || name.eq_ignore_ascii_case(".opac-folder")
                    || path
                        .extension()
                        .is_some_and(|ext| ext.eq_ignore_ascii_case("opac"))
            })
    }

    fn open_protected(path: &Path) -> Option<HANDLE> {
        open_protected_entry(path, 0)
    }

    fn open_protected_dir(path: &Path) -> Option<HANDLE> {
        open_protected_entry(path, FILE_FLAG_BACKUP_SEMANTICS)
    }

    fn open_protected_entry(path: &Path, extra_flags: u32) -> Option<HANDLE> {
        let wide_path = wide(&path.to_string_lossy());
        let handle = unsafe {
            CreateFileW(
                wide_path.as_ptr(),
                0,
                FILE_SHARE_READ,
                std::ptr::null(),
                OPEN_EXISTING,
                extra_flags | FILE_FLAG_OPEN_REPARSE_POINT,
                std::ptr::null_mut(),
            )
        };
        if handle == INVALID_HANDLE_VALUE || handle.is_null() {
            return None;
        }
        let mut info = BY_HANDLE_FILE_INFORMATION::default();
        let ok = unsafe { GetFileInformationByHandle(handle, &mut info) };
        if ok == 0 || (info.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0 {
            unsafe {
                CloseHandle(handle);
            }
            return None;
        }
        Some(handle)
    }

    fn run_service(args: &[String]) -> i32 {
        SERVICE_STOP_REQUESTED.store(false, Ordering::SeqCst);
        let parsed = parse_install_args(&args[2..]);
        let Some(profile_id) = parsed.profile_id.as_deref().and_then(parse_profile_id) else {
            return 2;
        };
        if parsed
            .user_sid
            .filter(|sid| sid.starts_with("S-1-") && sid.len() <= MAX_SID_CHARS)
            .is_none()
        {
            return 2;
        }
        let name = wide(&service_name_for_profile(&profile_id));
        let mut table = [
            SERVICE_TABLE_ENTRYW {
                lpServiceName: name.as_ptr() as *mut u16,
                lpServiceProc: Some(service_main),
            },
            SERVICE_TABLE_ENTRYW {
                lpServiceName: std::ptr::null_mut(),
                lpServiceProc: None,
            },
        ];
        let ok = unsafe { StartServiceCtrlDispatcherW(table.as_mut_ptr()) };
        if ok == 0 { 1 } else { 0 }
    }

    unsafe extern "system" fn service_main(_argc: u32, _argv: *mut *mut u16) {
        let parsed = parse_install_args(&std::env::args().collect::<Vec<_>>()[2..]);
        let Some(profile_id) = parsed.profile_id.as_deref().and_then(parse_profile_id) else {
            return;
        };
        let Some(user_sid) = parsed
            .user_sid
            .filter(|sid| sid.starts_with("S-1-") && sid.len() <= MAX_SID_CHARS)
        else {
            return;
        };
        let service_name = service_name_for_profile(&profile_id);
        let pipe_name = pipe_name_for_profile(&profile_id);
        let name = wide(&service_name);
        let status_handle: SERVICE_STATUS_HANDLE =
            unsafe { RegisterServiceCtrlHandlerW(name.as_ptr(), Some(service_ctrl_handler)) };
        if status_handle.is_null() {
            return;
        }

        let mut status = SERVICE_STATUS {
            dwServiceType: SERVICE_WIN32_OWN_PROCESS,
            dwCurrentState: SERVICE_START_PENDING,
            dwControlsAccepted: 0,
            dwWin32ExitCode: 0,
            dwServiceSpecificExitCode: 0,
            dwCheckPoint: 1,
            dwWaitHint: 5000,
        };
        unsafe {
            SetServiceStatus(status_handle, &status);
        }

        let Some(config) = load_config(&profile_id) else {
            status.dwCurrentState = SERVICE_STOPPED;
            status.dwWin32ExitCode = 87;
            unsafe {
                SetServiceStatus(status_handle, &status);
            }
            return;
        };
        let roots = config.roots.clone();
        if validate_configured_roots(&roots).is_err() {
            status.dwCurrentState = SERVICE_STOPPED;
            status.dwWin32ExitCode = 87;
            unsafe {
                SetServiceStatus(status_handle, &status);
            }
            return;
        }

        let mut protection = match arm_protection(&roots, &[]) {
            Some(value) => Some(value),
            None => {
                status.dwCurrentState = SERVICE_STOPPED;
                status.dwWin32ExitCode = 8;
                unsafe {
                    SetServiceStatus(status_handle, &status);
                }
                return;
            }
        };

        status.dwCurrentState = SERVICE_RUNNING;
        status.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
        status.dwCheckPoint = 0;
        status.dwWaitHint = 0;
        unsafe {
            SetServiceStatus(status_handle, &status);
        }

        while !SERVICE_STOP_REQUESTED.load(Ordering::SeqCst) {
            let pipe_security = match PipeSecurity::new(&user_sid) {
                Ok(value) => value,
                Err(_) => break,
            };
            let attributes = pipe_security.attributes();
            let pipe = unsafe {
                let name = wide(&pipe_name);
                CreateNamedPipeW(
                    name.as_ptr(),
                    PIPE_ACCESS_DUPLEX | FILE_FLAG_FIRST_PIPE_INSTANCE,
                    PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT | PIPE_REJECT_REMOTE_CLIENTS,
                    1,
                    64 * 1024,
                    64 * 1024,
                    1000,
                    &attributes,
                )
            };
            if pipe == INVALID_HANDLE_VALUE || pipe.is_null() {
                break;
            }

            CURRENT_PIPE.store(pipe as isize, Ordering::SeqCst);
            let connected = unsafe {
                ConnectNamedPipe(pipe, std::ptr::null_mut()) != 0
                    || GetLastError() == ERROR_PIPE_CONNECTED
            };
            if connected
                && client_is_authorized(pipe, &user_sid)
                && let Some(nonce) = authenticate_client(pipe, profile_id, &config.public_key)
            {
                handle_client(
                    pipe,
                    &profile_id,
                    &config.public_key,
                    &nonce,
                    &mut protection,
                );
            }
            unsafe {
                let _ = DisconnectNamedPipe(pipe);
                CloseHandle(pipe);
            }
            CURRENT_PIPE.store(-1, Ordering::SeqCst);
        }

        drop(protection);
        status.dwCurrentState = SERVICE_STOPPED;
        status.dwControlsAccepted = 0;
        unsafe {
            SetServiceStatus(status_handle, &status);
        }
    }

    unsafe extern "system" fn service_ctrl_handler(control: u32) {
        match control {
            SERVICE_CONTROL_STOP | SERVICE_CONTROL_SHUTDOWN => {
                request_service_stop();
            }
            _ => {}
        }
    }

    fn handle_client(
        pipe: HANDLE,
        profile_id: &Uuid,
        public_key: &[u8; 32],
        session_nonce: &[u8; 32],
        protection: &mut Option<Protection>,
    ) {
        let mut released = Vec::<ReleaseTarget>::new();
        let mut expected_sequence = 0u64;
        loop {
            let Some((command, payload)) = read_frame(pipe) else {
                // Una desconexion inesperada siempre cierra todas las excepciones
                // y devuelve la raiz completa al estado protegido.
                released.clear();
                let _ = restore_protection_or_request_shutdown(profile_id, protection, &released);
                return;
            };

            if command != CMD_RELEASE_PATH
                && command != CMD_REPROTECT_PATH
                && command != CMD_LOCK
                && command != CMD_QUIT
            {
                let _ = send_ack(pipe, false, Some("comando no permitido"));
                return;
            }
            let Some((sequence, command_payload, signature_bytes)) =
                decode_signed_command(&payload)
            else {
                let _ = send_ack(pipe, false, Some("autorizacion de comando invalida"));
                return;
            };
            if sequence != expected_sequence {
                let _ = send_ack(pipe, false, Some("secuencia de comando invalida"));
                return;
            }
            let Ok(verifier) = VerifyingKey::from_bytes(public_key) else {
                let _ = send_ack(pipe, false, Some("identidad criptografica invalida"));
                return;
            };
            let signature = Signature::from_bytes(&signature_bytes);
            if verifier
                .verify(
                    &client_command_message(
                        *profile_id,
                        session_nonce,
                        command,
                        sequence,
                        command_payload,
                    ),
                    &signature,
                )
                .is_err()
            {
                let _ = send_ack(pipe, false, Some("firma de comando rechazada"));
                return;
            }
            expected_sequence = expected_sequence.saturating_add(1);

            match command {
                CMD_RELEASE_PATH => {
                    let Some(raw_path) = decode_path_payload(command_payload) else {
                        let _ = send_ack(pipe, false, Some("ruta invalida"));
                        continue;
                    };
                    let configured = load_roots(profile_id);
                    let target = match validate_releasable_path(&raw_path, &configured) {
                        Ok(target) => target,
                        Err(error) => {
                            let _ = send_ack(pipe, false, Some(&error));
                            continue;
                        }
                    };
                    if released
                        .iter()
                        .any(|item| path_eq(&item.path, &target.path) && item.kind == target.kind)
                    {
                        let _ = send_ack(pipe, true, None);
                        continue;
                    }
                    if released.len() >= MAX_ACTIVE_RELEASES {
                        let _ = send_ack(
                            pipe,
                            false,
                            Some("demasiadas excepciones de proteccion activas"),
                        );
                        continue;
                    }
                    // Do not allow one authenticated session to accumulate a
                    // broader exception that would silently subsume another.
                    if matches!(target.kind, ReleaseKind::Tree)
                        && released
                            .iter()
                            .any(|item| path_within_root(&item.path, &target.path))
                    {
                        let _ = send_ack(
                            pipe,
                            false,
                            Some("la excepcion solicitada ampliaria otra excepcion activa"),
                        );
                        continue;
                    }
                    if released.iter().any(|item| {
                        item.kind == ReleaseKind::Tree && path_within_root(&target.path, &item.path)
                    }) {
                        let _ = send_ack(
                            pipe,
                            false,
                            Some("la ruta ya esta dentro de una excepcion de arbol activa"),
                        );
                        continue;
                    }
                    released.push(target);
                    if restore_protection_or_request_shutdown(profile_id, protection, &released) {
                        let _ = send_ack(pipe, true, None);
                    } else {
                        return;
                    }
                }
                CMD_REPROTECT_PATH => {
                    let Some(raw_path) = decode_path_payload(command_payload) else {
                        let _ = send_ack(pipe, false, Some("ruta invalida"));
                        continue;
                    };
                    // Tras borrar, renombrar o mover una ruta, el path original
                    // puede haber dejado de existir. En ese caso seguimos pudiendo
                    // reconstruir su ruta canónica a partir del padre existente;
                    // así la excepción que el Guard creó antes de la mutación se
                    // retira incluso si OPAC pasó una ruta no canónica.
                    let normalized = canonical_path_for_match(&raw_path);
                    released.retain(|item| {
                        let raw_match = path_eq(&item.path, &raw_path);
                        let normalized_match = normalized
                            .as_deref()
                            .is_some_and(|path| path_eq(&item.path, path));
                        !(raw_match || normalized_match)
                    });
                    if restore_protection_or_request_shutdown(profile_id, protection, &released) {
                        let _ = send_ack(pipe, true, None);
                    } else {
                        return;
                    }
                }
                CMD_LOCK => {
                    released.clear();
                    if !restore_protection_or_request_shutdown(profile_id, protection, &released) {
                        return;
                    }
                    let _ = send_ack(pipe, true, None);
                }
                CMD_QUIT => {
                    released.clear();
                    if !restore_protection_or_request_shutdown(profile_id, protection, &released) {
                        return;
                    }
                    let _ = send_ack(pipe, true, None);
                    return;
                }
                _ => {}
            }
        }
    }

    fn restore_protection_or_request_shutdown(
        profile_id: &Uuid,
        protection: &mut Option<Protection>,
        released: &[ReleaseTarget],
    ) -> bool {
        let roots = load_roots(profile_id);
        if validate_configured_roots(&roots).is_err() {
            request_service_stop();
            *protection = None;
            return false;
        }
        // The existing workers own the FILE_SHARE_READ-only handles. They must
        // be fully stopped before a new protection set can open replacement
        // handles, otherwise the authenticated release/reprotect operation can
        // deadlock against the Guard's own sharing policy.
        let previous = protection.take();
        drop(previous);
        match arm_protection(&roots, released) {
            Some(next) => {
                *protection = Some(next);
                true
            }
            None => {
                // Nunca mantenemos un Guard anunciado como sano si no se pudo
                // reconstruir toda su proteccion con las excepciones declaradas.
                request_service_stop();
                *protection = None;
                false
            }
        }
    }

    fn client_is_authorized(pipe: HANDLE, authorized_sid: &str) -> bool {
        unsafe {
            let mut pid = 0u32;
            if GetNamedPipeClientProcessId(pipe, &mut pid) == 0 || pid == 0 {
                return false;
            }
            let process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
            if process.is_null() {
                return false;
            }
            // El SID de Windows es solo una primera barrera de acceso al pipe.
            // La identidad lógica del usuario de OPAC se demuestra después con
            // el desafio Ed25519 ligado al profile_id. No comprobamos la ruta del
            // ejecutable aquí porque el Guard se materializa en ProgramData y la
            // GUI puede estar instalada en otra ubicación.
            let sid_ok = process_user_sid(process)
                .is_some_and(|sid| sid.eq_ignore_ascii_case(authorized_sid));
            CloseHandle(process);
            sid_ok
        }
    }

    fn process_user_sid(process: HANDLE) -> Option<String> {
        unsafe {
            let mut token = std::ptr::null_mut();
            if OpenProcessToken(process, TOKEN_QUERY, &mut token) == 0 {
                return None;
            }
            let mut needed = 0u32;
            let _ = GetTokenInformation(token, TokenUser, std::ptr::null_mut(), 0, &mut needed);
            if needed == 0 {
                CloseHandle(token);
                return None;
            }
            let words = (needed as usize).div_ceil(std::mem::size_of::<usize>());
            let mut buffer = vec![0usize; words.max(1)];
            if GetTokenInformation(
                token,
                TokenUser,
                buffer.as_mut_ptr().cast(),
                needed,
                &mut needed,
            ) == 0
            {
                CloseHandle(token);
                return None;
            }
            let token_user = &*buffer.as_ptr().cast::<TOKEN_USER>();
            let mut text = std::ptr::null_mut();
            if ConvertSidToStringSidW(token_user.User.Sid, &mut text) == 0 || text.is_null() {
                CloseHandle(token);
                return None;
            }
            let mut len = 0usize;
            while *text.add(len) != 0 && len <= MAX_SID_CHARS {
                len += 1;
            }
            let result = if len <= MAX_SID_CHARS {
                Some(String::from_utf16_lossy(std::slice::from_raw_parts(
                    text, len,
                )))
            } else {
                None
            };
            LocalFree(text.cast());
            CloseHandle(token);
            result
        }
    }

    struct PipeSecurity {
        descriptor: windows_sys::Win32::Security::PSECURITY_DESCRIPTOR,
    }

    impl PipeSecurity {
        fn new(user_sid: &str) -> io::Result<Self> {
            let sddl = format!("D:P(A;;GA;;;SY)(A;;GA;;;BA)(A;;GA;;;{user_sid})");
            let security = wide(&sddl);
            let mut descriptor = std::ptr::null_mut();
            let ok = unsafe {
                ConvertStringSecurityDescriptorToSecurityDescriptorW(
                    security.as_ptr(),
                    SDDL_REVISION_1,
                    &mut descriptor,
                    std::ptr::null_mut(),
                )
            };
            if ok == 0 || descriptor.is_null() {
                return Err(io::Error::last_os_error());
            }
            Ok(Self { descriptor })
        }

        fn attributes(&self) -> SECURITY_ATTRIBUTES {
            SECURITY_ATTRIBUTES {
                nLength: std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32,
                lpSecurityDescriptor: self.descriptor,
                bInheritHandle: 0,
            }
        }
    }

    impl Drop for PipeSecurity {
        fn drop(&mut self) {
            unsafe {
                let _ = LocalFree(self.descriptor.cast());
            }
        }
    }

    fn authenticate_client(
        pipe: HANDLE,
        profile_id: Uuid,
        public_key: &[u8; 32],
    ) -> Option<[u8; 32]> {
        let nonce = random_nonce();
        if send_frame_raw(pipe, CMD_CHALLENGE, &nonce).is_err() {
            return None;
        }
        let (command, signature_bytes) = read_frame(pipe)?;
        if command != CMD_AUTH || signature_bytes.len() != 64 {
            return None;
        }
        let signature_array: [u8; 64] = signature_bytes.as_slice().try_into().ok()?;
        let verifier = VerifyingKey::from_bytes(public_key).ok()?;
        if verifier
            .verify(
                &client_auth_message(profile_id, &nonce),
                &Signature::from_bytes(&signature_array),
            )
            .is_ok()
        {
            Some(nonce)
        } else {
            None
        }
    }

    fn authenticate_guard_pipe(
        file: &mut std::fs::File,
        profile_id: Uuid,
        private_key: &[u8; 32],
    ) -> io::Result<[u8; 32]> {
        let (command, payload) = read_frame_file(file).ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::PermissionDenied,
                "desafio de autenticacion invalido",
            )
        })?;
        if command != CMD_CHALLENGE || payload.len() != 32 {
            return Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "desafio de autenticacion invalido",
            ));
        }
        let nonce: [u8; 32] = payload.as_slice().try_into().map_err(|_| {
            io::Error::new(
                io::ErrorKind::PermissionDenied,
                "desafio de autenticacion invalido",
            )
        })?;
        let signing = ed25519_dalek::SigningKey::from_bytes(private_key);
        let signature =
            ed25519_dalek::Signer::sign(&signing, &client_auth_message(profile_id, &nonce));
        send_frame(file, CMD_AUTH, signature.to_bytes().as_slice())?;
        Ok(nonce)
    }

    fn send_frame_raw(pipe: HANDLE, command: u8, payload: &[u8]) -> io::Result<()> {
        if payload.len() > MAX_FRAME_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "payload demasiado grande",
            ));
        }
        let mut frame = Vec::with_capacity(5 + payload.len());
        frame.push(command);
        frame.extend_from_slice(&(payload.len() as u32).to_le_bytes());
        frame.extend_from_slice(payload);
        let mut offset = 0usize;
        while offset < frame.len() {
            let mut written = 0u32;
            let remaining = &frame[offset..];
            let ok = unsafe {
                windows_sys::Win32::Storage::FileSystem::WriteFile(
                    pipe,
                    remaining.as_ptr().cast(),
                    remaining.len() as u32,
                    &mut written,
                    std::ptr::null_mut(),
                )
            };
            if ok == 0 || written == 0 {
                return Err(io::Error::last_os_error());
            }
            offset += written as usize;
        }
        Ok(())
    }

    fn read_frame_file(file: &mut std::fs::File) -> Option<(u8, Vec<u8>)> {
        let mut command = [0u8; 1];
        std::io::Read::read_exact(file, &mut command).ok()?;
        let mut len_bytes = [0u8; 4];
        std::io::Read::read_exact(file, &mut len_bytes).ok()?;
        let len = u32::from_le_bytes(len_bytes) as usize;
        if len > MAX_FRAME_BYTES {
            return None;
        }
        let mut payload = vec![0u8; len];
        if len > 0 {
            std::io::Read::read_exact(file, &mut payload).ok()?;
        }
        Some((command[0], payload))
    }

    fn read_frame(pipe: HANDLE) -> Option<(u8, Vec<u8>)> {
        let mut command = [0u8; 1];
        read_pipe_exact(pipe, &mut command)?;
        let mut len_bytes = [0u8; 4];
        read_pipe_exact(pipe, &mut len_bytes)?;
        let len = u32::from_le_bytes(len_bytes) as usize;
        if len > MAX_FRAME_BYTES {
            return None;
        }
        let mut payload = vec![0u8; len];
        if len > 0 {
            read_pipe_exact(pipe, &mut payload)?;
        }
        Some((command[0], payload))
    }

    fn read_pipe_exact(pipe: HANDLE, buf: &mut [u8]) -> Option<()> {
        let mut offset = 0usize;
        while offset < buf.len() {
            let mut read = 0u32;
            let ok = unsafe {
                ReadFile(
                    pipe,
                    buf[offset..].as_mut_ptr(),
                    (buf.len() - offset) as u32,
                    &mut read,
                    std::ptr::null_mut(),
                )
            };
            if ok == 0 {
                let error = unsafe { GetLastError() };
                if error == ERROR_BROKEN_PIPE || error == ERROR_NO_DATA {
                    return None;
                }
                return None;
            }
            if read == 0 {
                return None;
            }
            offset += read as usize;
        }
        Some(())
    }

    fn send_ack(pipe: HANDLE, ok: bool, message: Option<&str>) -> io::Result<()> {
        if ok {
            send_frame_raw(pipe, CMD_ACK, &[])
        } else {
            send_frame_raw(
                pipe,
                CMD_NACK,
                message
                    .unwrap_or("OPAC Guard rechazo la operacion")
                    .as_bytes(),
            )
        }
    }

    fn decode_path_payload(payload: &[u8]) -> Option<PathBuf> {
        if payload.is_empty() || payload.len() > MAX_PATH_BYTES {
            return None;
        }
        let text = std::str::from_utf8(payload).ok()?;
        Some(PathBuf::from(text))
    }

    fn wide(value: &str) -> Vec<u16> {
        value.encode_utf16().chain(std::iter::once(0)).collect()
    }

    fn windows_quote_arg(value: &str) -> String {
        if !value.is_empty()
            && !value
                .chars()
                .any(|character| character.is_whitespace() || character == '\"')
        {
            return value.to_owned();
        }

        let mut out = String::with_capacity(value.len() + 2);
        out.push('\"');
        let mut backslashes = 0usize;
        for character in value.chars() {
            if character == '\\' {
                backslashes += 1;
            } else if character == '\"' {
                for _ in 0..(backslashes * 2 + 1) {
                    out.push('\\');
                }
                out.push('\"');
                backslashes = 0;
            } else {
                for _ in 0..backslashes {
                    out.push('\\');
                }
                out.push(character);
                backslashes = 0;
            }
        }
        for _ in 0..(backslashes * 2) {
            out.push('\\');
        }
        out.push('\"');
        out
    }

    fn hex_encode(bytes: &[u8]) -> String {
        bytes.iter().map(|byte| format!("{byte:02x}")).collect()
    }

    fn decode_hex_array<const N: usize>(text: &str) -> Result<[u8; N], String> {
        if text.len() != N * 2 {
            return Err("longitud hexadecimal invalida".to_owned());
        }
        let bytes = text.as_bytes();
        let mut out = [0u8; N];
        for index in 0..N {
            let hi = hex_nibble(bytes[index * 2])?;
            let lo = hex_nibble(bytes[index * 2 + 1])?;
            out[index] = (hi << 4) | lo;
        }
        Ok(out)
    }

    fn hex_nibble(byte: u8) -> Result<u8, String> {
        match byte {
            b'0'..=b'9' => Ok(byte - b'0'),
            b'a'..=b'f' => Ok(byte - b'a' + 10),
            b'A'..=b'F' => Ok(byte - b'A' + 10),
            _ => Err("texto hexadecimal invalido".to_owned()),
        }
    }

    #[cfg(test)]
    mod tests {
        use super::*;

        #[test]
        fn secure_guard_storage_tree_resolves_missing_descendant_under_profiles() {
            let base = std::env::temp_dir()
                .join(format!("opac_guard_tree_match_{}", Uuid::new_v4().simple()));
            let profiles = base.join("profiles");
            let requested = profiles.join(Uuid::new_v4().simple().to_string());
            fs::create_dir_all(&profiles).unwrap();

            let profiles_abs = canonical_path_for_match(&profiles).unwrap();
            let requested_abs = canonical_path_for_match(&requested).unwrap();
            assert!(path_within_root(&requested_abs, &profiles_abs));
            assert!(!path_eq(&requested_abs, &profiles_abs));

            let _ = fs::remove_dir_all(&base);
        }

        #[test]
        fn privileged_helpers_resolve_windows_binaries_from_system32() {
            let system_dir =
                system32_directory().expect("Windows system directory must be available");
            let sc = system32_tool("sc.exe");
            let icacls = system32_tool("icacls.exe");

            assert_eq!(
                sc.file_name().and_then(|name| name.to_str()),
                Some("sc.exe")
            );
            assert_eq!(
                icacls.file_name().and_then(|name| name.to_str()),
                Some("icacls.exe")
            );
            assert!(path_eq(
                sc.parent().expect("sc.exe must have a parent directory"),
                &system_dir
            ));
            assert!(path_eq(
                icacls
                    .parent()
                    .expect("icacls.exe must have a parent directory"),
                &system_dir
            ));
            assert!(
                system_dir
                    .file_name()
                    .and_then(|name| name.to_str())
                    .is_some_and(|name| name.eq_ignore_ascii_case("System32"))
            );
        }

        #[test]
        fn elevated_argument_quoting_handles_paths_with_spaces() {
            assert_eq!(
                windows_quote_arg(r"C:\Program Files\Opac Window\opac_window.exe"),
                r#""C:\Program Files\Opac Window\opac_window.exe""#
            );
            assert_eq!(windows_quote_arg("simple"), "simple");
        }

        #[test]
        fn service_identity_is_unique_per_opac_profile() {
            let profile_a = Uuid::from_u128(1);
            let profile_b = Uuid::from_u128(2);
            assert_eq!(
                service_name_for_profile(&profile_a),
                "OpacGuard-00000000000000000000000000000001"
            );
            assert_ne!(
                pipe_name_for_profile(&profile_a),
                pipe_name_for_profile(&profile_b)
            );
        }

        #[test]
        fn service_configuration_is_scoped_per_opac_profile() {
            let profile_a = Uuid::from_u128(1);
            let profile_b = Uuid::from_u128(2);
            assert_ne!(
                service_name_for_profile(&profile_a),
                service_name_for_profile(&profile_b)
            );
            assert_ne!(
                config_path(&profile_a).unwrap(),
                config_path(&profile_b).unwrap()
            );
            assert_ne!(
                pipe_name_for_profile(&profile_a),
                pipe_name_for_profile(&profile_b)
            );
        }

        #[test]
        fn install_validation_accepts_only_one_real_profile_root() {
            let profile = Uuid::from_u128(3);
            let base =
                std::env::temp_dir().join(format!("opac_guard_profile_root_{}", profile.simple()));
            let profiles = base.join("profiles");
            let root = profiles.join(profile.simple().to_string());
            std::fs::create_dir_all(&root).unwrap();
            assert!(validate_roots_for_profile(&profile, std::slice::from_ref(&root)).is_ok());
            assert!(validate_roots_for_profile(&profile, &[]).is_err());
            assert!(validate_roots_for_profile(&profile, &[root.clone(), root.clone()]).is_err());
            let _ = std::fs::remove_dir_all(base);
        }

        #[test]
        fn install_validation_rejects_wrong_profile_leaf() {
            let profile = Uuid::from_u128(4);
            let base =
                std::env::temp_dir().join(format!("opac_guard_wrong_root_{}", profile.simple()));
            let root = base.join("profiles").join("other");
            std::fs::create_dir_all(&root).unwrap();
            assert!(validate_roots_for_profile(&profile, &[root]).is_err());
            let _ = std::fs::remove_dir_all(base);
        }

        #[test]
        fn configured_roots_require_exactly_one_entry() {
            assert!(validate_configured_roots(&[]).is_err());
            assert!(validate_configured_roots(&[PathBuf::from(r"C:\Opac")]).is_ok());
            assert!(
                validate_configured_roots(
                    &[PathBuf::from(r"C:\Opac"), PathBuf::from(r"C:\Opac2"),]
                )
                .is_err()
            );
        }

        #[test]
        fn protected_extensions_are_exact() {
            assert!(is_protected_file(Path::new("a.OPAC")));
            assert!(is_protected_file(Path::new("keystore.opks")));
            assert!(is_protected_file(Path::new(".opac-folder")));
            assert!(!is_protected_file(Path::new("note.txt")));
            assert!(!is_protected_file(Path::new("backup.opac.tmp")));
        }

        #[test]
        fn root_normalization_removes_nested_roots() {
            let roots = normalize_roots(vec![
                PathBuf::from(r"C:\Opac"),
                PathBuf::from(r"C:\Opac\profiles\one"),
                PathBuf::from(r"C:\Other"),
            ]);
            assert!(roots.contains(&PathBuf::from(r"C:\Opac")));
            assert!(roots.contains(&PathBuf::from(r"C:\Other")));
            assert!(!roots.contains(&PathBuf::from(r"C:\Opac\profiles\one")));
        }

        #[test]
        fn root_normalization_respects_component_boundaries() {
            let roots = normalize_roots(vec![
                PathBuf::from(r"C:\Opac"),
                PathBuf::from(r"C:\Opac2"),
                PathBuf::from(r"C:\Opac\profiles"),
            ]);
            assert!(
                roots
                    .iter()
                    .any(|root| path_eq(root, Path::new(r"C:\Opac")))
            );
            assert!(
                roots
                    .iter()
                    .any(|root| path_eq(root, Path::new(r"C:\Opac2")))
            );
            assert!(
                !roots
                    .iter()
                    .any(|root| path_eq(root, Path::new(r"C:\Opac\profiles")))
            );
        }

        #[test]
        fn config_signature_rejects_unresolvable_root_before_uac() {
            let profile = Uuid::new_v4();
            let private = [35u8; 32];
            let missing =
                std::env::temp_dir().join(format!("opac_guard_missing_root_{}", profile.simple()));
            let result = super::super::guard_config_signature(profile, &[missing], &private);
            assert!(result.is_err());
        }

        #[test]
        fn safe_file_helpers_distinguish_absent_and_regular_files() {
            let dir = std::env::temp_dir().join(format!("opac_guard_safe_file_{}", Uuid::new_v4()));
            std::fs::create_dir_all(&dir).unwrap();
            let file = dir.join("roots.bin");
            assert!(!path_entry_exists(&file).unwrap());
            std::fs::write(&file, b"x").unwrap();
            assert!(path_entry_exists(&file).unwrap());
            assert!(ensure_safe_file(&file).is_ok());
            let _ = std::fs::remove_dir_all(dir);
        }

        #[test]
        fn config_candidate_order_is_primary_then_new_then_backup() {
            let profile = Uuid::from_u128(0x1234);
            let paths = config_candidate_paths(&profile).unwrap();
            let primary = config_path(&profile).unwrap();
            assert_eq!(paths[0], primary);
            assert_eq!(paths[1], primary.with_extension("bin.new"));
            assert_eq!(paths[2], primary.with_extension("bin.bak"));
        }

        #[test]
        fn config_roundtrip_serialization_is_parseable() {
            let profile = Uuid::from_u128(0x4321);
            let private = [33u8; 32];
            let signing = ed25519_dalek::SigningKey::from_bytes(&private);
            let public = signing.verifying_key().to_bytes();
            let base = std::env::temp_dir()
                .join(format!("opac_guard_config_roundtrip_{}", profile.simple()));
            let root = base.join("profiles").join(profile.simple().to_string());
            std::fs::create_dir_all(&root).unwrap();
            let message = config_message(profile, std::slice::from_ref(&root), &public).unwrap();
            let signature = ed25519_dalek::Signer::sign(&signing, &message).to_bytes();
            let data =
                encode_config(&profile, std::slice::from_ref(&root), public, signature).unwrap();
            let parsed = parse_config(&data, &profile).unwrap();
            assert_eq!(parsed.public_key, public);
            assert_eq!(parsed.roots.len(), 1);
            let _ = std::fs::remove_dir_all(base);
        }

        #[test]
        fn config_encoding_contains_one_root_count_only() {
            let profile = Uuid::from_u128(0x5432);
            let private = [34u8; 32];
            let signing = ed25519_dalek::SigningKey::from_bytes(&private);
            let public = signing.verifying_key().to_bytes();
            let base =
                std::env::temp_dir().join(format!("opac_guard_config_shape_{}", profile.simple()));
            let root = base.join("profiles").join(profile.simple().to_string());
            std::fs::create_dir_all(&root).unwrap();
            let message = config_message(profile, std::slice::from_ref(&root), &public).unwrap();
            let signature = ed25519_dalek::Signer::sign(&signing, &message).to_bytes();
            let data =
                encode_config(&profile, std::slice::from_ref(&root), public, signature).unwrap();
            let fixed_header = CONFIG_MAGIC.len() + 16 + 32 + 64 + 4;
            assert!(data.len() > fixed_header);
            let count_offset = CONFIG_MAGIC.len() + 16 + 32 + 64;
            assert_eq!(
                u32::from_le_bytes(data[count_offset..count_offset + 4].try_into().unwrap()),
                1
            );
            let root_len_offset = count_offset + 4;
            assert!(
                u32::from_le_bytes(
                    data[root_len_offset..root_len_offset + 4]
                        .try_into()
                        .unwrap()
                ) > 1
            );
            assert!(parse_config(&data, &profile).is_some());
            let _ = std::fs::remove_dir_all(base);
        }

        #[test]
        fn protection_is_fail_closed_when_workers_do_not_cover_roots() {
            assert!(workers_cover_roots(1, 1));
            assert!(workers_cover_roots(4, 4));
            assert!(!workers_cover_roots(0, 0));
            assert!(!workers_cover_roots(2, 1));
            assert!(!workers_cover_roots(1, 0));
        }

        #[test]
        fn directory_watch_policy_uses_overlapped_notifications() {
            assert_ne!(FILE_LIST_DIRECTORY, 0);
            assert_ne!(FILE_FLAG_OVERLAPPED, 0);
            assert_ne!(FILE_NOTIFY_CHANGE_DIR_NAME, 0);
            assert_ne!(FILE_NOTIFY_CHANGE_FILE_NAME, 0);
        }

        #[test]
        fn protected_handle_contract_does_not_share_write_or_delete() {
            assert_eq!(
                FILE_SHARE_READ & windows_sys::Win32::Storage::FileSystem::FILE_SHARE_READ,
                FILE_SHARE_READ
            );
            assert_eq!(
                FILE_SHARE_READ & windows_sys::Win32::Storage::FileSystem::FILE_SHARE_WRITE,
                0
            );
            assert_eq!(
                FILE_SHARE_READ & windows_sys::Win32::Storage::FileSystem::FILE_SHARE_DELETE,
                0
            );
        }

        #[test]
        fn reparse_point_flag_is_required_by_the_protected_open_policy() {
            assert_ne!(FILE_FLAG_OPEN_REPARSE_POINT, 0);
            assert_ne!(FILE_FLAG_BACKUP_SEMANTICS, 0);
        }

        #[test]
        fn released_tree_uses_component_boundaries() {
            let root = PathBuf::from(r"C:\OpacWindow\profiles\abc");
            assert!(path_within_root(
                Path::new(r"C:\OpacWindow\profiles\abc"),
                &root
            ));
            assert!(path_within_root(
                Path::new(r"C:\OpacWindow\profiles\abc\vaults"),
                &root
            ));
            assert!(!path_within_root(
                Path::new(r"C:\OpacWindow\profiles\abcd"),
                &root
            ));
        }

        #[test]
        fn released_paths_are_distinguished_between_file_and_tree() {
            let file = PathBuf::from(r"C:\Opac\vaults\a.opac");
            let tree = PathBuf::from(r"C:\Opac\vaults");
            let released = vec![
                ReleaseTarget {
                    path: file.clone(),
                    kind: ReleaseKind::File,
                },
                ReleaseTarget {
                    path: tree.clone(),
                    kind: ReleaseKind::Tree,
                },
            ];
            assert!(is_released_file(&file, &released));
            assert!(is_released_tree(&tree, &released));
            assert!(is_released_tree(
                Path::new(r"C:\Opac\vaults\nested\x.opac"),
                &released
            ));

            let file_only = vec![ReleaseTarget {
                path: file.clone(),
                kind: ReleaseKind::File,
            }];
            assert!(is_released_file(&file, &file_only));
            assert!(!is_released_tree(&file, &file_only));
        }

        #[test]
        fn ipc_auth_signature_roundtrip_and_tampering_are_detected() {
            let profile = Uuid::from_u128(0x55);
            let other_profile = Uuid::from_u128(0x56);
            let nonce = [9u8; 32];
            let private = [17u8; 32];
            let signing = ed25519_dalek::SigningKey::from_bytes(&private);
            let public = signing.verifying_key();
            let message = client_auth_message(profile, &nonce);
            let signature = ed25519_dalek::Signer::sign(&signing, &message);
            public.verify(&message, &signature).unwrap();
            assert!(
                public
                    .verify(&client_auth_message(other_profile, &nonce), &signature)
                    .is_err()
            );
            let mut altered_nonce = nonce;
            altered_nonce[0] ^= 0x80;
            assert!(
                public
                    .verify(&client_auth_message(profile, &altered_nonce), &signature)
                    .is_err()
            );
        }

        #[test]
        fn configured_roots_signature_rejects_changed_path() {
            let profile = Uuid::from_u128(0x77);
            let base =
                std::env::temp_dir().join(format!("opac_guard_changed_root_{}", profile.simple()));
            let root = base.join("original");
            let altered = base.join("altered");
            std::fs::create_dir_all(&root).unwrap();
            std::fs::create_dir_all(&altered).unwrap();
            let roots = vec![root.clone()];
            let private = [33u8; 32];
            let (public, signature) =
                super::super::guard_config_signature(profile, &roots, &private).unwrap();
            let message = config_message(profile, &roots, &public).unwrap();
            let verifier = VerifyingKey::from_bytes(&public).unwrap();
            verifier
                .verify(&message, &Signature::from_bytes(&signature))
                .unwrap();
            let altered_roots = vec![altered];
            let altered_message = config_message(profile, &altered_roots, &public).unwrap();
            assert!(
                verifier
                    .verify(&altered_message, &Signature::from_bytes(&signature))
                    .is_err()
            );
            let _ = std::fs::remove_dir_all(base);
        }

        #[test]
        fn release_path_command_has_one_authoritative_command_code() {
            assert_eq!(CMD_RELEASE_PATH, 4);
            let file = PathBuf::from(r"C:\Opac\one.opac");
            let released = vec![ReleaseTarget {
                path: file.clone(),
                kind: ReleaseKind::File,
            }];
            assert!(is_released_file(&file, &released));
            assert!(!is_released_tree(&file, &released));
        }

        #[test]
        fn signed_commands_are_bound_to_session_sequence_profile_and_payload() {
            let profile = Uuid::from_u128(0x1111);
            let other_profile = Uuid::from_u128(0x2222);
            let session_nonce = [7u8; 32];
            let other_nonce = [8u8; 32];
            let private = [61u8; 32];
            let signing = ed25519_dalek::SigningKey::from_bytes(&private);
            let public = signing.verifying_key();
            let payload = br"C:\Opac\vaults\one.opac";
            let command = CMD_RELEASE_PATH;
            let sequence = 9u64;
            let message =
                client_command_message(profile, &session_nonce, command, sequence, payload);
            let signature = ed25519_dalek::Signer::sign(&signing, &message);
            public.verify(&message, &signature).unwrap();
            assert!(
                public
                    .verify(
                        &client_command_message(profile, &other_nonce, command, sequence, payload),
                        &signature,
                    )
                    .is_err()
            );
            assert!(
                public
                    .verify(
                        &client_command_message(
                            other_profile,
                            &session_nonce,
                            command,
                            sequence,
                            payload
                        ),
                        &signature,
                    )
                    .is_err()
            );
            assert!(
                public
                    .verify(
                        &client_command_message(
                            profile,
                            &session_nonce,
                            command,
                            sequence + 1,
                            payload
                        ),
                        &signature,
                    )
                    .is_err()
            );
            assert!(
                public
                    .verify(
                        &client_command_message(
                            profile,
                            &session_nonce,
                            CMD_LOCK,
                            sequence,
                            payload
                        ),
                        &signature,
                    )
                    .is_err()
            );
            assert!(
                public
                    .verify(
                        &client_command_message(
                            profile,
                            &session_nonce,
                            command,
                            sequence,
                            br"C:\Opac\vaults\other.opac"
                        ),
                        &signature,
                    )
                    .is_err()
            );
        }

        #[test]
        fn release_tree_covers_only_descendants() {
            let tree = PathBuf::from(r"C:\Opac\vaults\dead");
            let released = vec![ReleaseTarget {
                path: tree.clone(),
                kind: ReleaseKind::Tree,
            }];
            assert!(is_released_tree(
                Path::new(r"C:\Opac\vaults\dead"),
                &released
            ));
            assert!(is_released_tree(
                Path::new(r"C:\Opac\vaults\dead\child.opac"),
                &released
            ));
            assert!(!is_released_tree(
                Path::new(r"C:\Opac\vaults\deadly\child.opac"),
                &released
            ));
            assert!(!is_released_tree(
                Path::new(r"C:\Opac\vaults\other\child.opac"),
                &released
            ));
        }

        #[test]
        fn active_release_limit_is_bounded() {
            assert_eq!(MAX_ACTIVE_RELEASES, 8);
        }

        #[test]
        fn broader_tree_exception_is_detectable_by_component_boundary() {
            let tree = PathBuf::from(r"C:\Opac\vaults");
            let child = PathBuf::from(r"C:\Opac\vaults\one");
            let sibling = PathBuf::from(r"C:\Opac\vaults2\one");
            assert!(path_within_root(&child, &tree));
            assert!(!path_within_root(&sibling, &tree));
        }

        #[test]
        fn releasable_path_validation_stays_inside_the_configured_profile() {
            let root = std::env::temp_dir().join(format!("opac-guard-release-{}", Uuid::new_v4()));
            let nested = root.join("vault");
            let protected_file = root.join("secret.opac");
            let plain_file = root.join("note.txt");
            fs::create_dir_all(&nested).unwrap();
            fs::write(&protected_file, b"ciphertext").unwrap();
            fs::write(&plain_file, b"plain").unwrap();

            let file_target =
                validate_releasable_path(&protected_file, std::slice::from_ref(&root)).unwrap();
            assert_eq!(file_target.kind, ReleaseKind::File);
            assert!(validate_releasable_path(&plain_file, std::slice::from_ref(&root)).is_err());
            let tree_target =
                validate_releasable_path(&nested, std::slice::from_ref(&root)).unwrap();
            assert_eq!(tree_target.kind, ReleaseKind::Tree);
            assert!(validate_releasable_path(&root, std::slice::from_ref(&root)).is_err());

            let outside =
                std::env::temp_dir().join(format!("opac-guard-outside-{}.opac", Uuid::new_v4()));
            fs::write(&outside, b"ciphertext").unwrap();
            assert!(validate_releasable_path(&outside, std::slice::from_ref(&root)).is_err());

            let _ = fs::remove_file(outside);
            let _ = fs::remove_dir_all(root);
        }

        #[test]
        fn releasable_path_validation_canonicalizes_configured_root() {
            let root =
                std::env::temp_dir().join(format!("opac-guard-canonical-root-{}", Uuid::new_v4()));
            let protected_file = root.join("secret.opac");
            fs::create_dir_all(&root).unwrap();
            fs::write(&protected_file, b"ciphertext").unwrap();

            let canonical_root = fs::canonicalize(&root).unwrap();
            let target =
                validate_releasable_path(&protected_file, std::slice::from_ref(&root)).unwrap();
            assert_eq!(target.kind, ReleaseKind::File);
            assert_eq!(target.path, fs::canonicalize(&protected_file).unwrap());

            let _ = fs::remove_file(protected_file);
            let _ = fs::remove_dir_all(canonical_root);
        }

        #[test]
        fn recovery_order_prefers_authenticated_candidate_and_repairs_primary() {
            let profile = Uuid::from_u128(0x88);
            let paths = config_candidate_paths(&profile).unwrap();
            assert!(paths[1].ends_with("roots.bin.new"));
            assert!(paths[2].ends_with("roots.bin.bak"));
            assert_ne!(paths[0], paths[1]);
            assert_ne!(paths[1], paths[2]);
        }

        #[test]
        fn protected_configuration_is_tied_to_the_profile_id_and_public_key() {
            let profile = Uuid::from_u128(0x99);
            let root =
                std::env::temp_dir().join(format!("opac_guard_config_tied_{}", profile.simple()));
            std::fs::create_dir_all(&root).unwrap();
            let roots = vec![root.clone()];
            let private = [44u8; 32];
            let (public, signature) =
                super::super::guard_config_signature(profile, &roots, &private).unwrap();
            let message = config_message(profile, &roots, &public).unwrap();
            let verifier = VerifyingKey::from_bytes(&public).unwrap();
            verifier
                .verify(&message, &Signature::from_bytes(&signature))
                .unwrap();
            let other_public = ed25519_dalek::SigningKey::from_bytes(&[45u8; 32])
                .verifying_key()
                .to_bytes();
            let other_message = config_message(profile, &roots, &other_public).unwrap();
            assert!(
                verifier
                    .verify(&other_message, &Signature::from_bytes(&signature))
                    .is_err()
            );
            let _ = std::fs::remove_dir_all(root);
        }
    }
    #[test]
    fn uninstall_cleanup_removes_only_known_files() {
        let dir = std::env::temp_dir().join(format!("opac-guard-cleanup-{}", Uuid::new_v4()));
        fs::create_dir_all(&dir).unwrap();
        let config = dir.join("roots.bin");
        let config_new = dir.join("roots.bin.new");
        let config_bak = dir.join("roots.bin.bak");
        let guard = dir.join("opac_guard.exe");
        let guard_new = dir.join("opac_guard.exe.new");
        let unrelated = dir.join("keep.me");
        for path in [
            &config,
            &config_new,
            &config_bak,
            &guard,
            &guard_new,
            &unrelated,
        ] {
            fs::write(path, b"x").unwrap();
        }
        for path in [&config, &config_new, &config_bak, &guard, &guard_new] {
            remove_file_if_exists(path).unwrap();
        }
        assert!(!config.exists());
        assert!(!config_new.exists());
        assert!(!config_bak.exists());
        assert!(!guard.exists());
        assert!(!guard_new.exists());
        assert!(unrelated.exists());
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn uninstall_cleanup_does_not_recursively_delete_nonempty_directory() {
        let dir = std::env::temp_dir().join(format!("opac-guard-dir-{}", Uuid::new_v4()));
        fs::create_dir_all(&dir).unwrap();
        fs::write(dir.join("child"), b"keep").unwrap();
        assert!(remove_dir_if_empty(&dir).is_err());
        assert!(dir.exists());
        fs::remove_dir_all(&dir).unwrap();
    }
}

#[cfg(windows)]
#[allow(unused_imports)]
pub use windows_guard::{
    GuardClient, GuardServiceStatus, current_user_sid, handle_embedded_admin_command,
    install_service_elevated, main_entry, service_status, uninstall_service_elevated,
};

#[cfg(not(windows))]
pub mod non_windows {
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub enum GuardServiceStatus {
        Missing,
        Stopped,
        Running,
        Other(u32),
        Unavailable(u32),
    }

    #[derive(Debug)]
    pub struct GuardClient;
    impl GuardClient {
        pub fn start(_profile_id: uuid::Uuid, _locked: bool, _signing_key: [u8; 32]) -> Self {
            Self
        }
        pub fn set_path_in_use(&self, _path: std::path::PathBuf) -> Result<(), String> {
            Ok(())
        }
        pub fn set_path_protected(&self, _path: std::path::PathBuf) -> Result<(), String> {
            Ok(())
        }
        pub fn set_locked(&self) -> Result<(), String> {
            Ok(())
        }
        pub fn shutdown(&mut self) {}
    }

    pub fn main_entry(_args: &[String]) -> i32 {
        1
    }
    pub fn handle_embedded_admin_command(_args: &[String], _guard_bytes: &[u8]) -> Option<i32> {
        None
    }
    pub fn service_status(_profile_id: uuid::Uuid) -> GuardServiceStatus {
        GuardServiceStatus::Missing
    }
    pub fn current_user_sid() -> Result<String, String> {
        Err("OPAC Guard solo esta disponible en Windows.".to_owned())
    }
    pub fn install_service_elevated(
        _profile_id: uuid::Uuid,
        _roots: &[std::path::PathBuf],
        _public_key: [u8; 32],
        _config_signature: [u8; 64],
    ) -> Result<(), String> {
        Err("OPAC Guard solo esta disponible en Windows.".to_owned())
    }
    pub fn uninstall_service_elevated(
        _profile_id: uuid::Uuid,
        _private_key: [u8; 32],
    ) -> Result<(), String> {
        Err("OPAC Guard solo esta disponible en Windows.".to_owned())
    }
}

#[cfg(not(windows))]
pub use non_windows::{
    GuardClient, GuardServiceStatus, current_user_sid, handle_embedded_admin_command,
    install_service_elevated, main_entry, service_status, uninstall_service_elevated,
};
