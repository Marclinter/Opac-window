# Fixed86 — cobertura de captura por región y por ventana

La protección de capturas de Fixed86 sigue basándose en `SetWindowDisplayAffinity` con `WDA_EXCLUDEFROMCAPTURE` sobre el HWND de nivel superior de OPAC.

No se añade un modo separado para "región" o "ventana": Windows aplica la afinidad al contenido de la ventana, por lo que las capturas compatibles que seleccionen una región o la propia ventana también deben excluir el contenido protegido.

Se añade además seguimiento del HWND protegido. Si la ventana nativa se recrea y obtiene otro HWND, OPAC reaplica automáticamente `WDA_EXCLUDEFROMCAPTURE` aunque el usuario no haya cambiado la preferencia.

La protección continúa dependiendo de que el mecanismo de captura respete la API de Windows y de que DWM esté componiendo el escritorio.
