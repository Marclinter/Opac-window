# OpacFixed208 — correcciones de compilación y regresión

Base: **OpacFixed207**.

Correcciones aplicadas tras `cargo check` / `cargo clippy` en Windows:

- `IMFSourceReaderCallback_Impl` ahora se implementa sobre el tipo generado `AsyncSourceReaderCallback_Impl`, que es el patrón requerido por `#[windows_core::implement(...)]` en `windows-core`/`windows-rs` 0.62.x.
- `VideoDecoderWorker` vuelve a recibir una referencia compartida al estado `playing`, requerida por el cálculo de buffering.
- El `Sender<VideoDecoderStatus>` usado dentro del hilo decoder se clona antes del `move`, evitando `E0382`.
- Eliminada la asignación inicial inútil de `expected_generation`, evitando el warning que se convierte en error con `-D warnings`.
- `guard`: la invariantes de `MAX_ACTIVE_RELEASES > 1` se trasladó a una aserción de compilación; el test conserva la regresión del valor público esperado sin provocar `clippy::assertions_on_constants`.
- Aplicado el formato pendiente reclamado por `cargo fmt --check` en `vault/mod.rs` y `video_preview.rs`.

No se han cambiado los límites ni el diseño de sincronización vídeo/audio de Fixed207.
