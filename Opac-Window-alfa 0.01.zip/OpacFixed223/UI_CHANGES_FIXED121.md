# Fixed121 — Corrección de textura en preview

Se corrige el único error reportado por `cargo check` en Fixed120.

- En `image_preview_panel`, `self.preview_image_texture.as_ref()` ya entrega `&TextureHandle`.
- La variable `texture` era por tanto un `&TextureHandle`; pasar `&texture` producía `&&TextureHandle`.
- Se usa `egui::Image::from_texture(texture)` para satisfacer la API de egui 0.36.2.
- No se modifica la ruta de vídeo ni la lógica de reproducción/seek.
