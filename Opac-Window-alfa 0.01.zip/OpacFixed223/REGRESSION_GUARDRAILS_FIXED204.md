# Fixed204 — guardas contra regresiones

## Objetivo

Este documento acompaña a la base Fixed204 para que futuras correcciones no reintroduzcan los problemas detectados durante la evolución del pipeline de vídeo y del núcleo de Cajas Fuertes.

## Reglas que deben conservarse

### Vídeo

1. **60 FPS es el máximo integrado.** `VIDEO_MAX_FPS` controla la admisión/presentación; no debe utilizarse para forzar un nuevo frame rate al Source Reader.
2. **El buffer es dinámico.** La memoria de frames no vuelve al modelo fijo de 256 MiB/60 frames. La única barrera dura de seguridad es 1 GiB de memoria privada del proceso, con margen interno.
3. **La admisión antes de un seek está rate-limited.** No se deben copiar todos los samples desde el keyframe hasta el objetivo. Solo se conserva el último frame útil con una cadencia máxima de 60 FPS.
4. **Una sola lectura async pendiente por sesión.** Después de cada `OnReadSample`, el coordinador decide si solicita la siguiente. No acumular solicitudes concurrentes sin necesidad.
5. **Las generaciones son obligatorias.** Seek, restart, cambio de media type y cierre deben impedir que frames/señales de una generación vieja lleguen a la presentación.
6. **`Flush` debe completarse antes de destruir la sesión.** `shutdown_reader_session()` recibe la sesión por valor. No sustituirlo por una referencia mutable y `drop(&session)`.
7. **El callback no espera a la GUI.** La transferencia al pipeline se hace mediante colas acotadas y condvars.
8. **Audio maestro.** Durante `audio_clock_pending && !audio_clock_active`, el scheduler no puede avanzar mediante su reloj monotónico.
9. **EOS no es automáticamente un error.** Solo es un fallo de vídeo si la generación llegó a EOS sin producir ningún frame utilizable.
10. **`IMFSample` no cruza hilos.** El callback convierte a memoria Rust segura y el procesador trabaja con esos buffers.

### Núcleo / Cajas Fuertes

11. `KeyStore::create_vault()` devuelve `Result`; todos los call sites internos deben tratar el error.
12. Todas las variantes de alta de Vault reutilizan las mismas validaciones de nombre/ubicación y unicidad.
13. `validate_keystore_body()` debe rechazar estados persistidos incoherentes, incluidos IDs/ubicaciones duplicadas y caracteres de control.
14. Los verificadores V2 deben usar el `chunk_size` almacenado en el header, no asumir el valor por defecto.
15. El borrado recursivo debe volver a comprobar las entradas inmediatamente antes de eliminarlas y nunca borrar entradas no gestionadas.
16. Los accesos a archivos gestionados deben pasar por las rutinas seguras que rechazan symlinks/reparse points.

## Errores históricos que no deben repetirse

- Añadir parámetros a una función y olvidar un call site: antes de cambiar firmas, buscar todos los usos.
- Reestructurar argumentos solo para satisfacer Clippy sin comprobar el flujo completo.
- Confiar en `Path::exists()` como comprobación de una entrada que puede ser un enlace roto; para seguridad usar `symlink_metadata()`.
- Calcular chunks verificados con `DEFAULT_CHUNK_SIZE` cuando el archivo almacena un tamaño explícito.
- Mantener un buffer de vídeo basado exclusivamente en número fijo de frames para fuentes VFR/24/30/60/120 FPS.
- Hacer un seek sin invalidar la generación anterior.
- Copiar todos los samples entre el keyframe y el objetivo del seek solo para actualizar un único fallback.

## Procedimiento de validación obligatorio

Antes de seguir desarrollando desde una nueva base:

```powershell
cargo fmt --check
cargo check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-targets --no-fail-fast
cargo build --release --locked
```

Para el preview de vídeo, además de los tests unitarios hay que probar realmente en Windows:

- vídeo de 24, 30 y 60 FPS;
- vídeo fuente de 120 FPS para comprobar el techo de 60 FPS;
- VFR;
- vídeo de varios minutos;
- pausa/reanudación;
- seek adelante, atrás, repetido y cerca de EOS;
- pérdida/reanudación del audio;
- cierre de la preview mientras hay lectura async pendiente;
- vídeos con cambios de media type compatibles con Media Foundation.

La ausencia de Rust/Cargo en el entorno de revisión no debe interpretarse como una validación de compilación. La validación real debe hacerse en el Windows objetivo.

## Fixed206 — windows-rs 0.62 callback macro y enum de sincronización

La implementación COM de `IMFSourceReaderCallback` con `windows-rs 0.62.2` debe tener disponible el crate directo `windows-core`, porque la macro `#[windows_core::implement(...)]` genera referencias a `windows_core` y el trait generado utiliza las interfaces del mismo crate. Mantener `windows = 0.62.2` sin la dependencia directa puede producir `E0433`/`IUnknownImpl` al compilar.

Para parámetros `Ref<'_, IMFSample>` de callbacks, utilizar `psample.as_ref()` para obtener el `Option<&IMFSample>`; no usar APIs inexistentes como `windows::core::ref_as_default`.

El tipo `VideoSyncAction` es parte de la lógica de sincronización A/V y debe permanecer definido junto a `VideoControlCommand`; las funciones `decide_video_sync` y el scheduler dependen de `Wait`, `Render`, `Drop` y `Resync(Duration)`. Una refactorización que elimine el enum provoca una cascada de errores `E0433/E0425`.
