# UI Changes — Fixed161

## Video preview: open with default player

The integrated video preview now shows an `Abrir en el reproductor predeterminado` action below the preview, even when the integrated preview loads successfully.

The action reuses the existing secure external-open flow: the selected vault file is copied/decrypted into the private session temporary directory and Windows opens that temporary copy using the system's default application association. The encrypted vault file is never opened directly by the external player.

The integrated preview path itself is unchanged in this Fixed; the known video preview playback-speed issue remains a separate performance task.
