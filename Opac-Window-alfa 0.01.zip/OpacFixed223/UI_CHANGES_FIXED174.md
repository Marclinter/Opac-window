# Opac Window — Fixed174

## Vista previa de vídeo: resolución y precarga

- La salida de vídeo para la vista previa se limita a un máximo de 640×640 px manteniendo la relación de aspecto y sin ampliar vídeos pequeños.
- Se añadió una precarga interna acotada de hasta 24 fotogramas y aproximadamente 500 ms por delante del reloj de audio.
- El buffer usa memoria predecible y se vacía al hacer seek/restart o cuando cambia la generación de control.
- La cola de eventos GUI aumenta moderadamente para soportar pequeños bloqueos de la interfaz sin convertirla en un buffer de memoria ilimitado.
- El reloj de audio sigue siendo la referencia A/V; los frames adelantados se muestran o descartan según sus timestamps.
