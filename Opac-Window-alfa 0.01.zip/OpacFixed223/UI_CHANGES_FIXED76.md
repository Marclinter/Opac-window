# UI_CHANGES_FIXED76

## Correcciones de compilacion de OPAC Guard

Fixed76 corrige los errores detectados por `cargo test --workspace --all-targets` en Windows con `windows-sys 0.61.2`.

Cambios principales:

- `PIPE_ACCESS_DUPLEX` se importa desde `Win32::Storage::FileSystem`.
- `WAIT_OBJECT_0` y `WAIT_TIMEOUT` se importan desde `Win32::Foundation`.
- `CreateFileW` recibe un puntero nulo compatible con la firma de `windows-sys 0.61.2` para `hTemplateFile`.
- `ReadFile` usa directamente el puntero `*mut u8` que requiere `windows-sys 0.61.2`.
- Los tests compartidos importan el trait `Verifier` de `ed25519-dalek`.
- El handle Win32 usado como evento de parada no se captura directamente en el cierre de `thread::spawn`: se transporta como `isize` y se reconstruye dentro del worker.
- `normalize_roots` usa un reborrow al canonicalizar un `PathBuf` mutable.
- Se corrige el lifetime de `to_string_lossy()` al serializar rutas.
- Se valida `guard_path.parent()` de forma compatible con `Result`.
- `run_service` valida el SID sin dejar una variable no usada.
- `arm_protection` conserva el número de raíces antes de consumir el vector al crear workers.

No se cambió la lógica funcional de protección de Guard en este arreglo; el objetivo es que el workspace vuelva a compilar y permita ejecutar la batería de tests completa en Windows.
