# Fixed147 - corrección de fotogramas RGB32 de Media Foundation

La vista previa de vídeo podía mostrar fotogramas con bandas, líneas y desplazamiento horizontal porque `decode_sample_to_rgba` asumía que cada fila ocupaba exactamente `width * 4` bytes. Media Foundation puede exponer un búfer 2D con padding adicional por fila o con orientación bottom-up.

Fixed147 conserva el búfer nativo del sample, usa `IMF2DBuffer::Lock2D` cuando está disponible y copia fila por fila respetando el pitch real. Si el búfer no es 2D, usa `MF_MT_DEFAULT_STRIDE` como fallback y también soporta stride negativo.

Se añadieron pruebas unitarias para padding por fila y stride negativo.

La mejora de arranque A/V de Fixed146 se conserva. OPAC Guard no fue modificado.
