# OpacFixed213 — endurecimiento de pruebas tras auditoría de Fixed212

Base: OpacFixed212.

Objetivo de esta capa: garantizar que las correcciones de 212 no estén ocultando fallos mediante fixtures demasiado permisivos.

Cambios:
1. Se mantiene la resolución de rutas de 212 y su regresión de padres intermedios inexistentes.
2. Se mantiene la corrección de admisión de frames durante seek: el primer frame en/tras el objetivo entra y los siguientes siguen sujetos a la cadencia.
3. La simulación de reproducción ya no reduce el contrato de `start()` a "un frame": calcula el número de frames realmente disponibles hasta el final y exige que el buffer cumpla exactamente ese mínimo.
4. Se añade una prueba independiente que conserva el escenario de 2 segundos de adelanto de audio y exige un hard-resync; así, el cambio del fixture de forward-seek de 2 s a 100 ms no elimina la cobertura de esa ruta.
5. La contraseña de exportación del test de importación sigue cumpliendo la política para que el test alcance la condición de ubicación duplicada.

No se modifican algoritmos criptográficos, Guard ni el pipeline Media Foundation de producción.
