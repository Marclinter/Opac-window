# Opac Window — Fixed195

## Vista previa de vídeo

Se separa la decodificación de Media Foundation del planificador de reproducción.
Esto evita que una llamada lenta a `ReadSample` o una conversión RGB32 bloquee el
vídeo mientras todavía existen fotogramas decodificados disponibles.

El decodificador mantiene una cola acotada de 60 fotogramas: 30 de adelanto más
30 de reserva. El planificador conserva únicamente 6 fotogramas de staging y la
cola de eventos de la GUI mantiene otros 6.

Al iniciar y después de un seek manual, el audio permanece pausado hasta que se
ha reconstruido el bloque de 30 fotogramas. Los seeks incrementan la generación
antes de publicar el destino bajo el mutex, evitando que el decodificador pueda
consumir un destino con una generación antigua.

Los fotogramas siguen viajando como `Zeroizing<Vec<u8>>` y las generaciones
eliminan cualquier fotograma pendiente de posiciones anteriores.
