# Fixed148 - regresiones de reproducción manual y rendimiento de cola

Se añadió una regresión para garantizar que un vídeo pausado solo decodifica un fotograma inicial (o uno solicitado explícitamente tras un seek), y que la reproducción normal sigue permitiendo la lectura continua de muestras.

La prueba visual manual debe comprobar que:

- al seleccionar un vídeo, aparece un fotograma estático y el control muestra `▶`;
- el audio permanece detenido hasta pulsar `▶`;
- al pulsar `▶`, vídeo y audio comienzan juntos;
- al pausar, el reloj de audio deja de gobernar la posición;
- vídeos con varios fotogramas no provocan múltiples subidas de textura por tick de la GUI.

La corrección de stride de Fixed147 debe seguir validada con los tests existentes.

Para vídeos que antes se reproducían con una cadencia muy baja, comprobar que la nueva ruta de procesamiento avanzado mantiene una cadencia continua y que el consumo de CPU disminuye cuando Windows dispone de transformaciones multimedia compatibles.
