# SECURITY_REVIEW_FIXED130

Esta revision endurece el proyecto en todas las superficies auditadas salvo OPAC Guard, que permanece sin cambios por decision explicita.

## Cambios aplicados

- La instancia de GUI mantiene un lock interproceso persistente sobre `profiles.oprp`. Si otra instancia ya posee el lock, la GUI no entra en modo fallback operativo: el catalogo queda bloqueado y no permite crear ni modificar perfiles.
- Cada `KeyStoreSession` mantiene un lock exclusivo interproceso mientras la sesion esta desbloqueada; las escrituras de esa sesion usan el camino interno ya protegido por ese lock. El catalogo de perfiles tambien conserva su lock mientras la instancia de GUI esta activa.
- Los archivos de persistencia y catalogo se leen con limites de tamaño antes de reservar memoria y, en Windows, se abren rechazando puntos de reanalisis.
- Los temporales de sesion, precarga y archivos abiertos externamente quedan bajo `LocalAppData\OpacWindow\session-temp`, con nombres aleatorios, permisos privados en Unix, marcador de PID y limpieza de sesiones huerfanas despues de un periodo de gracia.
- La cancelacion de una preparacion de video conserva el `JoinHandle` hasta que termina el worker antes de retirar el temporal plaintext.
- Los directorios de perfil y de Cajas se crean/restablecen con permisos privados donde la plataforma lo permite.
- El renombrado V2 de `.opac` se realiza mediante reescritura streaming por chunks, evitando materializar archivos grandes completos en memoria.
- La politica de contrasena maestra se impone tambien en el core (12..512 bytes); la politica de exportacion V2 aplica el mismo minimo/máximo y el importador V2 exige esa politica. Los formatos exportados V1 siguen siendo legibles para compatibilidad.
- El portapapeles de Vault Key se limpia automaticamente tras 30 segundos y tambien al bloquear la Caja, pero no borra un valor que el usuario haya sustituido por otro contenido.
- Los intentos de PIN en GUI aplican backoff exponencial temporal; esto es una friccion de interfaz y no pretende sustituir la resistencia offline de Argon2id.
- Las dependencias directas estan fijadas a versiones exactas y una build `release` falla de forma cerrada si falta `Cargo.lock`; debe generarse y comprometerse antes de una release.
- Se mantienen comprobaciones de rutas y handles para reducir TOCTOU, rechazando symlink/reparse points en las superficies de lectura sensibles.
- El renombrado V2 vuelve a posicionar el archivo de origen al inicio tras leer la metadata antes de iniciar la reescritura por chunks; así la validación previa no consume el encabezado que necesita el streaming.
- Las copias de caché plaintext de la GUI se abren mediante un handle que rechaza symlink/reparse points tanto antes como después de la apertura, reduciendo una carrera de sustitución en el cache de precarga.

## Pendientes deliberados

`Cargo.lock` no se inventa manualmente en este entorno porque requiere la resolucion real del grafo de dependencias por Cargo. En la maquina de build debe ejecutarse `cargo generate-lockfile` y, para releases, usar `cargo build --release --locked`.

La semantica completa de operaciones de filesystem basadas en rutas sigue teniendo una ventana TOCTOU teorica frente a un proceso del mismo usuario que manipule simultaneamente el arbol; esta version reduce esa superficie mediante aperturas seguras por handle, pero no pretende presentar esa clase de defensa como absoluta.

No se modifica OPAC Guard en Fixed130.


Fixed130 endurece tambien las ACL de los directorios privados de la GUI/Core, el borrado del secreto del portapapeles al salir, las lecturas genericas en memoria, y el lock Unix mediante flock para que un crash no deje un lock lateral huerfano. OPAC Guard no ha sido modificado.
