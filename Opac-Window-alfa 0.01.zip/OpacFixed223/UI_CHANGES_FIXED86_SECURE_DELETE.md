# Fixed86 — limpieza de copias descifradas tras borrado

Se reforzó la limpieza de archivos temporales descifrados para que un error momentáneo de `remove_file` no deje una copia fuera del flujo de limpieza.

## Cambios

- Las copias de `PreloadAll` se eliminan mediante un helper común.
- Si `remove_file` falla y el archivo sigue existiendo, su ruta se guarda en una cola de limpieza diferida.
- La cola se reintenta automáticamente durante el ciclo de la aplicación.
- La misma cola se usa cuando falla la actualización de una copia `PreloadAll` después de editar un archivo.
- Los temporales de audio generados específicamente para la reproducción también usan la cola de limpieza diferida.
- Una ruta que ya no existe se descarta de la cola automáticamente.
- La limpieza diferida no borra toda la caché de `PreloadAll`: afecta únicamente al archivo pendiente.

## Limitación

Si otro proceso mantiene un archivo plaintext abierto, Windows puede impedir su eliminación mientras ese proceso lo esté usando. OPAC vuelve a intentarlo mientras permanece ejecutándose; al cerrar el proceso no puede garantizar una eliminación física posterior que dependa de otro proceso todavía abierto.
