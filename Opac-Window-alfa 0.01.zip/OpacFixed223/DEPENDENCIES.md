# Dependencias y política de actualización

## Revisado: 2026-09-30

Las dependencias directas se actualizan cuando el cambio aporta mantenimiento, compatibilidad
con la cadena criptográfica actual o correcciones relevantes, sin cambiar formatos persistentes
sin una migración explícita.

### Dependencias actuales

- `argon2` 0.6
- `chacha20poly1305` 0.11
- `rand` 0.10.1+
- `ed25519-dalek` 2.1: identidad Ed25519 por perfil para autenticacion del Guard.
- `zeroize` 1.9
- `thiserror` 2
- `serde` 1.0.x
- `uuid` 1.26.x
- `eframe` 0.36.2 para la GUI nativa (MSRV 1.95)
- `postcard` 1.1.x con `alloc`
- `rfd` 0.17.2: dialogos nativos de seleccion/guardado. Se usa para la exportacion explicita y para la importacion manual de archivos; el selector de importacion usa la API asincrona para no bloquear la GUI.
- `pdfboss-core` 2.11.0 y `pdfboss-render` 2.11.0: parser y renderizador PDF en Rust puro para la vista previa visual integrada, sin dependencia de PDFium/MuPDF ni de una biblioteca C externa.

El proyecto usa Edition 2024 y declara `rust-version = "1.95"`.

### Cargo.lock y reproducibilidad

Las versiones exactas del grafo de dependencias no se fijan con `=x.y.z` en `Cargo.toml`.
Los manifiestos declaran requisitos SemVer razonables y `Cargo.lock` registra las versiones
exactas elegidas por Cargo para el build. Las compilaciones de release requieren ese lockfile
y `build.rs` fuerza también `--locked` al compilar el Guard embebido.

Para preparar o actualizar el grafo localmente, ejecutar `cargo generate-lockfile` (o el comando
normal de Cargo que actualice el lockfile) y revisar el diff antes de una release. Las releases
deben construirse con `cargo build --release --locked`.

### Migración desde bincode

`bincode` 1.3.3 estaba marcado como **unmaintained** por RustSec (RUSTSEC-2025-0141). No se
migra a la línea 3.x: esa release no supone una continuación mantenida del proyecto.

La migración de Opac Window se ha completado para las nuevas escrituras: `.opac` V2,
`keystore.opks` V2 y `.opackey` V2 usan Postcard. Para no romper instalaciones existentes,
el núcleo contiene un lector legacy mínimo que entiende únicamente las estructuras y límites
que Opac Window produjo con la codificación histórica de bincode 1.x. No existe código de
escritura legacy y `bincode` ya no aparece en `Cargo.toml` ni debe aparecer en `Cargo.lock`.

### Compatibilidad funcional

Las Vault Keys siguen siendo independientes por Caja Fuerte. La migración de serialización no
cambia ninguna clave, nonce, derivación de claves ni ciphertext. Solo cambia la representación
de las estructuras serializadas dentro de datos ya cifrados y autenticados.


## GUI

`eframe 0.36.2` / `egui 0.36.2` se usan con Rust 1.95+ y `default-features = false` con `default_fonts`, `glow` y `accesskit`.

- `egui_commonmark 0.25.0`: previsualizacion Markdown compatible con `egui 0.36`, sin funciones de red/carga de imagenes activadas.
- `rodio 0.22.2`: reproduccion local con `playback` y decodificacion FLAC/MP3/MP4/Vorbis/WAV.

### `image`

`image 0.25.10` se usa únicamente para decodificar PNG, JPEG, GIF y WebP durante la vista previa local. Los límites de tamaño y píxeles se aplican antes de decodificar y el decodificador está aislado para que una entrada que provoque un panic no derribe la GUI cuando el perfil de panic permite recuperarlo.

### Importación manual y GUI

El selector nativo de importación (`rfd`) no ejecuta el trabajo criptográfico: solo recoge las rutas
elegidas por el usuario. En la GUI de Fixed60 el selector se lanza en un hilo dedicado y entrega la
selección mediante `mpsc`; el cifrado posterior se realiza por la cola de importación existente. El
drag & drop directo de archivos y carpetas sobre la ventana principal permanece independiente del selector.


## OPAC Guard / Windows

Fixed74 no añade un runtime adicional para el Guard. Usa `windows-sys 0.61.2` sobre las APIs Win32 de servicio, filesystem, named pipes y seguridad. `guard/Cargo.toml` es una caja secundaria mínima que compila el servicio desde `guard/src/lib.rs`; `build.rs` la construye en modo release orientado a tamaño y embebe el PE resultante dentro de `opac_window.exe`. La instancia de servicio y su configuración se identifican por el UUID del perfil de Opac Window; el SID de Windows se conserva únicamente para restringir el canal IPC al usuario del sistema que ejecuta la GUI.

## OPAC Guard — Fixed81

`opac_guard` concentra sus dependencias de Windows en `guard/Cargo.toml`; el crate principal ya no declara `windows-sys` solo para reutilizar la implementación del Guard.


## Fixed86 — protección independiente de capturas

La GUI usa `raw-window-handle 0.6.2` para obtener el HWND y `windows-sys 0.61.2` para `SetWindowDisplayAffinity`. `eframe 0.36.2` habilita `persistence` únicamente para conservar el booleano de esta preferencia; la persistencia de posición/tamaño y memoria egui se desactiva explícitamente.
