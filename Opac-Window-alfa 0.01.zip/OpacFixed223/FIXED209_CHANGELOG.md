# OpacFixed209 — capa de warnings y Clippy

Base: **OpacFixed208**.

Correcciones aplicadas únicamente a partir de la salida real de `cargo check` y `cargo clippy --workspace --all-targets --all-features -- -D warnings` de Fixed208:

- `src/video_preview.rs`: eliminada la asignación redundante de `read_pending = false` en la rama de control; después de recrear el lector ya se asigna `true`.
- `src/video_preview.rs`: `new_session` deja de ser mutable porque su contenido no se modifica.
- `src/video_preview.rs`: `has_capacity`, `snapshot_playback_state` y `convert_bgra_row_to_rgba` pasan a ser helpers de test (`#[cfg(test)]`), porque solo se usan en pruebas de regresión y no en el binario de producción.
- `guard/src/lib.rs`: los seis `&[root.clone()]` de la prueba de validación se sustituyen por `std::slice::from_ref(&root)`, eliminando `clippy::cloned_ref_to_slice_refs` sin copiar el `PathBuf`.

No se cambian el callback COM de Media Foundation, `VideoSyncAction`, el modelo de sincronización audio/vídeo, los límites de memoria ni las protecciones de rutas.
