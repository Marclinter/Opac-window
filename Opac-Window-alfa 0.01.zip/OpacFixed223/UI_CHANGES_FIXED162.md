# Fixed162

## Multimedia / Media Foundation

- Fixed false `IMF2DBuffer` "too small for its stride" errors.
- `GetContiguousLength()` is no longer used as the memory bound for `Lock2D()`.
- Preferred path uses `IMF2DBuffer2::Lock2DSize()` to obtain actual accessible memory bounds.
- Safe fallback uses `IMF2DBuffer::ContiguousCopyTo()` when `IMF2DBuffer2` is unavailable.
- Added regression tests for padded positive pitch, negative pitch, and out-of-bounds 2D regions.
