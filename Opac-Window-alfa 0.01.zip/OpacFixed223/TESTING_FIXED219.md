# Testing Fixed220

Validate on Windows/MSVC:

```powershell
cargo fmt --check
cargo check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-targets --no-fail-fast
cargo build --release --locked
```

In particular, confirm that:

- `video_preview::sync_tests::media_foundation_smoke_produces_a_real_video_frame` passes.
- No `0xC00D36B2` / `MF_E_INVALIDREQUEST` is reported while recovering RGB32 output.
- The release build still uses `crt-static`.
- The final PE import table is inspected to confirm runtime dependency reduction.
