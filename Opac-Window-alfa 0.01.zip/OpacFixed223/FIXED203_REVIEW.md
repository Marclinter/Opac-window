# Opac Window Fixed203 — revisión y correcciones

## Correcciones aplicadas

### 1. Cierre real de la sesión de Media Foundation
`shutdown_reader_session()` pasa a recibir la `AsyncReaderSession` por valor. Antes recibía una referencia mutable y `drop(session)` solo liberaba la referencia, no el objeto propietario. Eso podía dejar vivas las referencias del lector/callback hasta que el llamador reemplazaba la sesión y añadir una espera innecesaria durante búsquedas y reinicios.

La sesión ahora se destruye explícitamente después de procesar `FlushCompleted`, manteniendo la espera máxima de 2 segundos únicamente como protección frente a una confirmación de Media Foundation que no llegue.

### 2. Verificación segura del temporal de cifrado
La verificación posterior al cifrado de un archivo V2 ya no abre el temporal con `File::open()`. Usa `open_safe_regular_file()`, por lo que la comprobación final conserva las mismas defensas contra symlinks/reparse points que el resto de accesos a archivos gestionados.

### 3. Alta de Vaults consistente
`KeyStore::create_vault()` deja de devolver un UUID sin posibilidad de error y pasa a devolver `Result<Uuid, VaultError>`. Ahora aplica las mismas restricciones de nombre/ubicación que las variantes con Vault Key/PIN y rechaza ubicaciones duplicadas antes de modificar el registro. Se adaptaron los call sites internos.

### 4. Validación persistente reforzada
`validate_keystore_body()` rechaza ahora nombres con caracteres de control, ubicaciones vacías o con caracteres de control y dos registros con la misma ubicación. Esto evita que un estado incoherente pueda llegar al Key Store cifrado aunque una ruta de creación futura se olvide de validar.

### 5. Importación de Vault Key
`import_vault()` reutiliza la validación de registro y rechaza una ubicación ya registrada antes de insertar el nuevo Vault. Se añadió una regresión específica para dos Vaults distintos intentando usar la misma ubicación.

### 6. Limpieza de temporales de GUI
`clear_temp_exports()` ya no utiliza `Path::exists()` para decidir si un borrado fallido debe conservarse para reintento. Usa `symlink_metadata()`, evitando perder el seguimiento de un temporal cuyo destino sea un enlace roto o cuyo acceso siga fallando.

## Validación disponible en este entorno

Se realizó revisión estática del proyecto y se inspeccionaron los módulos de cifrado, formato `.opac`, Key Store, persistencia, filesystem, sesiones, GUI y pipeline de vídeo/audio. El entorno utilizado para esta revisión no contiene Rust/Cargo, por lo que no se ejecutaron `cargo check`, `cargo test`, `cargo clippy` ni el build de Windows.

## Validación que debe ejecutarse en Windows

```powershell
cargo check
cargo test --workspace --all-targets --no-fail-fast
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo build --release --locked
```

La distribución recibida no contenía `Cargo.lock`. El propio `build.rs` de esta versión exige ese archivo en builds `release` y usa `--locked`, así que el lockfile debe generarse/recuperarse en el entorno de desarrollo y mantenerse junto al proyecto antes de considerar validado el release.

## Corrección adicional incorporada en Fixed204

La revisión de regresión encontró una ineficiencia en la ruta de seek: mientras `discard_before` estaba activo, `should_copy_sample()` aceptaba todos los samples anteriores al objetivo para alimentar el fallback. En vídeos de 120 FPS y GOP largos esto podía generar cientos de copias BGRA innecesarias aunque solo se conservara el último frame.

Fixed204 aplica la misma cadencia máxima de 60 FPS durante el paseo previo al objetivo. Se mantiene el último frame útil como fallback, pero se descartan samples intermedios demasiado próximos. Se añadió `seek_fallback_sampling_is_rate_limited_before_target()` como regresión.

`VIDEO_ARCHITECTURE_FINAL.md` fue actualizado y pasa a ser la especificación de referencia para 60 FPS + buffer dinámico + límite de seguridad de 1 GiB.
