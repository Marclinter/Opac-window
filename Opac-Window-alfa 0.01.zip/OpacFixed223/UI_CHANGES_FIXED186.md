# UI_CHANGES_FIXED186

## Simulacion determinista del reproductor de video

Se añadieron pruebas de simulación para validar el pipeline de preview sin depender de un codec o dispositivo concreto:

- precarga inicial de 30 frames antes de iniciar la reproducción;
- objetivo de 30 frames por segundo con 30 frames de adelanto y 30 frames de reserva;
- seeks hacia delante y hacia atrás con reconstrucción del buffer y reinicio coordinado del reloj de audio;
- múltiples seeks desde la barra de progreso conservando únicamente el último objetivo pendiente;
- descarte de frames de generaciones antiguas tras un seek;
- clamp del seek al final conocido del vídeo;
- continuidad del comportamiento de sincronización mediante `decide_video_sync`.

Son pruebas deterministas del control de estado y no sustituyen la prueba de reproducción real con Media Foundation.
