# Testing Fixed86 — protección de capturas de pantalla

## Compilación

```powershell
cargo test --workspace --all-targets
cargo clippy --workspace --all-targets --all-features -- -D warnings
```

## Prueba manual en Windows

1. Iniciar OPAC y entrar en cualquier vista con contenido de una Caja Fuerte.
2. Abrir **Ajustes**.
3. Activar **No permitir capturas de pantalla de OPAC**.
4. Usar `Win+Shift+S` para realizar una captura parcial que incluya la ventana de OPAC.
5. Comprobar que la ventana de OPAC no aparece en el resultado capturado.
6. Usar la opción de captura de **ventana** de la herramienta de Windows y seleccionar OPAC; comprobar que OPAC queda excluido.
7. Repetir una captura de **región** cuyo rectángulo esté dentro de OPAC y comprobar que el contenido protegido no aparece.
8. Probar una captura de pantalla completa que incluya OPAC.
9. Probar una aplicación de grabación/captura compatible con la API de afinidad de ventanas de Windows.
10. Desactivar la opción y comprobar que la ventana vuelve a ser capturable.
11. Reiniciar OPAC y comprobar que la preferencia se conserva.
12. Activar/desactivar OPAC Guard por separado y comprobar que no altera el estado de la protección de capturas.

## Criterio de fallo

Si OPAC muestra la opción como activa pero `Win+Shift+S` o una captura compatible sigue incluyendo la ventana, hay que tratarlo como fallo de integración y revisar el HWND/`SetWindowDisplayAffinity`.
