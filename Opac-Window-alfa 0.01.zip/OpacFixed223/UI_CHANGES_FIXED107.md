# Fixed107 — corrección de pruebas y limpieza del Guard

- Corregida la prueba `privileged_helpers_resolve_windows_binaries_from_system32` para que no dependa de la capitalización literal de la ruta `System32`.
- La prueba valida ahora el directorio de sistema devuelto por Windows, los nombres de `sc.exe` e `icacls.exe` y la correspondencia exacta del directorio padre.
- Marcada como `#[test]` la comprobación `config_candidate_order_is_primary_then_new_then_backup`, que anteriormente quedaba como función de test no utilizada.
- Eliminado el `use std::path::PathBuf` sin utilizar de `guard/tests/guard_public_api.rs`.
