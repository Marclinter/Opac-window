# Fixed160 - Reautenticación de OPAC Guard

- La desactivación de OPAC Guard ya no intenta abrir una segunda sesión del Key Store mientras la sesión activa conserva su bloqueo exclusivo.
- Se añade autenticación de contraseña sin lock ni efectos secundarios de recuperación (`.new`/`.bak`).
- Se valida también que el Key Store autenticado siga vinculado al perfil dedicado activo.
- Se añade una prueba de regresión que autentica correctamente mientras la sesión mantiene el lock y rechaza una contraseña incorrecta.
