# UI_CHANGES_FIXED173

The video preview's external-player action already existed but was placed after an `egui::ScrollArea::both()` that consumes the remaining preview-panel height. As a result, the button could be clipped below the visible panel.

The button and its security explanation are now placed before the video scroll area, so the action is visible while preserving the existing temporary-decrypted-file workflow.
