# Fixed86 — botón de arrastre y modo de apariencia

## Apariencia
- Se añade en **Ajustes** el selector **Modo oscuro / Modo claro**.
- **Modo oscuro** es el valor predeterminado cuando no existe una preferencia guardada.
- La preferencia se persiste con la clave `opac.dark_mode` y se restaura al reiniciar OPAC.
- El cambio se aplica inmediatamente al cambiar el selector.
- El modo oscuro conserva el tema visual personalizado de Fixed86.
- El modo claro usa la variante clara de egui con una paleta suave coherente con OPAC.

## Arrastre interno
- Se mantiene la preferencia `opac.internal_drag_with_left_button`.
- **Clic derecho** sigue siendo el valor predeterminado para preservar el comportamiento anterior.
