# Fixed95 — Cierre robusto de Ajustes

- La ventana de Ajustes usa ahora un estado `open` explícito para que el botón X de la barra de título funcione.
- El botón `Cerrar` conserva su comportamiento.
- `Esc` cierra Ajustes cuando no hay un diálogo modal de desactivación de OPAC Guard abierto.
- El diálogo de desactivación de OPAC Guard mantiene prioridad y no se cierra accidentalmente con `Esc` dirigido a Ajustes.
- El cambio no modifica la lógica de autenticación, cifrado, Guard, temas ni arrastre.
