# Arquitectura final de vídeo — Fixed199

## Pipeline

El preview integrado usa tres etapas separadas:

1. **Coordinator/Media Foundation**: mantiene el `IMFSourceReader`, usa `MF_SOURCE_READER_ASYNC_CALLBACK`, controla `ReadSample`, seek, restart, `Flush` y generaciones.
2. **Frame processor**: convierte los buffers BGRA recibidos a RGBA y los mantiene en un buffer acotado.
3. **Playback scheduler**: entrega frames a egui usando PTS, el reloj de audio como maestro cuando existe audio y un reloj monotónico cuando no lo hay.

Hay tres límites explícitos: cola RAW de 4 frames, buffer decodificado de hasta 60 frames y cola de presentación de 6 frames. Los frames de generaciones antiguas se invalidan inmediatamente ante seek/restart.

## Cadencia

Media Foundation ya no recibe una tasa artificial de 30 FPS. Se conserva la cadencia temporal del contenido y el scheduler limita la presentación a 30 FPS con sus timestamps. Esto evita introducir una conversión de frame-rate innecesaria dentro del pipeline multimedia.

## Seek y fin de vídeo

Cada seek publica una nueva generación. El coordinador marca el contexto anterior como inactivo, hace `Flush`, crea una nueva sesión y ejecuta `SetCurrentPosition` antes de solicitar samples. Como Media Foundation puede buscar en un keyframe anterior, los samples anteriores al objetivo se descartan y se conserva el último frame anterior como fallback. Si el seek cae al final del vídeo, ese último frame se promueve explícitamente en `EOS` para que el preview no quede esperando indefinidamente.

## Sincronización

Con audio reproducible, `rodio` proporciona el reloj maestro. El vídeo espera si va por delante, descarta frames cuando queda retrasado y solicita un hard-resync ante deriva grande. Si el audio deja de estar disponible, el scheduler usa un reloj monotónico local.

## Memoria y seguridad

El preview integrado se limita a 960x540. Los frames sensibles se guardan en `Zeroizing<Vec<u8>>`, con colas acotadas y presupuesto total de 256 MiB. El archivo cifrado se descifra una vez a un temporal privado porque Media Foundation necesita una fuente legible; se elimina al terminar la sesión o se reintenta su eliminación cuando Windows mantiene el archivo abierto.
