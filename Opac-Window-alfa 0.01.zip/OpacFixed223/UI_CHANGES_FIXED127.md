# Correcciones multimedia — Fixed127

## Control A/V durante esperas

La espera de un fotograma adelantado al audio ahora observa el estado completo de control:

- cancelacion de la tarea;
- reproduccion/pausa;
- reinicio;
- activacion del reloj de audio;
- generacion de control.

Esto evita que un vídeo quede esperando un reloj de audio que ya terminó y evita que una espera asociada a una generación antigua sobreviva a un seek o reinicio.

## Pausa y reloj local

Cuando el vídeo funciona sin reloj de audio, el ancla del reloj local se invalida mientras está pausado. Al reanudar, el reloj se reconstruye desde la posición actual y no desde el instante anterior a la pausa.

## Cancelación y temporales

Una preparación de vídeo cancelada puede seguir terminando su descifrado porque la operación de `vault_fs` no es cancelable a mitad del proceso. La GUI conserva ahora el `JoinHandle` del worker hasta que termina y solo entonces elimina el plaintext temporal. Así no se pierde el propietario del hilo ni se produce una carrera entre la escritura/renombrado y la eliminación del temporal.

Las transiciones de bloqueo/cierre de sesión esperan también a esos workers cancelados antes de eliminar la carpeta temporal de sesión.

## Barra de progreso

La posición mostrada y la posición base del slider se limitan a la duración conocida del vídeo. El reloj maestro sigue siendo el audio cuando está activo; la barra no cambia de modelo de sincronización.
