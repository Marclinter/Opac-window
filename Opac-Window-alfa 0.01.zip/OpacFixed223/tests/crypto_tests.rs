//! Tests de integracion de extremo a extremo, cubriendo (una parte de) la
//! bateria descrita en el README, seccion 24: "cifrado y descifrado",
//! "contrasena correcta/incorrecta", "PIN correcto/incorrecto",
//! "ciphertext modificado", "metadata modificada", "Key Store modificado",
//! "multiples Cajas Fuertes", "claves independientes", "cambio de
//! contrasena maestra", "cambio de PIN", "nombres Unicode", "archivos
//! pequenos/vacios".
//!
//! Los tests unitarios de cada pieza por separado viven dentro de cada
//! modulo (`#[cfg(test)]`); estos de aqui prueban el flujo completo tal y
//! como lo usaria la futura GUI, a traves de la API publica del crate.

use opac_window_core::KeyStore;
use opac_window_core::modules::master_key::Argon2Params;
use opac_window_core::modules::opac_format::{self, OpacMetadata};

fn fast_params() -> Argon2Params {
    // Parametros debiles a proposito, solo para que los tests sean rapidos.
    Argon2Params {
        memory_kib: 8 * 1024,
        iterations: 1,
        parallelism: 1,
    }
}

#[test]
fn full_flow_create_encrypt_export() {
    let (mut store, master_key) =
        KeyStore::create_new_with_params(b"contrasena-maestra", fast_params()).unwrap();
    let vault_id = store.create_vault("Personal", "/tmp/personal").unwrap();
    let vault_key = store.unlock_vault(vault_id, None).unwrap();

    let content = "informe con eñes y ñandú".as_bytes().to_vec();
    let metadata = OpacMetadata {
        original_name: "informe_ñandú.docx".to_string(),
        original_size: content.len() as u64,
        created_unix: Some(1_726_000_000),
        modified_unix: Some(1_726_000_100),
    };

    let blob = opac_format::encrypt(vault_key.as_bytes(), metadata, &content).unwrap();
    assert_eq!(
        u16::from_le_bytes([blob[4], blob[5]]),
        opac_format::OPAC_VERSION
    );
    let decrypted = opac_format::decrypt(vault_key.as_bytes(), &blob).unwrap();

    assert_eq!(decrypted.content.as_slice(), content.as_slice());
    assert_eq!(decrypted.metadata.original_name, "informe_ñandú.docx");

    // El Key Store tambien debe sobrevivir a un ciclo completo de guardado
    // y recarga con la misma contrasena.
    let bytes = store.to_bytes(&master_key).unwrap();
    let (reloaded, _mk) = KeyStore::from_bytes(&bytes, b"contrasena-maestra").unwrap();
    let reloaded_key = reloaded.unlock_vault(vault_id, None).unwrap();
    assert_eq!(vault_key.as_bytes(), reloaded_key.as_bytes());
}

#[test]
fn vault_with_pin_end_to_end() {
    let (mut store, _mk) =
        KeyStore::create_new_with_params(b"contrasena-maestra", fast_params()).unwrap();
    let vault_id = store
        .create_vault_with_pin_with_params("Trabajo", "/tmp/trabajo", b"7890123456", fast_params())
        .unwrap();

    // Sin PIN, o con PIN incorrecto, no se puede recuperar la Vault Key.
    assert!(store.unlock_vault(vault_id, None).is_err());
    assert!(store.unlock_vault(vault_id, Some(b"0000000000")).is_err());

    let vault_key = store.unlock_vault(vault_id, Some(b"7890123456")).unwrap();

    let content = b"datos de trabajo".to_vec();
    let metadata = OpacMetadata {
        original_name: "notas.txt".to_string(),
        original_size: content.len() as u64,
        created_unix: None,
        modified_unix: None,
    };
    let blob = opac_format::encrypt(vault_key.as_bytes(), metadata, &content).unwrap();

    // Cambiamos el PIN: los archivos .opac ya cifrados deben seguir
    // funcionando con la (misma) Vault Key subyacente.
    store
        .change_pin(vault_id, b"7890123456", b"1234567890")
        .unwrap();
    let vault_key_after = store.unlock_vault(vault_id, Some(b"1234567890")).unwrap();

    let decrypted = opac_format::decrypt(vault_key_after.as_bytes(), &blob).unwrap();
    assert_eq!(decrypted.content.as_slice(), content.as_slice());
}

#[test]
fn tampering_anywhere_is_detected() {
    let (mut store, _mk) =
        KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
    let vault_id = store.create_vault("Personal", "/tmp/personal").unwrap();
    let vault_key = store.unlock_vault(vault_id, None).unwrap();

    let metadata = OpacMetadata {
        original_name: "secreto.txt".to_string(),
        original_size: 7,
        created_unix: None,
        modified_unix: None,
    };
    let mut blob = opac_format::encrypt(vault_key.as_bytes(), metadata, b"secreto").unwrap();

    // Modificar cualquier byte del blob (cabecera o cuerpo sellado) debe
    // hacer que el descifrado se rechace por completo.
    for i in 0..blob.len() {
        let mut corrupted = blob.clone();
        corrupted[i] ^= 0x01;
        assert!(
            opac_format::decrypt(vault_key.as_bytes(), &corrupted).is_err(),
            "el byte {i} deberia invalidar el archivo"
        );
    }

    // El archivo original, sin tocar, debe seguir siendo valido.
    assert!(opac_format::decrypt(vault_key.as_bytes(), &blob).is_ok());
    blob.clear(); // solo para silenciar warnings de variable no usada al final
}

#[test]
fn independent_vaults_do_not_cross_decrypt() {
    let (mut store, _mk) =
        KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
    let vault_a = store.create_vault("Personal", "/tmp/a").unwrap();
    let vault_b = store.create_vault("Trabajo", "/tmp/b").unwrap();

    let key_a = store.unlock_vault(vault_a, None).unwrap();
    let key_b = store.unlock_vault(vault_b, None).unwrap();

    let metadata = OpacMetadata {
        original_name: "x.txt".to_string(),
        original_size: 1,
        created_unix: None,
        modified_unix: None,
    };
    let blob = opac_format::encrypt(key_a.as_bytes(), metadata, b"x").unwrap();

    // Un archivo cifrado con la Vault Key de "Personal" no debe poder
    // descifrarse con la Vault Key de "Trabajo".
    assert!(opac_format::decrypt(key_b.as_bytes(), &blob).is_err());
}
