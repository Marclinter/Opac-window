//! Regresiones adicionales sobre bordes y propiedades de integridad que son
//! faciles de romper al tocar el parser de `.opac`, el arbol fisico de una
//! Caja Fuerte o los limites de los datos persistidos.

use std::fs;
use std::io::Cursor;
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::path::PathBuf;

use opac_window_core::modules::crypto;
use opac_window_core::modules::master_key::Argon2Params;
use opac_window_core::modules::opac_format::{self, OpacError, OpacMetadata};
use opac_window_core::modules::pin::{self, PinError};
use opac_window_core::modules::vault_fs::{self, VaultFsError};
use opac_window_core::{KeyStore, KeyStoreSession, VaultKey};
use uuid::Uuid;

fn fast_params() -> Argon2Params {
    Argon2Params {
        memory_kib: 8 * 1024,
        iterations: 1,
        parallelism: 1,
    }
}

fn temp_root(prefix: &str) -> PathBuf {
    std::env::temp_dir().join(format!("{prefix}_{}", Uuid::new_v4()))
}

fn sample_metadata(name: &str, size: usize) -> OpacMetadata {
    OpacMetadata {
        original_name: name.to_owned(),
        original_size: size as u64,
        created_unix: None,
        modified_unix: None,
    }
}

fn assert_no_panic<F>(operation: F)
where
    F: FnOnce() + std::panic::UnwindSafe,
{
    assert!(catch_unwind(operation).is_ok());
}

fn first_chunk_record_offset(blob: &[u8]) -> usize {
    let meta_len = u32::from_le_bytes(blob[36..40].try_into().unwrap()) as usize;
    40 + meta_len
}

fn second_chunk_record_offset(blob: &[u8]) -> usize {
    let first = first_chunk_record_offset(blob);
    let sealed_len = u32::from_le_bytes(blob[first + 5..first + 9].try_into().unwrap()) as usize;
    first + 9 + sealed_len
}

#[test]
fn opac_rejects_metadata_names_that_can_escape_the_filesystem_namespace() {
    let key = crypto::random_key();
    for name in [
        "",
        ".",
        "..",
        "sub\ndir.txt",
        "sub\\dir.txt",
        "nul\0.txt",
        "control\tname.txt",
        "control\rname.txt",
    ] {
        let metadata = sample_metadata(name, 0);
        assert!(matches!(
            opac_format::encrypt(&key, metadata, b""),
            Err(OpacError::Metadata)
        ));
    }

    let oversized = "A".repeat(65 * 1024);
    assert!(matches!(
        opac_format::encrypt(&key, sample_metadata(&oversized, 0), b""),
        Err(OpacError::Metadata)
    ));
}

#[test]
fn opac_rejects_reordered_chunks_even_when_the_ciphertexts_are_intact() {
    let key = crypto::random_key();
    let content = b"0123456789abcdefghi";
    let mut blob = Vec::new();
    opac_format::encrypt_chunked(
        &key,
        sample_metadata("orden.bin", content.len()),
        4,
        &mut Cursor::new(content),
        &mut blob,
    )
    .unwrap();

    let second = second_chunk_record_offset(&blob);
    // Fuerza el segundo chunk a presentarse como indice 0 en vez de 1.
    blob[second + 1..second + 5].copy_from_slice(&0u32.to_le_bytes());

    let mut out = Vec::new();
    assert!(matches!(
        opac_format::decrypt_chunked(&key, &mut Cursor::new(blob), &mut out),
        Err(OpacError::Metadata)
    ));
}

#[test]
fn opac_rejects_a_chunk_falsely_marked_as_final_and_trailing_data() {
    let key = crypto::random_key();
    let content = b"0123456789abc";
    let mut blob = Vec::new();
    opac_format::encrypt_chunked(
        &key,
        sample_metadata("flags.bin", content.len()),
        4,
        &mut Cursor::new(content),
        &mut blob,
    )
    .unwrap();

    let first = first_chunk_record_offset(&blob);
    blob[first] = 1;

    let mut out = Vec::new();
    assert!(opac_format::decrypt_chunked(&key, &mut Cursor::new(blob), &mut out).is_err());
}

#[test]
fn opac_parser_rejects_malformed_headers_without_panicking() {
    let key = crypto::random_key();
    let content = b"contenido para probar framing";
    let mut blob = Vec::new();
    opac_format::encrypt_chunked(
        &key,
        sample_metadata("framing.bin", content.len()),
        4,
        &mut Cursor::new(content),
        &mut blob,
    )
    .unwrap();

    for (offset, value) in [
        (6usize, u16::MAX.to_le_bytes().to_vec()),
        (32usize, u32::MAX.to_le_bytes().to_vec()),
    ] {
        let mut malformed = blob.clone();
        malformed[offset..offset + value.len()].copy_from_slice(&value);
        assert_no_panic(AssertUnwindSafe(|| {
            let mut out = Vec::new();
            let _ = opac_format::decrypt_chunked(&key, &mut Cursor::new(malformed), &mut out);
        }));
    }
}

#[test]
fn pin_unlock_rejects_attacker_controlled_argon2_parameters_before_derivation() {
    let key = VaultKey::from_bytes([0x3Cu8; 32]);
    let protection = pin::protect(&key, b"Ab3dEf7g", fast_params()).unwrap();

    for params in [
        Argon2Params {
            memory_kib: 1,
            iterations: 1,
            parallelism: 1,
        },
        Argon2Params {
            memory_kib: u32::MAX,
            iterations: 1,
            parallelism: 1,
        },
        Argon2Params {
            memory_kib: 8 * 1024,
            iterations: u32::MAX,
            parallelism: 1,
        },
        Argon2Params {
            memory_kib: 8 * 1024,
            iterations: 1,
            parallelism: u32::MAX,
        },
    ] {
        let malformed = pin::PinProtection {
            pin_salt: protection.pin_salt,
            nonce: protection.nonce,
            wrapped_vault_key: protection.wrapped_vault_key.clone(),
            argon2_params: params,
        };
        assert!(matches!(
            pin::unlock(&malformed, b"Ab3dEf7g"),
            Err(PinError::InvalidParams)
        ));
    }
}

#[test]
fn vault_validate_access_rejects_unmanaged_plaintext_entries() {
    let root = temp_root("opac_unmanaged_tree");
    fs::create_dir_all(&root).unwrap();
    let vault = root.join("vault");
    let key = crypto::random_key();
    vault_fs::create_vault_folder(&vault).unwrap();
    fs::write(vault.join("plaintext.txt"), b"secret sentinel").unwrap();

    assert!(matches!(
        vault_fs::validate_vault_access(&vault, &key),
        Err(VaultFsError::InvalidVaultPath)
    ));
    assert_eq!(
        fs::read(vault.join("plaintext.txt")).unwrap(),
        b"secret sentinel"
    );

    fs::remove_dir_all(root).ok();
}

#[test]
fn folder_marker_must_not_carry_plaintext_content() {
    let root = temp_root("opac_marker_content");
    fs::create_dir_all(&root).unwrap();
    let vault = root.join("vault");
    let key = crypto::random_key();
    vault_fs::create_vault_folder(&vault).unwrap();
    let folder = vault_fs::create_folder(&vault, &vault, "Protegida", &key).unwrap();
    let marker = folder.join(".opac-folder");

    let malicious =
        opac_format::encrypt(&key, sample_metadata("Protegida", 9), b"plaintext").unwrap();
    fs::write(&marker, malicious).unwrap();

    assert!(matches!(
        vault_fs::list_vault_folders(&vault, &key),
        Err(VaultFsError::InvalidVaultPath)
    ));
    assert!(matches!(
        vault_fs::validate_vault_access(&vault, &key),
        Err(VaultFsError::InvalidVaultPath)
    ));

    fs::remove_dir_all(root).ok();
}

#[test]
fn deleting_a_managed_folder_is_prevalidated_before_any_child_is_removed() {
    let root = temp_root("opac_delete_preflight");
    fs::create_dir_all(&root).unwrap();
    let vault = root.join("vault");
    let key = crypto::random_key();
    let folder = vault_fs::create_folder(&vault, &vault, "Borrar", &key).unwrap();
    let child = vault_fs::create_folder(&vault, &folder, "Hijo", &key).unwrap();
    let unexpected = child.join("no-opac.txt");
    fs::write(&unexpected, b"must survive").unwrap();

    assert!(matches!(
        vault_fs::delete_folder(&vault, &folder, &key),
        Err(VaultFsError::InvalidVaultPath)
    ));
    assert!(folder.exists());
    assert!(child.exists());
    assert_eq!(fs::read(&unexpected).unwrap(), b"must survive");

    fs::remove_dir_all(root).ok();
}

#[test]
fn moving_a_folder_into_its_descendant_is_rejected_without_mutation() {
    let root = temp_root("opac_move_cycle");
    fs::create_dir_all(&root).unwrap();
    let vault = root.join("vault");
    let key = crypto::random_key();
    let parent = vault_fs::create_folder(&vault, &vault, "Padre", &key).unwrap();
    let child = vault_fs::create_folder(&vault, &parent, "Hijo", &key).unwrap();

    assert!(matches!(
        vault_fs::move_folder(&vault, &parent, &child, &key),
        Err(VaultFsError::InvalidVaultPath)
    ));
    assert!(parent.exists());
    assert!(child.exists());
    assert_eq!(vault_fs::list_vault_folders(&vault, &key).unwrap().len(), 2);

    fs::remove_dir_all(root).ok();
}

#[test]
fn rename_file_to_the_same_name_is_idempotent_and_does_not_reencrypt() {
    let root = temp_root("opac_rename_idempotent");
    fs::create_dir_all(&root).unwrap();
    let vault = root.join("vault");
    let source = root.join("nota.txt");
    let key = crypto::random_key();
    fs::write(&source, b"contenido estable").unwrap();

    let opac = vault_fs::encrypt_file_into_vault(&vault, &key, &source).unwrap();
    let before = fs::read(&opac).unwrap();
    let metadata = vault_fs::rename_file(&vault, &opac, &key, "nota.txt").unwrap();
    let after = fs::read(&opac).unwrap();

    assert_eq!(metadata.original_name, "nota.txt");
    assert_eq!(before, after);

    fs::remove_dir_all(root).ok();
}

#[test]
fn keystore_body_tampering_is_rejected() {
    let root = temp_root("opac_keystore_body_tamper");
    fs::create_dir_all(&root).unwrap();
    let path = root.join("keystore.opks");
    let password = b"password-correcta";
    let mut session = KeyStoreSession::create(&path, password).unwrap();
    session
        .create_vault("Personal", &root.join("Personal"))
        .unwrap();
    drop(session);

    let original = fs::read(&path).unwrap();
    // Los primeros 50 bytes contienen el framing publico de la version actual;
    // el cuerpo sellado comienza despues del campo sealed_len.
    let sealed_len = u32::from_le_bytes(original[46..50].try_into().unwrap()) as usize;
    assert!(sealed_len >= 16);
    assert!(50 + sealed_len <= original.len());
    let body_offset = 50 + sealed_len / 2;
    let mut tampered = original.clone();
    tampered[body_offset] ^= 0x80;

    assert!(KeyStore::from_bytes(&tampered, password).is_err());
    assert!(KeyStoreSession::open(&path, password).is_ok());

    fs::remove_dir_all(root).ok();
}

#[test]
fn wrong_password_does_not_rewrite_a_valid_keystore() {
    let root = temp_root("opac_wrong_password_persistence");
    fs::create_dir_all(&root).unwrap();
    let path = root.join("keystore.opks");
    let mut session = KeyStoreSession::create(&path, b"password-correcta").unwrap();
    session
        .create_vault("Personal", &root.join("Personal"))
        .unwrap();
    drop(session);
    let before = fs::read(&path).unwrap();

    assert!(KeyStoreSession::open(&path, b"password-equivocada").is_err());
    assert_eq!(fs::read(&path).unwrap(), before);

    fs::remove_dir_all(root).ok();
}

#[test]
fn create_vault_with_key_preserves_exact_vault_key() {
    let key = VaultKey::from_bytes([0x7Du8; 32]);
    let mut store =
        opac_window_core::KeyStore::create_new_with_params(b"password-larga", fast_params())
            .unwrap()
            .0;
    let id = store
        .create_vault_with_key("Personal", "D:/Personal", *key.as_bytes())
        .unwrap();
    let reopened = store.unlock_vault(id, None).unwrap();
    assert_eq!(reopened.as_bytes(), &[0x7D; 32]);
}

#[test]
fn malformed_vault_data_never_panics_when_reading_metadata_only() {
    let key = crypto::random_key();
    let valid = opac_format::encrypt(&key, sample_metadata("metadata.txt", 4), b"dato").unwrap();

    for len in [0usize, 1, 4, 8, 12, 24, 35, valid.len() / 2] {
        let candidate = valid[..len.min(valid.len())].to_vec();
        assert_no_panic(AssertUnwindSafe(|| {
            let mut cursor = Cursor::new(candidate);
            let _ = opac_format::read_metadata_only(&key, &mut cursor);
        }));
    }
}
