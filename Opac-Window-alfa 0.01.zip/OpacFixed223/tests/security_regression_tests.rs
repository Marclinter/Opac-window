//! Regresión de seguridad a nivel de API pública.
//!
//! Estos tests no pretenden demostrar ausencia de vulnerabilidades. Fijan
//! propiedades de diseño que una modificación futura no debería romper:
//! autenticación de AEAD/AAD, ausencia de secretos obvios en blobs persistentes,
//! límites de KDF, aislamiento entre Cajas Fuertes, atomicidad del descifrado
//! a disco, robustez de parsers frente a truncamientos y recuperación segura
//! del Key Store.

use std::fs;
use std::io::Cursor;
use std::panic::{AssertUnwindSafe, catch_unwind};
use std::path::{Path, PathBuf};

use opac_window_core::modules::crypto;
use opac_window_core::modules::export::export_vault_key_with_params;
use opac_window_core::modules::import::import_vault_key;
use opac_window_core::modules::master_key::{
    Argon2Params, DEFAULT_ITERATIONS, DEFAULT_MEMORY_KIB, DEFAULT_PARALLELISM, MAX_ITERATIONS,
    MAX_MEMORY_KIB, MAX_PARALLELISM, MIN_ITERATIONS, MIN_MEMORY_KIB, MIN_PARALLELISM,
    MasterKeyError,
};
use opac_window_core::modules::opac_format::{self, OpacMetadata};
use opac_window_core::modules::pin::{self, PinError};
use opac_window_core::modules::vault_fs;
use opac_window_core::{KeyStore, KeyStoreFile, SessionError, VaultAccessMode, VaultKey};
use uuid::Uuid;

fn fast_params() -> Argon2Params {
    // Parametros reducidos exclusivamente para que la suite sea rapida.
    // Los tests de seguridad no deben utilizarse para calibrar la configuracion
    // de produccion.
    Argon2Params {
        memory_kib: 8 * 1024,
        iterations: 1,
        parallelism: 1,
    }
}

fn temp_root(prefix: &str) -> PathBuf {
    std::env::temp_dir().join(format!("{prefix}_{}", Uuid::new_v4()))
}

fn contains_subslice(haystack: &[u8], needle: &[u8]) -> bool {
    !needle.is_empty()
        && needle.len() <= haystack.len()
        && haystack
            .windows(needle.len())
            .any(|window| window == needle)
}

fn assert_no_panic<F>(operation: F)
where
    F: FnOnce() + std::panic::UnwindSafe,
{
    assert!(catch_unwind(operation).is_ok());
}

fn assert_no_cleartext_bytes_in_tree(root: &Path, needles: &[&[u8]]) {
    fn walk(current: &Path, needles: &[&[u8]]) {
        for entry in fs::read_dir(current).unwrap() {
            let entry = entry.unwrap();
            let path = entry.path();
            let name = path
                .file_name()
                .and_then(|n| n.to_str())
                .unwrap_or_default();
            for needle in needles {
                assert!(
                    !contains_subslice(name.as_bytes(), needle),
                    "el nombre fisico contiene un sentinel en claro: {:?}",
                    path
                );
            }

            let file_type = entry.file_type().unwrap();
            if file_type.is_dir() {
                walk(&path, needles);
            } else if file_type.is_file() {
                let bytes = fs::read(&path).unwrap();
                for needle in needles {
                    assert!(
                        !contains_subslice(&bytes, needle),
                        "el archivo persistente contiene un sentinel en claro: {:?}",
                        path
                    );
                }
            }
        }
    }

    walk(root, needles);
}

#[test]
fn nested_ten_level_folder_chain_keeps_files_encrypted_and_ciphertext_stable() {
    let root = temp_root("opac_nested_ten_levels");
    fs::create_dir_all(&root).unwrap();
    let key_store_path = root.join("keystore.opks");
    let vault_path = root.join("Personal");
    let source = root.join("TOP_SECRET_source_17b2.txt");
    let destination = root.join("restored.txt");
    let original_content = b"TOP_SECRET_PAYLOAD_9c4e: contenido que nunca debe quedar en claro";
    fs::write(&source, original_content).unwrap();

    let mut session =
        opac_window_core::KeyStoreSession::create(&key_store_path, b"password-larga").unwrap();
    let vault_id = session.create_vault("Personal", &vault_path).unwrap();
    let vault = session.open_vault(vault_id, None).unwrap();

    // Construye exactamente diez niveles de carpetas gestionadas por la Caja.
    let mut current = vault.location().to_path_buf();
    let mut folder_names = Vec::new();
    for level in 1..=10 {
        let visible_name = format!("NIVEL_{level}_TOP_SECRET_FOLDER_5a91");
        current = vault.create_folder(&current, &visible_name).unwrap();
        folder_names.push(visible_name);
    }
    let deepest = current.clone();

    // Importar directamente al nivel 10 debe producir un .opac dentro de ese
    // directorio, sin modificar la clave ni volver a cifrar nada al pasar por
    // las carpetas intermedias.
    let opac_path = vault.import_file_into(&source, &deepest).unwrap();
    assert_eq!(
        opac_path.parent(),
        Some(deepest.as_path()),
        "el archivo no termino en el nivel mas profundo"
    );

    let ciphertext_before_move = fs::read(&opac_path).unwrap();
    assert!(!contains_subslice(
        &ciphertext_before_move,
        original_content
    ));
    assert!(!contains_subslice(
        &ciphertext_before_move,
        b"TOP_SECRET_source_17b2.txt"
    ));
    assert_no_cleartext_bytes_in_tree(
        vault.location(),
        &[
            b"TOP_SECRET_source_17b2.txt",
            b"TOP_SECRET_PAYLOAD_9c4e",
            b"NIVEL_1_TOP_SECRET_FOLDER_5a91",
            b"NIVEL_10_TOP_SECRET_FOLDER_5a91",
        ],
    );

    // La Vault Key correcta descifra el archivo aunque este a diez niveles de
    // profundidad. La ruta no forma parte del plaintext cifrado del archivo.
    let metadata = vault.decrypt_file(&opac_path, &destination).unwrap();
    assert_eq!(metadata.original_name, "TOP_SECRET_source_17b2.txt");
    assert_eq!(fs::read(&destination).unwrap(), original_content);

    // Moverlo no debe descifrar, recifrar ni cambiar su ciphertext: solo se
    // modifica la ubicacion fisica dentro de la misma Caja.
    let moved_to_root = vault.move_file(&opac_path, vault.location()).unwrap();
    let ciphertext_after_root_move = fs::read(&moved_to_root).unwrap();
    assert_eq!(ciphertext_before_move, ciphertext_after_root_move);

    let moved_back_to_deepest = vault.move_file(&moved_to_root, &deepest).unwrap();
    let ciphertext_after_deep_move = fs::read(&moved_back_to_deepest).unwrap();
    assert_eq!(ciphertext_before_move, ciphertext_after_deep_move);

    // Verifica otra vez desde el nivel 10 despues de los movimientos.
    let destination_after_move = root.join("restored_after_move.txt");
    let metadata_after_move = vault
        .decrypt_file(&moved_back_to_deepest, &destination_after_move)
        .unwrap();
    assert_eq!(
        metadata_after_move.original_name,
        "TOP_SECRET_source_17b2.txt"
    );
    assert_eq!(fs::read(&destination_after_move).unwrap(), original_content);

    // Ni los nombres visibles de las carpetas ni el contenido del archivo
    // deben quedar expuestos en disco mientras la Caja esta cifrada.
    assert_no_cleartext_bytes_in_tree(
        vault.location(),
        &[
            b"TOP_SECRET_source_17b2.txt",
            b"TOP_SECRET_PAYLOAD_9c4e",
            b"NIVEL_1_TOP_SECRET_FOLDER_5a91",
            b"NIVEL_10_TOP_SECRET_FOLDER_5a91",
        ],
    );

    // Tambien prueba que una clave distinta no puede abrir el mismo archivo
    // aunque conozca la ruta fisica profunda.
    let wrong_key = crypto::random_key();
    assert!(
        opac_format::decrypt(&wrong_key, &ciphertext_before_move).is_err(),
        "una Vault Key distinta no debe descifrar el archivo"
    );

    // Comprueba que el arbol fisico contiene los diez niveles esperados.
    let relative = deepest.strip_prefix(vault.location()).unwrap();
    assert_eq!(relative.components().count(), 10);
    assert_eq!(folder_names.len(), 10);

    fs::remove_dir_all(root).ok();
}

#[test]
fn default_argon2_policy_stays_inside_protocol_bounds() {
    let params = Argon2Params::default();
    assert_eq!(params.memory_kib, DEFAULT_MEMORY_KIB);
    assert_eq!(params.iterations, DEFAULT_ITERATIONS);
    assert_eq!(params.parallelism, DEFAULT_PARALLELISM);
    assert!(params.validate().is_ok());

    for memory_kib in [MIN_MEMORY_KIB - 1, MAX_MEMORY_KIB + 1] {
        let candidate = Argon2Params {
            memory_kib,
            iterations: DEFAULT_ITERATIONS,
            parallelism: DEFAULT_PARALLELISM,
        };
        assert_eq!(candidate.validate(), Err(MasterKeyError::InvalidParams));
    }

    for iterations in [MIN_ITERATIONS - 1, MAX_ITERATIONS + 1] {
        let candidate = Argon2Params {
            memory_kib: DEFAULT_MEMORY_KIB,
            iterations,
            parallelism: DEFAULT_PARALLELISM,
        };
        assert_eq!(candidate.validate(), Err(MasterKeyError::InvalidParams));
    }

    for parallelism in [MIN_PARALLELISM - 1, MAX_PARALLELISM + 1] {
        let candidate = Argon2Params {
            memory_kib: DEFAULT_MEMORY_KIB,
            iterations: DEFAULT_ITERATIONS,
            parallelism,
        };
        assert_eq!(candidate.validate(), Err(MasterKeyError::InvalidParams));
    }
}

#[test]
fn keystore_does_not_store_known_secrets_in_clear() {
    let password = b"MASTER_SENTINEL_4bb9c6a8";
    let vault_name = "VAULT_NAME_SENTINEL_9c74";
    let location = "LOCATION_SENTINEL_2a17";

    let (mut store, master_key) =
        KeyStore::create_new_with_params(password, fast_params()).unwrap();
    let id = store.create_vault(vault_name, location).unwrap();
    let vault_key = store.unlock_vault(id, None).unwrap();
    let bytes = store.to_bytes(&master_key).unwrap();

    assert!(!contains_subslice(&bytes, password));
    assert!(!contains_subslice(&bytes, vault_name.as_bytes()));
    assert!(!contains_subslice(&bytes, location.as_bytes()));

    // La Vault Key esta dentro del cuerpo autenticado del Key Store, no en
    // la cabecera publica. Con una clave de 256 bits, encontrarla completa
    // accidentalmente en el ciphertext es despreciable.
    assert!(!contains_subslice(&bytes, vault_key.as_bytes()));
}

#[test]
fn keystore_aad_and_kdf_header_tampering_is_rejected() {
    let password = b"correcta-para-header";
    let (mut store, master_key) =
        KeyStore::create_new_with_params(password, fast_params()).unwrap();
    store.create_vault("Personal", "D:/Personal").unwrap();
    let original = store.to_bytes(&master_key).unwrap();

    // Formato actual: magic[0..4], version[4..6], salt[6..22],
    // memory[22..26], iterations[26..30], parallelism[30..34], nonce[34..46].
    for position in [6usize, 22, 26, 30, 34] {
        let mut tampered = original.clone();
        tampered[position] ^= 0x01;
        assert!(KeyStore::from_bytes(&tampered, password).is_err());
    }

    // El framing tambien debe rechazar un sealed_len incoherente.
    let mut bad_length = original.clone();
    bad_length[46..50].copy_from_slice(&0u32.to_le_bytes());
    assert!(KeyStore::from_bytes(&bad_length, password).is_err());
}

#[test]
fn opac_hides_filename_and_rejects_authenticated_header_tampering() {
    let key = crypto::random_key();
    let metadata = OpacMetadata {
        original_name: "OPAC_SECRET_FILENAME_8d7b.txt".to_string(),
        original_size: 11,
        created_unix: None,
        modified_unix: None,
    };
    let blob = opac_format::encrypt(&key, metadata, b"secreto-abc").unwrap();

    assert!(!contains_subslice(&blob, b"OPAC_SECRET_FILENAME_8d7b.txt"));
    assert!(!contains_subslice(&blob, b"secreto-abc"));

    // Cabecera V2: magic[0..4], version[4..6], flags[6..8], file_id[8..24],
    // nonce_prefix[24..32], chunk_size[32..36]. Todos los campos participan
    // en la autenticacion de metadata y/o de contenido.
    for position in [6usize, 8, 24, 32] {
        let mut tampered = blob.clone();
        tampered[position] ^= 0x01;
        let mut out = Vec::new();
        assert!(opac_format::decrypt_chunked(&key, &mut Cursor::new(tampered), &mut out).is_err());
    }
}

#[test]
fn truncated_opac_inputs_never_panic() {
    let key = crypto::random_key();
    let metadata = OpacMetadata {
        original_name: "truncado.bin".to_string(),
        original_size: 32,
        created_unix: None,
        modified_unix: None,
    };
    let mut blob = Vec::new();
    opac_format::encrypt_chunked(
        &key,
        metadata,
        8,
        &mut Cursor::new(vec![0xAB; 32]),
        &mut blob,
    )
    .unwrap();

    for len in 0..blob.len() {
        let candidate = blob[..len].to_vec();
        assert_no_panic(AssertUnwindSafe(|| {
            let mut out = Vec::new();
            let _ = opac_format::decrypt_chunked(&key, &mut Cursor::new(candidate), &mut out);
        }));
    }
}

#[test]
fn truncated_keystore_inputs_never_panic() {
    let password = b"parser-password";
    let (mut store, master_key) =
        KeyStore::create_new_with_params(password, fast_params()).unwrap();
    store.create_vault("Parser", "D:/Parser").unwrap();
    let bytes = store.to_bytes(&master_key).unwrap();

    for len in 0..bytes.len() {
        let candidate = bytes[..len].to_vec();
        assert_no_panic(AssertUnwindSafe(|| {
            let _ = KeyStore::from_bytes(&candidate, password);
        }));
    }
}

#[test]
fn pin_policy_has_explicit_boundaries_and_wraps_the_vault_key() {
    let fixed_key = VaultKey::from_bytes([0xA5; 32]);
    let params = fast_params();

    let protection = pin::protect(&fixed_key, b"Ab3dEf7g", params).unwrap();
    assert!(!contains_subslice(
        &protection.wrapped_vault_key,
        b"Ab3dEf7g"
    ));
    assert!(!contains_subslice(
        &protection.wrapped_vault_key,
        &[0xA5; 32]
    ));
    assert_eq!(
        pin::unlock(&protection, b"Ab3dEf7g").unwrap().as_bytes(),
        &[0xA5; 32]
    );

    assert!(matches!(
        pin::protect(&fixed_key, b"123456789", params),
        Err(PinError::WeakPin)
    ));
    assert!(pin::protect(&fixed_key, b"1234567890", params).is_ok());
    assert!(matches!(
        pin::protect(&fixed_key, &[b'X'; 129], params),
        Err(PinError::WeakPin)
    ));

    let mut tampered = protection.wrapped_vault_key.clone();
    tampered[0] ^= 0x80;
    let tampered_protection = pin::PinProtection {
        pin_salt: protection.pin_salt,
        nonce: protection.nonce,
        wrapped_vault_key: tampered,
        argon2_params: protection.argon2_params,
    };
    assert!(matches!(
        pin::unlock(&tampered_protection, b"Ab3dEf7g"),
        Err(PinError::Crypto(_))
    ));
}

#[test]
fn export_blob_does_not_expose_vault_key_or_password_and_authenticates_header() {
    let key = VaultKey::from_bytes([0x5A; 32]);
    let password = b"EXPORT_PASSWORD_SENTINEL";
    let params = fast_params();
    let id = Uuid::new_v4();

    let bytes = export_vault_key_with_params(id, "ExportSentinel", &key, password, params).unwrap();
    assert!(!contains_subslice(&bytes, password));
    assert!(!contains_subslice(&bytes, &[0x5A; 32]));
    assert!(!contains_subslice(&bytes, b"ExportSentinel"));

    let imported = import_vault_key(&bytes, password).unwrap();
    assert_eq!(imported.vault_key.as_bytes(), &[0x5A; 32]);

    // Salt y nonce forman parte del AAD; modificarlos no puede convertir el
    // blob en otro export valido.
    for position in [6usize, 34] {
        let mut tampered = bytes.clone();
        tampered[position] ^= 0x01;
        assert!(import_vault_key(&tampered, password).is_err());
    }
}

#[test]
fn vault_session_rejects_paths_from_another_vault() {
    let root = temp_root("opac_isolation");
    fs::create_dir_all(&root).unwrap();
    let key_store_path = root.join("keystore.opks");
    let source = root.join("secreto.txt");
    fs::write(&source, b"solo caja A").unwrap();

    let mut session =
        opac_window_core::KeyStoreSession::create(&key_store_path, b"password-larga").unwrap();
    let vault_a_path = root.join("A");
    let vault_b_path = root.join("B");
    let vault_a = session.create_vault("A", &vault_a_path).unwrap();
    let vault_b = session.create_vault("B", &vault_b_path).unwrap();

    let a = session.open_vault(vault_a, None).unwrap();
    let opac_path = a.import_file(&source).unwrap();
    let b = session.open_vault(vault_b, None).unwrap();

    assert!(matches!(
        b.read_file_metadata(&opac_path),
        Err(SessionError::InvalidVaultPath)
    ));
    assert!(matches!(
        b.decrypt_file(&opac_path, &root.join("salida.txt")),
        Err(SessionError::InvalidVaultPath)
    ));
    assert!(matches!(
        b.delete_file(&opac_path),
        Err(SessionError::InvalidVaultPath)
    ));

    fs::remove_dir_all(root).ok();
}

#[test]
fn tampering_a_later_chunk_leaves_no_published_destination() {
    let root = temp_root("opac_atomic_decrypt");
    fs::create_dir_all(&root).unwrap();
    let vault_folder = root.join("caja");
    fs::create_dir_all(&vault_folder).unwrap();
    let source_path = vault_folder.join("tampered.opac");
    let destination = root.join("destino.txt");
    let key = crypto::random_key();
    let metadata = OpacMetadata {
        original_name: "secreto.bin".to_string(),
        original_size: 12,
        created_unix: None,
        modified_unix: None,
    };

    let mut blob = Vec::new();
    opac_format::encrypt_chunked(
        &key,
        metadata,
        4,
        &mut Cursor::new(b"0123456789ab".to_vec()),
        &mut blob,
    )
    .unwrap();

    // Localiza el segundo chunk: header V2 + metadata sellada +
    // [is_last:1][index:4][sealed_len:4][sealed].
    let mut position = 36usize;
    let meta_len = u32::from_le_bytes(blob[position..position + 4].try_into().unwrap()) as usize;
    position += 4 + meta_len;

    let first_chunk_len =
        u32::from_le_bytes(blob[position + 5..position + 9].try_into().unwrap()) as usize;
    position += 9 + first_chunk_len;
    let second_chunk_sealed_start = position + 9;
    blob[second_chunk_sealed_start] ^= 0x01;

    fs::write(&source_path, blob).unwrap();
    assert!(vault_fs::decrypt_file_from_vault(&source_path, &key, &destination).is_err());
    assert!(!destination.exists());
    assert!(source_path.exists());

    fs::remove_dir_all(root).ok();
}

#[test]
fn edited_file_is_reencrypted_and_does_not_store_plaintext() {
    let root = temp_root("opac_edit_security");
    fs::create_dir_all(&root).unwrap();
    let key_store_path = root.join("keystore.opks");
    let vault_path = root.join("Personal");
    let source = root.join("nota.txt");
    let original = b"secreto original de prueba";
    let edited = b"secreto editado de prueba";
    fs::write(&source, original).unwrap();

    let mut session =
        opac_window_core::KeyStoreSession::create(&key_store_path, b"password-larga").unwrap();
    let id = session.create_vault("Personal", &vault_path).unwrap();
    let vault = session.open_vault(id, None).unwrap();
    let opac = vault.import_file(&source).unwrap();

    let before = fs::read(&opac).unwrap();
    vault.replace_file_content(&opac, edited).unwrap();
    let after = fs::read(&opac).unwrap();

    assert_ne!(before, after);
    assert!(!contains_subslice(&after, edited));
    assert!(!contains_subslice(&after, original));

    let destination = root.join("recuperado.txt");
    vault.decrypt_file(&opac, &destination).unwrap();
    assert_eq!(fs::read(destination).unwrap(), edited);

    fs::remove_dir_all(root).ok();
}

#[test]
fn preview_size_limit_is_enforced_after_authenticated_metadata() {
    let root = temp_root("opac_preview_limit");
    fs::create_dir_all(&root).unwrap();
    let key_store_path = root.join("keystore.opks");
    let vault_path = root.join("Personal");
    let source = root.join("nota.txt");
    fs::write(&source, vec![b'X'; 128]).unwrap();

    let mut session =
        opac_window_core::KeyStoreSession::create(&key_store_path, b"password-larga").unwrap();
    let id = session.create_vault("Personal", &vault_path).unwrap();
    let vault = session.open_vault(id, None).unwrap();
    let opac = vault.import_file(&source).unwrap();

    assert!(matches!(
        vault.read_small_file(&opac, 16),
        Err(SessionError::PreviewTooLarge)
    ));
    assert!(vault.read_small_file(&opac, 256).is_ok());

    fs::remove_dir_all(root).ok();
}

#[test]
fn integrated_preview_reads_never_modify_or_plaintext_image_or_pdf_ciphertext() {
    let root = temp_root("opac_preview_ciphertext_lifecycle");
    fs::create_dir_all(&root).unwrap();
    let key_store_path = root.join("keystore.opks");
    let vault_path = root.join("Personal");

    let cases = [
        ("foto.png", b"IMAGE_PREVIEW_SECRET_SENTINEL".as_slice()),
        ("documento.pdf", b"PDF_PREVIEW_SECRET_SENTINEL".as_slice()),
    ];

    let mut session =
        opac_window_core::KeyStoreSession::create(&key_store_path, b"password-larga").unwrap();
    let id = session.create_vault("Personal", &vault_path).unwrap();
    let vault = session.open_vault(id, None).unwrap();

    for (name, content) in cases {
        let source = root.join(name);
        fs::write(&source, content).unwrap();
        let opac = vault.import_file(&source).unwrap();
        let before = fs::read(&opac).unwrap();

        let (_metadata, recovered) = vault.read_small_file(&opac, content.len() + 1).unwrap();
        assert_eq!(recovered.as_slice(), content);

        let after = fs::read(&opac).unwrap();
        assert_eq!(before, after, "preview must not rewrite {name}");
        assert!(!contains_subslice(&after, content));
        assert!(after.windows(4).any(|window| window == b"OPAC"));
    }

    fs::remove_dir_all(root).ok();
}

#[test]
fn valid_main_keystore_is_not_replaced_by_a_corrupt_recovery_sidecar() {
    let root = temp_root("opac_recovery");
    fs::create_dir_all(&root).unwrap();
    let path = root.join("keystore.opks");
    let sidecar = root.join("keystore.opks.new");
    let file = KeyStoreFile::new(&path);

    let (mut store, master_key) =
        KeyStore::create_new_with_params(b"password-segura", fast_params()).unwrap();
    store.create_vault("Valida", "D:/Valida").unwrap();
    file.save(&store, &master_key).unwrap();
    fs::write(&sidecar, b"esto no es un Key Store valido").unwrap();

    let (opened, _) = file.open(b"password-segura").unwrap();
    assert_eq!(opened.list_vaults()[0].name, "Valida");
    assert!(!sidecar.exists());

    fs::remove_dir_all(root).ok();
}

// Evita que una futura importacion automatica vuelva a hacer que el archivo
// de tests dependa accidentalmente de estado de acceso precargado.
#[test]
fn access_mode_default_remains_on_demand() {
    let (mut store, _master_key) =
        KeyStore::create_new_with_params(b"access-mode-password", fast_params()).unwrap();
    let id = store.create_vault("Personal", "D:/Personal").unwrap();
    assert_eq!(store.list_vaults()[0].id, id);
    assert_eq!(
        store.list_vaults()[0].access_mode,
        VaultAccessMode::OnDemand
    );
}

#[test]
fn scoped_session_rejects_sibling_prefix_outside_profile() {
    let root = temp_root("opac_scope_prefix_regression");
    let profile = root.join("profile");
    let sibling = root.join("profile-escape");
    let store = profile.join("keystore.opks");
    fs::create_dir_all(&sibling).unwrap();

    let mut session =
        opac_window_core::KeyStoreSession::create_scoped(&store, &profile, b"password-larga")
            .unwrap();

    assert!(matches!(
        session.create_vault_in_parent("Fuera", &sibling, None),
        Err(SessionError::VaultOutsideProfile)
    ));
    assert!(fs::read_dir(&sibling).unwrap().next().is_none());

    fs::remove_dir_all(root).ok();
}

#[test]
fn scoped_session_rejects_symlinked_parent_escape() {
    let root = temp_root("opac_scope_symlink_regression");
    let profile = root.join("profile");
    let outside = root.join("outside");
    let store = profile.join("keystore.opks");
    let link = profile.join("linked-parent");
    fs::create_dir_all(&outside).unwrap();

    let symlink_created = {
        #[cfg(unix)]
        {
            std::os::unix::fs::symlink(&outside, &link).is_ok()
        }
        #[cfg(windows)]
        {
            std::os::windows::fs::symlink_dir(&outside, &link).is_ok()
        }
        #[cfg(not(any(unix, windows)))]
        {
            false
        }
    };
    if !symlink_created {
        fs::remove_dir_all(root).ok();
        return;
    }

    let mut session =
        opac_window_core::KeyStoreSession::create_scoped(&store, &profile, b"password-larga")
            .unwrap();

    assert!(matches!(
        session.create_vault_in_parent("Escape", &link, None),
        Err(SessionError::VaultOutsideProfile)
    ));
    assert!(fs::read_dir(&outside).unwrap().next().is_none());

    fs::remove_dir_all(root).ok();
}
