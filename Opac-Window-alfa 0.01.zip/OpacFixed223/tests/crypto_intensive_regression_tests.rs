//! Bateria intensiva de regresion criptografica.
//!
//! La suite cubre muchas rondas de cifrado/descifrado en memoria y, ademas,
//! un flujo de filesystem real a diez niveles de carpetas. El objetivo no es
//! demostrar ausencia de vulnerabilidades, sino detectar regresiones en las
//! propiedades que deben permanecer invariantes:
//!
//! - mismo plaintext + misma clave => descifrado byte a byte identico;
//! - cifrado nuevo => ciphertext diferente (nonce/file-id nuevos);
//! - metadata preservada y autenticada;
//! - una clave equivocada no abre el blob;
//! - corrupcion de ciphertext no se acepta;
//! - nombres/contenidos sensibles no aparecen en los blobs persistentes;
//! - mover por un arbol profundo no descifra ni recifra: el ciphertext queda
//!   exactamente igual;
//! - el flujo soporta distintos tipos/tamanos de archivo, incluido un blob
//!   mayor de 8 MiB para ejercitar el camino chunked/streaming de V2.

use std::fs;
use std::path::{Path, PathBuf};

use opac_window_core::modules::crypto;
use opac_window_core::modules::opac_format::{self, OpacMetadata};
use opac_window_core::modules::vault_fs;
use uuid::Uuid;

const INTENSIVE_ROUNDS: usize = 128;
const LARGE_FILE_ROUNDS: usize = 4;
const DEPTH: usize = 10;

fn temp_root(prefix: &str) -> PathBuf {
    std::env::temp_dir().join(format!("{prefix}_{}", Uuid::new_v4()))
}

fn patterned_bytes(len: usize, mut state: u64) -> Vec<u8> {
    let mut out = vec![0u8; len];
    for byte in &mut out {
        // PRNG determinista solo para fixtures de test; no se usa para claves.
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        *byte = state as u8;
    }
    out
}

fn representative_files() -> Vec<(&'static str, Vec<u8>, &'static [u8])> {
    vec![
        ("vacio.txt", Vec::new(), b"VACIO_SENTINEL_01"),
        (
            "notas.md",
            b"# Titulo\n\nTexto **Markdown** con enlace y unicode: caf\xc3\xa9, \xc3\xb1and\xc3\xba.\n"
                .to_vec(),
            b"MARKDOWN_SENTINEL_02",
        ),
        (
            "vector.svg",
            b"<svg xmlns=\"http://www.w3.org/2000/svg\"><text>SVG_SENTINEL_03</text></svg>".to_vec(),
            b"SVG_SENTINEL_03",
        ),
        (
            "imagen.png",
            b"\x89PNG\r\n\x1a\nPNG_SENTINEL_04".to_vec(),
            b"PNG_SENTINEL_04",
        ),
        (
            "foto.jpg",
            b"\xff\xd8\xff\xe0JPEG\x00JPEG_SENTINEL_05\xff\xd9".to_vec(),
            b"JPEG_SENTINEL_05",
        ),
        (
            "animacion.gif",
            b"GIF89aGIF_SENTINEL_06\x3b".to_vec(),
            b"GIF_SENTINEL_06",
        ),
        (
            "documento.pdf",
            b"%PDF-1.7\n1 0 obj\n<< /Type /Catalog >>\nendobj\nPDF_SENTINEL_07\n%%EOF\n".to_vec(),
            b"PDF_SENTINEL_07",
        ),
        (
            "archivo.zip",
            b"PK\x03\x04ZIP_SENTINEL_08".to_vec(),
            b"ZIP_SENTINEL_08",
        ),
        (
            "audio.wav",
            b"RIFF\x24\x00\x00\x00WAVEfmt WAVE_SENTINEL_09".to_vec(),
            b"WAV_SENTINEL_09",
        ),
        (
            "grande.bin",
            patterned_bytes(8 * 1024 * 1024 + 4096, 0x9e37_79b9_7f4a_7c15),
            b"LARGE_SENTINEL_10",
        ),
    ]
}

fn assert_no_subslice(haystack: &[u8], needle: &[u8], context: &str) {
    if needle.is_empty() {
        return;
    }
    assert!(
        !haystack
            .windows(needle.len())
            .any(|window| window == needle),
        "plaintext detectado en {context}: {:?}",
        String::from_utf8_lossy(needle)
    );
}

fn assert_tree_has_no_plaintext(root: &Path, forbidden: &[&[u8]]) {
    fn walk(current: &Path, forbidden: &[&[u8]]) {
        for entry in fs::read_dir(current).unwrap() {
            let entry = entry.unwrap();
            let path = entry.path();
            let name = path
                .file_name()
                .map(|n| n.to_string_lossy().into_owned())
                .unwrap_or_default();
            for needle in forbidden {
                assert_no_subslice(name.as_bytes(), needle, "nombre fisico");
            }
            let file_type = entry.file_type().unwrap();
            if file_type.is_dir() {
                walk(&path, forbidden);
            } else if file_type.is_file() {
                let bytes = fs::read(&path).unwrap();
                for needle in forbidden {
                    assert_no_subslice(&bytes, needle, "blob persistente");
                }
            }
        }
    }

    walk(root, forbidden);
}

#[test]
fn intensive_multitype_encrypt_decrypt_roundtrip_is_stable_and_randomized() {
    let key = crypto::random_key();
    let wrong_key = crypto::random_key();

    for (name, content, sentinel) in representative_files() {
        let metadata = OpacMetadata {
            original_name: format!("INTENSIVE_{name}"),
            original_size: content.len() as u64,
            created_unix: Some(1_800_000_000),
            modified_unix: Some(1_800_000_001),
        };
        let rounds = if content.len() > 8 * 1024 * 1024 {
            LARGE_FILE_ROUNDS
        } else {
            INTENSIVE_ROUNDS
        };

        let mut previous_ciphertext = None;
        for round in 0..rounds {
            let ciphertext = opac_format::encrypt(&key, metadata.clone(), &content).unwrap();
            assert_eq!(&ciphertext[..4], opac_format::OPAC_MAGIC);
            assert_eq!(
                u16::from_le_bytes([ciphertext[4], ciphertext[5]]),
                opac_format::OPAC_VERSION
            );
            assert!(
                ciphertext.len() > content.len(),
                "ciphertext no tiene framing/AEAD suficiente"
            );
            assert_no_subslice(&ciphertext, sentinel, "ciphertext");
            assert_no_subslice(
                &ciphertext,
                metadata.original_name.as_bytes(),
                "ciphertext metadata",
            );

            if let Some(previous) = &previous_ciphertext {
                assert_ne!(
                    &ciphertext, previous,
                    "dos cifrados consecutivos de {name} produjeron el mismo ciphertext en ronda {round}"
                );
            }
            previous_ciphertext = Some(ciphertext.clone());

            let ciphertext_snapshot = ciphertext.clone();
            let decrypted = opac_format::decrypt(&key, &ciphertext).unwrap();
            assert_eq!(decrypted.metadata, metadata);
            assert_eq!(decrypted.content.as_slice(), content.as_slice());
            assert_eq!(
                ciphertext, ciphertext_snapshot,
                "descifrar no debe mutar el ciphertext"
            );

            assert!(
                opac_format::decrypt(&wrong_key, &ciphertext).is_err(),
                "una clave equivocada pudo descifrar {name} en ronda {round}"
            );

            // Perforamos periodicamente cada blob en una posicion interna y
            // confirmamos que el AEAD rechaza la corrupcion.
            if round % 16 == 0 {
                let mut tampered = ciphertext.clone();
                let position = tampered.len() / 2;
                tampered[position] ^= 0x80;
                assert!(
                    opac_format::decrypt(&key, &tampered).is_err(),
                    "ciphertext modificado aceptado para {name} en ronda {round}"
                );
            }
        }
    }
}

#[test]
fn intensive_filesystem_roundtrip_across_ten_nested_levels_preserves_ciphertext() {
    let root = temp_root("opac_intensive_fs_depth10");
    fs::create_dir_all(&root).unwrap();
    let vault_folder = root.join("vault");
    let key = crypto::random_key();

    let mut folders = Vec::with_capacity(DEPTH + 1);
    folders.push(vault_folder.clone());
    let mut parent = vault_folder.clone();
    for level in 1..=DEPTH {
        let name = format!("folder_{level}_PRIVADO");
        let created = vault_fs::create_folder(&vault_folder, &parent, &name, &key).unwrap();
        folders.push(created.clone());
        parent = created;
    }
    let deepest = folders[DEPTH].clone();

    let forbidden_names: Vec<Vec<u8>> = representative_files()
        .iter()
        .map(|(name, _, _)| format!("INTENSIVE_{name}").into_bytes())
        .chain((1..=DEPTH).map(|level| format!("folder_{level}_PRIVADO").into_bytes()))
        .collect();
    let forbidden_refs: Vec<&[u8]> = forbidden_names.iter().map(Vec::as_slice).collect();

    for (name, content, _sentinel) in representative_files() {
        let source = root.join(name);
        fs::write(&source, &content).unwrap();
        let mut opac_path =
            vault_fs::encrypt_file_into_vault_folder(&vault_folder, &deepest, &key, &source)
                .unwrap();
        let original_ciphertext = fs::read(&opac_path).unwrap();
        assert_no_subslice(
            &original_ciphertext,
            content.get(..content.len().min(32)).unwrap_or(&[]),
            "blob inicial",
        );

        // Una secuencia larga de movimientos root <-> niveles profundos debe
        // conservar exactamente el mismo ciphertext en cada paso.
        for round in 0..24usize {
            let destination = if round % 2 == 0 {
                &vault_folder
            } else {
                &folders[(round % DEPTH) + 1]
            };
            opac_path = vault_fs::move_file(&vault_folder, &opac_path, destination, &key).unwrap();
            assert_eq!(fs::read(&opac_path).unwrap(), original_ciphertext);
        }

        // Finalmente vuelve al nivel 10 y verifica varios descifrados reales.
        if opac_path.parent() != Some(deepest.as_path()) {
            opac_path = vault_fs::move_file(&vault_folder, &opac_path, &deepest, &key).unwrap();
        }
        for round in 0..8usize {
            let destination = root.join(format!("recovered_{round}_{name}"));
            let metadata =
                vault_fs::decrypt_file_from_vault(&opac_path, &key, &destination).unwrap();
            assert_eq!(metadata.original_name, name);
            assert_eq!(metadata.original_size, content.len() as u64);
            assert_eq!(fs::read(&destination).unwrap(), content);
            fs::remove_file(destination).unwrap();
        }

        // El contenido cifrado tampoco debe degradarse despues de los 24
        // movimientos + 8 descifrados.
        assert_eq!(fs::read(&opac_path).unwrap(), original_ciphertext);
        assert_tree_has_no_plaintext(&vault_folder, &forbidden_refs);
        fs::remove_file(source).unwrap();
    }

    // Confirma la geometria real: hay exactamente diez carpetas gestionadas
    // entre la raiz y el destino mas profundo.
    let relative = deepest.strip_prefix(&vault_folder).unwrap();
    assert_eq!(relative.components().count(), DEPTH);

    fs::remove_dir_all(root).ok();
}
