# Fixed112

## OPAC Guard: diagnóstico real del instalador elevado

- Corregido un bug en el canal de resultados administrativos: las ACL de archivos no pueden usar banderas de herencia `(OI)(CI)`, que son específicas de directorios.
- `secure_guard_file()` aplica ACL de archivo sin `(OI)(CI)` y después concede lectura al SID del usuario original.
- Esto permite que la GUI lea el error exacto cuando `--install-guard` termina con código 1, en lugar de mostrar únicamente el código de salida.
- Se mantiene `secure_guard_storage()` exclusivamente para directorios.
- No se modifica la lógica criptográfica ni el modelo de protección del Guard.
