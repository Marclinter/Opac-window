# Fixed101 — OPAC Guard activation diagnostics and reliable UAC handoff

- Replaced the fire-and-forget elevation launch with `ShellExecuteExW` using the documented `runas` verb and process tracking.
- The GUI now waits for the elevated helper to finish and reads a temporary result record when installation/uninstallation fails.
- UAC launch uses `SW_SHOWNORMAL` instead of hiding the helper, making the elevation request observable.
- The service-state verification window was extended to 15 seconds after successful install/uninstall.
- Added an explicit diagnostic channel so errors from `sc.exe`, ACL setup, configuration, or service start are surfaced to the GUI.
- The result file contains only operational status/error text and is deleted by the parent process after reading.
