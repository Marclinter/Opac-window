# Revisión de robustez y regresiones — Fixed126

Esta revisión se centra en la nueva sincronización multimedia. No sustituye una auditoría formal.

## Límites de seguridad preservados

No se modifica el formato cifrado `.opac`, la derivación de claves, el registro de Cajas Fuertes, el aislamiento por perfil ni OPAC Guard.

El audio y Media Foundation continúan recibiendo exclusivamente la copia temporal de vídeo ya autenticada y descifrada. La aplicación no pasa el ciphertext `.opac` directamente a los decodificadores multimedia.

Los límites existentes de tamaño y dimensiones para fotogramas se mantienen.

## Regresiones evitadas

La nueva generación de control evita aceptar fotogramas que pertenecían a la reproducción anterior después de un seek o reinicio.

La resincronización fuerte usa la posición actual del reloj de audio como destino del `SetCurrentPosition` de Media Foundation; no intenta modificar el ciphertext ni persistir ningún estado multimedia dentro de la Caja Fuerte.

Si el seek de audio falla, se desactiva el audio en lugar de continuar con dos líneas temporales independientes.

Si la pista de audio termina, se desactiva el reloj maestro para que el vídeo no quede detenido permanentemente esperando que avance una fuente finalizada.

## Riesgo residual

La exactitud final entre posición lógica de `rodio` y la latencia física del dispositivo de sonido depende del sistema operativo, dispositivo y buffers. El objetivo de este diseño es evitar la deriva acumulativa entre las dos líneas temporales; no puede garantizar una latencia física cero.
