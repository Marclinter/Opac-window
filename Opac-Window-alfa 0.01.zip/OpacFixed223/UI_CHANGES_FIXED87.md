# Fixed87 — corrección de compilación y revisión derivada de Fixed86

Fixed87 es la continuación de Fixed86 y mantiene todas sus funciones y correcciones.

## Corrección aplicada

- Corregida la llamada a `send_signed_command()` en `guard/src/lib.rs` para pasar
  `session_nonce` con el tipo correcto (`Option<&[u8; 32]>`) y eliminar el `Option<&&[u8; 32]>`
  que impedía compilar el `opac_guard`.

## Numeración

A partir de esta corrección, el identificador de la entrega es **Fixed87**. Las correcciones posteriores
se numerarán secuencialmente (Fixed88, Fixed89, ...), manteniendo los cambios anteriores.
