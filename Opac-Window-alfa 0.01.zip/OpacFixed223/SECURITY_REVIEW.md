# Revisión y endurecimiento de seguridad

## Decisión sobre V1/V2

El ZIP entregado no contiene `.git`, así que no existe historial de commits con el que
reconstruir una transición de versiones exacta. El propio código original sí permite
establecer la situación: `opac_format::OPAC_VERSION` era 1 y `vault_fs` seleccionaba V1
para archivos hasta `CHUNKED_THRESHOLD` (8 MiB) y V2 para archivos mayores.

Conclusión: V1 **no era un vestigio muerto**; era un formato de escritura todavía activo
para archivos pequeños. En esta revisión se ha convertido V2 en el único formato de escritura.
V1 queda como lector legacy y dispone de migración explícita a V2.

## Cambios aplicados

- `.opac` V2 es el formato canónico para todas las escrituras nuevas.
- `encrypt()` ya no genera V1 y selecciona automáticamente la estrategia V2.
- Hasta 8 MiB se usa un único chunk; por encima se usan chunks de 4 MiB.
- V1 se mantiene solo para lectura y migración.
- Se añadió `migrate_legacy_v1_file`.
- Se añadió una prueba que construye un blob con la estructura V1 original y comprueba que
  se puede migrar y recuperar con la misma Vault Key.
- Se añadió una prueba que comprueba que la representación binaria antigua de una Vault Key
  en `keystore.opks` sigue siendo legible tras introducir el wrapper zeroizing.
- Argon2id tiene límites antes de ejecutar la KDF, evitando parámetros controlados por un
  archivo que puedan provocar reservas arbitrarias de CPU/RAM.
- Parámetros por defecto: 64 MiB, 3 pasadas, 4 lanes.
- PIN/passcode: mínimo de 8 bytes; secretos exclusivamente numéricos requieren 10 dígitos.
- Parser V2: límites de metadata/chunks, índices consecutivos, `is_last` validado,
  tamaño de plaintext validado, `original_size` comprobado y rechazo de bytes posteriores.
- V1: se comprueba también `original_size` contra el contenido.
- Escritura de archivos: temporales impredecibles y `create_new`, evitando nombres temporales
  predecibles y carreras de creación.
- El origen del cifrado se abre una sola vez y su metadata se obtiene desde ese descriptor.
- Descifrado a disco: no se publica plaintext parcialmente descifrado en la ruta final.
- Se evita sobrescribir implícitamente un destino existente.
- Buffers sensibles intermedios relevantes se limpian con `zeroize`.
- Las rutas de datos de aplicación usan `LOCALAPPDATA` en Windows y `XDG_DATA_HOME` en
  plataformas no Windows cuando están disponibles.
- Se sustituyó la serialización nueva por Postcard y se añadió compatibilidad de lectura legacy para los datos históricos que usaban bincode 1.x.
- `.opac` V2 usa `flags = 3` en las nuevas escrituras: metadata Postcard + nonce endurecido. Los flags `0` y `1` se conservan para lectura de V2 históricos con nonce anterior; el campo está autenticado como AAD.
- `keystore.opks` y `.opackey` avanzan a versión 2 para sus nuevas escrituras; las versiones 1 siguen siendo legibles.
- Se eliminó `bincode` de las dependencias directas; no se generan nuevos datos con su codificación.
- Se añadió `KeyStoreFile` para persistencia crash-safe: candidato `.new`, copia `.bak`,
  commit mediante rename y recuperación criptográficamente validada tras interrupciones.
- Se añadió `KeyStoreSession` con guardado automático de mutaciones y rollback del estado
  anterior cuando una persistencia falla antes del commit.
- Se añadió `VaultSession` como API de alto nivel para listar archivos, leer metadata cifrada,
  importar, descifrar, borrar archivos y migrar V1, manteniendo la Vault Key separada por Caja Fuerte.

## Persistencia y ciclo de vida de sesiones

Las mutaciones de `KeyStoreSession` se guardan inmediatamente. La persistencia utiliza un archivo
principal y dos sidecars temporales para tolerar interrupciones en diferentes puntos del reemplazo.
La recuperación no confia en el nombre del candidato: cada candidato se abre y autentica antes de
ser restaurado. El diseño presupone una sola instancia de Opac Window como escritora activa; todavia
no existe un lock interproceso portable.

`VaultSession` posee su propia `VaultKey` y debe cerrarse independientemente. Esto permite que la GUI
controle el ciclo de vida de cada Caja Fuerte sin volver a exponer la Master Key.

## Limitaciones de validación en este entorno

El contenedor de revisión no tiene instalado `cargo`, `rustc` ni `rustfmt`, y el ZIP original
no contiene `.git`. Por ello no se ha podido ejecutar aquí `cargo test`, `cargo fmt --check`
ni `cargo clippy`. Se han hecho comprobaciones estructurales y de referencias, incluyendo
la ausencia de la antigua bifurcación V1/V2 en el flujo de escritura y la consistencia de los
bloques Rust modificados.

La validación final en un entorno Rust debe ejecutar al menos:

```bash
cargo fmt --check
cargo test
cargo clippy --all-targets --all-features -- -D warnings
cargo audit
```


### Preferencia de acceso por Caja Fuerte

La version actual del Key Store es V3 para persistir `VaultAccessMode`. Los Key Store V1/V2 siguen siendo legibles y se convierten a `OnDemand` cuando no contienen esta preferencia. El modo `PreloadAll` crea plaintext solo para los archivos que requieren un fichero real dentro de un directorio temporal aleatorio de la sesión. Las imágenes y PDF quedan excluidos de esa caché y sus vistas integradas se descifran directamente en memoria.


### Dependencias de GUI

La GUI usa eframe 0.36.2 con `default-features = false` y solo las features necesarias (`default_fonts`, `glow`, `accesskit`). Esto evita habilitar `links` y su cadena de navegador de forma innecesaria. Eframe 0.36.2 usa la cadena de fuentes actual de epaint.


### Actualizacion de la GUI

La GUI usa eframe 0.36.2 con Rust 1.95 como MSRV. Esta rama unifica la API de paneles de egui y usa la cadena de fuentes moderna de epaint, eliminando la antigua ruta que hacia aparecer ttf-parser en el arbol de dependencias. La GUI mantiene el drag & drop nativo habilitado en el viewport de eframe y cifra los archivos en un hilo de trabajo.


### Previsualizacion Markdown y audio

El renderer Markdown se configura sin `load-images` ni `fetch`, evitando que un documento mostrado en la GUI introduzca cargas de recursos externos. El audio no se reproduce desde el `.opac`: el archivo debe descifrarse completamente y verificarse primero en una copia temporal; `rodio` solo recibe ese archivo autenticado. La copia temporal se elimina al cambiar de seleccion, bloquear o cerrar.


### Previsualizacion multimedia

Markdown se renderiza localmente sin activar los features `load-images` ni `fetch` de `egui_commonmark`. El audio se autentica y descifra por completo antes de entregarse al decoder de `rodio`; el plaintext se mantiene en una copia temporal y se elimina al terminar la seleccion/sesion.

### PIN por Caja Fuerte
La Vault Key de una Caja Fuerte con PIN permanece envuelta con una clave derivada del PIN dentro del Key Store autenticado por la Master Key. La GUI no crea una `VaultSession` ni expone archivos, previews o la Vault Key mientras la Caja Fuerte siga bloqueada. Los archivos `.opac` permanecen cifrados en disco en todo momento; los modos de acceso solo generan plaintext temporal despues del desbloqueo.

### Protección por PIN en la GUI
Añadir un PIN no cambia la Vault Key ni recifra ningún archivo. La entrada de la Vault Key se reemplaza por `StoredKeyProtection::Pin` y la sesión actual de la Caja Fuerte se descarta al activar la protección. Al seleccionar la Caja Fuerte, la GUI muestra únicamente un estado bloqueado y solicita el PIN antes de crear una `VaultSession`; por ello la clave y los archivos no quedan disponibles para la interfaz antes de una autenticación correcta.

## Credenciales durante la GUI

Las copias temporales de la contraseña maestra creadas para abrir o crear el Key Store se mantienen en `Zeroizing<Vec<u8>>` y se liberan al terminar la operación. La contraseña y el PIN no se persisten en claro.

### Corrección de compilación de la GUI

`decrypt_file_from_vault` devuelve `Result<OpacMetadata, VaultFsError>`. La previsualización de audio no necesita conservar esa metadata, así que el patrón de éxito se ajustó de `Ok(())` a `Ok(_)`.


## Exportacion explicita

La GUI ofrece `Exportar…` exclusivamente desde el menu contextual de cada archivo. La ruta de destino se elige con el dialogo nativo de archivos y el descifrado se realiza a traves de `VaultSession::decrypt_file`. El nucleo escribe primero a un temporal aleatorio en la carpeta de destino y solo renombra al nombre final cuando el contenido ha sido descifrado y autenticado correctamente; tampoco sobrescribe destinos existentes de forma implicita.

El movimiento manual de un `.opac` con el Explorador de Windows no comparte este flujo y no provoca ningun descifrado automatico: la aplicacion no monitoriza movimientos externos ni convierte un simple `rename` en una exportacion.


### Eliminacion explicita de archivos
La GUI ofrece `Eliminar` junto a `Exportar…` en el menu contextual. Antes de borrar, pide confirmacion y despues llama a `VaultSession::delete_file`, que valida que la ruta pertenece a la Caja Fuerte y elimina el `.opac` cifrado. La operacion de eliminar no crea plaintext, no copia el archivo a un destino externo y no se activa por movimientos manuales en el Explorador. Si existe una copia temporal precargada del archivo eliminado, la GUI la elimina tambien.


## Endurecimiento adicional

- V2 mantiene compatibilidad con los archivos existentes (flags 0/1) y usa flags `3` para las nuevas escrituras: metadata Postcard + nonce endurecido. El nonce de cada chunk se construye a partir de 96 bits aleatorios por archivo (8 bytes del campo nonce-prefix + 4 bytes del `file_id`) y el indice del chunk se mezcla de forma inyectiva en los ultimos 32 bits. Esto reduce el espacio de colision entre archivos respecto al esquema historico de 64 bits sin cambiar la version principal del formato.
- Las operaciones sobre una Caja Fuerte rechazan enlaces simbolicos y puntos de reanalisis del sistema de archivos como entradas de almacenamiento. Tambien se evita tratar un enlace simbolico de destino como una ruta libre para sobrescritura durante exportaciones.
- La vista previa textual/Markdown de la GUI ahora conserva su contenido en `Zeroizing<String>`; la contraseña maestra se limpia tras un intento fallido de desbloqueo y los intentos fallidos de PIN se limpian inmediatamente.
- Las extensiones usadas para temporales multimedia/apertura externa se reducen a caracteres alfanumericos para evitar que un nombre de archivo autentico introduzca caracteres especiales en rutas temporales o en el lanzador de Windows.
- No se implementa borrado seguro de SSD: `remove_file`/`remove_dir_all` siguen siendo el mecanismo normal porque sobrescribir antes de borrar no garantiza la desaparicion del contenido en almacenamiento moderno.


### Revisión adicional de 2026-09

- La vista previa de archivos pequeños V2 ya no hace `fs::read` del `.opac` completo antes de autenticarlo: primero valida metadata mediante streaming y después vuelve a leer el contenedor V2 de forma acotada. Para V1 se mantiene el límite de tamaño del formato y se añade un límite conservador adicional para previews. Esto reduce una vía de consumo de memoria por archivos `.opac` enormes o malformados colocados en una Caja Fuerte.
- El `KeyStoreFile` ahora rechaza explícitamente el Key Store principal y sus sidecars si son enlaces simbólicos o puntos de reanalisis, y verifica que la carpeta padre existente no sea un enlace/reparse point antes de crearla. Esto reduce ataques locales basados en redirigir el almacenamiento del Key Store a otra ubicación.
- La detección de existencia usada al iniciar la GUI también considera entradas simbólicas, evitando que un enlace roto en la ruta del Key Store se confunda con una instalación nueva.
- La revisión de dependencias se contrastó con RustSec en septiembre de 2026. No se identificó en la consulta una alerta específica para `chacha20poly1305`, `argon2`, `zeroize`, `rodio`, `cpal`, `eframe`, `egui_commonmark` o `rfd` en las versiones fijadas; la comprobación efectiva de todo el árbol instalado sigue siendo `cargo audit`, porque la base de avisos cambia continuamente.

## Revisión adicional de endurecimiento: temporales de sesión

Se ha reducido la exposición de plaintext generado por la GUI:

- Los temporales usados para abrir archivos externamente, previsualizar audio y el modo `PreloadAll` viven ahora dentro de una carpeta aleatoria exclusiva de la sesión de Opac Window, en lugar de repartirse directamente por la raíz del directorio temporal del sistema.
- La carpeta de sesión se elimina al bloquear o cerrar la aplicación junto con los archivos temporales que administra la GUI.
- Cuando la GUI copia un archivo ya precargado para abrirlo externamente, usa `OpenOptions::create_new(true)` y sincroniza el archivo antes de entregarlo a la aplicación externa; si la copia o la sincronización falla, el parcial se elimina.
- El exportado explícito continúa siendo distinto: el plaintext se escribe en la ubicación elegida por el usuario y la copia `.opac` original permanece cifrada dentro de la Caja Fuerte.

Limitación residual: si una aplicación externa mantiene abierto un archivo descifrado, Windows puede impedir su borrado inmediato. Un fallo total del proceso también puede dejar temporales abiertos hasta que se puedan limpiar posteriormente; no se puede garantizar el borrado seguro de datos físicos de un SSD mediante `remove_file`.

## Suite automatizada de regresion de seguridad

Se añade `tests/security_regression_tests.rs` para convertir las propiedades de seguridad relevantes en contratos ejecutables con `cargo test`. La suite comprueba:

- que contrasenas, nombres sensibles y Vault Keys no aparecen directamente en blobs cifrados;
- autenticacion de cabeceras/AAD de Key Store, `.opac` y `.opackey`;
- limites min/max de Argon2id y las fronteras de la politica de PIN;
- rechazo de entradas truncadas sin panicos del parser;
- aislamiento de rutas entre Cajas Fuertes;
- atomicidad del descifrado a disco cuando falla un chunk posterior;
- limite de previews en memoria;
- que un `.new` corrupto no sustituye a un Key Store principal valido;
- que el modo de acceso por defecto sigue siendo `OnDemand`.

La suite establece invariantes verificables, no una garantia de seguridad absoluta. La revisión debe seguir combinando tests, Clippy, auditoria de dependencias y revisión manual.

## Regresión corregida: test de nonce V2 endurecido

El test `hardened_nonce_uses_a_96_bit_per_file_base` verifica ahora correctamente que el índice del chunk se incorpora mediante XOR a los últimos 32 bits del nonce. El test anterior esperaba incorrectamente que esos bytes permanecieran sin modificar para un índice distinto de cero. La implementación criptográfica no era la causa del fallo; era una expectativa incorrecta del test.

## Edición de texto y Markdown
La edición integrada nunca escribe el texto editado directamente sobre el `.opac`. El plaintext permanece en memoria dentro de estructuras `Zeroizing` y, al guardar, se genera primero un nuevo V2 temporal, se sincroniza y después se reemplaza la versión anterior mediante un backup temporal cifrado para permitir rollback ante un fallo de publicación. Los backups se eliminan al completar la operación; si el sistema no permite su eliminación, se devuelve error para no ocultar una limpieza incompleta.

El límite de edición coincide con el límite actual de vista previa (512 KiB), evitando que la GUI convierta accidentalmente archivos grandes en grandes buffers de plaintext editables. Al cambiar de archivo, Caja Fuerte, modo de acceso, bloqueo o cierre se intenta guardar cualquier edición pendiente.

Al cerrar la aplicación se intenta guardar cualquier edición pendiente antes de limpiar las carpetas temporales de sesión. Si el sistema operativo rechaza una operación de I/O durante el cierre, el proceso de salida no puede garantizar que un cambio pendiente llegue a persistirse; por ello el guardado explícito o el cambio de archivo son las rutas preferibles para confirmar el guardado antes de cerrar.

## Vista previa de imágenes

Las imágenes se descifran directamente a memoria y se convierten a RGBA antes de crear la textura de egui; no se escribe un archivo plaintext intermedio. La entrada está limitada a 32 MiB, 8.192 px por eje y 16 millones de píxeles, y se configura un límite adicional de 128 MiB para asignaciones del decoder. La detección de dimensiones se realiza antes de la decodificación completa y la llamada al decoder está envuelta en `catch_unwind` como defensa adicional ante decodificadores que entren en panic con datos maliciosos. La propia documentación de `image` advierte que algunos decodificadores pueden hacer panic con entradas maliciosas, por lo que esta defensa complementa —no sustituye— la autenticación AEAD de los archivos.

La imagen integrada no consulta `preloaded_files`, incluso cuando la Caja Fuerte usa `PreloadAll`, por lo que nunca reutiliza un temporal plaintext. Al cambiar de selección, eliminar el archivo, cambiar de Caja Fuerte, bloquear o cerrar, `clear_preview_state` libera la textura y los buffers de la vista; el `.opac` de origen no se modifica en ningún momento.

## Privacidad de nombres y carpetas

Los nombres visibles de archivos y carpetas no se utilizan como nombres físicos dentro de una Caja Fuerte. Los
archivos se almacenan con identificadores opacos y las carpetas se crean con identificadores aleatorios; su nombre
visible se conserva dentro de metadata cifrada y autenticada (`.opac` / `.opac-folder`). Mover una carpeta o un
archivo con drag & drop interno usa `rename` sobre el ciphertext y no cambia su contenido cifrado. Por ello, una
persona que inspeccione la Caja Fuerte cerrada desde el Explorador de Windows no debería poder leer nombres como
los que el usuario haya usado para describir contenido sensible a partir de los nombres físicos. La GUI sí muestra
esos nombres durante una sesión desbloqueada, porque necesita hacerlo para organizar y seleccionar archivos.

El nombre y la ubicación registrados para cada Caja Fuerte también pertenecen al Key Store cifrado; las Cajas
Fuertes creadas automáticamente reciben una carpeta física con identificador aleatorio en lugar del nombre visible.

## Vista previa de PDF

Los PDF integrados siguen la misma frontera: no usan la caché plaintext de `PreloadAll`. Se leen desde el `.opac`, se autentican y descifran a memoria mediante `VaultSession::read_small_file`, y se renderizan las primeras 3 páginas como RGBA en memoria con `pdfboss-render`. Los buffers RGBA pendientes de subir a la GPU se conservan en `Zeroizing<Vec<u8>>`; al cambiar de selección, eliminar el archivo, cambiar de Caja Fuerte, bloquear o cerrar, se limpia el estado y se liberan las texturas y los buffers pendientes. No se crea un PDF/PNG intermedio en disco para la vista integrada.


### Prueba de cifrado con diez niveles de carpetas

Se añadió el test `nested_ten_level_folder_chain_keeps_files_encrypted_and_ciphertext_stable` en
`tests/security_regression_tests.rs`. Crea una Caja Fuerte, construye exactamente diez niveles de
carpetas con nombres deliberadamente sensibles, introduce un archivo directamente en el décimo nivel,
comprueba que ni el nombre visible ni un sentinel del contenido aparecen en claro dentro del árbol
físico de la Caja, descifra el archivo con la Vault Key correcta y verifica que una clave distinta lo
rechaza. Después mueve el mismo `.opac` a la raíz y vuelve al nivel diez y exige que el ciphertext sea
byte a byte idéntico en ambos movimientos. La prueba también verifica que la profundidad física es
exactamente diez niveles.

Esta prueba no sustituye `cargo test`, `cargo clippy` o `cargo audit`; convierte la propiedad concreta de
que la profundidad de carpetas no altera el cifrado en una regresión automática.

### Regresion criptografica intensiva de multiples formatos

`tests/crypto_intensive_regression_tests.rs` ejerce V2 sobre varios tipos de
archivo (TXT/Markdown/SVG/PNG/JPEG/GIF/PDF/ZIP/WAV y un blob de 8 MiB + 4 KiB)
con 128 rondas consecutivas para los tamanos pequenos y 4 para el camino
chunked. En cada ronda se verifica descifrado byte a byte, metadata, rechazo
con clave equivocada, rechazo de corrupcion, ausencia de sentinels en claro y
uso de ciphertext distinto por cifrado nuevo. Un segundo test importa los
mismos tipos a una cadena de diez carpetas y repite 24 movimientos por archivo,
verificando que el ciphertext queda identico y que ocho descifrados posteriores
siguen devolviendo exactamente el plaintext original.

La prueba intensiva tambien confirma explicitamente que una operacion de
`decrypt` no muta el blob cifrado y que el nombre visible almacenado en la
metadata no aparece en claro dentro del ciphertext.

### GUI: árbol de carpetas

La representación jerárquica es únicamente una vista de la metadata ya autenticada de la Caja. Expandir, contraer o seleccionar carpetas no descifra ni reescribe archivos. El destino de una importación externa se calcula a partir de las regiones de UI asociadas a cada carpeta y se valida contra la raíz de la Caja antes de iniciar el cifrado.

- La Vault Key no se expone ni se formatea para la interfaz hasta una accion explicita en el boton «Clave». La vista utiliza una copia transitoria `Zeroizing` para mostrarla y esa copia se elimina al cerrar el dialogo o salir de alcance. La Vault Key de la Caja sigue siendo necesaria en memoria para listar metadata cifrada, previsualizar y cifrar/descifrar archivos; por tanto, retrasar su **desbloqueo criptografico interno** hasta ese boton romperia la operativa normal. Esta distincion evita confundir «no mostrar/revelar» con «no disponer de la clave para operar».
## Vault Key portable (2026-09-27)

La Vault Key es la clave simétrica final de 256 bits que cifra y autentica los archivos `.opac`. La GUI la muestra únicamente tras la acción explícita «Clave». La representación portable utilizada por la interfaz es una cadena hex de 64 caracteres; no se deriva de la contraseña maestra ni del PIN y no cambia al mover archivos o carpetas.

Se admite un segundo camino de acceso con la misma Vault Key: una Caja registrada puede abrirse con la clave directamente, incluso si está protegida además con PIN. En otro dispositivo, una carpeta física de Caja existente puede incorporarse al Key Store local proporcionando el nombre local y la Vault Key; antes de persistir el registro se autentican las entradas gestionadas de la carpeta. El contenido `.opac` no se descifra ni se re-cifra durante esta incorporación.

El flujo de importación no sigue enlaces simbólicos/puntos de reanálisis y rechaza entradas no gestionadas. La Vault Key introducida se mantiene en `Zeroizing` en el estado de la GUI y se limpia al cancelar/cerrar el diálogo. Copiar la clave al portapapeles es una acción separada y explícita del usuario.

En una Caja vacía no existe todavía un objeto cifrado que permita demostrar criptográficamente que la clave introducida es la correcta; esa situación no expone contenido porque no hay contenido protegido que descifrar. En cuanto existe una carpeta gestionada o un `.opac`, la incorporación valida su autenticidad con la clave antes de registrarla.

## Creacion de Cajas con Vault Key portable y ubicacion elegida

La creacion de una Caja permite opcionalmente reutilizar una Vault Key portable.
La clave no se deriva de la contrasena maestra ni se transforma: se almacena como
Vault Key de la nueva Caja dentro del Key Store cifrado. La carpeta fisica nueva usa
un nombre aleatorio dentro de la ubicacion padre elegida y los archivos que se anadan
despues usan exactamente esa clave, por lo que un `.opac` producido con la misma clave
puede autenticarse en otra Caja creada con ella. La ubicacion elegida no puede anidar
una nueva Caja dentro de una Caja ya registrada.

La seleccion de ubicacion se realiza mediante el selector del sistema. No se usa el
nombre visible de la Caja como nombre fisico de la carpeta. La clave pegada para la
importacion temporal vive en `Zeroizing`; al crear o cancelar, el estado de entrada se
limpia.


## Eliminación completa de una Caja Fuerte

La eliminación de una Caja Fuerte está disponible en la GUI únicamente cuando la Caja está realmente abierta y, si tiene PIN, cuando la sesión fue autenticada mediante el PIN. El acceso con Vault Key portable no habilita esta operación destructiva para Cajas protegidas con PIN.

Antes de eliminar la carpeta física se valida y autentica todo el árbol gestionado con la Vault Key. El registro del Key Store se persiste como paso previo y se restaura si el borrado físico falla. La raíz no es una carpeta movible dentro del árbol.

## Auditoria externa confirmada (2026-09-27)

Se revisaron dos afirmaciones adicionales antes de incorporarlas al código.

### pdfboss 2.11.0

La afirmación de que `pdfboss-core` / `pdfboss-render` 2.11.0 "no existe" es incorrecta para el estado actual de crates.io/docs.rs: existen versiones 2.11.0 de ambos crates. `pdfboss-core` 2.11.0 fue publicada el 2026-09-21 y `pdfboss-render` 2.11.0 también figura entre las versiones publicadas. Por ello esta revisión **no** cambia esas dependencias a 0.11.0. La serie 0.11.0 existe como versión histórica de estos crates, pero no es la versión actual equivalente de 2.11.0.

### Uso de `cmd.exe` para abrir archivos externos en Windows

La preocupación de seguridad sí es válida: el código anterior construía `cmd.exe /C start "" <ruta>`. `cmd.exe` aplica su propia gramática de shell, de modo que confiar en el quoting de `std::process::Command` no elimina por sí solo la interpretación de metacaracteres del shell. La documentación actual de Rust advierte específicamente que `cmd.exe` tiene un modo de interpretación no estándar y que un argumento malicioso puede potencialmente ejecutar comandos. Esto constituye una superficie innecesaria de shell parsing y se ha eliminado.

La vulnerabilidad concreta `CVE-2024-24576` (BatBadBut) afectaba a las invocaciones de batch/cmd en versiones antiguas del stdlib; no es preciso afirmar que este punto del código sea por sí solo el mismo CVE. El problema aquí es más general: **invocar `cmd.exe` para abrir una ruta no confiable expone una superficie de inyección de comandos evitable**.

La implementación de Windows usa ahora directamente `explorer.exe <ruta>`, evitando `cmd.exe` y su gramática de shell. La extensión temporal procedente del nombre visible sigue limitada a caracteres alfanuméricos ASCII.

### Fragmentos `.txt` fuera del build

Se eliminaron los fragmentos sueltos de `gui.rs`/`lib.rs` (`part1.txt`, `part2.txt`, `gui_rest.txt`, `gui_center.txt`, `gui_preview_drop.txt`, `gui_sidebar.txt`, `lib1.txt`, `lib2.txt`) que no forman parte del build. Esto reduce la posibilidad de que un archivo auxiliar sea confundido con código fuente durante una revisión o mantenimiento posterior.


## Revisión complementaria: progreso de cifrado por chunks

La GUI puede recibir contadores de progreso `(chunks_completados, chunks_totales)` durante el cifrado V2. El callback se ejecuta después de escribir cada chunk sellado en el temporal de destino y no recibe contenido plaintext, nombres internos ni claves. El progreso no cambia el framing ni los bytes cifrados; solo observa el avance del mismo proceso de cifrado atómico.


### Multiple file import queue

Manual multi-file import uses the native `rfd` multi-file picker. The selected paths are queued and ordered by regular-file size (ascending; original selection order is preserved for equal sizes). Each item is still passed through the existing safe-file validation and chunked encryption path, so prioritization changes scheduling only and does not alter the cryptographic format.

## 2026-09-28 — Importación múltiple concurrente

La cola de importación múltiple usa concurrencia acotada (máximo 8 trabajadores)
con despacho por tamaño ascendente. La concurrencia no cambia el formato `.opac`
ni el algoritmo AEAD: cada trabajador llama a la misma ruta de cifrado v2 por
chunks, con la misma Vault Key de solo lectura compartida mediante `Zeroizing`.

El progreso se transporta como contadores y nombre visible del archivo, nunca
como plaintext o claves. El estado de resultados se acumula en la tarea GUI para
no perder resultados que terminen antes que otros trabajadores.


## Revisión multiusuario local (2026-09-28)

Se añadió aislamiento por perfil para uso compartido del mismo PC. Cada perfil usa un `keystore.opks` distinto y una contraseña maestra distinta; las Vault Keys, nombres de Cajas Fuertes y ubicaciones registradas siguen protegidos por el Key Store de ese perfil.

El catálogo `profiles.oprp` es deliberadamente mínimo en sus nuevas escrituras: almacena solo identificadores de perfil y el tipo de almacenamiento. No contiene nombres de perfil, Vault Keys, nombres de Cajas ni archivos. Los catálogos V1 legacy pueden conservar nombres hasta la migración. Los Key Stores nuevos se ubican bajo una carpeta derivada de un UUID aleatorio, por lo que no se exponen nombres sensibles en el filesystem.

El cambio de usuario elimina de la sesión todas las referencias a VaultSession, archivos seleccionados, previews, temporales, cachés y credenciales introducidas en la GUI antes de presentar el selector de perfiles.

La separación no pretende vencer a un atacante con privilegios de administrador sobre el mismo sistema operativo. Ese atacante puede inspeccionar procesos, memoria o modificar/eliminar archivos a nivel del sistema. El objetivo es impedir el acceso accidental o no autorizado de otro usuario de la aplicación que no conozca la contraseña del perfil.

## Aislamiento por perfil (2026-09-28)

Los perfiles dedicados tienen una raiz fisica independiente en `profiles/<id>/`, con su `keystore.opks` y `vaults/`. Las sesiones abiertas desde la GUI usan una `KeyStoreSession` con alcance al perfil activo: la ruta del Key Store y las ubicaciones de las Cajas se validan contra la raiz canonica del perfil; rutas fuera de ella, Cajas anidadas entre si o la propia raiz como Caja se rechazan. La lista expuesta por una sesion con alcance filtra ubicaciones fuera de su raiz y las operaciones de apertura, creacion, importacion y borrado vuelven a validar el alcance.

Una Caja externa incorporada mediante Vault Key se autentica antes de copiarla al perfil activo y se copia solo como bytes gestionados/ciphertext, sin descifrar ni recifrar. La GUI deja el origen sin modificar. Esto mantiene la portabilidad de la Vault Key a la vez que evita que una Caja importada permanezca fuera del almacenamiento del usuario activo.

El almacenamiento legacy (`Perfil principal`) se conserva por compatibilidad con instalaciones anteriores; los perfiles dedicados nuevos usan aislamiento por carpeta. Una futura migracion puede mover el perfil legacy a su propia raiz sin cambiar las Vault Keys.

## Perfil principal y migracion legacy

En una instalacion antigua que ya tenia `keystore.opks`, el primer desbloqueo del perfil principal realiza una migracion unica a un directorio dedicado del perfil. Las Cajas se copian como ciphertext, sin descifrar archivos ni requerir sus PIN; el Key Store se vuelve a guardar en la nueva raiz con el mismo contenido logico. El catalogo solo cambia el perfil a almacenamiento dedicado despues de crear el nuevo almacenamiento con exito. Las rutas antiguas se eliminan despues del commit del catalogo, y cualquier fallo anterior deja el almacenamiento legacy intacto. Las nuevas instalaciones solo crean perfiles dedicados.

## Auditoría de aislamiento multiusuario — 2026-09-28

### Endurecimiento: vinculación criptográfica del Key Store al perfil

La revisión confirma que el aislamiento por ruta ya impide que una sesión
dedicada use ubicaciones de Cajas registradas fuera de su perfil: al abrir un
perfil se ejecuta `validate_profile_scope()` y las operaciones de Caja vuelven a
comprobar el alcance antes de actuar. Esto hace que un simple intercambio de
`keystore.opks` entre dos perfiles no permita acceder a las Cajas del otro perfil.

Como defensa de profundidad y para reducir el riesgo de futuras regresiones, los
Key Stores de perfiles dedicados nuevos quedan además vinculados al UUID del
perfil dentro del cuerpo autenticado del Key Store. `open_scoped` compara esa
vinculación antes de aceptar la sesión. Los Key Stores dedicados antiguos que no
tienen el campo se actualizan de forma persistente después de una autenticación
correcta y las migraciones legacy nuevas escriben la vinculación desde el principio.

La incorporación del campo cambia la estructura interna del Key Store, por lo que
las nuevas escrituras usan la versión 4 del formato y el lector conserva soporte
explícito para V1, V2 y V3. Esto evita reutilizar una misma versión de wire format
para dos estructuras incompatibles.

Se añadió una regresión que crea dos perfiles con la misma contraseña, intercambia
sus Key Stores y verifica que el Key Store del perfil equivocado es rechazado.

### Metadatos todavía visibles

El catálogo local `profiles.oprp` conserva identificadores de perfil y el tipo de almacenamiento para poder
resolver las rutas sin desbloquear un perfil. Las nuevas escrituras no contienen el nombre real del usuario,
ni Vault Keys, ni nombres de Cajas, ni contenido de archivos. La GUI usa etiquetas neutras (`Usuario 1`, etc.)
mientras el perfil está bloqueado; el nombre real se recupera desde el Key Store cifrado después de autenticar.

Las instalaciones antiguas pueden contener nombres de perfil en catálogos V1 hasta completar su migración.

### Límites de la frontera local

La separación de perfiles es una frontera de la aplicación. No sustituye las ACL
del sistema operativo frente a otro administrador de Windows, malware con
privilegios elevados o alguien que controle completamente la sesión del sistema.
En Windows, los puntos de reanálisis pueden cambiar el destino efectivo de las
operaciones de filesystem; el código los rechaza tanto al validar directorios como
archivos. Rust documenta además que `canonicalize` resuelve enlaces y que muchas
operaciones de filesystem están sujetas a riesgos TOCTOU.

## Endurecimiento adicional de perfiles (2026-09-28)

El catalogo global de perfiles ya no persiste los nombres de usuario en claro en sus nuevas escrituras.
La version 2 del catalogo conserva unicamente `profile_id` y el tipo de almacenamiento. El nombre visible
del usuario se guarda dentro del `keystore.opks`, en el cuerpo autenticado por la Master Key derivada de
su contraseña.

La GUI usa etiquetas neutras (`Usuario 1`, `Usuario 2`, etc.) mientras el perfil esta bloqueado. Tras una
autenticacion correcta, el nombre se recupera desde el Key Store cifrado y se muestra solo en la sesion activa.
Esto reduce la informacion expuesta a un observador que inspeccione el almacenamiento sin credenciales.

Las contraseñas de perfil no se almacenan: se usan para derivar la Master Key mediante Argon2id y los buffers
transitorios se limpian con `Zeroizing`. Las Vault Keys permanecen dentro del Key Store cifrado/autenticado.

Los catalogos V1 antiguos siguen pudiendo leerse para migracion; sus nombres pueden existir temporalmente en
memoria durante esa transicion. Al realizar una escritura V2, los nombres dejan de persistirse en el catalogo
global. Para perfiles antiguos, el primer desbloqueo copia el nombre al Key Store cifrado.

Se anadieron regresiones que comprueban que ni los nombres de perfil ni sentinels de contraseña aparecen en
el catalogo persistente, y que un nombre de perfil cifrado puede recuperarse correctamente despues de
serializar/deserializar el Key Store.

## Endurecimiento de runtime (2026-09-28)

- La sesion autenticada de Opac Window tiene un bloqueo automatico tras 10 minutos sin actividad de usuario. La actividad se detecta a partir de eventos de entrada de egui; la cuenta se reinicia al autenticar el perfil y tras un bloqueo/cambio de usuario.
- Si el tiempo de inactividad vence mientras hay una importacion, una precarga o una preparacion de audio en curso, el bloqueo queda pendiente y se ejecuta en cuanto la operacion termina, evitando cortar una escritura criptografica a mitad.
- El bloqueo y el cambio de usuario limpian inmediatamente la VaultSession, previews, buffers de preview, PINs, claves mostradas y Master Key. La reproduccion de audio detiene y espera su worker antes de liberar la salida.
- Los temporales usados para abrir contenido con aplicaciones externas y preparar audio se eliminan de forma proactiva. Si Windows mantiene un archivo abierto y el borrado falla, la ruta no se reutiliza por la siguiente sesion: queda en una lista de limpieza diferida y se vuelve a intentar periodicamente.
- El directorio temporal de la sesion tambien se marca para limpieza diferida si no puede eliminarse inmediatamente. Esto evita reutilizar accidentalmente el directorio de una sesion anterior tras cambiar de usuario.
- El bloqueo no depende de `Zeroize` como unica defensa: `Zeroizing` se usa para contrasenas y claves en memoria, mientras que el ciclo de vida de sesiones, previews, workers y temporales se acorta explicitamente.
- `PreloadAll` continua siendo una opcion explicita y sus temporales plaintext se limitan al directorio aleatorio de la sesion; el modo predeterminado sigue siendo `OnDemand`. Las vistas integradas de imagen y PDF no usan esa caché.


## Fixed56–Fixed60 — estado consolidado (2026-09-28)

### Fixed56: aislamiento por perfil y exportación

`KeyStoreSession::list_vaults()` valida las ubicaciones mediante `ensure_vault_location_in_profile_scope()`,
que permite registros cuyo directorio físico aún no se ha materializado sin aceptar una ubicación fuera
del perfil activo. `KeyStoreSession::export_vault()` revalida el scope antes de exportar la Vault Key,
y existe una regresión que comprueba este guard adicional.

### Fixed57: estabilidad del layout de egui

Los tamaños finitos de los controles sustituyen los usos de `f32::INFINITY` que podían provocar posiciones
`NaN` en layouts centrados de egui 0.36. Los controles que ocupan todo el ancho usan el ancho disponible
finito del contenedor.

### Fixed59: selector nativo directo

La acción `+ -> Importar archivos…` abre directamente el selector nativo de Windows. La importación por
arrastre de archivos y carpetas sobre la ventana principal permanece separada de ese selector.

### Fixed60: selector no bloqueante

El selector nativo se ejecuta en un hilo dedicado. La GUI recibe la selección mediante `mpsc::Receiver` y
la entrega a la cola de importación existente. Esta separación evita que el bloqueo modal del selector nativo
congele el hilo de egui o retrase el procesamiento de eventos de drag & drop en la ventana principal. No se
modifica la ruta criptográfica: los archivos seleccionados siguen usando validación de rutas, temporales
seguros y cifrado V2 por chunks.

### Estado de validación reportado por el entorno de desarrollo

En la validación realizada el 2026-09-28 se reportó compilación correcta, tests y Clippy correctos y una
ejecución de `cargo audit` que cargó la base RustSec y escaneó 436 dependencias sin mostrar un hallazgo
de vulnerabilidad en la salida proporcionada. Esta nota describe un resultado puntual; `cargo audit` debe
volver a ejecutarse porque su base de avisos se actualiza continuamente.

### Fixed63: representación visual del progreso y ramas terminales

La GUI muestra ahora un panel de progreso independiente del estado de expansión del árbol. La primera barra representa archivos completados frente al total de la importación y, cuando el archivo activo usa varios chunks, una segunda barra representa sus chunks completados frente al total. Ambos valores proceden de eventos reales del worker. La representación de las ramas terminales del árbol se ajustó para que el conector `└` termine visualmente en el nodo final sin un segmento vertical posterior accidental.


## Fixed67 — OPAC Guard (Windows, experimental)

Fixed67 incorpora `opac_guard.exe` como segundo binario del mismo proyecto. La GUI puede instalarlo/desinstalarlo desde **Ajustes → OPAC Guard** mediante una operación elevada por UAC; la interfaz principal permanece ejecutándose con los privilegios normales del usuario. Cada usuario que activa el Guard registra una instancia de servicio independiente, con nombre derivado de su SID (`OpacGuard-<SID>`), inicio automático y recuperación por reinicio tras un fallo.

### Protección de filesystem

El servicio guarda una lista acotada de raíces físicas y recorre sus subárboles sin abrir el contenido de los archivos. Los objetos gestionados que se protegen son `*.opac`, `.opac-folder` y `keystore.opks`. Para cada uno se solicita un handle con acceso requerido nulo y `FILE_SHARE_READ`, omitiendo `FILE_SHARE_WRITE` y `FILE_SHARE_DELETE`. El propósito es que Windows rechace aperturas incompatibles posteriores para escritura/borrado/renombrado mientras el handle permanezca abierto.

Las notificaciones de cambios de directorio de las primeras versiones se describen aquí como historial. Desde Fixed74 la monitorización usa `ReadDirectoryChangesW` con E/S superpuesta; la reenumeración ocurre tras una notificación y los fallos de protección son fail-closed. En Fixed85 también se tratan como fallo de enumeración los errores al leer una entrada y los reparse points que aparezcan dentro del perfil protegido.

Los puntos de reanálisis (`FILE_ATTRIBUTE_REPARSE_POINT`) no se siguen durante el recorrido para evitar atravesar enlaces/junctions hacia destinos externos; desde Fixed85, encontrar uno dentro del perfil protegido hace fallar la enumeración en modo fail-closed. Las raíces configuradas se normalizan y se eliminan raíces redundantes anidadas para reducir workers y uso de recursos.

### Estado GUI/Guard

El Guard arranca armado sobre todas las raíces persistidas. Mientras una sesión está autenticada, la GUI mantiene una conexión IPC al servicio, pero no existe un desbloqueo global de la raíz. Las raíces permanecen protegidas y solo una operación de mutación concreta puede solicitar una excepción tipada y temporal. Al bloquear/cerrar la sesión, el servicio elimina las excepciones activas y vuelve a armar toda la raíz. Si el pipe se rompe, el servicio también limpia las excepciones antes de aceptar otra conexión.

### Canal IPC y autorización

El canal del servicio se identifica por `profile_id`, rechaza clientes remotos y aplica una ACL basada en el SID de Windows como primera barrera. Después exige desafío/respuesta Ed25519 con la identidad almacenada en el Key Store del perfil. Cada orden posterior vuelve a firmarse y queda ligada al `profile_id`, al nonce fresco de la conexión, al tipo de comando, a una secuencia monotónica y al payload exacto. Las órdenes nunca transportan contraseñas ni plaintext.

### Consumo

`opac_guard.exe` no carga egui/eframe, no descifra archivos y no mantiene buffers del contenido. Su trabajo en reposo consiste principalmente en esperar notificaciones de cambio y mantener handles del sistema. El número de workers se reduce mediante la normalización de raíces; la primera implementación prioriza un coste bajo de CPU y memoria frente a una garantía de tamaño exacto, que debe medirse en Windows con árboles de 10, 100, 1.000 y más archivos.

### Alcance deliberadamente limitado

Fixed67 no incluye todavía copias de recuperación, detección criptográfica de corrupción, watchdog de la GUI ni instalador final. Esta primera iteración se limita a la protección preventiva mediante handles y a la persistencia del servicio.


### Aislamiento por usuario de Windows del Guard (Fixed67)

En Fixed67 se introdujo una separación por SID de Windows para el servicio, el pipe y la configuración del Guard. Esta versión fue posteriormente sustituida en Fixed68 porque el requisito funcional de OPAC es aislar por **usuario de la aplicación**, es decir, por perfil autenticado de Opac Window, no por cuenta de Windows.

### Fixed68 — Aislamiento por perfil de Opac Window

Fixed68 cambia la frontera de protección del Guard desde el SID de Windows al UUID del perfil de Opac Window. Cada perfil que activa la función obtiene una instancia de servicio independiente cuyo nombre, pipe y archivo de configuración se derivan del `profile_id` del perfil. La GUI consulta el estado usando exclusivamente el `active_profile_id` y solo instala/desinstala el servicio correspondiente a ese perfil.

La raíz que puede registrar el Guard queda restringida exactamente a `OpacWindow\profiles\<profile-id>`. No se permite registrar el almacenamiento global de Opac Window ni la raíz de otro perfil. Las órdenes IPC de liberación temporal (`CMD_RELEASE_PATH`) vuelven a validar esta frontera antes de cambiar la protección, y cada orden está firmada con Ed25519 y ligada al desafío de la sesión, al `profile_id`, al tipo de operación y a una secuencia monotónica. No existe una orden para desbloquear la raíz completa ni para añadir raíces arbitrarias.

El SID de Windows se conserva únicamente como mecanismo de autorización del canal IPC: el named pipe acepta al proceso `opac_window.exe` del usuario de Windows que instaló esa instancia. Esto es una capa de autorización del canal y no define el usuario de Opac Window que recibe la protección. Dos perfiles distintos del mismo Windows mantienen servicios, pipes y configuraciones independientes.


### Fixed70 — Guard embebido y materializacion bajo demanda

Fixed70 cambia la distribucion del Guard: `opac_window.exe` contiene el ejecutable del servicio como payload generado por `build.rs`. Una caja secundaria minima (`guard/Cargo.toml`) compila `guard/src/lib.rs` con un perfil release orientado a tamano; ese PE se incorpora al binario principal durante la compilacion. La copia `opac_guard.exe` no existe en disco mientras Guard permanece desactivado.

La activacion desde la GUI solicita UAC sobre el propio `opac_window.exe`. La instancia elevada verifica el perfil y la raiz recibida, materializa el payload bajo `%ProgramData%\\OpacWindow\\guard\\profiles\\<profile-id>`, persiste la configuracion y registra el servicio. La GUI normal nunca necesita privilegios de administrador. La desactivacion elevada tambien se realiza mediante el ejecutable principal y elimina el servicio antes de retirar su copia materializada.

En esta etapa el servicio sigue usando el usuario de servicio configurado por Windows y la proteccion de los binarios/ACL definitivos se deja para el instalador. La implementacion tambien elimina los antiguos comandos directos de instalacion/desinstalacion del ejecutable del Guard para que el componente materializado exponga solo el modo de servicio.

## Fixed71 — endurecimiento del Guard

Fixed71 mantiene la distribucion embebida de Fixed70 pero añade una identidad Ed25519 por perfil,
almacenada en el Key Store cifrado y persistida mediante la misma capa crash-safe de la sesion. La firma
de instalacion cubre `profile_id`, clave publica y raiz normalizada. El Guard verifica esa firma al cargar
la configuracion y rechaza configuraciones manipuladas.

La desactivacion elevada deja de depender solo del paso previo de la GUI: el comando administrativo lleva
un nonce de 32 bytes y una firma Ed25519 ligada a ese nonce y al `profile_id`. El servicio verifica esa
prueba antes de detener/eliminarse. La clave privada nunca se incluye en los argumentos del proceso elevado.

El IPC usa ACL del named pipe mas desafio/respuesta Ed25519. El SID de Windows es un filtro de acceso al
pipe, mientras que la identidad de la aplicacion sigue viniendo del `profile_id` y la clave del perfil.
Se retiro la dependencia de comparar la ruta del `opac_window.exe` con la ubicacion del Guard materializado,
porque ambas piezas viven en ubicaciones distintas por diseño.

La carpeta administrativa del Guard bajo ProgramData recibe ACLs explicitas para SYSTEM y Administradores
antes de escribir el ejecutable y la configuracion. Esto evita el problema anterior de ejecutar como LocalSystem
desde una carpeta de usuario escribible. El servicio sigue utilizando el contexto de servicio de Windows
actual en esta fase; el cambio a una identidad de servicio de privilegios minimos queda sujeto a pruebas de
acceso a los perfiles de usuario y se reserva para una iteracion posterior.

La exploracion de filesystem abre handles para archivos y directorios con `FILE_FLAG_OPEN_REPARSE_POINT`
y valida los atributos del objeto desde el propio handle para reducir TOCTOU. El preflight inicial falla
closed si una raiz no puede recorrer sus directorios. La persistencia administrativa usa `roots.bin.new`
y `roots.bin.bak` con sincronizacion previa al reemplazo.

La monitorizacion usa `ReadDirectoryChangesW` con E/S superpuesta; ante un cambio se hace una reenumeracion
controlada y, si la proteccion no puede restablecerse completamente, el servicio se detiene en modo fail-closed.



## Fixed74 — revisión de seguridad del Guard

### Corregido
- El Guard es un crate/target real del workspace y su PE se embebe en la GUI; no se distribuye como ejecutable separado mientras la funcion esta desactivada.
- La raiz protegida se compara con la ruta fisica completa derivada del `profile_id`; se rechazan rutas ajenas aunque reutilicen el mismo sufijo `OpacWindow\profiles\<id>`.
- El almacenamiento administrativo se materializa bajo `%ProgramData%\OpacWindow\guard` y recibe ACL explicitas. Las herramientas `sc.exe`, `icacls.exe` y PowerShell se resuelven desde ubicaciones del sistema.
- La configuracion `roots.bin` se autentica con Ed25519, tiene candidatos `.new`/`.bak` y una escritura temporal sincronizada.
- La desactivacion requiere autenticacion del Key Store, firma Ed25519 ligada a perfil+nonce y UAC. Tras una desactivacion completa, la identidad del Guard se borra del Key Store para forzar rotacion en la siguiente activacion.
- Los workers son fail-closed: un fallo de enumeracion, proteccion o vigilancia no deja el servicio declarado sano con proteccion parcial.
- La vigilancia usa `ReadDirectoryChangesW` con E/S superpuesta y rearma la notificacion antes de cada reenumeracion para reducir la ventana de perdida de cambios. Si el Guard debe detenerse, despierta la espera de un named pipe para que el servicio no quede bloqueado en `ConnectNamedPipe`.
- Las aperturas protegidas usan `FILE_FLAG_OPEN_REPARSE_POINT` y validan `BY_HANDLE_FILE_INFORMATION`, rechazando handles a reparse points.
- Las APIs de `ProfileCatalog` rechazan eliminar el registro o el almacenamiento dedicado si existe el estado administrativo del Guard.
- La limpieza de desinstalacion solo elimina `roots.bin*`, `opac_guard.exe` y su temporal; no se usa `remove_dir_all`. Si Windows no permite retirar un artefacto conocido, se informa del error.

### Riesgos residuales conocidos
- El servicio usa `LocalSystem` en esta fase. El ejecutable y configuracion estan bajo ACL restrictivas, pero el cambio a `LocalService`/cuenta de minimo privilegio requiere validar el acceso a los datos de perfil en Windows.
- Un administrador del sistema puede detener o eliminar un servicio y modificar recursos protegidos; esto esta fuera del modelo de amenaza de esta capa.
- La vigilancia basada en `ReadDirectoryChangesW` sigue reenumerando el subarbol despues de una notificacion; reduce polling, pero no evita el coste proporcional al tamaño del arbol.
- No hay aun copia de recuperacion del ciphertext ni restauracion automatica.
- No se afirma que el mecanismo de handles sea una proteccion antiransomware general.


### Fixed81 — reestructuración del Guard

- `opac_guard` es un único crate con `src/lib.rs` (implementación) y `src/main.rs` (wrapper).
- `opac_window` consume la librería; el binario de Guard ya no se recompila a partir de `src/guard.rs` mediante un módulo `#[path]`.
- El `build.rs` compila el binario Guard del workspace y embebe el artefacto exacto de la target triple, evitando localizar ejecutables por búsqueda recursiva.
- Esta separación reduce el riesgo de divergencia entre la GUI y el servicio y permite que `cargo test --workspace` y Clippy validen ambos destinos.

## Fixed85 — excepciones de uso mínimas y autenticadas

El Guard permanece armado mientras el perfil de OPAC esta desbloqueado. La GUI ya no puede pedir un desbloqueo global de la raiz. Para una operacion que realmente necesita modificar la estructura o el ciphertext solicita una excepcion tipada: archivo, directorio o subarbol.

Cada comando de liberacion y cada reproteccion viaja por el named pipe ya autenticado y, ademas, lleva una firma Ed25519 propia. La firma incluye el `profile_id`, el desafio aleatorio de la conexion, el tipo de comando, una secuencia monotona por conexion y el payload exacto. El servicio rechaza comandos con secuencia incorrecta, firma invalida o payload alterado.

Antes de liberar una ruta, el servicio exige que exista, no sea un reparse point, coincida con el tipo solicitado, pertenezca a una raiz configurada y, para archivos, sea uno de los artefactos cifrados protegidos por OPAC. La raiz completa del perfil nunca es liberable.

El servicio no responde con ACK de exito hasta reconstruir la proteccion restante con todas las excepciones declaradas. La GUI no continua una operacion protegida si no recibe esa confirmacion. Al finalizar, solicita la reproteccion de la ruta; una perdida del canal elimina todas las excepciones y vuelve a armar el arbol protegido.

Las lecturas y vistas previas no necesitan liberar el ciphertext porque los handles preventivos del Guard comparten `FILE_SHARE_READ` pero no escritura ni borrado. Solo las operaciones de mutacion abren esta ventana minima y temporal.


## Fixed86 — revisión de la protección de capturas

La opción de capturas no comparte estado con OPAC Guard ni cambia su IPC o sus permisos de archivos. Ante un fallo al activar, la preferencia se revierte a desactivada. Ante un fallo al desactivar, el estado efectivo conocido se mantiene y se reintenta, evitando una falsa indicación de que la protección ya fue retirada.


### Fixed105 — auditoría de instalación de Guard
Se revisó el recorrido completo GUI → elevación UAC → materialización del PE → configuración autenticada → registro/arranque del servicio → comprobación del estado.
La ruta administrativa deja de depender de variables de entorno controlables por el proceso no elevado para System32 y ProgramData. Además, se corrigió un defecto de serialización en roots.bin que impedía al servicio recuperar una configuración recién guardada.


### Fixed106 — revisión específica de instalación de Guard
La ruta administrativa se revisó completa. Se eliminó la posibilidad de que `PROGRAMDATA` o `SystemRoot` del proceso no elevado cambien la ubicación real del binario/configuración o la herramienta ejecutada con privilegios. El almacenamiento administrativo usa Known Folders y System32 usa GetSystemDirectoryW. También se corrigió la serialización de `roots.bin`, que debía ser parseable por el servicio al arrancar.


### Fixed107 — cierre de auditoría de instalación
Se corrigieron los últimos puntos detectados al inspeccionar la ruta completa: llamadas restantes a helpers ahora fallables, y el test de configuración ya ejercita el encoder real utilizado por `save_config`. Esto evita que una regresión del formato `roots.bin` vuelva a producir un servicio instalado pero incapaz de arrancar por configuración inválida.
