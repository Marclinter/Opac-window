# Fixed114 build source

Source lineage: Fixed113/112 project tree supplied by the user, with Fixed114 Guard path-resolution fix.

Primary validated defect:
`secure_guard_storage_tree()` could compare a canonical `profiles` path with a non-canonical missing descendant and reject a valid path.

Run on Windows:
`cargo check`
`cargo clippy --all-targets --all-features -- -D warnings`
`cargo test -p opac_guard --all-targets`
`cargo test`

Fixed119: correcciones de compilación y compatibilidad windows 0.62.2 para video_preview.
Fixed147: corrección de lectura de búferes RGB32 de Media Foundation respetando stride/padding/orientación 2D; conserva el ajuste de arranque A/V de Fixed146.


## Fixed150
- Coordinated chunk-level parallel encryption for a single large file, bounded to the existing worker ceiling.
- Multi-file imports retain file-level worker parallelism.
- Chunk ciphertext is written strictly in index order.
- Added regression coverage for multi-batch parallel chunk encryption and ordered roundtrip.

## Fixed218
- Derived from Fixed217.
- Windows/MSVC is configured for static CRT (`crt-static`).
- Static-CRT linkage is enforced by `build.rs` and compile-time guards in the main and Guard crates.
