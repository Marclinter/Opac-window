# Fixed221

Base: Fixed220.

## "Abrir en el reproductor predeterminado" ya no congela la GUI

`open_selected_externally` descifraba el archivo completo (o copiaba la copia
precargada) de forma síncrona en el hilo de la GUI, con el vídeo decodificándose
y el audio sonando a la vez. Con un MP4 grande eso bloqueaba el frame loop y la
ventana parecía congelada.

- El descifrado/copia pasa a un hilo (`ExternalOpenTask`); la GUI solo sondea el resultado.
- `ShellExecuteW` se sigue llamando desde el hilo de la GUI (COM/OLE ya inicializado por winit).
- `VaultSession::check_vault_file` expone la validación de ruta existente para hacerla antes de lanzar el hilo.
- Al bloquear/cambiar de usuario se espera al hilo y se borra su temporal.

Sin cambios en criptografía, formato, Guard ni pipeline de Media Foundation.
