# Fixed118 — corrección de compilación del visor de vídeo

## Correcciones

- `video_preview` vive en `src/video_preview.rs`; la declaración del módulo se mueve al crate raíz (`src/main.rs`) y `gui.rs` lo importa mediante `crate::video_preview`.
- Se inicializan en `OpacApp::new` los campos `video_duration` y `video_seek_override` añadidos por Fixed117.

## Sin cambios funcionales

- No se modifica el pipeline de vídeo, el seek, el arrastre, los temas, los morados ni OPAC Guard.
