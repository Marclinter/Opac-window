# UI / import changes Fixed150

- Large single-file imports now use coordinated chunk-level parallel encryption, up to the existing worker ceiling.
- Multi-file imports keep file-level parallelism to avoid multiplying worker pools.
- Chunks are encrypted in parallel in bounded batches and written to the `.opac` strictly in index order, preserving the file format.
- Import progress continues to report completed chunks without exposing plaintext.
