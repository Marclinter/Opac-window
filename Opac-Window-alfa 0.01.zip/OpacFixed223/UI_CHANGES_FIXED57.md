# UI changes — Fixed57

## Runtime fix: egui NaN en startup

Se sustituyeron los anchos `f32::INFINITY` usados como tamaño/desired width en la GUI por el ancho disponible finito de egui (`ui.available_width().max(1.0)`).

Esto evita que layouts centrados calculen posiciones del tipo infinito menos infinito, que en egui 0.36 puede terminar en un `Rect` con coordenadas `NaN` y provocar un panic durante el arranque.

El cambio afecta a los campos de texto y botones que buscaban ocupar todo el ancho disponible; visualmente mantienen ese comportamiento dentro de su contenedor.
