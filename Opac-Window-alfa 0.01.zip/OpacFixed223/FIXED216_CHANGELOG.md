# Fixed216

Base: OpacFixed215

## Changes
- Fixed the only warning reported by the user's `cargo check`/`cargo clippy` output: the `dwstreamindex` parameter in the Media Foundation `OnReadSample` callback is intentionally unused because `ReadSample(MF_SOURCE_READER_FIRST_VIDEO_STREAM, ...)` already targets the requested video stream and the callback receives the concrete stream index.
- Renamed the parameter to `_dwstreamindex` to make that intentional contract explicit and keep strict `-D warnings` clean.

## Scope
No video pipeline logic, decoding behavior, A/V synchronization, cryptography, Guard behavior, or memory limits were changed.
