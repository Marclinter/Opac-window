# UI / multimedia changes — Fixed185

- Hardened integrated video seeking after a runtime crash was reported while using the progress bar during playback.
- The worker now recreates the Media Foundation Source Reader before a user seek so decoder-internal state from the previous position cannot survive the seek.
- The video stream is flushed before `SetCurrentPosition`.
- After a seek, samples decoded from the keyframe before the requested timestamp are discarded until the requested position is reached.
- Audio remains paused during the seek/rebuild and is released only when the first frame from the new generation reaches the GUI.
- Existing 960×540 preview cap, 30 FPS target, 30-frame lead, 30-frame reserve and six-frame transport queue remain unchanged.
