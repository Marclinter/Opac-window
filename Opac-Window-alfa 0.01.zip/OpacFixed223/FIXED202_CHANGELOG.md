# Opac Window Fixed202 — correcciones de bugs

## Correcciones

### 1. Verificación `.opac` V2 con `chunk_size` explícito
`verify_v2_chunk_sequence()` ya no calcula el número esperado de chunks usando únicamente `DEFAULT_CHUNK_SIZE`.
Ahora utiliza el `chunk_size` almacenado en el header V2. Esto hace compatibles la generación y la verificación de archivos creados mediante `encrypt_chunked()` con tamaños de chunk personalizados.

### 2. Defensa adicional durante borrado recursivo
`delete_folder_tree()` vuelve a comprobar cada entrada inmediatamente antes de eliminarla.
- Solo se permiten archivos `.opac` y marcadores `.opac-folder`.
- Los directorios hijos deben seguir siendo directorios seguros y conservar su marcador.
- Los marcadores siguen sujetos al límite de tamaño.

Esto evita que un archivo no gestionado introducido después de la validación inicial sea eliminado silenciosamente por una operación de borrado recursivo.

### 3. Creación de Vault con PIN
`create_vault_with_pin_with_params()` ahora aplica las mismas restricciones básicas de nombre/ubicación y unicidad de ubicación que la creación mediante Vault Key.

### 4. Tests de regresión
Se añadieron pruebas para:
- aceptar V2 con `chunk_size` personalizado;
- rechazar entradas no gestionadas en la fase defensiva del borrado;
- rechazar metadata inválida y ubicaciones duplicadas en Vaults protegidas por PIN.

## Pendiente de validación de ejecución
Esta corrección fue realizada mediante revisión y modificación estática del código. La validación final debe ejecutarse en un entorno Rust/Windows con:

```powershell
cargo check
cargo test --workspace --all-targets --no-fail-fast
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo build --release --locked
```

No se afirma que esos comandos hayan pasado hasta ejecutarlos realmente.
