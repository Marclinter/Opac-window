# Fixed220

Base: Fixed218 (crt-static enabled and enforced).

## Media Foundation correction

Fixed218 exposed a real Media Foundation state error in the smoke test:
`0xC00D36B2` (`MF_E_INVALIDREQUEST`) while restoring RGB32 after a
`MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED` notification.

The previous path attempted `SetCurrentMediaType` immediately after the callback
sent its notification. In asynchronous Source Reader mode that can still race the
completion of the callback/sample request.

Fixed220 changes the handling as follows:

- Track callbacks currently executing with an atomic activity counter.
- Wait for callback quiescence before changing the reader media type.
- For `CURRENTMEDIATYPECHANGED`, first inspect `GetCurrentMediaType` as documented.
- Do not redundantly call `SetCurrentMediaType` when the current output is already RGB32.
- Reconfigure to RGB32 only when the current output subtype actually changed.
- Keep the existing resolution and memory safety checks.
- Keep crt-static unchanged.

This is intended to fix the underlying Media Foundation state race rather than
suppressing or weakening the smoke test.
