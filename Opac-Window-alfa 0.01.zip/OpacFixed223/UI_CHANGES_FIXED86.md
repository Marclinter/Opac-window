# Fixed86 — protección independiente de capturas de pantalla

Se añade en **Ajustes**, de forma completamente independiente de OPAC Guard, una opción **No permitir capturas de pantalla de OPAC**.

En Windows la implementación obtiene el HWND de la ventana eframe y aplica `SetWindowDisplayAffinity` con `WDA_EXCLUDEFROMCAPTURE`. Esto excluye la ventana de mecanismos de captura compatibles con Windows tanto en captura de pantalla completa como en selección de región o selección de ventana. No existe una API distinta que haya que activar para cada modalidad: la afinidad se aplica al HWND de nivel superior. Además, Fixed86 reaplica la afinidad si Windows recrea el HWND durante el ciclo de vida de la aplicación. Windows documenta este valor desde Windows 10 versión 2004.

La preferencia se guarda con la persistencia nativa de eframe. Se desactiva explícitamente la persistencia de posición/tamaño y memoria egui para no cambiar el comportamiento anterior de la aplicación: solo se persiste esta opción.

La protección no depende del Guard, no cambia ninguna política de archivos y no requiere UAC. Si Windows no puede aplicar la afinidad solicitada, la interfaz no presenta la función como activa y la opción de activación se revierte. Si falla al quitar la afinidad, se conserva el estado realmente aplicado y se reintenta para evitar anunciar que las capturas están permitidas cuando la protección puede seguir activa.

No es una garantía frente a cámaras, fotografías, capturadores que no respeten las APIs de Windows, ni otros métodos fuera del mecanismo de afinidad de ventana.
