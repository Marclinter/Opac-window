# Fixed28 — árbol de Caja Fuerte y acceso por Clave portable

- Las carpetas se muestran dentro del panel de contenido de la Caja Fuerte, no en la barra lateral de Cajas.
- Se sustituyeron las líneas dibujadas por conectores Unicode de árbol (`├─`, `└─`, `│`) para mantener la jerarquía estable al expandir y contraer.
- La raíz se mantiene como destino/selector, pero no dibuja una línea de conexión propia.
- El botón de creación usa `+` ASCII y un tamaño mayor para evitar glifos no soportados que aparecían como cuadrados vacíos.
- La creación de una Caja nueva genera siempre una Vault Key nueva.
- La incorporación de una Caja existente mediante Vault Key se concentra en el botón «Abrir caja con clave».
- No se modificó el formato criptográfico ni el flujo de cifrado de los archivos.


## fixed33: árbol visual y movimiento fuera de carpetas

- Los conectores del árbol se dibujan con el painter de egui en lugar de caracteres Unicode, evitando cortes o desalineaciones al expandir varios niveles.
- La raíz no dibuja un conector propio.
- La raíz es destino de DnD interno, pero nunca puede ser origen de un movimiento.
- Archivos y carpetas pueden salir de una carpeta arrastrándolos con clic derecho hasta la raíz o hasta otra carpeta.
- Soltar sobre un archivo no es un destino de movimiento; solo las carpetas y la raíz reciben movimientos internos.
