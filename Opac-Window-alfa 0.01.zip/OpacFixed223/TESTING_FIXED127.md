# Pruebas de regresión — Fixed127

## Casos cubiertos por pruebas unitarias

- un fotograma adelantado al audio entra en espera;
- un fotograma dentro de tolerancia se muestra;
- un fotograma atrasado se descarta;
- una deriva grande solicita resincronización;
- un cambio de generación invalida el estado anterior;
- una espera de audio se aborta al desactivar el reloj maestro;
- una espera de audio se aborta al cambiar la generación;
- una espera sigue siendo válida cuando todos los controles están activos y pertenecen a la misma generación.

## Verificación funcional en Windows

La validación final de reproducción debe ejecutarse en Windows con la toolchain del proyecto:

```powershell
cargo fmt --check
cargo check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
```

Para multimedia, repetir además:

1. reproducción con audio durante varios minutos;
2. pausa y reanudación sin audio;
3. seek hacia delante y hacia atrás mientras se reproduce;
4. reinicio tras finalizar;
5. audio que termina antes que el vídeo;
6. cancelación durante un descifrado de vídeo grande y comprobación de que el temporal desaparece cuando finaliza el worker;
7. comprobar que la barra nunca supera la duración mostrada.
