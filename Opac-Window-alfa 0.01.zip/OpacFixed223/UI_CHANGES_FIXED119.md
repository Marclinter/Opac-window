# Fixed119 — compatibilidad Rust/Windows para previsualización de vídeo

Corrige la compatibilidad de `src/video_preview.rs` con `windows 0.62.2` y el borrow de `TextureHandle` en la GUI.

Correcciones: `CoInitializeEx` (HRESULT), `MFCreateAttributes` (out parameter), constantes de Media Foundation mediante su valor subyacente, `IMFMediaBuffer::Lock` con puntero de salida, sustracción segura de `Instant`, y clonación del `TextureHandle` antes de mutar `OpacApp` durante los controles del visor.

No modifica la lógica criptográfica ni los tonos morados de la interfaz.
