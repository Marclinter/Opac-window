# UI_CHANGES_FIXED77

## Correccion de compilacion de OPAC Guard

Fixed77 corrige el error detectado en Fixed76 durante `cargo test --workspace --all-targets`: `root_count` se usaba despues de consumir `roots`.

Cambios:

- Se conserva el numero de raices inmediatamente despues de normalizarlas y antes de consumir el vector al crear los workers.
- Se elimina el import superior no utilizado de `Path`; los usos especificos de Windows mantienen sus imports locales.

No se cambia la politica de proteccion ni la logica criptografica del Guard.


## Fixed78
- Se completan los campos de `KeyStoreBody` al decodificar formatos legacy, incluyendo la identidad de OPAC Guard por defecto para mantener compatibilidad con almacenes antiguos.
- El crate standalone `opac_guard` deja de generar ruido de `dead_code` por las APIs de integración que son consumidas por `opac_window` y no por su binario autónomo de pruebas.
