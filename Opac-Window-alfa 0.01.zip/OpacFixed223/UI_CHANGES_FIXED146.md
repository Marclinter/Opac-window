# Cambios Fixed146 — arranque de vídeo/audio sin carrera de reloj

Se corrigió una carrera de arranque entre el reproductor de audio y Media Foundation.

Antes, al recibir `Ready`, la GUI iniciaba inmediatamente el reproductor de audio y marcaba el reloj maestro como activo. En vídeos cuyo primer fotograma tardaba más en llegar, el audio podía adelantarse al decodificador de vídeo antes de que hubiera un solo fotograma visible. El trabajador de vídeo podía entrar entonces en el flujo de espera/resincronización mientras la vista seguía mostrando "Preparando vídeo".

Ahora:

- el reproductor de audio se prepara pausado al recibir `Ready`;
- el reloj maestro permanece desactivado mientras el audio esté pendiente de arranque;
- el vídeo puede entregar su primer fotograma usando su reloj local;
- al llegar el primer fotograma mientras la reproducción está activa, se inicia el audio y se activa el reloj maestro;
- el reinicio de un vídeo vuelve a usar el mismo orden: primero fotograma, después audio;
- `update_video_audio_clock()` no considera activo un reproductor que todavía está pendiente de ese primer fotograma.

Esto mantiene el modelo actual de sincronización A/V después del arranque, pero elimina la carrera inicial.

OPAC Guard no se modifica en este Fixed.
