# Fixed223

Base: Fixed222.

## Audio desfasado tras mover la barra de posición

Síntoma: tras arrastrar la barra "Posición", el vídeo se reposicionaba bien pero el
audio sonaba en otro punto (normalmente adelantado) y seguía así con desfase constante.

Causa probable: `seek_video_playback` llamaba a `Player::try_seek` sobre el
decodificador de rodio abierto sobre el MP4 completo. Ese seek no dejaba el audio en
la posición pedida, pero `get_pos()` informaba la pedida, de modo que el reloj maestro
(audio) y el audio real quedaban desalineados de forma permanente.

Cambio:
- Ya no se usa `try_seek`. Al soltar la barra se crea en un hilo un `Player` nuevo con
  `Decoder::skip_duration(requested)`, que descarta el audio anterior a la posición
  pedida (sin seek de demuxer, preciso por construcción). La GUI no se bloquea.
- Como `get_pos()` de un Player nuevo cuenta desde 0, el reloj del audio es ahora
  `video_audio_base + get_pos()`.
- Mientras el audio se reposiciona, ▶/⏸ solo registran la intención; se aplica al terminar.
- Un nuevo seek cancela el anterior. Sin pista de audio el comportamiento no cambia.
- Sin cambios en cripto, formato, Guard ni en el scheduler de Media Foundation.

No verificado: no se ha compilado ni probado. Ver "Pruebas manuales" abajo.

## Pruebas manuales

1. Reproducir, arrastrar la barra a distintos puntos (inicio, mitad, casi el final): el
   audio debe coincidir con la imagen (voz/labios, golpes).
2. Arrastrar con el vídeo en pausa y pulsar ▶ después.
3. Arrastrar varias veces seguidas y rápido.
4. Arrastrar y pulsar ▶/⏸ mientras se reposiciona.
5. Seek cerca del final y dejar terminar; pulsar ↻.
6. Cambiar el volumen tras un seek (debe afectar al audio nuevo).
