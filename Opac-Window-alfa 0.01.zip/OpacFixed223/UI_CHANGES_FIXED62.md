# OPAC Window Fixed62

## Árbol de jerarquía

- Las líneas verticales del árbol se extienden sobre la mitad del `item_spacing` de egui.
- Esto elimina los pequeños cortes visibles entre filas hermanas sin cambiar la indentación ni la interacción del árbol.
- La geometría de las ramas sigue anclada a la columna de los controles de expansión.

## Progreso de cifrado de archivos grandes

- Se mantiene la barra de progreso por chunks introducida anteriormente.
- V2 utiliza un único chunk hasta 8 MiB; por encima de 8 MiB usa chunks de 4 MiB.
- La GUI muestra una barra de 0–100 % para el archivo grande que está siendo cifrado en ese momento.
- El backend informa después de cada chunk autenticado y escrito.
- El test de regresión verifica 1/3, 2/3 y 3/3 para un archivo de 8 MiB + 1 byte.


> Refinado en Fixed63: el progreso se trasladó a un panel siempre visible y las ramas terminales reciben una protección visual adicional.
