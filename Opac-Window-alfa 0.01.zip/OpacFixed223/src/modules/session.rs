//! API de alto nivel para la futura GUI de Opac Window.
//!
//! `KeyStoreSession` representa una sesion desbloqueada de la instalacion
//! local. `VaultSession` representa una Caja Fuerte concreta ya abierta con
//! su propia Vault Key. La GUI debe trabajar con estas APIs y no acceder
//! directamente a primitivas criptograficas ni al formato binario.

use std::fs;
use std::io::{self, Read, Seek, SeekFrom};
use std::path::{Path, PathBuf};

use thiserror::Error;
use uuid::Uuid;
use zeroize::Zeroizing;

use crate::modules::keys::VaultKey;
use crate::modules::master_key::{MasterKey, MasterKeyError};
use crate::modules::opac_format::{self, OpacError, OpacMetadata};
use crate::modules::persistence::{ExclusiveFileLock, KeyStoreFile, PersistenceError};
use crate::modules::vault::{KeyStore, VaultAccessMode, VaultError, VaultInfo};
use crate::modules::vault_fs::{self, VaultFsError};

#[derive(Debug, Error)]
pub enum SessionError {
    #[error(transparent)]
    Persistence(#[from] PersistenceError),
    #[error(transparent)]
    Vault(#[from] VaultError),
    #[error(transparent)]
    VaultFs(#[from] VaultFsError),
    #[error(transparent)]
    Opac(#[from] OpacError),
    #[error(transparent)]
    MasterKey(#[from] MasterKeyError),
    #[error("el archivo indicado no pertenece a la carpeta de la Caja Fuerte")]
    InvalidVaultPath,
    #[error("el archivo no es un .opac valido")]
    InvalidVaultFile,
    #[error("la Caja Fuerte esta fuera de la carpeta del usuario activo")]
    VaultOutsideProfile,
    #[error("el archivo es demasiado grande para una vista previa en memoria")]
    PreviewTooLarge,
}

/// Sesion local desbloqueada. Mientras exista, la Master Key permanece en
/// memoria; al destruirla, la Master Key se libera y `Zeroizing` limpia sus
/// bytes. Cada `VaultSession` abierta es independiente y conserva su propia
/// Vault Key hasta que esa sesion se destruye o se llama a `VaultSession::lock`.
pub struct KeyStoreSession {
    storage: KeyStoreFile,
    // Mantiene un bloqueo exclusivo mientras la sesion esta desbloqueada.
    _writer_lock: ExclusiveFileLock,
    store: KeyStore,
    master_key: MasterKey,
    profile_root: Option<PathBuf>,
}

#[derive(Debug)]
pub struct PreparedScopedOpen {
    storage: KeyStoreFile,
    writer_lock: ExclusiveFileLock,
    profile_root: PathBuf,
}

impl PreparedScopedOpen {
    fn prepare(
        path: impl Into<PathBuf>,
        profile_root: impl Into<PathBuf>,
    ) -> Result<Self, SessionError> {
        let path = path.into();
        let profile_root = profile_root.into();
        vault_fs::create_vault_folder(&profile_root)?;
        ensure_path_within_profile_root(&path, &profile_root)?;
        let storage = KeyStoreFile::new(path);
        let writer_lock = storage.acquire_lock()?;
        Ok(Self {
            storage,
            writer_lock,
            profile_root,
        })
    }

    fn open_unlocked(&self, master_password: &[u8]) -> Result<(KeyStore, MasterKey), SessionError> {
        let (store, master_key) = self.storage.open_unlocked(master_password)?;
        validate_store_profile_scope(&store, &self.profile_root)?;
        if let Some(profile_id) = profile_id_from_root(&self.profile_root)
            && let Some(bound_id) = store.profile_id()
            && bound_id != profile_id
        {
            return Err(SessionError::VaultOutsideProfile);
        }
        Ok((store, master_key))
    }

    pub fn finish(
        self,
        mut store: KeyStore,
        master_key: MasterKey,
    ) -> Result<KeyStoreSession, SessionError> {
        validate_store_profile_scope(&store, &self.profile_root)?;
        if let Some(profile_id) = profile_id_from_root(&self.profile_root)
            && let Some(bound_id) = store.profile_id()
            && bound_id != profile_id
        {
            return Err(SessionError::VaultOutsideProfile);
        }
        if let Some(profile_id) = profile_id_from_root(&self.profile_root)
            && store.profile_id().is_none()
        {
            store.bind_profile_id(profile_id)?;
            self.storage.save_unlocked(&store, &master_key)?;
        }
        Ok(KeyStoreSession {
            storage: self.storage,
            _writer_lock: self.writer_lock,
            store,
            master_key,
            profile_root: Some(self.profile_root),
        })
    }
}

impl KeyStoreSession {
    pub fn create(path: impl Into<PathBuf>, master_password: &[u8]) -> Result<Self, SessionError> {
        let storage = KeyStoreFile::new(path);
        let writer_lock = storage.acquire_lock()?;
        let (store, master_key) = storage.create_new_unlocked(master_password)?;
        Ok(Self {
            storage,
            _writer_lock: writer_lock,
            store,
            master_key,
            profile_root: None,
        })
    }

    pub fn create_default(master_password: &[u8]) -> Result<Self, SessionError> {
        let path = KeyStoreFile::default_path().ok_or_else(|| {
            PersistenceError::Io(std::io::Error::new(
                std::io::ErrorKind::NotFound,
                "no se pudo determinar la carpeta local de Opac Window",
            ))
        })?;
        Self::create(path, master_password)
    }

    pub fn open(path: impl Into<PathBuf>, master_password: &[u8]) -> Result<Self, SessionError> {
        let storage = KeyStoreFile::new(path);
        let writer_lock = storage.acquire_lock()?;
        let (store, master_key) = storage.open_unlocked(master_password)?;
        Ok(Self {
            storage,
            _writer_lock: writer_lock,
            store,
            master_key,
            profile_root: None,
        })
    }

    pub fn open_default(master_password: &[u8]) -> Result<Self, SessionError> {
        let path = KeyStoreFile::default_path().ok_or_else(|| {
            PersistenceError::Io(std::io::Error::new(
                std::io::ErrorKind::NotFound,
                "no se pudo determinar la carpeta local de Opac Window",
            ))
        })?;
        Self::open(path, master_password)
    }

    pub fn create_scoped(
        path: impl Into<PathBuf>,
        profile_root: impl Into<PathBuf>,
        master_password: &[u8],
    ) -> Result<Self, SessionError> {
        Self::create_scoped_internal(path, profile_root, master_password, None)
    }

    pub fn create_scoped_named(
        path: impl Into<PathBuf>,
        profile_root: impl Into<PathBuf>,
        profile_name: &str,
        master_password: &[u8],
    ) -> Result<Self, SessionError> {
        Self::create_scoped_internal(path, profile_root, master_password, Some(profile_name))
    }

    fn create_scoped_internal(
        path: impl Into<PathBuf>,
        profile_root: impl Into<PathBuf>,
        master_password: &[u8],
        profile_name: Option<&str>,
    ) -> Result<Self, SessionError> {
        let path = path.into();
        let profile_root = profile_root.into();
        vault_fs::create_vault_folder(&profile_root)?;
        ensure_path_within_profile_root(&path, &profile_root)?;
        let mut session = Self::create(path, master_password)?;
        session.profile_root = Some(profile_root.clone());
        if let Some(profile_id) = profile_id_from_root(&profile_root) {
            session.store.bind_profile_id(profile_id)?;
        }
        if let Some(profile_name) = profile_name {
            session.store.set_profile_name(profile_name)?;
        }
        session.save()?;
        Ok(session)
    }

    pub fn open_scoped(
        path: impl Into<PathBuf>,
        profile_root: impl Into<PathBuf>,
        master_password: &[u8],
    ) -> Result<Self, SessionError> {
        let prepared = PreparedScopedOpen::prepare(path, profile_root)?;
        let (store, master_key) = prepared.open_unlocked(master_password)?;
        prepared.finish(store, master_key)
    }

    /// Prepara la apertura de un perfil dedicado adquiriendo el bloqueo en el
    /// hilo llamador. El bloqueo nunca se transfiere al worker criptografico.
    pub fn prepare_scoped_open(
        path: impl Into<PathBuf>,
        profile_root: impl Into<PathBuf>,
    ) -> Result<PreparedScopedOpen, SessionError> {
        PreparedScopedOpen::prepare(path, profile_root)
    }

    /// Abre un perfil dedicado sin adquirir un lock. Debe usarse unicamente
    /// mientras la GUI ya mantiene el lock obtenido por `prepare_scoped_open`.
    /// El resultado contiene solo datos que pueden cruzar un canal entre hilos.
    pub fn open_scoped_unlocked_parts(
        path: impl Into<PathBuf>,
        profile_root: impl Into<PathBuf>,
        master_password: &[u8],
    ) -> Result<(KeyStore, MasterKey), SessionError> {
        let path = path.into();
        let profile_root = profile_root.into();
        vault_fs::create_vault_folder(&profile_root)?;
        ensure_path_within_profile_root(&path, &profile_root)?;
        let storage = KeyStoreFile::new(path);
        let (store, master_key) = storage.open_unlocked(master_password)?;
        validate_store_profile_scope(&store, &profile_root)?;
        if let Some(profile_id) = profile_id_from_root(&profile_root)
            && let Some(bound_id) = store.profile_id()
            && bound_id != profile_id
        {
            return Err(SessionError::VaultOutsideProfile);
        }
        Ok((store, master_key))
    }

    /// Reautentica una contrasena contra un perfil dedicado sin intentar abrir
    /// otra sesion ni adquirir el bloqueo exclusivo que ya posee la GUI.
    /// No modifica el Key Store ni limpia archivos de recuperacion.
    pub fn authenticate_scoped(
        path: impl Into<PathBuf>,
        profile_root: impl Into<PathBuf>,
        master_password: &[u8],
    ) -> Result<(), SessionError> {
        let path = path.into();
        let profile_root = profile_root.into();
        ensure_path_within_profile_root(&path, &profile_root)?;
        let storage = KeyStoreFile::new(path);
        let (store, _master_key) = storage
            .authenticate_unlocked(master_password)
            .map_err(SessionError::from)?;
        if let Some(profile_id) = profile_id_from_root(&profile_root)
            && let Some(bound_id) = store.profile_id()
            && bound_id != profile_id
        {
            return Err(SessionError::VaultOutsideProfile);
        }
        Ok(())
    }

    /// Migra una sesion de perfil antigua a un directorio de usuario dedicado.
    /// Los directorios de Cajas se copian como ciphertext puro y despues se
    /// actualizan sus ubicaciones en el Key Store. La Vault Key no se modifica
    /// y las Cajas con PIN no requieren introducir sus PIN para la migracion.
    ///
    /// Devuelve las rutas antiguas para que el llamador las elimine solo despues
    /// de haber actualizado el catalogo de perfiles.
    pub fn migrate_to_profile_root(
        &mut self,
        new_profile_root: impl Into<PathBuf>,
    ) -> Result<(PathBuf, Vec<PathBuf>), SessionError> {
        if self.profile_root.is_some() {
            return Err(SessionError::VaultOutsideProfile);
        }
        let new_root = new_profile_root.into();
        vault_fs::create_vault_folder(&new_root)?;
        let new_vaults_root = new_root.join("vaults");
        vault_fs::create_vault_folder(&new_vaults_root)?;
        let new_root_abs = fs::canonicalize(&new_root).unwrap_or_else(|_| new_root.clone());

        let vaults = self.store.list_vaults();
        let mut moves: Vec<(Uuid, PathBuf, PathBuf)> = Vec::with_capacity(vaults.len());
        let mut destinations = std::collections::HashSet::with_capacity(vaults.len());

        for info in &vaults {
            let source = PathBuf::from(&info.location);
            let source_abs = fs::canonicalize(&source).map_err(SessionError::from)?;
            if source_abs == new_root_abs
                || source_abs.starts_with(&new_root_abs)
                || new_root_abs.starts_with(&source_abs)
                || moves.iter().any(|(_, existing, _)| {
                    source_abs == *existing
                        || source_abs.starts_with(existing)
                        || existing.starts_with(&source_abs)
                })
            {
                let _ = fs::remove_dir_all(&new_root);
                return Err(SessionError::InvalidVaultPath);
            }
            vault_fs::ensure_migratable_vault_root(&source_abs)?;
            let destination = new_vaults_root.join(Uuid::new_v4().simple().to_string());
            if !destinations.insert(destination.clone()) {
                let _ = fs::remove_dir_all(&new_root);
                return Err(SessionError::InvalidVaultPath);
            }
            if let Err(error) = vault_fs::copy_vault_root_for_migration(&source_abs, &destination) {
                let _ = fs::remove_dir_all(&new_root);
                return Err(SessionError::VaultFs(error));
            }
            moves.push((info.id, source_abs, destination));
        }

        let destination_storage =
            crate::modules::persistence::KeyStoreFile::new(new_root.join("keystore.opks"));
        let previous_store = self.store.to_bytes(&self.master_key)?;
        let old_storage = self.storage.clone();
        let old_storage_path = old_storage.path().to_path_buf();
        let old_sources: Vec<PathBuf> = moves
            .iter()
            .map(|(_id, source, _destination)| source.clone())
            .collect();

        for (id, _source, destination) in &moves {
            if let Err(error) = self
                .store
                .set_vault_location(*id, &destination.to_string_lossy())
            {
                self.store =
                    KeyStore::from_bytes_with_master_key(&previous_store, &self.master_key)?;
                let _ = fs::remove_dir_all(&new_root);
                return Err(SessionError::Vault(error));
            }
        }
        if let Some(profile_id) = profile_id_from_root(&new_root) {
            self.store.bind_profile_id(profile_id)?;
        }

        let destination_lock = match destination_storage.acquire_lock() {
            Ok(lock) => lock,
            Err(error) => {
                self.store =
                    KeyStore::from_bytes_with_master_key(&previous_store, &self.master_key)?;
                let _ = fs::remove_dir_all(&new_root);
                return Err(SessionError::Persistence(error));
            }
        };
        if let Err(error) = destination_storage.save_unlocked(&self.store, &self.master_key) {
            self.store = KeyStore::from_bytes_with_master_key(&previous_store, &self.master_key)?;
            let _ = destination_storage.rollback_uncommitted_save_unlocked();
            let _ = fs::remove_dir_all(&new_root);
            drop(destination_lock);
            return Err(SessionError::Persistence(error));
        }

        self.storage = destination_storage;
        self._writer_lock = destination_lock;
        self.profile_root = Some(new_root);

        // No se elimina nada aqui. El catalogo de perfiles debe confirmar antes
        // que el nuevo almacenamiento dedicado sera el oficial.
        Ok((old_storage_path, old_sources))
    }

    pub fn profile_root(&self) -> Option<&Path> {
        self.profile_root.as_deref()
    }

    pub fn storage_path(&self) -> &Path {
        self.storage.path()
    }

    pub fn profile_name(&self) -> Option<&str> {
        self.store.profile_name()
    }

    pub fn set_profile_name(&mut self, name: &str) -> Result<(), SessionError> {
        self.store.set_profile_name(name)?;
        self.save()?;
        Ok(())
    }

    pub fn profile_vaults_root(&self) -> Result<PathBuf, SessionError> {
        let root = self
            .profile_root
            .clone()
            .ok_or(SessionError::VaultOutsideProfile)?;
        let vaults_root = root.join("vaults");
        vault_fs::create_vault_folder(&vaults_root)?;
        Ok(vaults_root)
    }

    fn ensure_in_profile_scope(&self, path: &Path) -> Result<(), SessionError> {
        let Some(root) = self.profile_root.as_deref() else {
            return Ok(());
        };
        let root_abs = fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
        let path_abs = resolve_scope_path(path)?;
        if !path_abs.starts_with(&root_abs) {
            return Err(SessionError::VaultOutsideProfile);
        }
        Ok(())
    }

    fn ensure_vault_location_in_profile_scope(&self, path: &Path) -> Result<(), SessionError> {
        self.ensure_in_profile_scope(path)?;
        if let Some(root) = self.profile_root.as_deref() {
            let root_abs = fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
            let path_abs = resolve_scope_path(path)?;
            if path_abs == root_abs {
                return Err(SessionError::VaultOutsideProfile);
            }
        }
        Ok(())
    }

    pub fn path(&self) -> &Path {
        self.storage.path()
    }

    pub fn list_vaults(&self) -> Vec<VaultInfo> {
        self.store
            .list_vaults()
            .into_iter()
            .filter(|info| {
                self.ensure_vault_location_in_profile_scope(Path::new(&info.location))
                    .is_ok()
            })
            .collect()
    }

    pub fn open_vault(
        &self,
        vault_id: Uuid,
        pin: Option<&[u8]>,
    ) -> Result<VaultSession, SessionError> {
        let info = self
            .store
            .list_vaults()
            .into_iter()
            .find(|vault| vault.id == vault_id)
            .ok_or(VaultError::NotFound)?;
        self.ensure_vault_location_in_profile_scope(Path::new(&info.location))?;
        let key = self.store.unlock_vault(vault_id, pin)?;
        Ok(VaultSession { info, key })
    }

    /// Abre una Caja Fuerte usando directamente su Vault Key portable. Esto
    /// constituye una credencial alternativa al PIN: quien posea la clave
    /// puede acceder a los archivos de esa Caja. No modifica la proteccion
    /// almacenada en el Key Store ni los archivos `.opac`.
    pub fn open_vault_with_key(
        &self,
        vault_id: Uuid,
        key: [u8; 32],
    ) -> Result<VaultSession, SessionError> {
        let info = self
            .store
            .list_vaults()
            .into_iter()
            .find(|vault| vault.id == vault_id)
            .ok_or(VaultError::NotFound)?;
        self.ensure_vault_location_in_profile_scope(Path::new(&info.location))?;
        vault_fs::validate_vault_access(Path::new(&info.location), &key)?;
        Ok(VaultSession {
            info,
            key: VaultKey::from_bytes(key),
        })
    }

    /// Elimina una Caja Fuerte completamente. Para Cajas con PIN exige que
    /// la sesion haya sido abierta con el PIN; una Vault Key portable por si
    /// sola no habilita esta operacion destructiva. El Key Store se persiste
    /// antes del borrado fisico y se restaura si este ultimo falla.
    pub fn delete_vault(
        &mut self,
        vault_id: Uuid,
        vault_key: &[u8; 32],
        pin_authenticated: bool,
    ) -> Result<(), SessionError> {
        let info = self
            .store
            .list_vaults()
            .into_iter()
            .find(|vault| vault.id == vault_id)
            .ok_or(VaultError::NotFound)?;

        if info.has_pin && !pin_authenticated {
            return Err(VaultError::PinRequired.into());
        }
        if !info.has_pin && !self.store.vault_key_matches(vault_id, vault_key)? {
            return Err(SessionError::InvalidVaultPath);
        }

        let location = PathBuf::from(&info.location);
        self.ensure_vault_location_in_profile_scope(&location)?;
        let location_abs = fs::canonicalize(&location).unwrap_or_else(|_| location.clone());
        for other in self.list_vaults() {
            if other.id == vault_id {
                continue;
            }
            let other_path = PathBuf::from(&other.location);
            let other_abs = fs::canonicalize(&other_path).unwrap_or_else(|_| other_path.clone());
            if location_abs == other_abs
                || location_abs.starts_with(&other_abs)
                || other_abs.starts_with(&location_abs)
            {
                return Err(SessionError::InvalidVaultPath);
            }
        }

        // Autentica el arbol completo antes de tocar el Key Store. Esto tambien
        // evita borrar un directorio que contenga entradas no gestionadas.
        vault_fs::validate_vault_access(&location, vault_key)?;

        let previous_bytes = self.store.to_bytes(&self.master_key)?;
        self.store.remove_vault(vault_id)?;
        if let Err(error) = self.storage.save_unlocked(&self.store, &self.master_key) {
            let _ = self.storage.rollback_uncommitted_save_unlocked();
            self.store = KeyStore::from_bytes_with_master_key(&previous_bytes, &self.master_key)?;
            return Err(SessionError::Persistence(error));
        }

        if let Err(error) = vault_fs::delete_vault_root(&location, vault_key) {
            self.store = KeyStore::from_bytes_with_master_key(&previous_bytes, &self.master_key)?;
            if let Err(restore_error) = self.storage.save_unlocked(&self.store, &self.master_key) {
                let _ = self.storage.rollback_uncommitted_save_unlocked();
                return Err(SessionError::Persistence(restore_error));
            }
            return Err(SessionError::VaultFs(error));
        }

        Ok(())
    }

    pub fn set_vault_access_mode(
        &mut self,
        vault_id: Uuid,
        mode: VaultAccessMode,
    ) -> Result<(), SessionError> {
        self.mutate_and_persist(|store| {
            store.set_vault_access_mode(vault_id, mode)?;
            Ok(())
        })
    }

    pub fn create_vault(&mut self, name: &str, location: &Path) -> Result<Uuid, SessionError> {
        self.ensure_vault_location_in_profile_scope(location)?;
        self.mutate_and_persist(|store| {
            store
                .create_vault(name, &location.to_string_lossy())
                .map_err(SessionError::from)
        })
    }

    /// Crea una Caja Fuerte en el padre indicado. La carpeta fisica final usa
    /// un nombre aleatorio para no exponer el nombre visible de la Caja.
    /// `imported_key` permite reutilizar una Vault Key portable ya existente.
    pub fn create_vault_in_parent(
        &mut self,
        name: &str,
        parent: &Path,
        imported_key: Option<[u8; 32]>,
    ) -> Result<Uuid, SessionError> {
        self.ensure_in_profile_scope(parent)?;
        if !parent.exists() {
            return Err(SessionError::Persistence(PersistenceError::Io(
                std::io::Error::new(
                    std::io::ErrorKind::NotFound,
                    "la ubicacion elegida no existe",
                ),
            )));
        }
        if !parent.is_dir() {
            return Err(SessionError::Persistence(PersistenceError::Io(
                std::io::Error::new(
                    std::io::ErrorKind::NotADirectory,
                    "la ubicacion elegida no es una carpeta",
                ),
            )));
        }
        let parent_absolute = fs::canonicalize(parent).unwrap_or_else(|_| parent.to_path_buf());
        for info in self.list_vaults() {
            let vault_path = Path::new(&info.location);
            let vault_absolute =
                fs::canonicalize(vault_path).unwrap_or_else(|_| vault_path.to_path_buf());
            if parent_absolute == vault_absolute || parent_absolute.starts_with(&vault_absolute) {
                return Err(SessionError::InvalidVaultPath);
            }
        }

        // La carpeta elegida por el usuario es un contenedor externo y no debe
        // perder su ACL/permisos. Solo validamos su seguridad; la nueva carpeta
        // de la Caja Fuerte recibe despues la ACL privada de OPAC.
        vault_fs::validate_safe_directory(parent)?;

        for _ in 0..32 {
            let folder = parent.join(Uuid::new_v4().simple().to_string());
            if folder.exists() {
                continue;
            }
            vault_fs::create_vault_folder(&folder)?;
            let result = if let Some(key) = imported_key {
                self.create_vault_with_key(name, &folder, key)
            } else {
                self.create_vault(name, &folder)
            };
            match result {
                Ok(id) => return Ok(id),
                Err(error) => {
                    let _ = fs::remove_dir(&folder);
                    return Err(error);
                }
            }
        }

        Err(SessionError::Persistence(PersistenceError::Io(
            std::io::Error::new(
                std::io::ErrorKind::AlreadyExists,
                "no se pudo reservar una carpeta unica para la Caja Fuerte",
            ),
        )))
    }

    /// Crea una Caja Fuerte en la zona de almacenamiento local de Opac Window
    /// sin exigir a la GUI que gestione rutas. Cada carpeta recibe un
    /// identificador aleatorio y no utiliza el nombre visible de la Caja.
    pub fn create_vault_default(&mut self, name: &str) -> Result<Uuid, SessionError> {
        let vaults_root = if self.profile_root.is_some() {
            self.profile_vaults_root()?
        } else {
            let root = vault_fs::default_vaults_root().ok_or_else(|| {
                SessionError::Persistence(PersistenceError::Io(std::io::Error::new(
                    std::io::ErrorKind::NotFound,
                    "no se pudo determinar el almacenamiento local de Opac Window",
                )))
            })?;
            root.join("vaults")
        };
        vault_fs::create_vault_folder(&vaults_root)?;

        for _ in 0..32 {
            let folder = vaults_root.join(Uuid::new_v4().simple().to_string());
            if folder.exists() {
                continue;
            }
            vault_fs::create_vault_folder(&folder)?;
            match self.create_vault(name, &folder) {
                Ok(id) => return Ok(id),
                Err(error) => {
                    let _ = std::fs::remove_dir(&folder);
                    return Err(error);
                }
            }
        }

        Err(SessionError::Persistence(PersistenceError::Io(
            std::io::Error::new(
                std::io::ErrorKind::AlreadyExists,
                "no se pudo reservar una carpeta local unica para la Caja Fuerte",
            ),
        )))
    }

    /// Variante predeterminada que reutiliza una Vault Key portable. La Caja
    /// se crea vacia y queda registrada con exactamente la clave proporcionada.
    pub fn create_vault_default_with_key(
        &mut self,
        name: &str,
        key: [u8; 32],
    ) -> Result<Uuid, SessionError> {
        let vaults_root = if self.profile_root.is_some() {
            self.profile_vaults_root()?
        } else {
            let root = vault_fs::default_vaults_root().ok_or_else(|| {
                SessionError::Persistence(PersistenceError::Io(std::io::Error::new(
                    std::io::ErrorKind::NotFound,
                    "no se pudo determinar el almacenamiento local de Opac Window",
                )))
            })?;
            root.join("vaults")
        };
        vault_fs::create_vault_folder(&vaults_root)?;

        for _ in 0..32 {
            let folder = vaults_root.join(Uuid::new_v4().simple().to_string());
            if folder.exists() {
                continue;
            }
            vault_fs::create_vault_folder(&folder)?;
            match self.create_vault_with_key(name, &folder, key) {
                Ok(id) => return Ok(id),
                Err(error) => {
                    let _ = std::fs::remove_dir(&folder);
                    return Err(error);
                }
            }
        }

        Err(SessionError::Persistence(PersistenceError::Io(
            std::io::Error::new(
                io::ErrorKind::AlreadyExists,
                "no se pudo reservar una carpeta local unica para la Caja Fuerte",
            ),
        )))
    }

    pub fn create_vault_with_key(
        &mut self,
        name: &str,
        location: &Path,
        key: [u8; 32],
    ) -> Result<Uuid, SessionError> {
        self.ensure_vault_location_in_profile_scope(location)?;
        self.mutate_and_persist(|store| {
            store
                .create_vault_with_key(name, &location.to_string_lossy(), key)
                .map_err(SessionError::from)
        })
    }

    pub fn create_vault_with_pin(
        &mut self,
        name: &str,
        location: &Path,
        pin: &[u8],
    ) -> Result<Uuid, SessionError> {
        self.ensure_vault_location_in_profile_scope(location)?;
        self.mutate_and_persist(|store| {
            store
                .create_vault_with_pin(name, &location.to_string_lossy(), pin)
                .map_err(SessionError::from)
        })
    }

    pub fn add_pin(&mut self, vault_id: Uuid, pin: &[u8]) -> Result<(), SessionError> {
        self.mutate_and_persist(|store| {
            store.add_pin(vault_id, pin)?;
            Ok(())
        })
    }

    pub fn change_pin(
        &mut self,
        vault_id: Uuid,
        old_pin: &[u8],
        new_pin: &[u8],
    ) -> Result<(), SessionError> {
        self.mutate_and_persist(|store| {
            store.change_pin(vault_id, old_pin, new_pin)?;
            Ok(())
        })
    }

    pub fn import_vault(
        &mut self,
        data: &[u8],
        export_password: &[u8],
        location: &Path,
    ) -> Result<Uuid, SessionError> {
        self.ensure_vault_location_in_profile_scope(location)?;
        self.mutate_and_persist(|store| {
            store
                .import_vault(data, export_password, &location.to_string_lossy())
                .map_err(SessionError::from)
        })
    }

    /// Registra una carpeta de Caja Fuerte existente usando directamente su
    /// Vault Key portable. La carpeta debe contener solo entradas gestionadas
    /// y su contenido se autentica antes de tocar el Key Store.
    pub fn import_vault_with_key(
        &mut self,
        name: &str,
        location: &Path,
        key: [u8; 32],
    ) -> Result<Uuid, SessionError> {
        self.ensure_vault_location_in_profile_scope(location)?;
        self.mutate_and_persist(|store| {
            store
                .import_vault_with_key(name, &location.to_string_lossy(), key)
                .map_err(SessionError::from)
        })
    }

    /// Importa una Caja Fuerte externa copiando su arbol cifrado a la carpeta
    /// privada del perfil activo. La carpeta de origen nunca se modifica y los
    /// bytes ciphertext se copian sin descifrar ni recifrar.
    pub fn import_external_vault_with_key(
        &mut self,
        name: &str,
        source: &Path,
        key: [u8; 32],
    ) -> Result<Uuid, SessionError> {
        let vaults_root = self.profile_vaults_root()?;
        vault_fs::validate_vault_access(source, &key)?;
        for _ in 0..32 {
            let destination = vaults_root.join(Uuid::new_v4().simple().to_string());
            if destination.exists() {
                continue;
            }
            match vault_fs::copy_vault_root(source, &destination, &key) {
                Ok(()) => {
                    let result = self.import_vault_with_key(name, &destination, key);
                    if result.is_err() {
                        let _ = vault_fs::delete_vault_root(&destination, &key);
                    }
                    return result;
                }
                Err(error) => return Err(SessionError::VaultFs(error)),
            }
        }
        Err(SessionError::Persistence(PersistenceError::Io(
            io::Error::new(
                io::ErrorKind::AlreadyExists,
                "no se pudo reservar una carpeta interna para la Caja importada",
            ),
        )))
    }

    pub fn export_vault(
        &self,
        vault_id: Uuid,
        pin: Option<&[u8]>,
        export_password: &[u8],
    ) -> Result<Vec<u8>, SessionError> {
        let info = self
            .store
            .list_vaults()
            .into_iter()
            .find(|vault| vault.id == vault_id)
            .ok_or(VaultError::NotFound)?;
        self.ensure_vault_location_in_profile_scope(Path::new(&info.location))?;
        Ok(self.store.export_vault(vault_id, pin, export_password)?)
    }

    /// Cambia la contrasena maestra y persiste el nuevo Key Store de forma
    /// recuperable. Ninguna Vault Key ni ningun `.opac` se vuelve a cifrar.
    pub fn change_master_password(&mut self, new_password: &[u8]) -> Result<(), SessionError> {
        let previous_bytes = self.store.to_bytes(&self.master_key)?;
        let previous_master = MasterKey::from_bytes(*self.master_key.as_bytes());

        let new_master = self.store.change_master_password(new_password)?;
        self.master_key = new_master;

        if let Err(error) = self.storage.save_unlocked(&self.store, &self.master_key) {
            let _ = self.storage.rollback_uncommitted_save_unlocked();
            let restored = KeyStore::from_bytes_with_master_key(&previous_bytes, &previous_master)?;
            self.store = restored;
            self.master_key = previous_master;
            return Err(SessionError::Persistence(error));
        }
        Ok(())
    }

    pub fn save(&self) -> Result<(), SessionError> {
        Ok(self.storage.save_unlocked(&self.store, &self.master_key)?)
    }

    /// Devuelve la identidad criptografica de OPAC Guard si el perfil ya la
    /// tiene configurada: clave privada para firmar desafios y clave publica
    /// correspondiente. La privada solo abandona el Key Store cifrado en la
    /// memoria del proceso GUI y debe mantenerse en un wrapper zeroizing.
    pub fn guard_identity(&self) -> Option<(Zeroizing<[u8; 32]>, [u8; 32])> {
        self.store
            .guard_identity()
            .map(|(private, public)| (Zeroizing::new(private), public))
    }

    /// Crea y persiste la identidad de Guard para este perfil una sola vez.
    pub fn ensure_guard_identity(
        &mut self,
    ) -> Result<(Zeroizing<[u8; 32]>, [u8; 32]), SessionError> {
        if let Some(identity) = self.guard_identity() {
            return Ok(identity);
        }
        let previous_bytes = self.store.to_bytes(&self.master_key)?;
        let private = crate::modules::crypto::random_key();
        let signing = ed25519_dalek::SigningKey::from_bytes(&private);
        let public = signing.verifying_key().to_bytes();
        self.store.set_guard_identity(private, public)?;
        if let Err(error) = self.storage.save_unlocked(&self.store, &self.master_key) {
            self.store = KeyStore::from_bytes_with_master_key(&previous_bytes, &self.master_key)?;
            let _ = self.storage.rollback_uncommitted_save_unlocked();
            return Err(SessionError::Persistence(error));
        }
        Ok((Zeroizing::new(private), public))
    }

    /// Elimina la identidad persistida del Guard despues de una desactivacion
    /// autenticada. La siguiente activacion generara una identidad nueva, lo
    /// que invalida pruebas de desactivacion capturadas de una instalacion anterior.
    pub fn clear_guard_identity(&mut self) -> Result<(), SessionError> {
        if self.guard_identity().is_none() {
            return Ok(());
        }
        let previous_bytes = self.store.to_bytes(&self.master_key)?;
        self.store.clear_guard_identity();
        if let Err(error) = self.storage.save_unlocked(&self.store, &self.master_key) {
            self.store = KeyStore::from_bytes_with_master_key(&previous_bytes, &self.master_key)?;
            let _ = self.storage.rollback_uncommitted_save_unlocked();
            return Err(SessionError::Persistence(error));
        }
        Ok(())
    }

    /// Cierra la sesion del Key Store inmediatamente. Las `VaultSession`
    /// que se hayan entregado a la GUI son objetos independientes y deben
    /// bloquearse por separado.
    pub fn lock(self) {}

    fn mutate_and_persist<T, F>(&mut self, mutation: F) -> Result<T, SessionError>
    where
        F: FnOnce(&mut KeyStore) -> Result<T, SessionError>,
    {
        let previous_bytes = self.store.to_bytes(&self.master_key)?;
        let result = mutation(&mut self.store)?;
        if let Err(error) = validate_vault_location_set(&self.store) {
            self.store = KeyStore::from_bytes_with_master_key(&previous_bytes, &self.master_key)?;
            return Err(error);
        }
        if let Some(root) = self.profile_root.as_deref()
            && let Err(error) = validate_store_profile_scope(&self.store, root)
        {
            self.store = KeyStore::from_bytes_with_master_key(&previous_bytes, &self.master_key)?;
            return Err(error);
        }
        if let Err(error) = self.storage.save_unlocked(&self.store, &self.master_key) {
            let _ = self.storage.rollback_uncommitted_save_unlocked();
            self.store = KeyStore::from_bytes_with_master_key(&previous_bytes, &self.master_key)?;
            return Err(SessionError::Persistence(error));
        }
        Ok(result)
    }
}

fn resolve_scope_path(path: &Path) -> Result<PathBuf, SessionError> {
    let mut missing_components = Vec::new();
    let mut current = path.to_path_buf();

    while !current.exists() {
        let Some(name) = current.file_name() else {
            break;
        };
        missing_components.push(name.to_os_string());
        if !current.pop() {
            break;
        }
    }

    let mut resolved = fs::canonicalize(&current).map_err(SessionError::from)?;
    for component in missing_components.iter().rev() {
        resolved.push(component);
    }
    Ok(resolved)
}

fn validate_vault_location_set(store: &KeyStore) -> Result<(), SessionError> {
    let vaults = store.list_vaults();
    let mut paths = Vec::with_capacity(vaults.len());
    for info in &vaults {
        paths.push(resolve_scope_path(Path::new(&info.location))?);
    }
    for (index, path) in paths.iter().enumerate() {
        for (other_index, other) in paths.iter().enumerate() {
            if index != other_index
                && (path == other || path.starts_with(other) || other.starts_with(path))
            {
                return Err(SessionError::VaultOutsideProfile);
            }
        }
    }
    Ok(())
}

fn validate_store_profile_scope(store: &KeyStore, root: &Path) -> Result<(), SessionError> {
    vault_fs::create_vault_folder(root)?;
    let root_abs = fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
    let vaults = store.list_vaults();
    let mut paths = Vec::with_capacity(vaults.len());
    for info in &vaults {
        let path = Path::new(&info.location);
        ensure_path_within_profile_root(path, root)?;
        let path_abs = resolve_scope_path(path)?;
        if !path_abs.starts_with(&root_abs) || path_abs == root_abs {
            return Err(SessionError::VaultOutsideProfile);
        }
        paths.push(path_abs);
    }
    for (index, path) in paths.iter().enumerate() {
        for (other_index, other) in paths.iter().enumerate() {
            if index != other_index && (path.starts_with(other) || other.starts_with(path)) {
                return Err(SessionError::VaultOutsideProfile);
            }
        }
    }
    Ok(())
}

fn profile_id_from_root(profile_root: &Path) -> Option<Uuid> {
    let name = profile_root.file_name()?.to_str()?;
    Uuid::parse_str(name).ok()
}

fn ensure_path_within_profile_root(path: &Path, profile_root: &Path) -> Result<(), SessionError> {
    let root_abs = fs::canonicalize(profile_root).unwrap_or_else(|_| profile_root.to_path_buf());
    let target_abs = resolve_scope_path(path)?;
    if target_abs == root_abs || !target_abs.starts_with(&root_abs) {
        return Err(SessionError::VaultOutsideProfile);
    }
    Ok(())
}

/// Caja Fuerte concreta abierta. Contiene una unica Vault Key, independiente
/// de las demas Cajas Fuertes.
pub struct VaultSession {
    info: VaultInfo,
    key: VaultKey,
}

impl VaultSession {
    pub fn info(&self) -> &VaultInfo {
        &self.info
    }

    pub fn location(&self) -> &Path {
        Path::new(&self.info.location)
    }

    pub fn set_access_mode(&mut self, mode: VaultAccessMode) {
        self.info.access_mode = mode;
    }

    /// Acceso interno a la Vault Key para operaciones criptograficas de la
    /// propia sesion. La GUI no debe usar este metodo para presentarla al
    /// usuario.
    #[allow(dead_code)]
    pub fn key_bytes(&self) -> &[u8; 32] {
        self.key.as_bytes()
    }

    /// Crea una copia transitoria de la Vault Key exclusivamente para una
    /// accion explicita de usuario, como pulsar el boton «Clave». El buffer
    /// resultante se limpia al salir de su ambito.
    pub fn reveal_vault_key(&self) -> Zeroizing<[u8; 32]> {
        Zeroizing::new(*self.key.as_bytes())
    }

    pub fn list_files(&self) -> Result<Vec<PathBuf>, SessionError> {
        Ok(vault_fs::list_vault_files(self.location())?)
    }

    pub fn list_folders(&self) -> Result<Vec<(PathBuf, OpacMetadata)>, SessionError> {
        Ok(vault_fs::list_vault_folders(
            self.location(),
            self.key.as_bytes(),
        )?)
    }

    /// Recupera en memoria un archivo pequeno, limitado expresamente para
    /// previsualizaciones de texto de la GUI. No debe utilizarse para abrir
    /// archivos grandes; para esos casos la GUI usa `decrypt_file`.
    pub fn read_small_file(
        &self,
        path: &Path,
        max_bytes: usize,
    ) -> Result<(OpacMetadata, Zeroizing<Vec<u8>>), SessionError> {
        self.validate_vault_file(path)?;
        let mut file = vault_fs::open_safe_regular_file(path)?;
        let version = read_opac_version(&mut file)?;

        if version == opac_format::OPAC_VERSION {
            // Authenticate the metadata first. Esto evita leer de golpe todo
            // el ciphertext de un `.opac` potencialmente malformado solo
            // porque la GUI quiere una vista previa pequeña.
            file.seek(SeekFrom::Start(0))?;
            let metadata = opac_format::read_metadata_only(self.key.as_bytes(), &mut file)?;
            let size = usize::try_from(metadata.original_size).unwrap_or(usize::MAX);
            if size > max_bytes {
                return Err(SessionError::PreviewTooLarge);
            }

            file.seek(SeekFrom::Start(0))?;
            let mut content = Zeroizing::new(Vec::with_capacity(size));
            let decrypted_metadata =
                opac_format::decrypt_chunked(self.key.as_bytes(), &mut file, &mut *content)?;
            if decrypted_metadata != metadata || content.len() != size {
                return Err(SessionError::InvalidVaultFile);
            }
            return Ok((decrypted_metadata, content));
        }

        if version == opac_format::OPAC_VERSION_LEGACY_V1 {
            // V1 ya tiene un límite interno de 16 MiB, pero evitamos incluso
            // esa lectura completa cuando el ciphertext ya es claramente
            // demasiado grande para una vista previa de `max_bytes`.
            const LEGACY_PREVIEW_OVERHEAD: u64 = 128 * 1024;
            let file_len = file.metadata()?.len();
            if file_len > max_bytes as u64 + LEGACY_PREVIEW_OVERHEAD {
                return Err(SessionError::PreviewTooLarge);
            }
            let data = {
                use std::io::Read;
                let hard_limit = (max_bytes as u64 + LEGACY_PREVIEW_OVERHEAD).saturating_add(1);
                let mut data = Vec::with_capacity(file_len as usize);
                file.take(hard_limit).read_to_end(&mut data)?;
                if data.len() as u64 > max_bytes as u64 + LEGACY_PREVIEW_OVERHEAD {
                    return Err(SessionError::PreviewTooLarge);
                }
                data
            };
            let decrypted = opac_format::decrypt(self.key.as_bytes(), &data)?;
            if decrypted.content.len() > max_bytes {
                return Err(SessionError::PreviewTooLarge);
            }
            return Ok((decrypted.metadata, decrypted.content));
        }

        Err(SessionError::InvalidVaultFile)
    }

    pub fn read_file_metadata(&self, path: &Path) -> Result<OpacMetadata, SessionError> {
        self.validate_vault_file(path)?;
        let mut file = vault_fs::open_safe_regular_file(path)?;
        let version = read_opac_version(&mut file)?;
        if version == opac_format::OPAC_VERSION {
            file.seek(SeekFrom::Start(0))?;
            return Ok(opac_format::read_metadata_only(
                self.key.as_bytes(),
                &mut file,
            )?);
        }
        if version == opac_format::OPAC_VERSION_LEGACY_V1 {
            let file_len = file.metadata()?.len();
            if file_len > opac_format::MAX_LEGACY_V1_FILE_SIZE {
                return Err(SessionError::InvalidVaultFile);
            }
            let hard_limit = opac_format::MAX_LEGACY_V1_FILE_SIZE.saturating_add(1);
            let mut data = Vec::with_capacity(file_len as usize);
            file.take(hard_limit).read_to_end(&mut data)?;
            if data.len() as u64 > opac_format::MAX_LEGACY_V1_FILE_SIZE {
                return Err(SessionError::InvalidVaultFile);
            }
            return Ok(opac_format::decrypt(self.key.as_bytes(), &data)?.metadata);
        }
        Err(SessionError::InvalidVaultFile)
    }

    pub fn import_file(&self, source: &Path) -> Result<PathBuf, SessionError> {
        self.import_file_into(source, self.location())
    }

    pub fn import_file_into(
        &self,
        source: &Path,
        target_folder: &Path,
    ) -> Result<PathBuf, SessionError> {
        // La raiz fisica de una Caja puede no existir hasta la primera escritura.
        // `encrypt_file_into_vault_folder` crea y valida la raiz de forma segura
        // antes de validar `target_folder`, evitando rechazar la primera
        // importacion con `NotFound`.
        Ok(vault_fs::encrypt_file_into_vault_folder(
            self.location(),
            target_folder,
            self.key.as_bytes(),
            source,
        )?)
    }

    pub fn create_folder(&self, parent_folder: &Path, name: &str) -> Result<PathBuf, SessionError> {
        Ok(vault_fs::create_folder(
            self.location(),
            parent_folder,
            name,
            self.key.as_bytes(),
        )?)
    }

    pub fn create_text_file(
        &self,
        parent_folder: &Path,
        name: &str,
    ) -> Result<PathBuf, SessionError> {
        Ok(vault_fs::create_text_file(
            self.location(),
            parent_folder,
            name,
            self.key.as_bytes(),
        )?)
    }

    pub fn move_file(
        &self,
        opac_path: &Path,
        destination_folder: &Path,
    ) -> Result<PathBuf, SessionError> {
        Ok(vault_fs::move_file(
            self.location(),
            opac_path,
            destination_folder,
            self.key.as_bytes(),
        )?)
    }

    pub fn move_folder(
        &self,
        folder_path: &Path,
        destination_parent: &Path,
    ) -> Result<PathBuf, SessionError> {
        Ok(vault_fs::move_folder(
            self.location(),
            folder_path,
            destination_parent,
            self.key.as_bytes(),
        )?)
    }

    pub fn delete_folder(&self, folder_path: &Path) -> Result<(), SessionError> {
        Ok(vault_fs::delete_folder(
            self.location(),
            folder_path,
            self.key.as_bytes(),
        )?)
    }

    pub fn rename_file(
        &self,
        opac_path: &Path,
        new_name: &str,
    ) -> Result<OpacMetadata, SessionError> {
        self.validate_vault_file(opac_path)?;
        Ok(vault_fs::rename_file(
            self.location(),
            opac_path,
            self.key.as_bytes(),
            new_name,
        )?)
    }

    pub fn rename_folder(
        &self,
        folder_path: &Path,
        new_name: &str,
    ) -> Result<OpacMetadata, SessionError> {
        Ok(vault_fs::rename_folder(
            self.location(),
            folder_path,
            self.key.as_bytes(),
            new_name,
        )?)
    }

    pub fn export_folder(
        &self,
        folder_path: &Path,
        destination_parent: &Path,
    ) -> Result<(usize, usize), SessionError> {
        Ok(vault_fs::export_folder_to_directory(
            self.location(),
            folder_path,
            destination_parent,
            self.key.as_bytes(),
        )?)
    }

    /// Descifra de forma segura a un destino nuevo; nunca sobrescribe un
    /// archivo existente y deja el destino intacto ante un fallo.
    pub fn decrypt_file(
        &self,
        opac_path: &Path,
        destination: &Path,
    ) -> Result<OpacMetadata, SessionError> {
        self.validate_vault_file(opac_path)?;
        Ok(vault_fs::decrypt_file_from_vault(
            opac_path,
            self.key.as_bytes(),
            destination,
        )?)
    }

    /// Reemplaza el contenido de un archivo ya existente y vuelve a cifrarlo
    /// bajo la misma ruta opaca. La operación es atómica a nivel lógico:
    /// primero se prepara y sincroniza el nuevo `.opac`, después se aparta la
    /// versión anterior y solo se publica la nueva cuando está lista.
    pub fn replace_file_content(
        &self,
        opac_path: &Path,
        content: &[u8],
    ) -> Result<OpacMetadata, SessionError> {
        self.validate_vault_file(opac_path)?;
        Ok(vault_fs::replace_file_content(
            self.location(),
            opac_path,
            self.key.as_bytes(),
            content,
        )?)
    }

    pub fn delete_file(&self, opac_path: &Path) -> Result<(), SessionError> {
        self.validate_vault_file(opac_path)?;
        Ok(vault_fs::delete_vault_file(self.location(), opac_path)?)
    }

    /// Migra todos los V1 encontrados en la Caja Fuerte. Los V2 actuales se
    /// dejan intactos. Devuelve las nuevas rutas de los archivos migrados.
    pub fn migrate_legacy_files(&self) -> Result<Vec<PathBuf>, SessionError> {
        let mut migrated = Vec::new();
        for path in self.list_files()? {
            let before = path.clone();
            let after =
                vault_fs::migrate_legacy_v1_file(&before, self.location(), self.key.as_bytes())?;
            if after != before {
                migrated.push(after);
            }
        }
        Ok(migrated)
    }

    /// Cierra la Caja Fuerte inmediatamente.
    pub fn lock(self) {}

    /// Valida que `path` pertenece a esta Caja Fuerte. Permite a la GUI
    /// comprobarlo en el hilo de la interfaz antes de descifrar en segundo plano.
    pub fn check_vault_file(&self, path: &Path) -> Result<(), SessionError> {
        self.validate_vault_file(path)
    }

    fn validate_vault_file(&self, path: &Path) -> Result<(), SessionError> {
        vault_fs::validate_vault_path(self.location(), path).map_err(|error| match error {
            VaultFsError::InvalidVaultPath => SessionError::InvalidVaultPath,
            VaultFsError::UnsafeFilesystemEntry => {
                SessionError::VaultFs(VaultFsError::UnsafeFilesystemEntry)
            }
            other => SessionError::VaultFs(other),
        })?;
        if path.extension().and_then(|ext| ext.to_str()) != Some("opac") {
            return Err(SessionError::InvalidVaultPath);
        }
        Ok(())
    }
}

fn read_opac_version(file: &mut fs::File) -> Result<u16, SessionError> {
    use std::io::Read;
    let mut header = [0u8; 6];
    file.read_exact(&mut header).map_err(VaultFsError::Io)?;
    if &header[..4] != opac_format::OPAC_MAGIC {
        return Err(SessionError::InvalidVaultFile);
    }
    Ok(u16::from_le_bytes([header[4], header[5]]))
}

impl From<std::io::Error> for SessionError {
    fn from(error: std::io::Error) -> Self {
        SessionError::VaultFs(VaultFsError::Io(error))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use uuid::Uuid;

    fn temp_root() -> PathBuf {
        std::env::temp_dir().join(format!("opac_session_{}", Uuid::new_v4()))
    }

    fn fast_password() -> &'static [u8] {
        b"password-largo-de-prueba"
    }

    #[test]
    fn migrate_legacy_session_to_dedicated_root_preserves_ciphertext() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let legacy_store_path = root.join("keystore.opks");
        let legacy_vault_root = root.join("legacy-vault");
        let source = root.join("secreto.txt");
        fs::write(&source, b"contenido secreto de migracion").unwrap();

        let mut session = KeyStoreSession::create(&legacy_store_path, fast_password()).unwrap();
        let id = session
            .create_vault("Personal", &legacy_vault_root)
            .unwrap();
        let vault = session.open_vault(id, None).unwrap();
        let opac = vault.import_file(&source).unwrap();
        let ciphertext = fs::read(&opac).unwrap();
        let old_source_abs = fs::canonicalize(&legacy_vault_root).unwrap();

        let dedicated_root = root.join("profiles").join("usuario");
        let (old_store, old_sources) = session.migrate_to_profile_root(&dedicated_root).unwrap();
        let migrated = session
            .list_vaults()
            .into_iter()
            .find(|info| info.id == id)
            .unwrap();
        let migrated_root = PathBuf::from(&migrated.location);
        assert!(migrated_root.starts_with(&dedicated_root));
        assert_eq!(old_store, legacy_store_path);
        assert_eq!(old_sources, vec![old_source_abs.clone()]);
        assert!(legacy_vault_root.is_dir());

        let migrated_opac = migrated_root.join(opac.file_name().unwrap());
        assert_eq!(fs::read(&migrated_opac).unwrap(), ciphertext);
        let recovered = root.join("recovered.txt");
        session
            .open_vault(id, None)
            .unwrap()
            .decrypt_file(&migrated_opac, &recovered)
            .unwrap();
        assert_eq!(
            fs::read(recovered).unwrap(),
            b"contenido secreto de migracion"
        );

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn migrate_pin_vault_to_dedicated_root_without_requiring_pin() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let legacy_store_path = root.join("keystore.opks");
        let legacy_vault_root = root.join("legacy-pin-vault");
        let source = root.join("secreto-pin.txt");
        fs::write(&source, b"contenido protegido por pin").unwrap();

        let mut session = KeyStoreSession::create(&legacy_store_path, fast_password()).unwrap();
        let id = session
            .create_vault_with_pin("Personal", &legacy_vault_root, b"Ab3dEf7g")
            .unwrap();
        let vault = session.open_vault(id, Some(b"Ab3dEf7g")).unwrap();
        let opac = vault.import_file(&source).unwrap();
        let ciphertext = fs::read(&opac).unwrap();

        let dedicated_root = root.join("profiles").join("usuario");
        let (_old_store, _old_sources) = session.migrate_to_profile_root(&dedicated_root).unwrap();

        let info = session
            .list_vaults()
            .into_iter()
            .find(|info| info.id == id)
            .unwrap();
        assert!(Path::new(&info.location).starts_with(&dedicated_root));
        assert!(matches!(
            session.open_vault(id, None),
            Err(SessionError::Vault(VaultError::PinRequired))
        ));

        let migrated = session.open_vault(id, Some(b"Ab3dEf7g")).unwrap();
        let migrated_opac = PathBuf::from(&info.location).join(opac.file_name().unwrap());
        assert_eq!(fs::read(&migrated_opac).unwrap(), ciphertext);
        let recovered = root.join("recovered-pin.txt");
        migrated.decrypt_file(&migrated_opac, &recovered).unwrap();
        assert_eq!(fs::read(recovered).unwrap(), b"contenido protegido por pin");

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn create_open_and_persist_vault() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        assert_eq!(session.list_vaults().len(), 1);
        drop(session);

        let reopened = KeyStoreSession::open(&key_store_path, fast_password()).unwrap();
        let vault = reopened.open_vault(id, None).unwrap();
        assert_eq!(vault.info().name, "Personal");

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn second_key_store_session_is_rejected_while_first_is_alive() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        assert!(matches!(
            KeyStoreSession::open(&key_store_path, fast_password()),
            Err(SessionError::Persistence(PersistenceError::WriterLocked))
        ));
        drop(session);
        let reopened = KeyStoreSession::open(&key_store_path, fast_password()).unwrap();
        drop(reopened);
        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn vault_session_isolated_and_can_roundtrip_file() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");
        let source = root.join("documento.txt");
        let destination = root.join("recuperado.txt");
        fs::write(&source, b"contenido secreto").unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        let vault = session.open_vault(id, None).unwrap();
        let opac = vault.import_file(&source).unwrap();
        let metadata = vault.read_file_metadata(&opac).unwrap();
        assert_eq!(metadata.original_name, "documento.txt");
        vault.decrypt_file(&opac, &destination).unwrap();
        assert_eq!(fs::read(&destination).unwrap(), b"contenido secreto");

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn guard_identity_rotates_after_deactivation() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let profile_root = root.join(Uuid::new_v4().simple().to_string());
        fs::create_dir_all(&profile_root).unwrap();
        let key_store_path = profile_root.join("keystore.opks");

        let mut session = KeyStoreSession::create_scoped_named(
            &key_store_path,
            &profile_root,
            "Perfil Guard",
            fast_password(),
        )
        .unwrap();
        let first = session.ensure_guard_identity().unwrap();
        let first_private = *first.0;
        let first_public = first.1;

        session.clear_guard_identity().unwrap();
        assert!(session.guard_identity().is_none());

        let second = session.ensure_guard_identity().unwrap();
        assert_ne!(first_private, *second.0);
        assert_ne!(first_public, second.1);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn first_file_import_materializes_vault_root() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");
        let source = root.join("primero.txt");
        fs::write(&source, b"primer contenido secreto").unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        assert!(!vault_path.exists());
        let vault = session.open_vault(id, None).unwrap();

        let opac = vault.import_file(&source).unwrap();
        assert!(vault_path.is_dir());
        assert!(opac.exists());
        let destination = root.join("restaurado.txt");
        vault.decrypt_file(&opac, &destination).unwrap();
        assert_eq!(fs::read(&destination).unwrap(), b"primer contenido secreto");

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn scoped_reauthentication_works_while_session_holds_writer_lock() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let profile_root = root.join(Uuid::new_v4().simple().to_string());
        let key_store_path = profile_root.join("keystore.opks");
        let password = fast_password();

        let session = KeyStoreSession::create_scoped_named(
            &key_store_path,
            &profile_root,
            "Perfil Guard",
            password,
        )
        .unwrap();

        assert!(
            KeyStoreSession::authenticate_scoped(&key_store_path, &profile_root, password,).is_ok()
        );
        assert!(
            KeyStoreSession::authenticate_scoped(
                &key_store_path,
                &profile_root,
                b"otra-contrasena-incorreccta",
            )
            .is_err()
        );

        drop(session);
        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn scoped_profile_name_roundtrips_encrypted_without_password_on_disk() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let profile_root = root.join(Uuid::new_v4().simple().to_string());
        fs::create_dir_all(&profile_root).unwrap();
        let key_store_path = profile_root.join("keystore.opks");
        let password = b"perfil-password-super-largo";
        let secret_name = "Nombre de perfil extremadamente privado";

        let session = KeyStoreSession::create_scoped_named(
            &key_store_path,
            &profile_root,
            secret_name,
            password,
        )
        .unwrap();
        assert_eq!(session.profile_name(), Some(secret_name));
        drop(session);

        let bytes = fs::read(&key_store_path).unwrap();
        assert!(
            !bytes
                .windows(secret_name.len())
                .any(|w| w == secret_name.as_bytes())
        );
        assert!(!bytes.windows(password.len()).any(|w| w == password));

        let reopened =
            KeyStoreSession::open_scoped(&key_store_path, &profile_root, password).unwrap();
        assert_eq!(reopened.profile_name(), Some(secret_name));

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn reveal_vault_key_is_explicit_and_does_not_rotate_key() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        let vault = session.open_vault(id, None).unwrap();

        let first = vault.reveal_vault_key();
        let second = vault.reveal_vault_key();
        assert_eq!(&*first, &*second);
        assert_eq!(first.len(), 32);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn portable_key_opens_pin_vault_and_decrypts_nested_file() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");
        let source = root.join("secreto.bin");
        fs::write(&source, b"contenido portable secreto").unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session
            .create_vault_with_pin("Personal", &vault_path, b"Ab3dEf7g")
            .unwrap();
        let pin_vault = session.open_vault(id, Some(b"Ab3dEf7g")).unwrap();
        let key = *pin_vault.key_bytes();
        let folder = vault_fs::create_folder(&vault_path, &vault_path, "Nivel 1", &key).unwrap();
        let opac = pin_vault.import_file_into(&source, &folder).unwrap();
        let ciphertext_before = fs::read(&opac).unwrap();

        let reopened = session.open_vault_with_key(id, key).unwrap();
        let destination = root.join("recuperado.bin");
        reopened.decrypt_file(&opac, &destination).unwrap();
        assert_eq!(
            fs::read(destination).unwrap(),
            b"contenido portable secreto"
        );
        assert_eq!(fs::read(&opac).unwrap(), ciphertext_before);

        let mut wrong_key = key;
        wrong_key[0] ^= 0x5a;
        assert!(session.open_vault_with_key(id, wrong_key).is_err());

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn import_vault_with_portable_key_persists_registration_without_reencrypting() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("destination.opks");
        let vault_path = root.join("copied-vault");
        let source = root.join("origen.txt");
        fs::write(&source, b"texto de transferencia").unwrap();

        let source_store_path = root.join("source.opks");
        let mut source_session =
            KeyStoreSession::create(&source_store_path, fast_password()).unwrap();
        let source_id = source_session.create_vault("Origen", &vault_path).unwrap();
        let source_vault = source_session.open_vault(source_id, None).unwrap();
        let opac = source_vault.import_file(&source).unwrap();
        let key = *source_vault.key_bytes();
        let ciphertext_before = fs::read(&opac).unwrap();

        let mut destination = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let imported_id = destination
            .import_vault_with_key("Transferida", &vault_path, key)
            .unwrap();
        let imported = destination.open_vault(imported_id, None).unwrap();
        let recovered = root.join("recuperado.txt");
        imported.decrypt_file(&opac, &recovered).unwrap();
        assert_eq!(fs::read(recovered).unwrap(), b"texto de transferencia");
        assert_eq!(fs::read(&opac).unwrap(), ciphertext_before);
        drop(destination);

        let reopened = KeyStoreSession::open(&key_store_path, fast_password()).unwrap();
        assert_eq!(reopened.list_vaults().len(), 1);
        assert_eq!(
            reopened.open_vault(imported_id, None).unwrap().key_bytes(),
            &key
        );

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn create_vault_default_with_imported_key_is_usable_and_persistent() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("destination.opks");
        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let imported_key = [0x3Cu8; 32];

        let id = session
            .create_vault_default_with_key("Importada", imported_key)
            .unwrap();
        let info = session
            .list_vaults()
            .into_iter()
            .find(|info| info.id == id)
            .unwrap();
        assert!(Path::new(&info.location).is_dir());
        assert_eq!(
            session.open_vault(id, None).unwrap().key_bytes(),
            &imported_key
        );
        drop(session);

        let reopened = KeyStoreSession::open(&key_store_path, fast_password()).unwrap();
        assert_eq!(
            reopened.open_vault(id, None).unwrap().key_bytes(),
            &imported_key
        );

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn create_vault_in_parent_with_imported_key_is_usable_and_persistent() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let source_store_path = root.join("source.opks");
        let destination_store_path = root.join("destination.opks");
        let parent = root.join("destino-personalizado");
        fs::create_dir_all(&parent).unwrap();
        let source = root.join("origen.txt");
        fs::write(&source, b"contenido interoperable").unwrap();

        let mut source_session =
            KeyStoreSession::create(&source_store_path, fast_password()).unwrap();
        let source_id = source_session
            .create_vault("Origen", &root.join("origen-vault"))
            .unwrap();
        let source_vault = source_session.open_vault(source_id, None).unwrap();
        let source_opac = source_vault.import_file(&source).unwrap();
        let imported_key = *source_vault.key_bytes();
        let original_ciphertext = fs::read(&source_opac).unwrap();

        let mut destination =
            KeyStoreSession::create(&destination_store_path, fast_password()).unwrap();
        let id = destination
            .create_vault_in_parent("Importada", &parent, Some(imported_key))
            .unwrap();
        let info = destination
            .list_vaults()
            .into_iter()
            .find(|info| info.id == id)
            .unwrap();
        let vault_path = PathBuf::from(&info.location);
        assert!(vault_path.starts_with(&parent));
        assert!(vault_path.is_dir());
        assert_eq!(
            destination.open_vault(id, None).unwrap().key_bytes(),
            &imported_key
        );

        // Simulamos el traslado de ciphertext entre dispositivos: el archivo
        // `.opac` se copia sin volver a cifrarlo y la nueva Caja, creada con la
        // misma Vault Key, debe poder leerlo.
        let copied_opac = vault_path.join(source_opac.file_name().unwrap());
        fs::copy(&source_opac, &copied_opac).unwrap();
        assert_eq!(fs::read(&copied_opac).unwrap(), original_ciphertext);
        let imported_vault = destination.open_vault(id, None).unwrap();
        let recovered = root.join("recuperado-desde-ciphertext.txt");
        imported_vault
            .decrypt_file(&copied_opac, &recovered)
            .unwrap();
        assert_eq!(fs::read(&recovered).unwrap(), b"contenido interoperable");
        assert_eq!(fs::read(&copied_opac).unwrap(), original_ciphertext);
        let mut wrong_key = imported_key;
        wrong_key[0] ^= 0xA5;
        assert!(destination.open_vault_with_key(id, wrong_key).is_err());

        // La Caja tambien se comporta como una Caja normal: los archivos nuevos
        // usan exactamente la clave importada.
        let new_source = root.join("nuevo.txt");
        fs::write(&new_source, b"nuevo contenido con la misma clave").unwrap();
        let new_opac = imported_vault.import_file(&new_source).unwrap();
        let new_recovered = root.join("nuevo-recuperado.txt");
        imported_vault
            .decrypt_file(&new_opac, &new_recovered)
            .unwrap();
        assert_eq!(
            fs::read(&new_recovered).unwrap(),
            b"nuevo contenido con la misma clave"
        );
        drop(destination);

        let reopened = KeyStoreSession::open(&destination_store_path, fast_password()).unwrap();
        let reopened_vault = reopened.open_vault(id, None).unwrap();
        assert_eq!(reopened_vault.key_bytes(), &imported_key);

        fs::remove_dir_all(root).ok();
    }

    #[cfg(unix)]
    #[test]
    fn create_vault_in_parent_does_not_change_parent_permissions() {
        use std::os::unix::fs::PermissionsExt;

        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let parent = root.join("contenedor-compartido");
        fs::create_dir_all(&parent).unwrap();
        fs::set_permissions(&parent, fs::Permissions::from_mode(0o755)).unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        session
            .create_vault_in_parent("Sin tocar padre", &parent, None)
            .unwrap();

        let mode = fs::metadata(&parent).unwrap().permissions().mode() & 0o777;
        assert_eq!(mode, 0o755);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn create_vault_in_parent_rejects_nesting_inside_existing_vault() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let existing = root.join("existente");
        fs::create_dir_all(&existing).unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Existente", &existing).unwrap();
        let nested_parent = existing.join("subcarpeta");
        fs::create_dir_all(&nested_parent).unwrap();

        let result = session.create_vault_in_parent("No permitida", &nested_parent, None);
        assert!(matches!(result, Err(SessionError::InvalidVaultPath)));
        assert_eq!(session.list_vaults().len(), 1);
        assert_eq!(session.list_vaults()[0].id, id);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn scoped_create_vault_accepts_missing_intermediate_parent_inside_profile() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let profile = root.join("profile");
        let key_store_path = profile.join("keystore.opks");
        let vault_path = profile.join("vaults").join("vault-a");

        let mut session =
            KeyStoreSession::create_scoped(&key_store_path, &profile, fast_password()).unwrap();
        let id = session.create_vault("Caja", &vault_path).unwrap();

        assert_eq!(session.list_vaults().len(), 1);
        assert_eq!(session.list_vaults()[0].id, id);
        assert!(session.open_vault(id, None).is_ok());

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn create_vault_rejects_nested_location_during_persisted_mutation() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let outer = root.join("outer");
        let nested = outer.join("nested");
        fs::create_dir_all(&nested).unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let outer_id = session.create_vault("Exterior", &outer).unwrap();
        assert!(matches!(
            session.create_vault("Anidada", &nested),
            Err(SessionError::VaultOutsideProfile)
        ));
        assert_eq!(session.list_vaults()[0].id, outer_id);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn scoped_sessions_isolate_vault_locations_by_profile_root() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let profile_a = root.join("profile-a");
        let profile_b = root.join("profile-b");
        let store_a = profile_a.join("keystore.opks");
        let store_b = profile_b.join("keystore.opks");
        let vault_a_root = profile_a.join("vaults");
        let vault_b_root = profile_b.join("vaults");
        fs::create_dir_all(&vault_a_root).unwrap();
        fs::create_dir_all(&vault_b_root).unwrap();

        let mut a = KeyStoreSession::create_scoped(&store_a, &profile_a, fast_password()).unwrap();
        let id_a = a.create_vault("A", &vault_a_root.join("a")).unwrap();
        assert_eq!(a.list_vaults().len(), 1);
        assert!(a.open_vault(id_a, None).is_ok());

        assert!(matches!(
            a.create_vault("Fuera", &vault_b_root.join("evil")),
            Err(SessionError::VaultOutsideProfile)
        ));

        let mut b = KeyStoreSession::create_scoped(&store_b, &profile_b, fast_password()).unwrap();
        let id_b = b.create_vault("B", &vault_b_root.join("b")).unwrap();
        assert_eq!(b.list_vaults().len(), 1);
        assert!(b.open_vault(id_b, None).is_ok());
        assert!(b.open_vault(id_a, None).is_err());

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn scoped_export_rechecks_vault_location_scope() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let profile = root.join("profile");
        let outside = root.join("outside");
        fs::create_dir_all(profile.join("vaults")).unwrap();
        fs::create_dir_all(&outside).unwrap();
        let store_path = profile.join("keystore.opks");

        let mut session =
            KeyStoreSession::create_scoped(&store_path, &profile, fast_password()).unwrap();
        let id = session
            .create_vault("Exportable", &profile.join("vaults").join("vault"))
            .unwrap();

        session
            .store
            .set_vault_location(id, &outside.to_string_lossy())
            .unwrap();

        assert!(matches!(
            session.export_vault(id, None, b"export-password"),
            Err(SessionError::VaultOutsideProfile)
        ));

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn scoped_session_rejects_keystore_entries_outside_active_profile() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let profile = root.join("profile");
        let outside = root.join("outside-vault");
        fs::create_dir_all(profile.join("vaults")).unwrap();
        fs::create_dir_all(&outside).unwrap();
        let store_path = profile.join("keystore.opks");
        let mut session = KeyStoreSession::create(&store_path, fast_password()).unwrap();
        session.create_vault("Fuera", &outside).unwrap();
        session.save().unwrap();
        assert!(KeyStoreSession::open_scoped(&store_path, &profile, fast_password()).is_err());
        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn scoped_session_rejects_keystore_path_outside_active_profile() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let profile = root.join("profile");
        let outside_store = root.join("outside-keystore.opks");
        fs::create_dir_all(profile.join("vaults")).unwrap();
        assert!(matches!(
            KeyStoreSession::create_scoped(&outside_store, &profile, fast_password()),
            Err(SessionError::VaultOutsideProfile)
        ));
        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn scoped_profiles_reject_keystore_swap_even_with_same_password() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let password = fast_password();
        let profile_a = root.join(Uuid::new_v4().simple().to_string());
        let profile_b = root.join(Uuid::new_v4().simple().to_string());
        let store_a = profile_a.join("keystore.opks");
        let store_b = profile_b.join("keystore.opks");

        let mut a = KeyStoreSession::create_scoped(&store_a, &profile_a, password).unwrap();
        let mut b = KeyStoreSession::create_scoped(&store_b, &profile_b, password).unwrap();
        let id_a = a.create_vault("A", &profile_a.join("vault-a")).unwrap();
        let id_b = b.create_vault("B", &profile_b.join("vault-b")).unwrap();
        assert!(a.open_vault(id_a, None).is_ok());
        assert!(b.open_vault(id_b, None).is_ok());

        let swap = root.join("swap");
        fs::create_dir_all(&swap).unwrap();
        let swapped_store = swap.join("keystore.opks");
        fs::copy(&store_b, &swapped_store).unwrap();
        assert!(KeyStoreSession::open_scoped(&swapped_store, &profile_a, password).is_err());

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn independent_profile_keystores_do_not_unlock_each_other() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let a_path = root.join("profiles-a.keystore.opks");
        let b_path = root.join("profiles-b.keystore.opks");
        let a_password = fast_password();
        let b_password = b"perfil-b-password-larga";

        let mut a = KeyStoreSession::create(&a_path, a_password).unwrap();
        a.create_vault("A-Privada", &root.join("A-Vault")).unwrap();
        let b = KeyStoreSession::create(&b_path, b_password).unwrap();
        assert!(KeyStoreSession::open(&a_path, b_password).is_err());
        assert!(KeyStoreSession::open(&b_path, a_password).is_err());
        assert_eq!(a.list_vaults().len(), 1);
        assert!(b.list_vaults().is_empty());

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn add_pin_is_persisted_and_keeps_vault_key() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");
        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        let original = session.open_vault(id, None).unwrap();
        let original_key = *original.key_bytes();

        session.add_pin(id, b"Ab3dEf7g").unwrap();
        drop(session);
        let reopened = KeyStoreSession::open(&key_store_path, fast_password()).unwrap();
        assert!(matches!(
            reopened.open_vault(id, None),
            Err(SessionError::Vault(VaultError::PinRequired))
        ));
        let reopened_vault = reopened.open_vault(id, Some(b"Ab3dEf7g")).unwrap();
        assert_eq!(reopened_vault.key_bytes(), &original_key);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn access_mode_is_persisted_per_vault() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        assert_eq!(
            session.list_vaults()[0].access_mode,
            VaultAccessMode::OnDemand
        );
        session
            .set_vault_access_mode(id, VaultAccessMode::PreloadAll)
            .unwrap();
        drop(session);

        let reopened = KeyStoreSession::open(&key_store_path, fast_password()).unwrap();
        assert_eq!(
            reopened.list_vaults()[0].access_mode,
            VaultAccessMode::PreloadAll
        );

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn master_password_change_is_persisted_without_rotating_vault_key() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        let key_before = *session.open_vault(id, None).unwrap().key_bytes();

        session
            .change_master_password(b"nueva-password-larga")
            .unwrap();
        drop(session);
        assert!(KeyStoreSession::open(&key_store_path, fast_password()).is_err());
        let reopened = KeyStoreSession::open(&key_store_path, b"nueva-password-larga").unwrap();
        assert_eq!(
            reopened.open_vault(id, None).unwrap().key_bytes(),
            &key_before
        );

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn vault_session_with_pin_and_explicit_lock() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");
        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session
            .create_vault_with_pin("Personal", &vault_path, b"1234567890")
            .unwrap();
        assert!(session.open_vault(id, None).is_err());
        let vault = session.open_vault(id, Some(b"1234567890")).unwrap();
        let visible_key = vault.key_bytes();
        assert_eq!(visible_key.len(), 32);
        vault.lock();
        session.lock();
        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn delete_vault_requires_the_real_key_for_an_unprotected_vault() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_parent = root.join("vaults");
        fs::create_dir_all(&vault_parent).unwrap();
        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session
            .create_vault_in_parent("Personal", &vault_parent, None)
            .unwrap();
        let info = session
            .list_vaults()
            .into_iter()
            .find(|info| info.id == id)
            .unwrap();
        let vault_path = PathBuf::from(info.location);
        let wrong_key = [0xA5u8; 32];

        assert!(matches!(
            session.delete_vault(id, &wrong_key, true),
            Err(SessionError::InvalidVaultPath)
        ));
        assert!(vault_path.exists());
        assert!(session.list_vaults().iter().any(|info| info.id == id));

        let vault = session.open_vault(id, None).unwrap();
        let key = Zeroizing::new(*vault.key_bytes());
        session.delete_vault(id, &key, true).unwrap();
        assert!(!vault_path.exists());
        assert!(session.list_vaults().iter().all(|info| info.id != id));

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn delete_pin_vault_requires_pin_authenticated_session() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_parent = root.join("vaults");
        fs::create_dir_all(&vault_parent).unwrap();
        let source = root.join("secreto.txt");
        fs::write(&source, b"contenido que debe desaparecer con la caja").unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session
            .create_vault_in_parent("Personal", &vault_parent, None)
            .unwrap();
        session.add_pin(id, b"Abcd1234").unwrap();
        let vault_path = session
            .list_vaults()
            .into_iter()
            .find(|info| info.id == id)
            .map(|info| PathBuf::from(info.location))
            .unwrap();
        let vault = session.open_vault(id, Some(b"Abcd1234")).unwrap();
        let key = Zeroizing::new(*vault.key_bytes());
        vault.import_file(&source).unwrap();

        assert!(matches!(
            session.delete_vault(id, &key, false),
            Err(SessionError::Vault(VaultError::PinRequired))
        ));
        assert!(vault_path.exists());
        assert!(session.list_vaults().iter().any(|info| info.id == id));

        session.delete_vault(id, &key, true).unwrap();
        assert!(!vault_path.exists());
        assert!(session.list_vaults().iter().all(|info| info.id != id));

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn replacing_file_content_reencrypts_and_preserves_disk_path() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");
        let source = root.join("documento.txt");
        fs::write(&source, b"version inicial").unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        let vault = session.open_vault(id, None).unwrap();
        let opac = vault.import_file(&source).unwrap();

        let metadata = vault
            .replace_file_content(&opac, b"version editada")
            .unwrap();
        assert_eq!(metadata.original_name, "documento.txt");
        assert_eq!(metadata.original_size, b"version editada".len() as u64);

        let destination = root.join("recuperado.txt");
        vault.decrypt_file(&opac, &destination).unwrap();
        assert_eq!(fs::read(destination).unwrap(), b"version editada");
        assert_eq!(vault.list_files().unwrap(), vec![opac.clone()]);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn failed_replacement_keeps_original_file() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");
        let source = root.join("documento.txt");
        fs::write(&source, b"contenido original").unwrap();

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        let vault = session.open_vault(id, None).unwrap();
        let opac = vault.import_file(&source).unwrap();
        let before = fs::read(&opac).unwrap();

        // Una ruta exterior nunca puede utilizarse como destino de edición.
        assert!(
            vault
                .replace_file_content(&source, b"no debe cambiar")
                .is_err()
        );
        assert_eq!(fs::read(&opac).unwrap(), before);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn deleting_a_vault_file_is_scoped_to_the_vault_folder() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");
        let source = root.join("documento.txt");
        fs::write(&source, b"contenido").unwrap();
        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        let vault = session.open_vault(id, None).unwrap();
        let opac = vault.import_file(&source).unwrap();
        vault.delete_file(&opac).unwrap();
        assert!(!opac.exists());
        assert!(vault.delete_file(&source).is_err());
        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn migrate_legacy_files_from_session() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let key_store_path = root.join("keystore.opks");
        let vault_path = root.join("Personal");

        let mut session = KeyStoreSession::create(&key_store_path, fast_password()).unwrap();
        let id = session.create_vault("Personal", &vault_path).unwrap();
        fs::create_dir_all(&vault_path).unwrap();
        let legacy_path = vault_path.join("legacy.opac");

        let key = *session.open_vault(id, None).unwrap().key_bytes();
        let content = b"legacy";
        let metadata = OpacMetadata {
            original_name: "legacy.txt".into(),
            original_size: content.len() as u64,
            created_unix: None,
            modified_unix: None,
        };
        let mut metadata_bytes = Vec::new();
        metadata_bytes.extend_from_slice(&(metadata.original_name.len() as u64).to_le_bytes());
        metadata_bytes.extend_from_slice(metadata.original_name.as_bytes());
        metadata_bytes.extend_from_slice(&metadata.original_size.to_le_bytes());
        metadata_bytes.push(0);
        metadata_bytes.push(0);
        let file_id = crate::modules::crypto::random_file_id();
        let nonce = crate::modules::crypto::random_nonce();
        let mut header = opac_format::OPAC_MAGIC.to_vec();
        header.extend_from_slice(&opac_format::OPAC_VERSION_LEGACY_V1.to_le_bytes());
        header.extend_from_slice(&0u16.to_le_bytes());
        header.extend_from_slice(&file_id);
        header.extend_from_slice(&nonce);
        let mut inner = Vec::new();
        inner.extend_from_slice(&(metadata_bytes.len() as u32).to_le_bytes());
        inner.extend_from_slice(&metadata_bytes);
        inner.extend_from_slice(content);
        let sealed = crate::modules::crypto::seal(&key, &nonce, &header, &inner).unwrap();
        let mut blob = header;
        blob.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        blob.extend_from_slice(&sealed);
        fs::write(&legacy_path, blob).unwrap();
        drop(session);

        let reopened = KeyStoreSession::open(&key_store_path, fast_password()).unwrap();
        let vault = reopened.open_vault(id, None).unwrap();
        let migrated = vault.migrate_legacy_files().unwrap();
        assert_eq!(migrated.len(), 1);
        assert!(!legacy_path.exists());
        assert_eq!(vault.read_file_metadata(&migrated[0]).unwrap(), metadata);

        fs::remove_dir_all(root).ok();
    }
    #[test]
    fn prepared_scoped_open_keeps_lock_on_caller_and_returns_send_safe_parts() {
        let root = std::env::temp_dir().join(format!("opac-prepared-open-{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let profile_root = root.join("profile-00000000-0000-0000-0000-000000000000");
        fs::create_dir_all(&profile_root).unwrap();
        let key_store_path = profile_root.join("keystore.opks");
        let password = fast_password();

        let session =
            KeyStoreSession::create_scoped(&key_store_path, &profile_root, password).unwrap();
        drop(session);

        let prepared =
            KeyStoreSession::prepare_scoped_open(&key_store_path, &profile_root).unwrap();
        let password_for_thread = password.to_vec();
        let path_for_thread = key_store_path.clone();
        let root_for_thread = profile_root.clone();
        let handle = std::thread::spawn(move || {
            KeyStoreSession::open_scoped_unlocked_parts(
                path_for_thread,
                root_for_thread,
                &password_for_thread,
            )
            .unwrap()
        });
        let (store, master_key) = handle.join().unwrap();
        let session = prepared.finish(store, master_key).unwrap();
        assert_eq!(session.profile_root(), Some(profile_root.as_path()));
        drop(session);
        fs::remove_dir_all(root).unwrap();
    }
}
