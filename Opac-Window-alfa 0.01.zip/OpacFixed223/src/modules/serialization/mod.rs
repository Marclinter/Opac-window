//! Serializacion de estructuras persistentes.
//!
//! Las escrituras actuales usan Postcard. Los decodificadores legacy estan
//! implementados a mano para poder eliminar la dependencia `bincode` del
//! binario actual sin perder compatibilidad con datos que Opac Window ya
//! genero con bincode 1.x.

use serde::Serialize;

pub(crate) mod legacy_bincode;

pub(crate) fn encode<T: Serialize + ?Sized>(value: &T) -> Result<Vec<u8>, postcard::Error> {
    postcard::to_allocvec(value)
}
