//! Lector minimo y acotado de la codificacion producida por
//! `bincode::serialize` de bincode 1.3.x con las opciones por defecto.
//!
//! No se expone un serializador legacy. Este modulo existe solo para abrir
//! datos historicos de Opac Window. Todos los tamaños estan limitados por el
//! llamador antes de reservar memoria.

use uuid::Uuid;

#[derive(Debug)]
pub(crate) enum LegacyError {
    Truncated,
    InvalidLength,
    InvalidUtf8,
    InvalidUuid,
    InvalidDiscriminant,
    TrailingBytes,
}

pub(crate) struct Reader<'a> {
    data: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    pub(crate) fn new(data: &'a [u8]) -> Self {
        Self { data, pos: 0 }
    }

    fn take(&mut self, len: usize) -> Result<&'a [u8], LegacyError> {
        let end = self
            .pos
            .checked_add(len)
            .ok_or(LegacyError::InvalidLength)?;
        if end > self.data.len() {
            return Err(LegacyError::Truncated);
        }
        let out = &self.data[self.pos..end];
        self.pos = end;
        Ok(out)
    }

    pub(crate) fn u8(&mut self) -> Result<u8, LegacyError> {
        Ok(self.take(1)?[0])
    }

    pub(crate) fn u32(&mut self) -> Result<u32, LegacyError> {
        let bytes = self.take(4)?;
        Ok(u32::from_le_bytes(
            bytes.try_into().map_err(|_| LegacyError::Truncated)?,
        ))
    }

    pub(crate) fn u64(&mut self) -> Result<u64, LegacyError> {
        let bytes = self.take(8)?;
        Ok(u64::from_le_bytes(
            bytes.try_into().map_err(|_| LegacyError::Truncated)?,
        ))
    }

    pub(crate) fn fixed<const N: usize>(&mut self) -> Result<[u8; N], LegacyError> {
        let bytes = self.take(N)?;
        bytes.try_into().map_err(|_| LegacyError::Truncated)
    }

    pub(crate) fn bytes(&mut self, max_len: usize) -> Result<Vec<u8>, LegacyError> {
        let len = usize::try_from(self.u64()?).map_err(|_| LegacyError::InvalidLength)?;
        if len > max_len {
            return Err(LegacyError::InvalidLength);
        }
        Ok(self.take(len)?.to_vec())
    }

    pub(crate) fn string(&mut self, max_len: usize) -> Result<String, LegacyError> {
        let bytes = self.bytes(max_len)?;
        String::from_utf8(bytes).map_err(|_| LegacyError::InvalidUtf8)
    }

    pub(crate) fn uuid(&mut self) -> Result<Uuid, LegacyError> {
        let bytes = self.bytes(16)?;
        if bytes.len() != 16 {
            return Err(LegacyError::InvalidUuid);
        }
        let array: [u8; 16] = bytes.try_into().map_err(|_| LegacyError::InvalidUuid)?;
        Ok(Uuid::from_bytes(array))
    }

    pub(crate) fn option_u64(&mut self) -> Result<Option<u64>, LegacyError> {
        match self.u8()? {
            0 => Ok(None),
            1 => Ok(Some(self.u64()?)),
            _ => Err(LegacyError::InvalidDiscriminant),
        }
    }

    pub(crate) fn sequence_len(&mut self, max_len: usize) -> Result<usize, LegacyError> {
        let len = usize::try_from(self.u64()?).map_err(|_| LegacyError::InvalidLength)?;
        if len > max_len {
            return Err(LegacyError::InvalidLength);
        }
        Ok(len)
    }

    pub(crate) fn finish(self) -> Result<(), LegacyError> {
        if self.pos == self.data.len() {
            Ok(())
        } else {
            Err(LegacyError::TrailingBytes)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_bincode_1_fixed_integer_layout() {
        let mut data = Vec::new();
        data.extend_from_slice(&6u64.to_le_bytes());
        data.extend_from_slice(b"legacy");
        let mut reader = Reader::new(&data);
        assert_eq!(reader.bytes(32).unwrap(), b"legacy");
        reader.finish().unwrap();
    }

    #[test]
    fn rejects_trailing_bytes() {
        let data = [1u8, 2u8];
        let mut reader = Reader::new(&data);
        assert_eq!(reader.u8().unwrap(), 1);
        assert!(matches!(reader.finish(), Err(LegacyError::TrailingBytes)));
    }
}
