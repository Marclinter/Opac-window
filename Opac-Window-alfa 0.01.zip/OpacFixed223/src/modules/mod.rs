//! Módulos del núcleo criptográfico y de almacenamiento de Opac Window.
//!
//! V2 del formato `.opac` es el único formato de escritura. V1 queda como
//! lector legacy para compatibilidad y puede migrarse a V2 desde `vault_fs`.
//! La futura GUI debe consumir únicamente las APIs del crate y no duplicar
//! lógica criptográfica.

pub mod crypto;
pub mod export;
pub mod files;
pub mod import;
pub mod keys;
pub mod master_key;
pub mod opac_format;
pub mod persistence;
pub mod pin;
pub mod profiles;
pub mod session;
pub mod temporary;
pub mod vault;
pub mod vault_fs;

pub(crate) mod serialization;
