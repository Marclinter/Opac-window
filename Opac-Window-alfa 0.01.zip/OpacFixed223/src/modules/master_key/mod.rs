//! Derivación de la Master Key mediante Argon2id.
//!
//! El salt y los parámetros se almacenan junto al Key Store; la contraseña
//! nunca se persiste. Los parámetros se validan antes de ejecutar Argon2id
//! incluso cuando proceden de un archivo no confiable, para evitar abusos de
//! memoria/CPU mediante parámetros extremos.

use argon2::{Algorithm, Argon2, Params, Version};
use rand::{TryRng, rngs::SysRng};
use thiserror::Error;
use zeroize::Zeroizing;

use crate::modules::crypto::KEY_LEN;

pub const MASTER_KEY_LEN: usize = KEY_LEN;
pub const SALT_LEN: usize = 16;
pub const MIN_MASTER_PASSWORD_LEN: usize = 12;
pub const MAX_MASTER_PASSWORD_LEN: usize = 512;

/// Parámetros por defecto pensados para una aplicación local-first de escritorio.
/// RFC 9106 identifica 64 MiB / 3 pasadas / 4 lanes como una opción recomendada
/// cuando no se puede dedicar gigabytes de RAM a cada derivación.
pub const DEFAULT_MEMORY_KIB: u32 = 64 * 1024;
pub const DEFAULT_ITERATIONS: u32 = 3;
pub const DEFAULT_PARALLELISM: u32 = 4;

/// Límites de protocolo. Evitan que un archivo modificado fuerce una reserva
/// arbitrariamente grande antes de que la autenticación AEAD pueda comprobarse.
/// El límite superior es deliberadamente finito por tratarse de una aplicación
/// local-first: un archivo no confiable nunca puede pedir gigabytes de RAM.
pub const MIN_MEMORY_KIB: u32 = 8 * 1024;
pub const MAX_MEMORY_KIB: u32 = 128 * 1024;
pub const MIN_ITERATIONS: u32 = 1;
pub const MAX_ITERATIONS: u32 = 10;
pub const MIN_PARALLELISM: u32 = 1;
pub const MAX_PARALLELISM: u32 = 4;

#[derive(Debug, Error, PartialEq, Eq)]
pub enum MasterKeyError {
    #[error("los parametros de Argon2id no son validos o exceden los limites admitidos")]
    InvalidParams,
    #[error("fallo al derivar la clave (Argon2id)")]
    DerivationFailed,
    #[error("la contraseña maestra debe tener entre 12 y 512 caracteres")]
    WeakPassword,
}

pub struct MasterKey(pub(crate) Zeroizing<[u8; MASTER_KEY_LEN]>);

impl MasterKey {
    pub fn as_bytes(&self) -> &[u8; MASTER_KEY_LEN] {
        &self.0
    }

    pub(crate) fn from_bytes(bytes: [u8; MASTER_KEY_LEN]) -> Self {
        MasterKey(Zeroizing::new(bytes))
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Argon2Params {
    pub memory_kib: u32,
    pub iterations: u32,
    pub parallelism: u32,
}

impl Default for Argon2Params {
    fn default() -> Self {
        Self {
            memory_kib: DEFAULT_MEMORY_KIB,
            iterations: DEFAULT_ITERATIONS,
            parallelism: DEFAULT_PARALLELISM,
        }
    }
}

impl Argon2Params {
    pub fn validate(&self) -> Result<(), MasterKeyError> {
        if !(MIN_MEMORY_KIB..=MAX_MEMORY_KIB).contains(&self.memory_kib)
            || !(MIN_ITERATIONS..=MAX_ITERATIONS).contains(&self.iterations)
            || !(MIN_PARALLELISM..=MAX_PARALLELISM).contains(&self.parallelism)
        {
            return Err(MasterKeyError::InvalidParams);
        }

        // Argon2 requiere al menos 8 * p KiB.
        if self.memory_kib < 8 * self.parallelism {
            return Err(MasterKeyError::InvalidParams);
        }

        Ok(())
    }
}

pub fn random_salt() -> [u8; SALT_LEN] {
    let mut salt = [0u8; SALT_LEN];
    let mut rng = SysRng;
    rng.try_fill_bytes(&mut salt)
        .expect("system secure random source unavailable");
    salt
}

pub fn validate_master_password(password: &[u8]) -> Result<(), MasterKeyError> {
    let length = std::str::from_utf8(password)
        .map(|text| text.chars().count())
        .unwrap_or(password.len());
    if !(MIN_MASTER_PASSWORD_LEN..=MAX_MASTER_PASSWORD_LEN).contains(&length) {
        return Err(MasterKeyError::WeakPassword);
    }
    Ok(())
}

pub fn derive_master_key(
    password: &[u8],
    salt: &[u8; SALT_LEN],
    params: &Argon2Params,
) -> Result<MasterKey, MasterKeyError> {
    params.validate()?;

    let argon_params = Params::new(
        params.memory_kib,
        params.iterations,
        params.parallelism,
        Some(MASTER_KEY_LEN),
    )
    .map_err(|_| MasterKeyError::InvalidParams)?;

    let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, argon_params);
    let mut out = Zeroizing::new([0u8; MASTER_KEY_LEN]);
    argon2
        .hash_password_into(password, salt, &mut out[..])
        .map_err(|_| MasterKeyError::DerivationFailed)?;

    Ok(MasterKey(out))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fast_params_for_tests() -> Argon2Params {
        Argon2Params {
            memory_kib: 8 * 1024,
            iterations: 1,
            parallelism: 1,
        }
    }

    #[test]
    fn same_password_and_salt_give_same_key() {
        let salt = random_salt();
        let params = fast_params_for_tests();
        let k1 = derive_master_key(b"contrasena-correcta", &salt, &params).unwrap();
        let k2 = derive_master_key(b"contrasena-correcta", &salt, &params).unwrap();
        assert_eq!(k1.as_bytes(), k2.as_bytes());
    }

    #[test]
    fn different_password_gives_different_key() {
        let salt = random_salt();
        let params = fast_params_for_tests();
        let k1 = derive_master_key(b"contrasena-correcta", &salt, &params).unwrap();
        let k2 = derive_master_key(b"otra-contrasena", &salt, &params).unwrap();
        assert_ne!(k1.as_bytes(), k2.as_bytes());
    }

    #[test]
    fn different_salt_gives_different_key() {
        let salt1 = random_salt();
        let salt2 = random_salt();
        let params = fast_params_for_tests();
        let k1 = derive_master_key(b"misma-contrasena", &salt1, &params).unwrap();
        let k2 = derive_master_key(b"misma-contrasena", &salt2, &params).unwrap();
        assert_ne!(k1.as_bytes(), k2.as_bytes());
    }

    #[test]
    fn weak_master_password_is_rejected_by_policy() {
        assert_eq!(
            validate_master_password(b"corta"),
            Err(MasterKeyError::WeakPassword)
        );
        assert!(validate_master_password(b"esta-es-una-clave-segura").is_ok());
    }

    #[test]
    fn unicode_master_password_uses_character_count_for_policy() {
        let password = "🙂".repeat(MAX_MASTER_PASSWORD_LEN);
        assert!(validate_master_password(password.as_bytes()).is_ok());

        let too_long = "🙂".repeat(MAX_MASTER_PASSWORD_LEN + 1);
        assert_eq!(
            validate_master_password(too_long.as_bytes()),
            Err(MasterKeyError::WeakPassword)
        );
    }

    #[test]
    fn extreme_parameters_are_rejected_before_derivation() {
        let params = Argon2Params {
            memory_kib: u32::MAX,
            iterations: u32::MAX,
            parallelism: u32::MAX,
        };
        assert_eq!(params.validate(), Err(MasterKeyError::InvalidParams));
    }
}
