//! Formato binario versionado `.opac`.
//!
//! V2 es el formato canónico y único formato que se escribe para archivos
//! nuevos. V1 se conserva únicamente como compatibilidad de lectura para
//! archivos creados por versiones anteriores del núcleo. Esto evita romper
//! una instalación local existente sin mantener dos formatos activos.
//!
//! V2 usa streaming por chunks, nonces derivados de una base aleatoria de 96 bits
//! para archivos nuevos (con compatibilidad para el esquema V2 historico),
//! metadatos sellados aparte y campos de framing autenticados por AAD.

use std::io::{self, Cursor, Read, Write};
use std::sync::mpsc;
use std::thread;

use serde::{Deserialize, Serialize};
use thiserror::Error;
use zeroize::Zeroizing;

use crate::modules::crypto::{self, CryptoError, FILE_ID_LEN, KEY_LEN, NONCE_LEN};
use crate::modules::serialization::{self, legacy_bincode::Reader as LegacyReader};

pub const OPAC_MAGIC: &[u8; 4] = b"OPAC";
pub const OPAC_VERSION: u16 = 2;
pub const OPAC_VERSION_LEGACY_V1: u16 = 1;
/// V2 metadata encoding: historical V2 files used 0 (bincode 1.x); new files use 1 (Postcard).
pub const OPAC_FLAG_POSTCARD_METADATA: u16 = 1;
/// V2 nonce hardening: new files use a 96-bit per-file nonce base derived
/// from 8 random bytes plus 4 random bytes from `file_id`, then XOR the
/// chunk index into the last 32 bits. This keeps nonce uniqueness across
/// chunks deterministic within a file and raises the cross-file collision
/// space from 64 to 96 random bits, while preserving the existing V2 header.
pub const OPAC_FLAG_NONCE_96BIT: u16 = 2;
pub const OPAC_FLAG_CURRENT: u16 = OPAC_FLAG_POSTCARD_METADATA | OPAC_FLAG_NONCE_96BIT;
#[deprecated(note = "V2 is the canonical format; kept only for source compatibility")]
pub const OPAC_VERSION_CHUNKED: u16 = OPAC_VERSION;

const HEADER_LEN_V1: usize = 4 + 2 + 2 + FILE_ID_LEN + NONCE_LEN;
const HEADER_LEN_V2: usize = 4 + 2 + 2 + FILE_ID_LEN + NONCE_PREFIX_LEN + 4;
const LEN_FIELD: usize = 4;
const AEAD_TAG_LEN: usize = 16;
const MAX_METADATA_LEN: usize = 64 * 1024;
pub const DEFAULT_CHUNK_SIZE: usize = 4 * 1024 * 1024;
/// Por debajo o igual a este tamaño V2 utiliza un único chunk de datos.
/// Por encima, V2 usa streaming con `DEFAULT_CHUNK_SIZE` por chunk.
pub const DEFAULT_CHUNKING_THRESHOLD: u64 = 8 * 1024 * 1024;
pub const MAX_CHUNK_SIZE: usize = 64 * 1024 * 1024;
pub const MAX_PARALLEL_CHUNK_WORKERS: usize = 8;
const NONCE_PREFIX_LEN: usize = 8;
const META_CHUNK_INDEX: u32 = u32::MAX;
const MAX_V1_SEALED_LEN: usize = 16 * 1024 * 1024;
pub const MAX_LEGACY_V1_FILE_SIZE: u64 =
    (HEADER_LEN_V1 + LEN_FIELD) as u64 + MAX_V1_SEALED_LEN as u64;

#[derive(Debug, Error)]
pub enum OpacError {
    #[error(transparent)]
    Crypto(#[from] CryptoError),
    #[error(transparent)]
    Io(#[from] io::Error),
    #[error("no es un archivo .opac valido (magic incorrecto)")]
    BadMagic,
    #[error("version de formato .opac no soportada: {0}")]
    UnsupportedVersion(u16),
    #[error("el archivo .opac esta truncado o es demasiado corto")]
    Truncated,
    #[error("los metadatos internos o el framing del archivo no son validos")]
    Metadata,
    #[error("el archivo .opac esta corrupto o supera el limite permitido")]
    Corrupt,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct OpacMetadata {
    pub original_name: String,
    pub original_size: u64,
    pub created_unix: Option<u64>,
    pub modified_unix: Option<u64>,
}

pub struct DecryptedOpacFile {
    pub metadata: OpacMetadata,
    /// Plaintext is zeroized when the decrypted file leaves scope.
    pub content: Zeroizing<Vec<u8>>,
}

fn build_header_v1(
    version: u16,
    flags: u16,
    file_id: &[u8; FILE_ID_LEN],
    nonce: &[u8; NONCE_LEN],
) -> Vec<u8> {
    let mut header = Vec::with_capacity(HEADER_LEN_V1);
    header.extend_from_slice(OPAC_MAGIC);
    header.extend_from_slice(&version.to_le_bytes());
    header.extend_from_slice(&flags.to_le_bytes());
    header.extend_from_slice(file_id);
    header.extend_from_slice(nonce);
    header
}

fn build_header_v2(
    flags: u16,
    file_id: &[u8; FILE_ID_LEN],
    nonce_prefix: &[u8; NONCE_PREFIX_LEN],
    chunk_size: u32,
) -> Vec<u8> {
    let mut header = Vec::with_capacity(HEADER_LEN_V2);
    header.extend_from_slice(OPAC_MAGIC);
    header.extend_from_slice(&OPAC_VERSION.to_le_bytes());
    header.extend_from_slice(&flags.to_le_bytes());
    header.extend_from_slice(file_id);
    header.extend_from_slice(nonce_prefix);
    header.extend_from_slice(&chunk_size.to_le_bytes());
    header
}

fn chunk_nonce_legacy(nonce_prefix: &[u8; NONCE_PREFIX_LEN], index: u32) -> [u8; NONCE_LEN] {
    let mut nonce = [0u8; NONCE_LEN];
    nonce[..NONCE_PREFIX_LEN].copy_from_slice(nonce_prefix);
    nonce[NONCE_PREFIX_LEN..].copy_from_slice(&index.to_be_bytes());
    nonce
}

fn chunk_nonce_hardened(
    nonce_prefix: &[u8; NONCE_PREFIX_LEN],
    file_id: &[u8; FILE_ID_LEN],
    index: u32,
) -> [u8; NONCE_LEN] {
    let mut nonce = [0u8; NONCE_LEN];
    nonce[..NONCE_PREFIX_LEN].copy_from_slice(nonce_prefix);
    nonce[NONCE_PREFIX_LEN..].copy_from_slice(&file_id[..NONCE_LEN - NONCE_PREFIX_LEN]);
    let index_bytes = index.to_be_bytes();
    for offset in NONCE_PREFIX_LEN..NONCE_LEN {
        nonce[offset] ^= index_bytes[offset - NONCE_PREFIX_LEN];
    }
    nonce
}

fn chunk_nonce_for_flags(
    flags: u16,
    nonce_prefix: &[u8; NONCE_PREFIX_LEN],
    file_id: &[u8; FILE_ID_LEN],
    index: u32,
) -> Result<[u8; NONCE_LEN], OpacError> {
    match flags {
        0 | OPAC_FLAG_POSTCARD_METADATA => Ok(chunk_nonce_legacy(nonce_prefix, index)),
        OPAC_FLAG_CURRENT => Ok(chunk_nonce_hardened(nonce_prefix, file_id, index)),
        _ => Err(OpacError::Metadata),
    }
}

fn chunk_aad(header: &[u8], is_last: bool, index: u32) -> Vec<u8> {
    let mut aad = Vec::with_capacity(header.len() + 9);
    aad.extend_from_slice(header);
    aad.extend_from_slice(b"DATA");
    aad.push(if is_last { 1 } else { 0 });
    aad.extend_from_slice(&index.to_be_bytes());
    aad
}

fn metadata_aad(header: &[u8]) -> Vec<u8> {
    let mut aad = Vec::with_capacity(header.len() + 4);
    aad.extend_from_slice(header);
    aad.extend_from_slice(b"META");
    aad
}

fn validate_metadata(metadata: &OpacMetadata) -> Result<(), OpacError> {
    let name = metadata.original_name.as_str();
    if name.is_empty()
        || name == "."
        || name == ".."
        || name.contains('/')
        || name.contains('\\')
        || name.contains('\0')
        || name.chars().any(|ch| ch.is_control())
        || metadata.original_name.len() > MAX_METADATA_LEN
    {
        return Err(OpacError::Metadata);
    }
    Ok(())
}

/// Cifra datos nuevos en V2. El nombre `encrypt` se conserva como API simple
/// para clientes del núcleo, pero ya no genera V1.
///
/// La política de V2 es automática: hasta `DEFAULT_CHUNKING_THRESHOLD` se usa
/// un único chunk de tamaño ajustado al archivo; por encima se usa streaming
/// con `DEFAULT_CHUNK_SIZE`. El formato y la clave siguen siendo V2 en ambos
/// casos.
pub fn encrypt(
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    content: &[u8],
) -> Result<Vec<u8>, OpacError> {
    let mut out = Vec::with_capacity(content.len().saturating_add(1024));
    encrypt_v2_auto(vault_key, metadata, &mut Cursor::new(content), &mut out)?;
    Ok(out)
}

/// Elige automáticamente la estrategia de V2 según el tamaño declarado en
/// `metadata.original_size`. Para uso de archivos, el llamador debe obtener ese
/// tamaño del descriptor/metadata del mismo archivo que va a leer.
pub fn chunk_count_for_size(original_size: u64) -> u64 {
    if original_size <= DEFAULT_CHUNKING_THRESHOLD {
        1
    } else {
        ((original_size - 1) / DEFAULT_CHUNK_SIZE as u64) + 1
    }
}

/// Cuenta los chunks de un archivo usando el tamaño de chunk realmente
/// almacenado en el header V2. Los verificadores no deben asumir
/// `DEFAULT_CHUNK_SIZE`, porque `encrypt_chunked` permite tamaños explícitos.
fn chunk_count_for_size_with_chunk_size(original_size: u64, chunk_size: usize) -> u64 {
    if original_size == 0 {
        return 1;
    }
    ((original_size - 1) / chunk_size as u64) + 1
}

pub fn encrypt_v2_auto<R: Read, W: Write>(
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    reader: &mut R,
    writer: &mut W,
) -> Result<(), OpacError> {
    encrypt_v2_auto_with_progress(vault_key, metadata, reader, writer, |_completed, _total| {})
}

/// Variante de `encrypt_v2_auto_with_progress` que permite repartir la
/// criptografia de un archivo grande entre varios workers. La escritura del
/// formato sigue siendo estrictamente ordenada: los chunks pueden cifrarse en
/// paralelo, pero se serializan por indice antes de tocar el `.opac`.
///
/// Solo usa paralelismo cuando el archivo supera el umbral de chunking y el
/// llamador solicita mas de un worker. La memoria maxima adicional queda
/// acotada aproximadamente a `parallel_workers * DEFAULT_CHUNK_SIZE`.
pub fn encrypt_v2_auto_with_parallel_progress<R: Read, W: Write, F: FnMut(u64, u64)>(
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    reader: &mut R,
    writer: &mut W,
    parallel_workers: usize,
    mut on_chunk_progress: F,
) -> Result<(), OpacError> {
    let chunk_size = if metadata.original_size <= DEFAULT_CHUNKING_THRESHOLD {
        usize::try_from(metadata.original_size.max(1)).map_err(|_| OpacError::Metadata)?
    } else {
        DEFAULT_CHUNK_SIZE
    };

    let workers = parallel_workers.clamp(1, MAX_PARALLEL_CHUNK_WORKERS);
    if workers <= 1 || metadata.original_size <= DEFAULT_CHUNKING_THRESHOLD {
        return encrypt_chunked_with_progress(
            vault_key,
            metadata,
            chunk_size,
            reader,
            writer,
            &mut on_chunk_progress,
        );
    }

    encrypt_chunked_parallel_with_progress(
        vault_key,
        metadata,
        chunk_size,
        workers,
        reader,
        writer,
        &mut on_chunk_progress,
    )
}

/// Variante de `encrypt_v2_auto` que informa el progreso una vez que cada
/// chunk de contenido ha quedado autenticado y escrito. El callback nunca
/// recibe plaintext, solo contadores `(chunks_completados, chunks_totales)`.
pub fn encrypt_v2_auto_with_progress<R: Read, W: Write, F: FnMut(u64, u64)>(
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    reader: &mut R,
    writer: &mut W,
    mut on_chunk_progress: F,
) -> Result<(), OpacError> {
    let chunk_size = if metadata.original_size <= DEFAULT_CHUNKING_THRESHOLD {
        usize::try_from(metadata.original_size.max(1)).map_err(|_| OpacError::Metadata)?
    } else {
        DEFAULT_CHUNK_SIZE
    };

    encrypt_chunked_with_progress(
        vault_key,
        metadata,
        chunk_size,
        reader,
        writer,
        &mut on_chunk_progress,
    )
}

/// Descifra tanto V2 (canónico) como V1 (legacy, solo lectura).
/// Para V2 este helper materializa el contenido en memoria; para archivos
/// grandes se recomienda `decrypt_chunked` o `vault_fs::decrypt_file_from_vault`.
pub fn decrypt(vault_key: &[u8; KEY_LEN], data: &[u8]) -> Result<DecryptedOpacFile, OpacError> {
    if data.len() < 6 {
        return Err(OpacError::Truncated);
    }
    if &data[..4] != OPAC_MAGIC {
        return Err(OpacError::BadMagic);
    }
    let version = u16::from_le_bytes([data[4], data[5]]);

    match version {
        OPAC_VERSION => {
            let mut content = Vec::new();
            let metadata = decrypt_chunked(vault_key, &mut Cursor::new(data), &mut content)?;
            Ok(DecryptedOpacFile {
                metadata,
                content: Zeroizing::new(content),
            })
        }
        OPAC_VERSION_LEGACY_V1 => decrypt_v1_legacy(vault_key, data),
        other => Err(OpacError::UnsupportedVersion(other)),
    }
}

fn decode_legacy_metadata(data: &[u8]) -> Result<OpacMetadata, OpacError> {
    let mut reader = LegacyReader::new(data);
    let metadata = OpacMetadata {
        original_name: reader
            .string(MAX_METADATA_LEN)
            .map_err(|_| OpacError::Metadata)?,
        original_size: reader.u64().map_err(|_| OpacError::Metadata)?,
        created_unix: reader.option_u64().map_err(|_| OpacError::Metadata)?,
        modified_unix: reader.option_u64().map_err(|_| OpacError::Metadata)?,
    };
    reader.finish().map_err(|_| OpacError::Metadata)?;
    validate_metadata(&metadata)?;
    Ok(metadata)
}

/// Decodificador V1 privado. No se usa para crear archivos nuevos.
fn decrypt_v1_legacy(
    vault_key: &[u8; KEY_LEN],
    data: &[u8],
) -> Result<DecryptedOpacFile, OpacError> {
    if data.len() < HEADER_LEN_V1 + LEN_FIELD {
        return Err(OpacError::Truncated);
    }

    let version = u16::from_le_bytes([data[4], data[5]]);
    if version != OPAC_VERSION_LEGACY_V1 {
        return Err(OpacError::UnsupportedVersion(version));
    }

    let flags = u16::from_le_bytes([data[6], data[7]]);
    let mut file_id = [0u8; FILE_ID_LEN];
    file_id.copy_from_slice(&data[8..8 + FILE_ID_LEN]);

    let nonce_start = 8 + FILE_ID_LEN;
    let mut nonce = [0u8; NONCE_LEN];
    nonce.copy_from_slice(&data[nonce_start..nonce_start + NONCE_LEN]);

    let len_pos = HEADER_LEN_V1;
    let sealed_len = u32::from_le_bytes(
        data[len_pos..len_pos + LEN_FIELD]
            .try_into()
            .map_err(|_| OpacError::Truncated)?,
    ) as usize;
    let body_pos = len_pos + LEN_FIELD;
    if !(AEAD_TAG_LEN..=MAX_V1_SEALED_LEN).contains(&sealed_len) {
        return Err(OpacError::Metadata);
    }
    if sealed_len > data.len().saturating_sub(body_pos) || body_pos + sealed_len != data.len() {
        return Err(OpacError::Truncated);
    }

    let header = build_header_v1(OPAC_VERSION_LEGACY_V1, flags, &file_id, &nonce);
    let inner = Zeroizing::new(crypto::open(vault_key, &nonce, &header, &data[body_pos..])?);

    if inner.len() < LEN_FIELD {
        return Err(OpacError::Truncated);
    }
    let meta_len = u32::from_le_bytes(
        inner[..LEN_FIELD]
            .try_into()
            .map_err(|_| OpacError::Truncated)?,
    ) as usize;
    if meta_len == 0 || meta_len > MAX_METADATA_LEN || inner.len() < LEN_FIELD + meta_len {
        return Err(OpacError::Metadata);
    }

    let metadata: OpacMetadata = decode_legacy_metadata(&inner[LEN_FIELD..LEN_FIELD + meta_len])?;
    validate_metadata(&metadata)?;
    let content = Zeroizing::new(inner[LEN_FIELD + meta_len..].to_vec());
    if metadata.original_size != content.len() as u64 {
        return Err(OpacError::Metadata);
    }

    Ok(DecryptedOpacFile { metadata, content })
}

fn read_chunk<R: Read>(reader: &mut R, buf: &mut [u8]) -> Result<Zeroizing<Vec<u8>>, OpacError> {
    let mut total = 0usize;
    while total < buf.len() {
        let n = reader.read(&mut buf[total..])?;
        if n == 0 {
            break;
        }
        total += n;
    }
    Ok(Zeroizing::new(buf[..total].to_vec()))
}

fn read_exact_or_truncated<R: Read>(reader: &mut R, buf: &mut [u8]) -> Result<(), OpacError> {
    reader.read_exact(buf).map_err(|e| {
        if e.kind() == io::ErrorKind::UnexpectedEof {
            OpacError::Truncated
        } else {
            OpacError::Io(e)
        }
    })
}

/// Escribe siempre V2 y mantiene memoria acotada al tamaño de chunk.
pub fn encrypt_chunked<R: Read, W: Write>(
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    chunk_size: usize,
    reader: &mut R,
    writer: &mut W,
) -> Result<(), OpacError> {
    encrypt_chunked_with_progress(
        vault_key,
        metadata,
        chunk_size,
        reader,
        writer,
        &mut |_completed, _total| {},
    )
}

fn encrypt_chunked_with_progress<R: Read, W: Write, F: FnMut(u64, u64)>(
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    chunk_size: usize,
    reader: &mut R,
    writer: &mut W,
    on_chunk_progress: &mut F,
) -> Result<(), OpacError> {
    validate_metadata(&metadata)?;
    if chunk_size == 0 || chunk_size > MAX_CHUNK_SIZE || chunk_size > u32::MAX as usize {
        return Err(OpacError::Metadata);
    }

    let file_id = crypto::random_file_id();
    let random_nonce = crypto::random_nonce();
    let mut nonce_prefix = [0u8; NONCE_PREFIX_LEN];
    nonce_prefix.copy_from_slice(&random_nonce[..NONCE_PREFIX_LEN]);
    let flags = OPAC_FLAG_CURRENT;
    let header = build_header_v2(flags, &file_id, &nonce_prefix, chunk_size as u32);
    writer.write_all(&header)?;

    let metadata_bytes =
        Zeroizing::new(serialization::encode(&metadata).map_err(|_| OpacError::Metadata)?);
    if metadata_bytes.len() > MAX_METADATA_LEN {
        return Err(OpacError::Metadata);
    }
    let meta_nonce = chunk_nonce_for_flags(flags, &nonce_prefix, &file_id, META_CHUNK_INDEX)?;
    let meta_aad = metadata_aad(&header);
    let meta_sealed = crypto::seal(vault_key, &meta_nonce, &meta_aad, &metadata_bytes)?;
    writer.write_all(&(meta_sealed.len() as u32).to_le_bytes())?;
    writer.write_all(&meta_sealed)?;

    let mut buffer = Zeroizing::new(vec![0u8; chunk_size]);
    let mut current = read_chunk(reader, &mut buffer[..])?;
    let mut index: u32 = 0;
    let mut total_read: u64 = 0;
    let total_chunks = chunk_count_for_size(metadata.original_size);

    loop {
        let next = read_chunk(reader, &mut buffer[..])?;
        let is_last = next.is_empty();
        let chunk_len = current.len();

        let nonce = chunk_nonce_for_flags(flags, &nonce_prefix, &file_id, index)?;
        let aad = chunk_aad(&header, is_last, index);
        let sealed = crypto::seal(vault_key, &nonce, &aad, &current)?;
        if sealed.len() < AEAD_TAG_LEN || sealed.len() > MAX_CHUNK_SIZE + AEAD_TAG_LEN {
            return Err(OpacError::Metadata);
        }

        writer.write_all(&[if is_last { 1 } else { 0 }])?;
        writer.write_all(&index.to_le_bytes())?;
        writer.write_all(&(sealed.len() as u32).to_le_bytes())?;
        writer.write_all(&sealed)?;
        on_chunk_progress((index as u64) + 1, total_chunks);

        total_read = total_read
            .checked_add(chunk_len as u64)
            .ok_or(OpacError::Metadata)?;

        if is_last {
            break;
        }
        index = index.checked_add(1).ok_or(OpacError::Metadata)?;
        if index == META_CHUNK_INDEX {
            return Err(OpacError::Metadata);
        }
        current = next;
    }

    if total_read != metadata.original_size {
        return Err(OpacError::Metadata);
    }
    Ok(())
}

/// Huella determinista no criptográfica usada exclusivamente para detectar
/// intercambios accidentales de plaintext entre workers antes de publicar un
/// chunk cifrado. La autenticación real sigue estando a cargo de ChaCha20-Poly1305.
fn chunk_fingerprint(data: &[u8]) -> u128 {
    let mut left = 0xcbf29ce484222325u64;
    let mut right = 0x9e3779b185ebca87u64;
    for (offset, byte) in data.iter().copied().enumerate() {
        left ^= u64::from(byte);
        left = left.wrapping_mul(0x100000001b3);
        right ^= left.rotate_left(17) ^ (offset as u64);
        right = right.wrapping_mul(0x9e3779b185ebca87);
    }
    ((left as u128) << 64) | right as u128
}

#[derive(Debug)]
struct ParallelChunkResult {
    index: u32,
    is_last: bool,
    plain_len: usize,
    source_fingerprint: u128,
    sealed: Result<Vec<u8>, OpacError>,
}

fn review_parallel_batch(
    mut results: Vec<ParallelChunkResult>,
    batch_start: u32,
    expected_fingerprints: &[u128],
    last_is_known: bool,
    chunk_size: usize,
) -> Result<Vec<ParallelChunkResult>, OpacError> {
    if results.len() != expected_fingerprints.len() || results.is_empty() {
        return Err(OpacError::Metadata);
    }

    results.sort_unstable_by_key(|result| result.index);
    let batch_end = batch_start
        .checked_add(results.len() as u32 - 1)
        .ok_or(OpacError::Metadata)?;

    for (offset, result) in results.iter().enumerate() {
        let expected_index = batch_start
            .checked_add(offset as u32)
            .ok_or(OpacError::Metadata)?;
        if result.index != expected_index
            || result.source_fingerprint != expected_fingerprints[offset]
        {
            return Err(OpacError::Metadata);
        }

        let should_be_last = last_is_known && result.index == batch_end;
        if result.is_last != should_be_last {
            return Err(OpacError::Metadata);
        }

        let sealed = result.sealed.as_ref().map_err(|_| OpacError::Metadata)?;
        if sealed.len() < AEAD_TAG_LEN || sealed.len() > chunk_size + AEAD_TAG_LEN {
            return Err(OpacError::Metadata);
        }
        if result.plain_len == 0 || result.plain_len > chunk_size {
            return Err(OpacError::Metadata);
        }
    }

    Ok(results)
}

fn encrypt_chunked_parallel_with_progress<R: Read, W: Write, F: FnMut(u64, u64)>(
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    chunk_size: usize,
    worker_count: usize,
    reader: &mut R,
    writer: &mut W,
    on_chunk_progress: &mut F,
) -> Result<(), OpacError> {
    validate_metadata(&metadata)?;
    if chunk_size == 0 || chunk_size > MAX_CHUNK_SIZE || chunk_size > u32::MAX as usize {
        return Err(OpacError::Metadata);
    }
    let worker_count = worker_count.clamp(2, MAX_PARALLEL_CHUNK_WORKERS);

    let file_id = crypto::random_file_id();
    let random_nonce = crypto::random_nonce();
    let mut nonce_prefix = [0u8; NONCE_PREFIX_LEN];
    nonce_prefix.copy_from_slice(&random_nonce[..NONCE_PREFIX_LEN]);
    let flags = OPAC_FLAG_CURRENT;
    let header = build_header_v2(flags, &file_id, &nonce_prefix, chunk_size as u32);
    writer.write_all(&header)?;

    let metadata_bytes =
        Zeroizing::new(serialization::encode(&metadata).map_err(|_| OpacError::Metadata)?);
    if metadata_bytes.len() > MAX_METADATA_LEN {
        return Err(OpacError::Metadata);
    }
    let meta_nonce = chunk_nonce_for_flags(flags, &nonce_prefix, &file_id, META_CHUNK_INDEX)?;
    let meta_aad = metadata_aad(&header);
    let meta_sealed = crypto::seal(vault_key, &meta_nonce, &meta_aad, &metadata_bytes)?;
    writer.write_all(&(meta_sealed.len() as u32).to_le_bytes())?;
    writer.write_all(&meta_sealed)?;

    let (result_tx, result_rx) = mpsc::channel::<ParallelChunkResult>();
    let mut job_senders = Vec::with_capacity(worker_count);
    let mut worker_handles = Vec::with_capacity(worker_count);
    let mut spawn_error = None;

    for worker_index in 0..worker_count {
        let (job_tx, job_rx) = mpsc::channel::<Option<(u32, bool, u128, Zeroizing<Vec<u8>>)>>();
        let tx = result_tx.clone();
        let worker_key = *vault_key;
        let worker_nonce_prefix = nonce_prefix;
        let worker_file_id = file_id;
        let worker_header = header.clone();
        match thread::Builder::new()
            .name(format!("opac-chunk-encrypt-{worker_index}"))
            .spawn(move || {
                while let Ok(message) = job_rx.recv() {
                    let Some((index, is_last, source_fingerprint, plain)) = message else {
                        break;
                    };
                    let plain_len = plain.len();
                    let result = (|| -> Result<Vec<u8>, OpacError> {
                        let nonce = chunk_nonce_for_flags(
                            flags,
                            &worker_nonce_prefix,
                            &worker_file_id,
                            index,
                        )?;
                        let aad = chunk_aad(&worker_header, is_last, index);
                        crypto::seal(&worker_key, &nonce, &aad, &plain).map_err(OpacError::from)
                    })();
                    if tx
                        .send(ParallelChunkResult {
                            index,
                            is_last,
                            plain_len,
                            source_fingerprint,
                            sealed: result,
                        })
                        .is_err()
                    {
                        break;
                    }
                }
            }) {
            Ok(handle) => {
                job_senders.push(job_tx);
                worker_handles.push(handle);
            }
            Err(error) => {
                spawn_error = Some(OpacError::Io(io::Error::other(format!(
                    "no se pudo iniciar el worker de chunks {worker_index}: {error}"
                ))));
                break;
            }
        }
    }
    drop(result_tx);

    if let Some(error) = spawn_error {
        for sender in job_senders {
            let _ = sender.send(None);
        }
        for handle in worker_handles {
            let _ = handle.join();
        }
        return Err(error);
    }

    let total_chunks = chunk_count_for_size(metadata.original_size);
    let mut next_index = 0u32;
    let mut total_read = 0u64;
    let mut written_chunks = 0u64;
    let mut written_next_index = 0u32;
    let mut pending: Option<Zeroizing<Vec<u8>>> = None;
    let mut failure: Option<OpacError> = None;
    let mut finished = false;

    'batches: loop {
        let batch_start = next_index;
        let mut batch: Vec<(u32, u128, Zeroizing<Vec<u8>>)> = Vec::with_capacity(worker_count);
        let mut eof_while_filling = false;

        while batch.len() < worker_count {
            let plain = if let Some(pending) = pending.take() {
                pending
            } else {
                let mut buffer = Zeroizing::new(vec![0u8; chunk_size]);
                let chunk = match read_chunk(reader, &mut buffer[..]) {
                    Ok(chunk) => chunk,
                    Err(error) => {
                        failure = Some(error);
                        break 'batches;
                    }
                };
                if chunk.is_empty() {
                    eof_while_filling = true;
                    break;
                }
                chunk
            };

            if next_index == META_CHUNK_INDEX {
                failure = Some(OpacError::Metadata);
                break 'batches;
            }
            total_read = match total_read.checked_add(plain.len() as u64) {
                Some(value) => value,
                None => {
                    failure = Some(OpacError::Metadata);
                    break 'batches;
                }
            };
            let source_fingerprint = chunk_fingerprint(&plain);
            batch.push((next_index, source_fingerprint, plain));
            next_index = match next_index.checked_add(1) {
                Some(value) => value,
                None => {
                    failure = Some(OpacError::Metadata);
                    break 'batches;
                }
            };
        }

        if batch.is_empty() {
            if eof_while_filling {
                finished = true;
            }
            break;
        }

        let batch_len = batch.len();
        let last_is_known = if eof_while_filling || batch_len < worker_count {
            true
        } else {
            let mut buffer = Zeroizing::new(vec![0u8; chunk_size]);
            let chunk = match read_chunk(reader, &mut buffer[..]) {
                Ok(chunk) => chunk,
                Err(error) => {
                    failure = Some(error);
                    break 'batches;
                }
            };
            if chunk.is_empty() {
                true
            } else {
                pending = Some(chunk);
                false
            }
        };

        let expected_fingerprints: Vec<u128> = batch
            .iter()
            .map(|(_, fingerprint, _)| *fingerprint)
            .collect();
        for (local_index, (index, source_fingerprint, plain)) in batch.into_iter().enumerate() {
            let is_last = last_is_known && local_index + 1 == batch_len;
            if job_senders[local_index]
                .send(Some((index, is_last, source_fingerprint, plain)))
                .is_err()
            {
                failure = Some(OpacError::Io(io::Error::other(
                    "un worker de chunks terminó inesperadamente",
                )));
                break 'batches;
            }
        }

        let mut results = Vec::with_capacity(batch_len);
        for _ in 0..batch_len {
            match result_rx.recv() {
                Ok(result) => results.push(result),
                Err(_) => {
                    failure = Some(OpacError::Io(io::Error::other(
                        "un worker de chunks no devolvio su resultado",
                    )));
                    break 'batches;
                }
            }
        }

        let results = match review_parallel_batch(
            results,
            batch_start,
            &expected_fingerprints,
            last_is_known,
            chunk_size,
        ) {
            Ok(results) => results,
            Err(error) => {
                failure = Some(error);
                break 'batches;
            }
        };

        for result in results {
            if result.index != written_next_index {
                failure = Some(OpacError::Metadata);
                break 'batches;
            }
            let sealed = match result.sealed {
                Ok(sealed) => sealed,
                Err(error) => {
                    failure = Some(error);
                    break 'batches;
                }
            };
            if sealed.len() < AEAD_TAG_LEN || sealed.len() > chunk_size + AEAD_TAG_LEN {
                failure = Some(OpacError::Metadata);
                break 'batches;
            }
            if result.plain_len == 0 || result.plain_len > chunk_size {
                failure = Some(OpacError::Metadata);
                break 'batches;
            }
            if writer
                .write_all(&[if result.is_last { 1 } else { 0 }])
                .is_err()
            {
                failure = Some(OpacError::Io(io::Error::other(
                    "no se pudo escribir el estado final del chunk",
                )));
                break 'batches;
            }
            if let Err(error) = writer.write_all(&result.index.to_le_bytes()) {
                failure = Some(OpacError::Io(error));
                break 'batches;
            }
            if let Err(error) = writer.write_all(&(sealed.len() as u32).to_le_bytes()) {
                failure = Some(OpacError::Io(error));
                break 'batches;
            }
            if let Err(error) = writer.write_all(&sealed) {
                failure = Some(OpacError::Io(error));
                break 'batches;
            }
            on_chunk_progress(result.index as u64 + 1, total_chunks);
            written_chunks += 1;
            written_next_index = written_next_index
                .checked_add(1)
                .ok_or(OpacError::Metadata)?;
            if result.is_last {
                finished = true;
            }
        }

        if finished {
            break;
        }
    }

    for sender in job_senders {
        let _ = sender.send(None);
    }
    for handle in worker_handles {
        let _ = handle.join();
    }

    if let Some(error) = failure {
        return Err(error);
    }
    if !finished
        || total_read != metadata.original_size
        || written_chunks != total_chunks
        || written_next_index != u32::try_from(total_chunks).map_err(|_| OpacError::Metadata)?
    {
        return Err(OpacError::Metadata);
    }
    Ok(())
}

/// Verifica el framing y la autenticidad de un V2 ya cifrado antes de publicarlo.
///
/// Esta revisión se ejecuta sobre el temporal antes de convertirlo en el archivo
/// final. Comprueba que los indices sean exactamente 0..N-1, que solo el ultimo
/// chunk lleve el marcador final, que las longitudes correspondan al tamaño
/// declarado y que no haya bytes sobrantes. Además, reautentica cada ciphertext
/// con su nonce y AAD correspondientes; el plaintext resultante se descarta
/// inmediatamente.
pub fn verify_v2_chunk_sequence<R: Read + io::Seek>(
    vault_key: &[u8; KEY_LEN],
    reader: &mut R,
) -> Result<OpacMetadata, OpacError> {
    let start = reader.stream_position()?;
    let mut header = [0u8; HEADER_LEN_V2];
    read_exact_or_truncated(reader, &mut header)?;
    if &header[..4] != OPAC_MAGIC {
        return Err(OpacError::BadMagic);
    }
    let version = u16::from_le_bytes([header[4], header[5]]);
    if version != OPAC_VERSION {
        return Err(OpacError::UnsupportedVersion(version));
    }
    let flags = u16::from_le_bytes([header[6], header[7]]);
    if flags != 0 && flags != OPAC_FLAG_POSTCARD_METADATA && flags != OPAC_FLAG_CURRENT {
        return Err(OpacError::Metadata);
    }

    let mut file_id = [0u8; FILE_ID_LEN];
    file_id.copy_from_slice(&header[8..8 + FILE_ID_LEN]);
    let np_start = 8 + FILE_ID_LEN;
    let mut nonce_prefix = [0u8; NONCE_PREFIX_LEN];
    nonce_prefix.copy_from_slice(&header[np_start..np_start + NONCE_PREFIX_LEN]);
    let chunk_size_pos = np_start + NONCE_PREFIX_LEN;
    let chunk_size = u32::from_le_bytes(
        header[chunk_size_pos..chunk_size_pos + 4]
            .try_into()
            .map_err(|_| OpacError::Truncated)?,
    ) as usize;
    if chunk_size == 0 || chunk_size > MAX_CHUNK_SIZE {
        return Err(OpacError::Metadata);
    }

    reader.seek(io::SeekFrom::Start(start))?;
    let metadata = read_metadata_only(vault_key, reader)?;
    let expected_chunks = chunk_count_for_size_with_chunk_size(metadata.original_size, chunk_size);
    let mut expected_index = 0u32;
    let mut total_plain = 0u64;

    loop {
        let mut is_last_byte = [0u8; 1];
        read_exact_or_truncated(reader, &mut is_last_byte)?;
        let is_last = match is_last_byte[0] {
            0 => false,
            1 => true,
            _ => return Err(OpacError::Metadata),
        };

        let mut index_bytes = [0u8; 4];
        read_exact_or_truncated(reader, &mut index_bytes)?;
        let index = u32::from_le_bytes(index_bytes);
        if index != expected_index {
            return Err(OpacError::Metadata);
        }

        let mut len_bytes = [0u8; 4];
        read_exact_or_truncated(reader, &mut len_bytes)?;
        let sealed_len = u32::from_le_bytes(len_bytes) as usize;
        if sealed_len < AEAD_TAG_LEN || sealed_len > chunk_size + AEAD_TAG_LEN {
            return Err(OpacError::Metadata);
        }
        let plain_len = sealed_len - AEAD_TAG_LEN;
        if (!is_last && plain_len != chunk_size) || (is_last && plain_len > chunk_size) {
            return Err(OpacError::Metadata);
        }

        let mut sealed = vec![0u8; sealed_len];
        read_exact_or_truncated(reader, &mut sealed)?;
        let nonce = chunk_nonce_for_flags(flags, &nonce_prefix, &file_id, index)?;
        let aad = chunk_aad(&header, is_last, index);
        // Re-authenticate every final ciphertext against its expected index/AAD.
        // The plaintext is discarded immediately; this pass is a final integrity
        // check and does not materialize the source file in memory.
        let _plaintext = Zeroizing::new(crypto::open(vault_key, &nonce, &aad, &sealed)?);

        total_plain = total_plain
            .checked_add(plain_len as u64)
            .ok_or(OpacError::Metadata)?;

        if is_last {
            break;
        }
        expected_index = expected_index.checked_add(1).ok_or(OpacError::Metadata)?;
        if expected_index == META_CHUNK_INDEX {
            return Err(OpacError::Metadata);
        }
    }

    if expected_index as u64 + 1 != expected_chunks || total_plain != metadata.original_size {
        return Err(OpacError::Metadata);
    }

    let mut probe = [0u8; 1];
    match reader.read(&mut probe) {
        Ok(0) => {}
        Ok(_) => return Err(OpacError::Metadata),
        Err(error) => return Err(OpacError::Io(error)),
    }

    Ok(metadata)
}

/// Lee y autentica únicamente la metadata de un V2 sin consumir ni descifrar
/// los chunks de contenido. Para V1 legacy la compatibilidad requiere leer el
/// bloque completo mediante `decrypt` porque metadata y contenido estaban
/// sellados juntos.
pub fn read_metadata_only<R: Read>(
    vault_key: &[u8; KEY_LEN],
    reader: &mut R,
) -> Result<OpacMetadata, OpacError> {
    let mut fixed = [0u8; HEADER_LEN_V2];
    read_exact_or_truncated(reader, &mut fixed)?;
    if &fixed[..4] != OPAC_MAGIC {
        return Err(OpacError::BadMagic);
    }
    let version = u16::from_le_bytes([fixed[4], fixed[5]]);
    if version != OPAC_VERSION {
        return Err(OpacError::UnsupportedVersion(version));
    }

    let flags = u16::from_le_bytes([fixed[6], fixed[7]]);
    if flags != 0 && flags != OPAC_FLAG_POSTCARD_METADATA && flags != OPAC_FLAG_CURRENT {
        return Err(OpacError::Metadata);
    }

    let mut file_id = [0u8; FILE_ID_LEN];
    file_id.copy_from_slice(&fixed[8..8 + FILE_ID_LEN]);
    let np_start = 8 + FILE_ID_LEN;
    let mut nonce_prefix = [0u8; NONCE_PREFIX_LEN];
    nonce_prefix.copy_from_slice(&fixed[np_start..np_start + NONCE_PREFIX_LEN]);
    let mut chunk_size_bytes = [0u8; 4];
    chunk_size_bytes
        .copy_from_slice(&fixed[np_start + NONCE_PREFIX_LEN..np_start + NONCE_PREFIX_LEN + 4]);
    let chunk_size = u32::from_le_bytes(chunk_size_bytes) as usize;
    if chunk_size == 0 || chunk_size > MAX_CHUNK_SIZE {
        return Err(OpacError::Metadata);
    }

    let mut meta_len_bytes = [0u8; 4];
    read_exact_or_truncated(reader, &mut meta_len_bytes)?;
    let meta_len = u32::from_le_bytes(meta_len_bytes) as usize;
    if !(AEAD_TAG_LEN..=MAX_METADATA_LEN + AEAD_TAG_LEN).contains(&meta_len) {
        return Err(OpacError::Metadata);
    }
    let mut meta_sealed = vec![0u8; meta_len];
    read_exact_or_truncated(reader, &mut meta_sealed)?;

    let meta_nonce = chunk_nonce_for_flags(flags, &nonce_prefix, &file_id, META_CHUNK_INDEX)?;
    let meta_aad = metadata_aad(&fixed);
    let metadata_bytes = Zeroizing::new(crypto::open(
        vault_key,
        &meta_nonce,
        &meta_aad,
        &meta_sealed,
    )?);
    if metadata_bytes.len() > MAX_METADATA_LEN {
        return Err(OpacError::Metadata);
    }
    let metadata = if flags == OPAC_FLAG_POSTCARD_METADATA || flags == OPAC_FLAG_CURRENT {
        let (value, remainder) = postcard::take_from_bytes::<OpacMetadata>(&metadata_bytes)
            .map_err(|_| OpacError::Metadata)?;
        if !remainder.is_empty() {
            return Err(OpacError::Metadata);
        }
        value
    } else {
        decode_legacy_metadata(&metadata_bytes)?
    };
    validate_metadata(&metadata)?;
    Ok(metadata)
}

/// Descifra V2 en streaming.
///
/// La función puede haber escrito chunks anteriores cuando un chunk posterior
/// falla. Quien necesite atomicidad de disco debe usar un archivo temporal,
/// como hace `vault_fs`.
pub fn decrypt_chunked<R: Read, W: Write>(
    vault_key: &[u8; KEY_LEN],
    reader: &mut R,
    writer: &mut W,
) -> Result<OpacMetadata, OpacError> {
    let mut fixed = [0u8; HEADER_LEN_V2];
    read_exact_or_truncated(reader, &mut fixed)?;
    if &fixed[..4] != OPAC_MAGIC {
        return Err(OpacError::BadMagic);
    }
    let version = u16::from_le_bytes([fixed[4], fixed[5]]);
    if version != OPAC_VERSION {
        return Err(OpacError::UnsupportedVersion(version));
    }

    let flags = u16::from_le_bytes([fixed[6], fixed[7]]);
    if flags != 0 && flags != OPAC_FLAG_POSTCARD_METADATA && flags != OPAC_FLAG_CURRENT {
        return Err(OpacError::Metadata);
    }

    let mut file_id = [0u8; FILE_ID_LEN];
    file_id.copy_from_slice(&fixed[8..8 + FILE_ID_LEN]);
    let np_start = 8 + FILE_ID_LEN;
    let mut nonce_prefix = [0u8; NONCE_PREFIX_LEN];
    nonce_prefix.copy_from_slice(&fixed[np_start..np_start + NONCE_PREFIX_LEN]);
    let chunk_size_pos = np_start + NONCE_PREFIX_LEN;
    let chunk_size = u32::from_le_bytes(
        fixed[chunk_size_pos..chunk_size_pos + 4]
            .try_into()
            .map_err(|_| OpacError::Truncated)?,
    ) as usize;
    if chunk_size == 0 || chunk_size > MAX_CHUNK_SIZE {
        return Err(OpacError::Metadata);
    }

    let header = fixed.to_vec();

    let mut meta_len_bytes = [0u8; 4];
    read_exact_or_truncated(reader, &mut meta_len_bytes)?;
    let meta_len = u32::from_le_bytes(meta_len_bytes) as usize;
    if !(AEAD_TAG_LEN..=MAX_METADATA_LEN + AEAD_TAG_LEN).contains(&meta_len) {
        return Err(OpacError::Metadata);
    }
    let mut meta_sealed = vec![0u8; meta_len];
    read_exact_or_truncated(reader, &mut meta_sealed)?;
    let meta_nonce = chunk_nonce_for_flags(flags, &nonce_prefix, &file_id, META_CHUNK_INDEX)?;
    let meta_aad = metadata_aad(&header);
    let metadata_bytes = Zeroizing::new(crypto::open(
        vault_key,
        &meta_nonce,
        &meta_aad,
        &meta_sealed,
    )?);
    if metadata_bytes.len() > MAX_METADATA_LEN {
        return Err(OpacError::Metadata);
    }
    let metadata = if flags == OPAC_FLAG_POSTCARD_METADATA || flags == OPAC_FLAG_CURRENT {
        let (value, remainder) = postcard::take_from_bytes::<OpacMetadata>(&metadata_bytes)
            .map_err(|_| OpacError::Metadata)?;
        if !remainder.is_empty() {
            return Err(OpacError::Metadata);
        }
        value
    } else {
        decode_legacy_metadata(&metadata_bytes)?
    };
    validate_metadata(&metadata)?;

    let mut expected_index: u32 = 0;
    let mut total_written: u64 = 0;

    loop {
        let mut is_last_byte = [0u8; 1];
        read_exact_or_truncated(reader, &mut is_last_byte)?;
        let is_last = match is_last_byte[0] {
            0 => false,
            1 => true,
            _ => return Err(OpacError::Metadata),
        };

        let mut index_bytes = [0u8; 4];
        read_exact_or_truncated(reader, &mut index_bytes)?;
        let index = u32::from_le_bytes(index_bytes);
        if index != expected_index {
            return Err(OpacError::Metadata);
        }

        let mut len_bytes = [0u8; 4];
        read_exact_or_truncated(reader, &mut len_bytes)?;
        let sealed_len = u32::from_le_bytes(len_bytes) as usize;
        if sealed_len < AEAD_TAG_LEN || sealed_len > chunk_size + AEAD_TAG_LEN {
            return Err(OpacError::Metadata);
        }

        let mut sealed = vec![0u8; sealed_len];
        read_exact_or_truncated(reader, &mut sealed)?;

        let nonce = chunk_nonce_for_flags(flags, &nonce_prefix, &file_id, index)?;
        let aad = chunk_aad(&header, is_last, index);
        let plain = Zeroizing::new(crypto::open(vault_key, &nonce, &aad, &sealed)?);

        if (!is_last && plain.len() != chunk_size) || (is_last && plain.len() > chunk_size) {
            return Err(OpacError::Metadata);
        }

        writer.write_all(&plain)?;
        total_written = total_written
            .checked_add(plain.len() as u64)
            .ok_or(OpacError::Metadata)?;

        if is_last {
            break;
        }
        expected_index = expected_index.checked_add(1).ok_or(OpacError::Metadata)?;
        if expected_index == META_CHUNK_INDEX {
            return Err(OpacError::Metadata);
        }
    }

    let mut probe = [0u8; 1];
    match reader.read(&mut probe) {
        Ok(0) => {}
        Ok(_) => return Err(OpacError::Metadata),
        Err(e) => return Err(OpacError::Io(e)),
    }

    if total_written != metadata.original_size {
        return Err(OpacError::Metadata);
    }
    Ok(metadata)
}

/// Reescribe un V2 cambiando únicamente los metadatos autenticados.
/// El contenido se descifra y cifra chunk a chunk, por lo que la memoria usada
/// queda acotada al mayor chunk y no crece con el tamaño del archivo.
pub fn rewrite_v2_metadata<R: Read, W: Write>(
    vault_key: &[u8; KEY_LEN],
    new_metadata: OpacMetadata,
    reader: &mut R,
    writer: &mut W,
) -> Result<(), OpacError> {
    validate_metadata(&new_metadata)?;

    let mut fixed = [0u8; HEADER_LEN_V2];
    read_exact_or_truncated(reader, &mut fixed)?;
    if &fixed[..4] != OPAC_MAGIC {
        return Err(OpacError::BadMagic);
    }
    if u16::from_le_bytes([fixed[4], fixed[5]]) != OPAC_VERSION {
        return Err(OpacError::UnsupportedVersion(u16::from_le_bytes([
            fixed[4], fixed[5],
        ])));
    }
    let flags = u16::from_le_bytes([fixed[6], fixed[7]]);
    if flags != 0 && flags != OPAC_FLAG_POSTCARD_METADATA && flags != OPAC_FLAG_CURRENT {
        return Err(OpacError::Metadata);
    }
    let mut old_file_id = [0u8; FILE_ID_LEN];
    old_file_id.copy_from_slice(&fixed[8..8 + FILE_ID_LEN]);
    let np_start = 8 + FILE_ID_LEN;
    let mut old_nonce_prefix = [0u8; NONCE_PREFIX_LEN];
    old_nonce_prefix.copy_from_slice(&fixed[np_start..np_start + NONCE_PREFIX_LEN]);
    let chunk_size = u32::from_le_bytes(
        fixed[np_start + NONCE_PREFIX_LEN..np_start + NONCE_PREFIX_LEN + 4]
            .try_into()
            .map_err(|_| OpacError::Truncated)?,
    ) as usize;
    if chunk_size == 0 || chunk_size > MAX_CHUNK_SIZE {
        return Err(OpacError::Metadata);
    }

    let old_header = fixed.to_vec();
    let current_metadata = read_metadata_from_header_stream(
        vault_key,
        flags,
        &old_file_id,
        &old_nonce_prefix,
        &old_header,
        reader,
    )?;
    if current_metadata.original_size != new_metadata.original_size {
        return Err(OpacError::Metadata);
    }

    let new_file_id = crypto::random_file_id();
    let random_nonce = crypto::random_nonce();
    let mut new_nonce_prefix = [0u8; NONCE_PREFIX_LEN];
    new_nonce_prefix.copy_from_slice(&random_nonce[..NONCE_PREFIX_LEN]);
    let new_flags = OPAC_FLAG_CURRENT;
    let new_header = build_header_v2(
        new_flags,
        &new_file_id,
        &new_nonce_prefix,
        chunk_size as u32,
    );
    writer.write_all(&new_header)?;

    let metadata_bytes =
        Zeroizing::new(serialization::encode(&new_metadata).map_err(|_| OpacError::Metadata)?);
    if metadata_bytes.len() > MAX_METADATA_LEN {
        return Err(OpacError::Metadata);
    }
    let meta_nonce =
        chunk_nonce_for_flags(new_flags, &new_nonce_prefix, &new_file_id, META_CHUNK_INDEX)?;
    let meta_sealed = crypto::seal(
        vault_key,
        &meta_nonce,
        &metadata_aad(&new_header),
        &metadata_bytes,
    )?;
    writer.write_all(&(meta_sealed.len() as u32).to_le_bytes())?;
    writer.write_all(&meta_sealed)?;

    let mut index = 0u32;
    let mut total = 0u64;
    let mut sealed = vec![0u8; chunk_size.saturating_add(AEAD_TAG_LEN)];
    loop {
        let mut is_last = [0u8; 1];
        read_exact_or_truncated(reader, &mut is_last)?;
        let is_last = match is_last[0] {
            0 => false,
            1 => true,
            _ => return Err(OpacError::Metadata),
        };
        let mut index_bytes = [0u8; 4];
        read_exact_or_truncated(reader, &mut index_bytes)?;
        if u32::from_le_bytes(index_bytes) != index {
            return Err(OpacError::Metadata);
        }
        let mut len_bytes = [0u8; 4];
        read_exact_or_truncated(reader, &mut len_bytes)?;
        let sealed_len = u32::from_le_bytes(len_bytes) as usize;
        if sealed_len < AEAD_TAG_LEN || sealed_len > chunk_size.saturating_add(AEAD_TAG_LEN) {
            return Err(OpacError::Metadata);
        }
        if sealed.len() < sealed_len {
            sealed.resize(sealed_len, 0);
        }
        read_exact_or_truncated(reader, &mut sealed[..sealed_len])?;
        let old_nonce = chunk_nonce_for_flags(flags, &old_nonce_prefix, &old_file_id, index)?;
        let old_aad = chunk_aad(&old_header, is_last, index);
        let plain = Zeroizing::new(crypto::open(
            vault_key,
            &old_nonce,
            &old_aad,
            &sealed[..sealed_len],
        )?);
        if (!is_last && plain.len() != chunk_size) || (is_last && plain.len() > chunk_size) {
            return Err(OpacError::Metadata);
        }
        let new_nonce = chunk_nonce_for_flags(new_flags, &new_nonce_prefix, &new_file_id, index)?;
        let new_aad = chunk_aad(&new_header, is_last, index);
        let new_sealed = crypto::seal(vault_key, &new_nonce, &new_aad, &plain)?;
        writer.write_all(&[if is_last { 1 } else { 0 }])?;
        writer.write_all(&index.to_le_bytes())?;
        writer.write_all(&(new_sealed.len() as u32).to_le_bytes())?;
        writer.write_all(&new_sealed)?;
        total = total
            .checked_add(plain.len() as u64)
            .ok_or(OpacError::Metadata)?;
        if is_last {
            break;
        }
        index = index.checked_add(1).ok_or(OpacError::Metadata)?;
        if index == META_CHUNK_INDEX {
            return Err(OpacError::Metadata);
        }
    }
    let mut probe = [0u8; 1];
    if reader.read(&mut probe)? != 0 {
        return Err(OpacError::Metadata);
    }
    if total != new_metadata.original_size {
        return Err(OpacError::Metadata);
    }
    Ok(())
}

fn read_metadata_from_header_stream<R: Read>(
    vault_key: &[u8; KEY_LEN],
    flags: u16,
    file_id: &[u8; FILE_ID_LEN],
    nonce_prefix: &[u8; NONCE_PREFIX_LEN],
    header: &[u8],
    reader: &mut R,
) -> Result<OpacMetadata, OpacError> {
    let mut meta_len_bytes = [0u8; 4];
    read_exact_or_truncated(reader, &mut meta_len_bytes)?;
    let meta_len = u32::from_le_bytes(meta_len_bytes) as usize;
    if !(AEAD_TAG_LEN..=MAX_METADATA_LEN + AEAD_TAG_LEN).contains(&meta_len) {
        return Err(OpacError::Metadata);
    }
    let mut meta_sealed = vec![0u8; meta_len];
    read_exact_or_truncated(reader, &mut meta_sealed)?;
    let meta_nonce = chunk_nonce_for_flags(flags, nonce_prefix, file_id, META_CHUNK_INDEX)?;
    let metadata_bytes = Zeroizing::new(crypto::open(
        vault_key,
        &meta_nonce,
        &metadata_aad(header),
        &meta_sealed,
    )?);
    if metadata_bytes.len() > MAX_METADATA_LEN {
        return Err(OpacError::Metadata);
    }
    let metadata = if flags == OPAC_FLAG_POSTCARD_METADATA || flags == OPAC_FLAG_CURRENT {
        let (value, remainder) = postcard::take_from_bytes::<OpacMetadata>(&metadata_bytes)
            .map_err(|_| OpacError::Metadata)?;
        if !remainder.is_empty() {
            return Err(OpacError::Metadata);
        }
        value
    } else {
        decode_legacy_metadata(&metadata_bytes)?
    };
    validate_metadata(&metadata)?;
    Ok(metadata)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_metadata(size: u64) -> OpacMetadata {
        OpacMetadata {
            original_name: "archivo.bin".to_string(),
            original_size: size,
            created_unix: Some(1_700_000_000),
            modified_unix: Some(1_700_000_100),
        }
    }

    fn legacy_metadata_bytes(metadata: &OpacMetadata) -> Vec<u8> {
        fn push_u64(out: &mut Vec<u8>, value: u64) {
            out.extend_from_slice(&value.to_le_bytes());
        }
        fn push_string(out: &mut Vec<u8>, value: &str) {
            push_u64(out, value.len() as u64);
            out.extend_from_slice(value.as_bytes());
        }
        fn push_option_u64(out: &mut Vec<u8>, value: Option<u64>) {
            match value {
                None => out.push(0),
                Some(value) => {
                    out.push(1);
                    push_u64(out, value);
                }
            }
        }

        let mut out = Vec::new();
        push_string(&mut out, &metadata.original_name);
        push_u64(&mut out, metadata.original_size);
        push_option_u64(&mut out, metadata.created_unix);
        push_option_u64(&mut out, metadata.modified_unix);
        out
    }
    fn encrypt_to_vec(key: &[u8; KEY_LEN], content: &[u8], chunk_size: usize) -> Vec<u8> {
        let mut out = Vec::new();
        encrypt_chunked(
            key,
            sample_metadata(content.len() as u64),
            chunk_size,
            &mut Cursor::new(content.to_vec()),
            &mut out,
        )
        .unwrap();
        out
    }

    #[test]
    fn encrypt_always_writes_v2_with_postcard_metadata() {
        let key = crypto::random_key();
        let blob = encrypt(&key, sample_metadata(3), b"abc").unwrap();
        assert_eq!(u16::from_le_bytes([blob[4], blob[5]]), OPAC_VERSION);
        assert_eq!(u16::from_le_bytes([blob[6], blob[7]]), OPAC_FLAG_CURRENT);
    }

    #[test]
    fn small_files_use_single_v2_chunk() {
        let key = crypto::random_key();
        let content = b"abc";
        let blob = encrypt(&key, sample_metadata(content.len() as u64), content).unwrap();
        let chunk_size = u32::from_le_bytes(blob[32..36].try_into().unwrap());
        assert_eq!(chunk_size, content.len() as u32);

        let mut out = Vec::new();
        decrypt_chunked(&key, &mut Cursor::new(blob), &mut out).unwrap();
        assert_eq!(out, content);
    }

    #[test]
    fn empty_files_use_single_v2_chunk() {
        let key = crypto::random_key();
        let blob = encrypt(&key, sample_metadata(0), b"").unwrap();
        let chunk_size = u32::from_le_bytes(blob[32..36].try_into().unwrap());
        assert_eq!(chunk_size, 1);

        let mut out = Vec::new();
        decrypt_chunked(&key, &mut Cursor::new(blob), &mut out).unwrap();
        assert!(out.is_empty());
    }

    #[test]
    fn parallel_chunk_encryption_preserves_order_and_roundtrips() {
        let key = crypto::random_key();
        let content_len = 17 * 1024 * 1024 + 123;
        let content: Vec<u8> = (0..content_len).map(|index| (index % 251) as u8).collect();
        let metadata = sample_metadata(content.len() as u64);

        let mut blob = Vec::new();
        let mut progress = Vec::new();
        encrypt_v2_auto_with_parallel_progress(
            &key,
            metadata.clone(),
            &mut Cursor::new(content.clone()),
            &mut blob,
            4,
            |completed, total| progress.push((completed, total)),
        )
        .unwrap();

        let mut recovered = Vec::new();
        let opened = decrypt_chunked(&key, &mut Cursor::new(blob), &mut recovered).unwrap();
        assert_eq!(opened, metadata);
        assert_eq!(recovered, content);
        assert_eq!(progress, vec![(1, 5), (2, 5), (3, 5), (4, 5), (5, 5)]);
    }

    #[test]
    fn parallel_batch_review_repairs_worker_completion_order_without_reordering_indices() {
        let results = vec![
            ParallelChunkResult {
                index: 2,
                is_last: true,
                plain_len: 1,
                source_fingerprint: chunk_fingerprint(b"C"),
                sealed: Ok(vec![0; AEAD_TAG_LEN + 1]),
            },
            ParallelChunkResult {
                index: 0,
                is_last: false,
                plain_len: 1,
                source_fingerprint: chunk_fingerprint(b"A"),
                sealed: Ok(vec![0; AEAD_TAG_LEN + 1]),
            },
            ParallelChunkResult {
                index: 1,
                is_last: false,
                plain_len: 1,
                source_fingerprint: chunk_fingerprint(b"B"),
                sealed: Ok(vec![0; AEAD_TAG_LEN + 1]),
            },
        ];

        let reviewed = review_parallel_batch(
            results,
            0,
            &[
                chunk_fingerprint(b"A"),
                chunk_fingerprint(b"B"),
                chunk_fingerprint(b"C"),
            ],
            true,
            1,
        )
        .unwrap();

        assert_eq!(
            reviewed
                .iter()
                .map(|result| result.index)
                .collect::<Vec<_>>(),
            vec![0, 1, 2]
        );
    }

    #[test]
    fn parallel_batch_review_rejects_worker_returning_the_wrong_source_chunk() {
        let results = vec![ParallelChunkResult {
            index: 0,
            is_last: true,
            plain_len: 1,
            source_fingerprint: chunk_fingerprint(b"B"),
            sealed: Ok(vec![0; AEAD_TAG_LEN + 1]),
        }];

        assert!(matches!(
            review_parallel_batch(results, 0, &[chunk_fingerprint(b"A")], true, 1),
            Err(OpacError::Metadata)
        ));
    }

    #[test]
    fn final_v2_sequence_review_accepts_custom_chunk_size() {
        let key = crypto::random_key();
        let content = b"abcdefghijkl";
        let mut blob = Vec::new();
        encrypt_chunked(
            &key,
            sample_metadata(content.len() as u64),
            4,
            &mut Cursor::new(content),
            &mut blob,
        )
        .unwrap();

        assert!(verify_v2_chunk_sequence(&key, &mut Cursor::new(blob)).is_ok());
    }

    #[test]
    fn final_v2_sequence_review_accepts_a_valid_parallel_output() {
        let key = crypto::random_key();
        let content = b"abcdefghijkl";
        let mut blob = Vec::new();
        encrypt_v2_auto_with_parallel_progress(
            &key,
            sample_metadata(content.len() as u64),
            &mut Cursor::new(content),
            &mut blob,
            4,
            |_completed, _total| {},
        )
        .unwrap();

        assert!(verify_v2_chunk_sequence(&key, &mut Cursor::new(blob)).is_ok());
    }

    #[test]
    fn final_v2_sequence_review_rejects_ciphertext_under_the_wrong_index() {
        let key = crypto::random_key();
        let content = b"abcdefghijkl";
        let mut blob = Vec::new();
        encrypt_chunked(
            &key,
            sample_metadata(content.len() as u64),
            4,
            &mut Cursor::new(content),
            &mut blob,
        )
        .unwrap();

        let first = first_test_chunk_record_offset(&blob);
        let second = second_test_chunk_record_offset(&blob);
        let first_len = u32::from_le_bytes(blob[first + 5..first + 9].try_into().unwrap()) as usize;
        let second_len =
            u32::from_le_bytes(blob[second + 5..second + 9].try_into().unwrap()) as usize;
        assert_eq!(first_len, second_len);
        let first_payload = blob[first + 9..first + 9 + first_len].to_vec();
        let second_payload = blob[second + 9..second + 9 + second_len].to_vec();
        blob[first + 9..first + 9 + first_len].copy_from_slice(&second_payload);
        blob[second + 9..second + 9 + second_len].copy_from_slice(&first_payload);

        assert!(matches!(
            verify_v2_chunk_sequence(&key, &mut Cursor::new(blob)),
            Err(OpacError::Crypto(_))
        ));
    }

    #[test]
    fn final_v2_sequence_review_rejects_swapped_records() {
        let key = crypto::random_key();
        let content = b"abcdefghijkl";
        let mut blob = Vec::new();
        encrypt_chunked(
            &key,
            sample_metadata(content.len() as u64),
            4,
            &mut Cursor::new(content),
            &mut blob,
        )
        .unwrap();

        let first = first_test_chunk_record_offset(&blob);
        let second = second_test_chunk_record_offset(&blob);
        let first_len = u32::from_le_bytes(blob[first + 5..first + 9].try_into().unwrap()) as usize;
        let second_len =
            u32::from_le_bytes(blob[second + 5..second + 9].try_into().unwrap()) as usize;
        let mut rebuilt = blob[..first].to_vec();
        rebuilt.extend_from_slice(&blob[second..second + 9 + second_len]);
        rebuilt.extend_from_slice(&blob[first..first + 9 + first_len]);
        rebuilt.extend_from_slice(&blob[second + 9 + second_len..]);

        assert!(matches!(
            verify_v2_chunk_sequence(&key, &mut Cursor::new(rebuilt)),
            Err(OpacError::Metadata)
        ));
    }

    fn first_test_chunk_record_offset(blob: &[u8]) -> usize {
        let meta_len = u32::from_le_bytes(blob[36..40].try_into().unwrap()) as usize;
        40 + meta_len
    }

    fn second_test_chunk_record_offset(blob: &[u8]) -> usize {
        let first = first_test_chunk_record_offset(blob);
        let sealed_len =
            u32::from_le_bytes(blob[first + 5..first + 9].try_into().unwrap()) as usize;
        first + 9 + sealed_len
    }

    #[test]
    fn files_above_threshold_use_default_chunk_size() {
        let key = crypto::random_key();
        let len = (DEFAULT_CHUNKING_THRESHOLD as usize) + 1;
        let content = vec![0x5Au8; len];
        let blob = encrypt(&key, sample_metadata(len as u64), &content).unwrap();
        let chunk_size = u32::from_le_bytes(blob[32..36].try_into().unwrap());
        assert_eq!(chunk_size, DEFAULT_CHUNK_SIZE as u32);

        let mut out = Vec::new();
        decrypt_chunked(&key, &mut Cursor::new(blob), &mut out).unwrap();
        assert_eq!(out, content);
    }

    #[test]
    fn inconsistent_declared_size_is_rejected_on_encryption() {
        let key = crypto::random_key();
        let result = encrypt(&key, sample_metadata(999), b"abc");
        assert!(matches!(result, Err(OpacError::Metadata)));
    }

    #[test]
    fn roundtrip_multiple_chunks() {
        let key = crypto::random_key();
        let content = b"0123456789ABCDEFG".to_vec();
        let blob = encrypt_to_vec(&key, &content, 4);
        let mut out = Vec::new();
        let metadata = decrypt_chunked(&key, &mut Cursor::new(blob), &mut out).unwrap();
        assert_eq!(out, content);
        assert_eq!(metadata.original_size, content.len() as u64);
    }

    #[test]
    fn chunk_count_for_size_matches_v2_policy() {
        assert_eq!(chunk_count_for_size(0), 1);
        assert_eq!(chunk_count_for_size(DEFAULT_CHUNKING_THRESHOLD), 1);
        assert_eq!(chunk_count_for_size(DEFAULT_CHUNKING_THRESHOLD + 1), 3);
        assert_eq!(chunk_count_for_size((DEFAULT_CHUNK_SIZE as u64) * 3), 3);
    }

    #[test]
    fn encryption_progress_reports_each_chunk() {
        let key = crypto::random_key();
        let content = vec![0x5au8; DEFAULT_CHUNKING_THRESHOLD as usize + 1];
        let metadata = OpacMetadata {
            original_name: "grande.bin".into(),
            original_size: content.len() as u64,
            created_unix: None,
            modified_unix: None,
        };
        let mut blob = Vec::new();
        let mut progress = Vec::new();
        encrypt_v2_auto_with_progress(
            &key,
            metadata,
            &mut Cursor::new(content),
            &mut blob,
            |completed, total| progress.push((completed, total)),
        )
        .unwrap();
        assert_eq!(progress, vec![(1, 3), (2, 3), (3, 3)]);
    }

    #[test]
    fn roundtrip_empty_content() {
        let key = crypto::random_key();
        let blob = encrypt_to_vec(&key, b"", 4);
        let mut out = Vec::new();
        decrypt_chunked(&key, &mut Cursor::new(blob), &mut out).unwrap();
        assert!(out.is_empty());
    }

    #[test]
    fn wrong_key_is_rejected() {
        let key = crypto::random_key();
        let other_key = crypto::random_key();
        let blob = encrypt_to_vec(&key, b"contenido secreto largo", 4);
        let mut out = Vec::new();
        assert!(decrypt_chunked(&other_key, &mut Cursor::new(blob), &mut out).is_err());
    }

    #[test]
    fn truncated_stream_is_rejected() {
        let key = crypto::random_key();
        let blob = encrypt_to_vec(&key, b"contenido secreto largo y con varios chunks", 4);
        let truncated = &blob[..blob.len() / 2];
        let mut out = Vec::new();
        assert!(matches!(
            decrypt_chunked(&key, &mut Cursor::new(truncated.to_vec()), &mut out),
            Err(OpacError::Truncated)
        ));
    }

    #[test]
    fn extension_after_last_chunk_is_rejected() {
        let key = crypto::random_key();
        let mut blob = encrypt_to_vec(&key, b"contenido corto", 4);
        blob.extend_from_slice(b"basura");
        let mut out = Vec::new();
        assert!(decrypt_chunked(&key, &mut Cursor::new(blob), &mut out).is_err());
    }

    #[test]
    fn malformed_chunk_length_is_rejected_before_allocation() {
        let key = crypto::random_key();
        let blob = encrypt_to_vec(&key, b"hola mundo", 4);
        let mut cursor = Cursor::new(blob.clone());
        let mut fixed = vec![0u8; HEADER_LEN_V2];
        cursor.read_exact(&mut fixed).unwrap();
        let mut meta_len = [0u8; 4];
        cursor.read_exact(&mut meta_len).unwrap();
        let ml = u32::from_le_bytes(meta_len) as usize;
        cursor.set_position((HEADER_LEN_V2 + 4 + ml + 1 + 4) as u64);
        let chunk_len_pos = cursor.position() as usize;
        let mut modified = blob;
        modified[chunk_len_pos..chunk_len_pos + 4].copy_from_slice(&(u32::MAX).to_le_bytes());
        let mut out = Vec::new();
        assert!(matches!(
            decrypt_chunked(&key, &mut Cursor::new(modified), &mut out),
            Err(OpacError::Metadata)
        ));
    }

    #[test]
    fn hardened_nonce_is_unique_for_distinct_chunk_indices() {
        let nonce_prefix = [0x11u8; NONCE_PREFIX_LEN];
        let file_id = [0x22u8; FILE_ID_LEN];
        let first = chunk_nonce_hardened(&nonce_prefix, &file_id, 0);
        let second = chunk_nonce_hardened(&nonce_prefix, &file_id, 1);
        let metadata = chunk_nonce_hardened(&nonce_prefix, &file_id, META_CHUNK_INDEX);
        assert_ne!(first, second);
        assert_ne!(first, metadata);
        assert_ne!(second, metadata);
    }

    #[test]
    fn hardened_nonce_uses_a_96_bit_per_file_base() {
        let nonce_prefix_a = [0x11u8; NONCE_PREFIX_LEN];
        let nonce_prefix_b = [0x12u8; NONCE_PREFIX_LEN];
        let file_id = [0x22u8; FILE_ID_LEN];
        let a = chunk_nonce_hardened(&nonce_prefix_a, &file_id, 7);
        let b = chunk_nonce_hardened(&nonce_prefix_b, &file_id, 7);
        assert_ne!(a, b);
        assert_eq!(&a[..8], &nonce_prefix_a);
        assert_eq!(&b[..8], &nonce_prefix_b);

        let mut expected_tail = [0u8; NONCE_LEN - NONCE_PREFIX_LEN];
        expected_tail.copy_from_slice(&file_id[..NONCE_LEN - NONCE_PREFIX_LEN]);
        let index_bytes = 7u32.to_be_bytes();
        for (byte, index_byte) in expected_tail.iter_mut().zip(index_bytes) {
            *byte ^= index_byte;
        }
        assert_eq!(&a[NONCE_PREFIX_LEN..], &expected_tail);
    }

    #[test]
    fn legacy_v2_bincode_metadata_is_still_readable() {
        let key = crypto::random_key();
        let metadata = sample_metadata(3);
        let content = b"abc";
        let file_id = crypto::random_file_id();
        let random_nonce = crypto::random_nonce();
        let mut nonce_prefix = [0u8; NONCE_PREFIX_LEN];
        nonce_prefix.copy_from_slice(&random_nonce[..NONCE_PREFIX_LEN]);
        let header = build_header_v2(0, &file_id, &nonce_prefix, 3);

        let metadata_bytes = legacy_metadata_bytes(&metadata);
        let meta_nonce = chunk_nonce_legacy(&nonce_prefix, META_CHUNK_INDEX);
        let meta_aad = metadata_aad(&header);
        let meta_sealed = crypto::seal(&key, &meta_nonce, &meta_aad, &metadata_bytes).unwrap();

        let nonce = chunk_nonce_legacy(&nonce_prefix, 0);
        let aad = chunk_aad(&header, true, 0);
        let sealed = crypto::seal(&key, &nonce, &aad, content).unwrap();

        let mut blob = header;
        blob.extend_from_slice(&(meta_sealed.len() as u32).to_le_bytes());
        blob.extend_from_slice(&meta_sealed);
        blob.push(1);
        blob.extend_from_slice(&0u32.to_le_bytes());
        blob.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        blob.extend_from_slice(&sealed);

        let mut out = Vec::new();
        let loaded = decrypt_chunked(&key, &mut Cursor::new(blob), &mut out).unwrap();
        assert_eq!(loaded, metadata);
        assert_eq!(out, content);
    }

    #[test]
    fn legacy_v1_roundtrip_is_readable() {
        let key = crypto::random_key();
        let metadata = sample_metadata(5);
        let content = b"abcde";
        let file_id = crypto::random_file_id();
        let nonce = crypto::random_nonce();
        let header = build_header_v1(OPAC_VERSION_LEGACY_V1, 0, &file_id, &nonce);
        let metadata_bytes = legacy_metadata_bytes(&metadata);
        let mut inner = Vec::with_capacity(4 + metadata_bytes.len() + content.len());
        inner.extend_from_slice(&(metadata_bytes.len() as u32).to_le_bytes());
        inner.extend_from_slice(&metadata_bytes);
        inner.extend_from_slice(content);
        let sealed = crypto::seal(&key, &nonce, &header, &inner).unwrap();
        let mut blob = header;
        blob.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        blob.extend_from_slice(&sealed);

        let opened = decrypt(&key, &blob).unwrap();
        assert_eq!(opened.metadata, metadata);
        assert_eq!(opened.content.as_slice(), content);
    }

    #[test]
    fn legacy_v1_with_inconsistent_size_is_rejected() {
        let key = crypto::random_key();
        let mut metadata = sample_metadata(999);
        metadata.original_name = "x.txt".to_string();
        let content = b"abc";
        let file_id = crypto::random_file_id();
        let nonce = crypto::random_nonce();
        let header = build_header_v1(OPAC_VERSION_LEGACY_V1, 0, &file_id, &nonce);
        let metadata_bytes = legacy_metadata_bytes(&metadata);
        let mut inner = Vec::new();
        inner.extend_from_slice(&(metadata_bytes.len() as u32).to_le_bytes());
        inner.extend_from_slice(&metadata_bytes);
        inner.extend_from_slice(content);
        let sealed = crypto::seal(&key, &nonce, &header, &inner).unwrap();
        let mut blob = header;
        blob.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        blob.extend_from_slice(&sealed);
        assert!(matches!(decrypt(&key, &blob), Err(OpacError::Metadata)));
    }
}
