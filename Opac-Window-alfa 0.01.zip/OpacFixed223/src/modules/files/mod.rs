//! Helpers de E/S de archivos en claro (leer del disco / escribir al
//! disco). Deliberadamente simple y sin logica criptografica: el README
//! (seccion 20) exige que "la GUI no debera contener logica criptografica
//! propia", y lo mismo aplica aqui - este modulo solo mueve bytes.
//!
//! El camino genérico `read_plain_file` sigue siendo una API cómoda para
//! operaciones pequeñas en memoria. El flujo de una Caja Fuerte usa
//! `read_metadata_only` + streaming V2 para no cargar archivos grandes.

use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
#[cfg(unix)]
use std::os::unix::fs::OpenOptionsExt;
#[cfg(windows)]
use std::os::windows::fs::OpenOptionsExt;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use crate::modules::opac_format::OpacMetadata;

pub const MAX_IN_MEMORY_PLAIN_FILE_BYTES: u64 = 64 * 1024 * 1024;

/// Lee un archivo del disco junto con los metadatos que necesitamos guardar
/// cifrados (nombre, tamano, fechas), listo para pasarselo a
/// `opac_format::encrypt`.
pub fn read_plain_file(path: &Path) -> io::Result<(OpacMetadata, Vec<u8>)> {
    read_plain_file_bounded(path, MAX_IN_MEMORY_PLAIN_FILE_BYTES)
}

/// Lee un archivo regular en memoria con un limite explicito. El archivo se
/// abre con comprobaciones que rechazan symlinks/reparse points para evitar
/// que una sustitucion concurrente cambie el objeto despues de validarlo.
pub fn read_plain_file_bounded(path: &Path, max_bytes: u64) -> io::Result<(OpacMetadata, Vec<u8>)> {
    let file = open_safe_regular_file(path)?;
    let metadata_fs = file.metadata()?;
    let len = metadata_fs.len();
    if len > max_bytes {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("el archivo supera el limite de {} bytes", max_bytes),
        ));
    }

    let hard_limit = max_bytes.saturating_add(1);
    let mut content = Vec::with_capacity(len as usize);
    file.take(hard_limit).read_to_end(&mut content)?;
    if content.len() as u64 > max_bytes {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("el archivo supera el limite de {} bytes", max_bytes),
        ));
    }

    let original_name = path
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();

    let created_unix = metadata_fs.created().ok().and_then(system_time_to_unix);
    let modified_unix = metadata_fs.modified().ok().and_then(system_time_to_unix);

    let metadata = OpacMetadata {
        original_name,
        original_size: len,
        created_unix,
        modified_unix,
    };

    Ok((metadata, content))
}

/// Escribe contenido ya descifrado en la ubicacion elegida por el usuario
/// (por ejemplo, al exportar un archivo, README seccion 5).
pub fn write_plain_file(path: &Path, content: &[u8]) -> io::Result<()> {
    let parent = path.parent().ok_or_else(|| {
        io::Error::new(
            io::ErrorKind::InvalidInput,
            "el destino no tiene carpeta padre",
        )
    })?;
    ensure_safe_directory(parent)?;
    if fs::symlink_metadata(path).is_ok() {
        return Err(io::Error::new(
            io::ErrorKind::AlreadyExists,
            "el destino ya existe o es un enlace; no se sobrescribe implícitamente",
        ));
    }
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    options.mode(0o600);
    let mut file = options.open(path)?;
    file.write_all(content)?;
    file.sync_all()?;
    Ok(())
}

fn open_safe_regular_file(path: &Path) -> io::Result<File> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || !metadata.is_file() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "la entrada de archivo no es segura",
        ));
    }

    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(windows)]
    options.custom_flags(0x0020_0000); // FILE_FLAG_OPEN_REPARSE_POINT
    let file = options.open(path)?;
    let opened = file.metadata()?;
    if opened.file_type().is_symlink() || !opened.is_file() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "la entrada de archivo abierta no es segura",
        ));
    }
    Ok(file)
}

fn ensure_safe_directory(path: &Path) -> io::Result<()> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "la carpeta padre no es segura",
        ));
    }
    Ok(())
}

/// Igual que [`read_plain_file`] pero SIN leer el contenido: solo consulta
/// los metadatos del sistema de archivos (nombre, tamano, fechas).
///
/// El flujo de una Caja Fuerte usa este metadata para abrir el origen y
/// procesarlo mediante `opac_format::encrypt_chunked` sin cargar el archivo
/// completo en memoria.
pub fn read_metadata_only(path: &Path) -> io::Result<OpacMetadata> {
    let metadata_fs = fs::metadata(path)?;

    let original_name = path
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();

    let created_unix = metadata_fs.created().ok().and_then(system_time_to_unix);
    let modified_unix = metadata_fs.modified().ok().and_then(system_time_to_unix);

    Ok(OpacMetadata {
        original_name,
        original_size: metadata_fs.len(),
        created_unix,
        modified_unix,
    })
}

pub(crate) fn system_time_to_unix_for_core(time: SystemTime) -> Option<u64> {
    time.duration_since(UNIX_EPOCH).ok().map(|d| d.as_secs())
}

fn system_time_to_unix(time: SystemTime) -> Option<u64> {
    system_time_to_unix_for_core(time)
}
