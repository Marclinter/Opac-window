//! Persistencia crash-safe del Key Store local.
//!
//! El archivo principal (`keystore.opks`) nunca se sobrescribe in-place.
//! Cada guardado escribe primero un candidato (`.new`), lo sincroniza y solo
//! despues hace el commit mediante rename. Se conserva temporalmente una
//! copia anterior (`.bak`) para poder recuperar un proceso interrumpido en
//! Windows o Unix.
//!
//! La politica de recuperacion es conservadora:
//! - si el principal es valido, prevalece y los residuos se eliminan;
//! - si el principal falta/no es valido, se prefiere un `.new` valido;
//! - si tampoco existe, se intenta un `.bak` valido.
//!
//! La validez siempre se comprueba criptograficamente con la contraseña o
//! Master Key actuales; no se confia en un archivo candidato solo por su
//! nombre.

use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
#[cfg(unix)]
use std::os::unix::fs::OpenOptionsExt;
#[cfg(windows)]
use std::os::windows::fs::OpenOptionsExt;
use std::path::{Path, PathBuf};

use thiserror::Error;

use crate::modules::master_key::MasterKey;
use crate::modules::vault::{KeyStore, VaultError};

const NEW_SUFFIX: &str = ".new";
const BACKUP_SUFFIX: &str = ".bak";
const MAX_KEYSTORE_FILE_SIZE: u64 = 4 + 2 + 16 + 12 + 4 + 16 * 1024 * 1024;

#[derive(Debug, Error)]
pub enum PersistenceError {
    #[error(transparent)]
    Io(#[from] io::Error),
    #[error(transparent)]
    Vault(#[from] VaultError),
    #[error("el Key Store no tiene un candidato recuperable")]
    NoRecoverableStore,
    #[error("ya existe un Key Store en esa ruta")]
    AlreadyExists,
    #[error("el Key Store ya esta abierto por otra instancia de Opac Window")]
    WriterLocked,
}

/// Acceso persistente al archivo `keystore.opks` de una instalacion local.
#[derive(Debug, Clone)]
pub struct KeyStoreFile {
    path: PathBuf,
}

impl KeyStoreFile {
    pub fn new(path: impl Into<PathBuf>) -> Self {
        Self { path: path.into() }
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Ruta por defecto de una instalacion local-first.
    pub fn default_path() -> Option<PathBuf> {
        crate::modules::vault_fs::default_vaults_root().map(|root| root.join("keystore.opks"))
    }

    /// Crea y persiste un Key Store nuevo.
    pub fn create_new(
        &self,
        master_password: &[u8],
    ) -> Result<(KeyStore, MasterKey), PersistenceError> {
        let _lock = self.acquire_lock()?;
        self.create_new_unlocked(master_password)
    }

    pub(crate) fn create_new_unlocked(
        &self,
        master_password: &[u8],
    ) -> Result<(KeyStore, MasterKey), PersistenceError> {
        if path_entry_exists(&self.path)? {
            return Err(PersistenceError::AlreadyExists);
        }

        ensure_safe_parent(&self.path)?;

        let (store, master_key) = KeyStore::create_new(master_password)?;
        self.save_unlocked(&store, &master_key)?;
        Ok((store, master_key))
    }

    /// Abre el Key Store y recupera una operacion incompleta si existiera.
    pub fn open(&self, master_password: &[u8]) -> Result<(KeyStore, MasterKey), PersistenceError> {
        let _lock = self.acquire_lock()?;
        self.open_unlocked(master_password)
    }

    /// Comprueba una contrasena contra el Key Store sin adquirir el bloqueo
    /// exclusivo de escritura ni tocar `.new`/`.bak`. Se usa para
    /// reautenticaciones mientras la sesion autenticada ya mantiene el lock.
    pub(crate) fn authenticate_unlocked(
        &self,
        master_password: &[u8],
    ) -> Result<(KeyStore, MasterKey), PersistenceError> {
        load_store_from_path(&self.path, master_password)
    }

    pub(crate) fn open_unlocked(
        &self,
        master_password: &[u8],
    ) -> Result<(KeyStore, MasterKey), PersistenceError> {
        let main_result = load_store_from_path(&self.path, master_password);
        match main_result {
            Ok(value) => {
                self.cleanup_sidecars();
                Ok(value)
            }
            Err(main_error) => {
                let new_result = load_store_from_path(&self.new_path(), master_password);
                if let Ok(value) = new_result {
                    self.replace_main_from(&self.new_path())?;
                    self.cleanup_sidecars();
                    return Ok(value);
                }

                let backup_result = load_store_from_path(&self.backup_path(), master_password);
                if let Ok(value) = backup_result {
                    self.replace_main_from(&self.backup_path())?;
                    self.cleanup_sidecars();
                    return Ok(value);
                }

                // Si no habia ningun archivo principal, distinguimos "falta"
                // de "corrupcion" devolviendo el error original cuando sea
                // posible. Para un archivo ausente, no hay store que abrir.
                if !self.path.exists()
                    && !self.new_path().exists()
                    && !self.backup_path().exists()
                    && let PersistenceError::Io(error) = &main_error
                    && error.kind() == io::ErrorKind::NotFound
                {
                    return Err(PersistenceError::NoRecoverableStore);
                }
                Err(main_error)
            }
        }
    }

    /// Guarda el estado actual mediante una secuencia de reemplazo recuperable.
    ///
    /// Punto de commit: `rename(.new, principal)`. Antes de ese punto, el
    /// principal anterior sigue intacto. Si el proceso muere despues de mover
    /// el principal a `.bak`, el siguiente `open()` podra elegir el `.new`.
    pub fn save(&self, store: &KeyStore, master_key: &MasterKey) -> Result<(), PersistenceError> {
        let _lock = self.acquire_lock()?;
        self.save_unlocked(store, master_key)
    }

    pub(crate) fn save_unlocked(
        &self,
        store: &KeyStore,
        master_key: &MasterKey,
    ) -> Result<(), PersistenceError> {
        ensure_safe_parent(&self.path)?;
        ensure_safe_existing_entry(&self.path)?;
        ensure_safe_existing_entry(&self.new_path())?;
        ensure_safe_existing_entry(&self.backup_path())?;

        // Un sidecar abandonado de un proceso anterior no forma parte de la
        // operacion actual: se reemplaza por el nuevo candidato.
        remove_if_exists(&self.new_path())?;
        remove_if_exists(&self.backup_path())?;

        let bytes = store.to_bytes(master_key)?;
        let mut staged = open_staged_exclusive(&self.new_path())?;
        staged.write_all(&bytes)?;
        staged.sync_all()?;
        drop(staged);

        if self.path.exists() {
            fs::rename(&self.path, self.backup_path())?;
        }

        if let Err(error) = fs::rename(self.new_path(), &self.path) {
            // Dejamos `.new` o `.bak` intactos si algo falla: el proximo
            // arranque puede recuperar un estado consistente.
            return Err(PersistenceError::Io(error));
        }

        sync_parent_dir(&self.path);
        // El commit ya ha terminado: un fallo al limpiar la copia anterior no
        // debe convertir una escritura valida en un error aparente. La copia
        // puede limpiarse en el siguiente arranque.
        let _ = remove_if_exists(&self.backup_path());
        Ok(())
    }

    pub(crate) fn acquire_lock(&self) -> Result<ExclusiveFileLock, PersistenceError> {
        ExclusiveFileLock::acquire(self.path.clone()).map_err(|error| {
            if error.kind() == io::ErrorKind::AlreadyExists {
                PersistenceError::WriterLocked
            } else {
                PersistenceError::Io(error)
            }
        })
    }

    pub(crate) fn rollback_uncommitted_save_unlocked(&self) -> Result<(), PersistenceError> {
        if !self.path.exists() && self.backup_path().exists() {
            remove_if_exists(&self.path)?;
            fs::rename(self.backup_path(), &self.path)?;
            sync_parent_dir(&self.path);
        }
        remove_if_exists(&self.new_path())?;
        remove_if_exists(&self.backup_path())?;
        Ok(())
    }

    /// Elimina un sidecar `.new` o `.bak` abandonado. Es util antes de una
    /// operacion manual de diagnostico y no toca el Key Store principal.
    pub fn cleanup_recovery_files(&self) -> Result<(), PersistenceError> {
        remove_if_exists(&self.new_path())?;
        remove_if_exists(&self.backup_path())?;
        Ok(())
    }

    fn new_path(&self) -> PathBuf {
        sidecar_path(&self.path, NEW_SUFFIX)
    }

    fn backup_path(&self) -> PathBuf {
        sidecar_path(&self.path, BACKUP_SUFFIX)
    }

    fn replace_main_from(&self, source: &Path) -> Result<(), PersistenceError> {
        remove_if_exists(&self.path)?;
        fs::rename(source, &self.path)?;
        sync_parent_dir(&self.path);
        Ok(())
    }

    fn cleanup_sidecars(&self) {
        let _ = remove_if_exists(&self.new_path());
        let _ = remove_if_exists(&self.backup_path());
    }
}

fn load_store_from_path(
    path: &Path,
    master_password: &[u8],
) -> Result<(KeyStore, MasterKey), PersistenceError> {
    ensure_safe_existing_entry(path)?;
    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(windows)]
    options.custom_flags(0x0020_0000);
    let file = options.open(path)?;
    ensure_safe_opened_file(&file)?;
    let len = file.metadata()?.len();
    if len > MAX_KEYSTORE_FILE_SIZE {
        return Err(PersistenceError::Vault(VaultError::Corrupt));
    }
    let hard_limit = MAX_KEYSTORE_FILE_SIZE.saturating_add(1);
    let mut bytes = Vec::with_capacity(len as usize);
    file.take(hard_limit).read_to_end(&mut bytes)?;
    if bytes.len() as u64 > MAX_KEYSTORE_FILE_SIZE {
        return Err(PersistenceError::Vault(VaultError::Corrupt));
    }
    Ok(KeyStore::from_bytes(&bytes, master_password)?)
}

fn ensure_safe_opened_file(file: &File) -> Result<(), io::Error> {
    let metadata = file.metadata()?;
    if metadata.file_type().is_symlink() || is_reparse_point(&metadata) || !metadata.is_file() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "el Key Store se abrio desde una entrada de filesystem no segura",
        ));
    }
    Ok(())
}

fn path_entry_exists(path: &Path) -> Result<bool, io::Error> {
    match fs::symlink_metadata(path) {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(error),
    }
}

fn ensure_safe_existing_entry(path: &Path) -> Result<(), io::Error> {
    let metadata = match fs::symlink_metadata(path) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(()),
        Err(error) => return Err(error),
    };
    if metadata.file_type().is_symlink() || is_reparse_point(&metadata) {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            format!(
                "no se permite un enlace o punto de reanalisis en {}",
                path.display()
            ),
        ));
    }
    Ok(())
}

fn ensure_safe_parent(path: &Path) -> Result<(), io::Error> {
    let parent = path.parent().unwrap_or_else(|| Path::new("."));

    // Solo se crean componentes que no existen. El primer ancestro existente
    // debe ser una carpeta real, no un symlink/reparse point, para no seguir
    // silenciosamente una ruta controlada por otro proceso.
    if let Some(existing) = nearest_existing_ancestor(parent)? {
        let metadata = fs::symlink_metadata(&existing)?;
        if metadata.file_type().is_symlink() || is_reparse_point(&metadata) {
            return Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                format!(
                    "la ruta del Key Store pasa por un enlace o punto de reanalisis: {}",
                    existing.display()
                ),
            ));
        }
        if !metadata.is_dir() {
            return Err(io::Error::new(
                io::ErrorKind::NotADirectory,
                format!(
                    "el padre del Key Store no es una carpeta: {}",
                    existing.display()
                ),
            ));
        }
    }

    fs::create_dir_all(parent)?;
    ensure_safe_existing_directory(parent)
}

fn nearest_existing_ancestor(path: &Path) -> Result<Option<PathBuf>, io::Error> {
    let mut current = Some(path);
    while let Some(candidate) = current {
        match fs::symlink_metadata(candidate) {
            Ok(_) => return Ok(Some(candidate.to_path_buf())),
            Err(error) if error.kind() == io::ErrorKind::NotFound => {
                current = candidate.parent();
            }
            Err(error) => return Err(error),
        }
    }
    Ok(None)
}

fn ensure_safe_existing_directory(path: &Path) -> Result<(), io::Error> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || is_reparse_point(&metadata) {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            format!(
                "la carpeta del Key Store no puede ser un enlace o punto de reanalisis: {}",
                path.display()
            ),
        ));
    }
    if !metadata.is_dir() {
        return Err(io::Error::new(
            io::ErrorKind::NotADirectory,
            format!(
                "la carpeta del Key Store no es un directorio: {}",
                path.display()
            ),
        ));
    }
    Ok(())
}

fn is_reparse_point(metadata: &fs::Metadata) -> bool {
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0400;
        metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0
    }
    #[cfg(not(windows))]
    {
        let _ = metadata;
        false
    }
}

fn sidecar_path(path: &Path, suffix: &str) -> PathBuf {
    let file_name = path
        .file_name()
        .map(|name| name.to_string_lossy().to_string())
        .unwrap_or_else(|| "keystore.opks".to_string());
    path.with_file_name(format!("{file_name}{suffix}"))
}

fn open_staged_exclusive(path: &Path) -> Result<File, io::Error> {
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    options.open(path)
}

fn remove_if_exists(path: &Path) -> Result<(), io::Error> {
    match fs::remove_file(path) {
        Ok(()) => Ok(()),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error),
    }
}

fn sync_parent_dir(path: &Path) {
    #[cfg(unix)]
    {
        if let Some(parent) = path.parent() {
            if let Ok(dir) = File::open(parent) {
                let _ = dir.sync_all();
            }
        }
    }

    #[cfg(not(unix))]
    {
        let _ = path;
    }
}

#[derive(Debug)]
pub(crate) struct ExclusiveFileLock {
    #[cfg(windows)]
    handle: windows_sys::Win32::Foundation::HANDLE,
    #[cfg(unix)]
    file: File,
    #[cfg(all(not(windows), not(unix)))]
    path: PathBuf,
}

impl ExclusiveFileLock {
    pub(crate) fn acquire(resource_path: PathBuf) -> io::Result<Self> {
        let resource_path = normalize_lock_resource_path(resource_path);
        #[cfg(windows)]
        {
            use std::ffi::OsStr;
            use std::os::windows::ffi::OsStrExt;
            use std::ptr::null_mut;
            use windows_sys::Win32::Foundation::{CloseHandle, ERROR_ALREADY_EXISTS, GetLastError};
            use windows_sys::Win32::System::Threading::CreateMutexW;

            let normalized = resource_path.to_string_lossy().to_ascii_lowercase();
            let mut hash = 0xcbf29ce484222325u64;
            for byte in normalized.as_bytes() {
                hash ^= u64::from(*byte);
                hash = hash.wrapping_mul(0x100000001b3);
            }
            let name = format!("Local\\OpacWindow-Writer-{hash:016x}");
            let mut wide: Vec<u16> = OsStr::new(&name).encode_wide().collect();
            wide.push(0);
            let handle = unsafe { CreateMutexW(null_mut(), 1, wide.as_ptr()) };
            if handle.is_null() {
                return Err(io::Error::last_os_error());
            }
            if unsafe { GetLastError() } == ERROR_ALREADY_EXISTS {
                unsafe {
                    CloseHandle(handle);
                }
                return Err(io::Error::new(
                    io::ErrorKind::AlreadyExists,
                    "el recurso ya esta bloqueado por otra instancia",
                ));
            }
            Ok(Self { handle })
        }

        #[cfg(unix)]
        {
            use std::os::fd::AsRawFd;

            let lock_path = resource_path.with_extension(format!(
                "{}lock",
                resource_path
                    .extension()
                    .and_then(|e| e.to_str())
                    .unwrap_or("opks.")
            ));
            let mut options = OpenOptions::new();
            options.read(true).write(true).create(true);
            options.mode(0o600);
            let file = options.open(&lock_path)?;
            const LOCK_EX: i32 = 2;
            const LOCK_NB: i32 = 4;
            unsafe extern "C" {
                fn flock(fd: i32, operation: i32) -> i32;
            }
            let result = unsafe { flock(file.as_raw_fd(), LOCK_EX | LOCK_NB) };
            if result != 0 {
                return Err(io::Error::new(
                    io::ErrorKind::AlreadyExists,
                    "el recurso ya esta bloqueado por otra instancia",
                ));
            }
            Ok(Self { file })
        }

        #[cfg(all(not(windows), not(unix)))]
        {
            let lock_path = resource_path.with_extension(format!(
                "{}lock",
                resource_path
                    .extension()
                    .and_then(|e| e.to_str())
                    .unwrap_or("opks.")
            ));
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&lock_path)?;
            writeln!(file, "{}", std::process::id())?;
            file.sync_all()?;
            Ok(Self { path: lock_path })
        }
    }
}

fn normalize_lock_resource_path(path: PathBuf) -> PathBuf {
    if let Ok(canonical) = fs::canonicalize(&path) {
        return canonical;
    }
    let Some(parent) = path.parent() else {
        return path;
    };
    let normalized_parent = fs::canonicalize(parent).unwrap_or_else(|_| parent.to_path_buf());
    match path.file_name() {
        Some(name) => normalized_parent.join(name),
        None => normalized_parent,
    }
}

impl Drop for ExclusiveFileLock {
    fn drop(&mut self) {
        #[cfg(windows)]
        {
            use windows_sys::Win32::Foundation::CloseHandle;
            use windows_sys::Win32::System::Threading::ReleaseMutex;
            unsafe {
                let _ = ReleaseMutex(self.handle);
                let _ = CloseHandle(self.handle);
            }
        }
        #[cfg(unix)]
        {
            use std::os::fd::AsRawFd;
            const LOCK_UN: i32 = 8;
            unsafe extern "C" {
                fn flock(fd: i32, operation: i32) -> i32;
            }
            let _ = unsafe { flock(self.file.as_raw_fd(), LOCK_UN) };
        }

        #[cfg(all(not(windows), not(unix)))]
        {
            let _ = fs::remove_file(&self.path);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::modules::master_key::Argon2Params;
    use crate::modules::vault::KEYSTORE_VERSION;
    use uuid::Uuid;

    fn fast_params() -> Argon2Params {
        Argon2Params {
            memory_kib: 8 * 1024,
            iterations: 1,
            parallelism: 1,
        }
    }

    fn temp_path() -> PathBuf {
        std::env::temp_dir().join(format!("opac_persist_{}.opks", Uuid::new_v4()))
    }

    fn staged(path: &Path) -> PathBuf {
        sidecar_path(path, NEW_SUFFIX)
    }

    fn backup(path: &Path) -> PathBuf {
        sidecar_path(path, BACKUP_SUFFIX)
    }

    #[test]
    fn second_writer_is_rejected_while_first_is_alive() {
        let path = temp_path();
        let first = KeyStoreFile::new(&path);
        let second = KeyStoreFile::new(&path);
        let _lock = first.acquire_lock().unwrap();
        assert!(matches!(
            second.acquire_lock(),
            Err(PersistenceError::WriterLocked)
        ));
        let _ = fs::remove_file(path);
    }

    #[test]
    fn create_and_open_roundtrip() {
        let path = temp_path();
        let file = KeyStoreFile::new(&path);
        let (mut store, master_key) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        let id = store.create_vault("Personal", "D:/Personal").unwrap();
        file.save(&store, &master_key).unwrap();
        let (opened, _) = file.open(b"pw-test-segura").unwrap();
        assert_eq!(opened.list_vaults().len(), 1);
        assert_eq!(opened.list_vaults()[0].id, id);
        assert!(!staged(&path).exists());
        assert!(!backup(&path).exists());
        let _ = fs::remove_file(path);
    }

    #[test]
    fn recovery_prefers_valid_new_when_main_is_missing() {
        let path = temp_path();
        let file = KeyStoreFile::new(&path);
        let (mut store, master_key) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        store.create_vault("Nueva", "D:/Nueva").unwrap();
        let new_bytes = store.to_bytes(&master_key).unwrap();
        fs::write(staged(&path), &new_bytes).unwrap();

        let (opened, _) = file.open(b"pw-test-segura").unwrap();
        assert_eq!(opened.list_vaults()[0].name, "Nueva");
        assert!(path.exists());
        assert!(!staged(&path).exists());
        let _ = fs::remove_file(path);
    }

    #[test]
    fn recovery_prefers_main_when_new_is_left_before_commit() {
        let path = temp_path();
        let file = KeyStoreFile::new(&path);
        let (mut old_store, old_master) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        old_store.create_vault("Antigua", "D:/Antigua").unwrap();
        file.save(&old_store, &old_master).unwrap();

        let (mut new_store, new_master) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        new_store.create_vault("Nueva", "D:/Nueva").unwrap();
        fs::write(staged(&path), new_store.to_bytes(&new_master).unwrap()).unwrap();

        let (opened, _) = file.open(b"pw-test-segura").unwrap();
        // El principal valido gana: el `.new` representa una operacion que
        // todavia no habia alcanzado el punto de commit.
        assert_eq!(opened.list_vaults()[0].name, "Antigua");
        assert!(!staged(&path).exists());
        let _ = fs::remove_file(path);
    }

    #[test]
    fn recovery_uses_backup_when_main_is_invalid() {
        let path = temp_path();
        let file = KeyStoreFile::new(&path);
        let (mut store, master_key) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        store.create_vault("Valida", "D:/Valida").unwrap();
        file.save(&store, &master_key).unwrap();
        fs::copy(&path, backup(&path)).unwrap();
        fs::write(&path, b"corrupto").unwrap();

        let (opened, _) = file.open(b"pw-test-segura").unwrap();
        assert_eq!(opened.list_vaults()[0].name, "Valida");
        assert!(!backup(&path).exists());
        let _ = fs::remove_file(path);
    }

    #[test]
    fn rollback_restores_backup_after_commit_interruption() {
        let path = temp_path();
        let file = KeyStoreFile::new(&path);
        let (mut store, master_key) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        store.create_vault("Antigua", "D:/Antigua").unwrap();
        file.save(&store, &master_key).unwrap();

        let (mut replacement, replacement_master) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        replacement.create_vault("Nueva", "D:/Nueva").unwrap();
        fs::write(
            staged(&path),
            replacement.to_bytes(&replacement_master).unwrap(),
        )
        .unwrap();
        fs::rename(&path, backup(&path)).unwrap();

        file.rollback_uncommitted_save_unlocked().unwrap();
        let (opened, _) = file.open(b"pw-test-segura").unwrap();
        assert_eq!(opened.list_vaults()[0].name, "Antigua");

        let _ = fs::remove_file(path);
    }

    #[cfg(unix)]
    #[test]
    fn create_new_rejects_keystore_symlink() {
        use std::os::unix::fs::symlink;

        let base = std::env::temp_dir().join(format!("opac_persist_link_{}", Uuid::new_v4()));
        fs::create_dir_all(&base).unwrap();
        let real = base.join("real.opks");
        let link = base.join("keystore.opks");
        fs::write(&real, b"no sustituir").unwrap();
        symlink(&real, &link).unwrap();

        let file = KeyStoreFile::new(&link);
        assert!(matches!(
            file.create_new(b"pw-test-segura"),
            Err(PersistenceError::AlreadyExists)
        ));
        assert_eq!(fs::read(&real).unwrap(), b"no sustituir");
        fs::remove_dir_all(&base).ok();
    }

    #[cfg(unix)]
    #[test]
    fn save_rejects_symlink_parent() {
        use std::os::unix::fs::symlink;

        let base =
            std::env::temp_dir().join(format!("opac_persist_parent_link_{}", Uuid::new_v4()));
        let outside = std::env::temp_dir().join(format!("opac_persist_outside_{}", Uuid::new_v4()));
        fs::create_dir_all(&base).unwrap();
        fs::create_dir_all(&outside).unwrap();
        let link_parent = base.join("store");
        symlink(&outside, &link_parent).unwrap();

        let path = link_parent.join("keystore.opks");
        let file = KeyStoreFile::new(&path);
        let (store, master_key) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        assert!(matches!(
            file.save(&store, &master_key),
            Err(PersistenceError::Io(error)) if error.kind() == io::ErrorKind::PermissionDenied
        ));
        assert!(!outside.join("keystore.opks").exists());

        fs::remove_dir_all(&base).ok();
        fs::remove_dir_all(&outside).ok();
    }

    #[test]
    fn persisted_header_is_current_version() {
        let path = temp_path();
        let file = KeyStoreFile::new(&path);
        let (store, master_key) =
            KeyStore::create_new_with_params(b"pw-test-segura", fast_params()).unwrap();
        file.save(&store, &master_key).unwrap();
        let bytes = fs::read(&path).unwrap();
        assert_eq!(u16::from_le_bytes([bytes[4], bytes[5]]), KEYSTORE_VERSION);
        let _ = fs::remove_file(path);
    }
}
