//! Exportacion protegida de Vault Keys entre dispositivos (README, seccion
//! 18, funcionalidad implementada: "Exportacion protegida de claves").
//!
//! Formato `.opackey`. Igual que en `keystore.opks` (`modules::vault`),
//! solo el salt y los parametros de Argon2id van en claro (SIN cifrar,
//! pero autenticados como AAD): son imprescindibles para poder derivar la
//! clave de exportacion antes incluso de saber si la contrasena de
//! exportacion introducida es correcta. Todo lo demas va dentro del
//! bloque sellado.
//!
//! ```text
//! [4]  magic             b"OPKY"
//! [2]  version (u16 LE)
//! [16] salt              salt de Argon2id para la contrasena de exportacion
//! [4]  argon2 memory_kib (u32 LE)
//! [4]  argon2 iterations (u32 LE)
//! [4]  argon2 parallelism(u32 LE)
//! [12] nonce
//! [4]  sealed_len (u32 LE)
//! [sealed_len] cuerpo sellado (AEAD) = id + nombre + Vault Key (en claro)
//! ```
//!
//! Decision de diseno: la derivacion de la clave de exportacion a partir
//! de la contrasena de exportacion reutiliza `master_key::derive_master_key`
//! en vez de reimplementar Argon2id aqui. Conceptualmente es exactamente
//! la misma operacion (contrasena + salt + parametros -> 256 bits via
//! Argon2id); duplicar ese codigo solo anadiria una segunda ruta que
//! podria divergir con el tiempo sin que nada lo detectara.
//!
//! Sin la contrasena de exportacion Y este archivo `.opackey`, nadie
//! puede recuperar la Vault Key: no existe una puerta trasera (README,
//! seccion 18), igual que en el resto del nucleo.
//!
//! Nota para quien construya la GUI encima: este formato exporta la Vault
//! Key SIN su proteccion por PIN, aunque la Caja Fuerte la tuviera en
//! este dispositivo. Es deliberado - el PIN protege la Vault Key dentro
//! del Key Store de ESTE dispositivo; en el dispositivo de destino, el
//! usuario decide si quiere volver a protegerla con un PIN (posiblemente
//! distinto) despues de importarla.

use serde::{Deserialize, Serialize};
use thiserror::Error;
use uuid::Uuid;
use zeroize::{Zeroize, Zeroizing};

use crate::modules::crypto::{self, CryptoError, KEY_LEN, NONCE_LEN};
use crate::modules::keys::VaultKey;
use crate::modules::master_key::{self, Argon2Params, MasterKeyError, SALT_LEN, derive_master_key};
use crate::modules::serialization;

pub const OPACKEY_MAGIC: &[u8; 4] = b"OPKY";
pub const OPACKEY_VERSION_LEGACY_V1: u16 = 1;
pub const OPACKEY_VERSION: u16 = 2;
const MAX_EXPORT_SEALED_LEN: usize = 64 * 1024;
const MAX_EXPORT_NAME_LEN: usize = 4096;
pub const MIN_EXPORT_PASSWORD_LEN: usize = 12;
pub const MAX_EXPORT_PASSWORD_LEN: usize = 512;

/// Valida la politica de contrasena para nuevos artefactos `.opackey` V2.
/// Los formatos legacy V1 siguen siendo importables para conservar compatibilidad.
pub(crate) fn validate_export_password(export_password: &[u8]) -> Result<(), ExportError> {
    let length = std::str::from_utf8(export_password)
        .map(|text| text.chars().count())
        .unwrap_or(export_password.len());
    if !(MIN_EXPORT_PASSWORD_LEN..=MAX_EXPORT_PASSWORD_LEN).contains(&length) {
        return Err(ExportError::WeakPassword);
    }
    Ok(())
}

#[derive(Debug, Error)]
pub enum ExportError {
    #[error(transparent)]
    Crypto(#[from] CryptoError),
    #[error(transparent)]
    MasterKey(#[from] MasterKeyError),
    #[error("error de serializacion interna")]
    Serialization,
    #[error("la contraseña de exportacion debe tener entre 12 y 512 caracteres")]
    WeakPassword,
}

#[derive(Serialize, Deserialize)]
pub(crate) struct ExportedVaultBody {
    pub(crate) vault_id: Uuid,
    pub(crate) vault_name: String,
    pub(crate) vault_key: [u8; KEY_LEN],
}

impl Drop for ExportedVaultBody {
    fn drop(&mut self) {
        self.vault_key.zeroize();
    }
}

pub(crate) fn build_header(
    version: u16,
    salt: &[u8; SALT_LEN],
    params: &Argon2Params,
    nonce: &[u8; NONCE_LEN],
) -> Vec<u8> {
    let mut header = Vec::with_capacity(4 + 2 + SALT_LEN + 12 + NONCE_LEN);
    header.extend_from_slice(OPACKEY_MAGIC);
    header.extend_from_slice(&version.to_le_bytes());
    header.extend_from_slice(salt);
    header.extend_from_slice(&params.memory_kib.to_le_bytes());
    header.extend_from_slice(&params.iterations.to_le_bytes());
    header.extend_from_slice(&params.parallelism.to_le_bytes());
    header.extend_from_slice(nonce);
    header
}

/// Exporta la Vault Key de una Caja Fuerte (ya en claro, ver nota del
/// modulo sobre el PIN), protegida por una contrasena de exportacion que
/// el usuario elige para este viaje entre dispositivos. Usa los
/// parametros de Argon2id por defecto.
pub fn export_vault_key(
    vault_id: Uuid,
    vault_name: &str,
    vault_key: &VaultKey,
    export_password: &[u8],
) -> Result<Vec<u8>, ExportError> {
    export_vault_key_with_params(
        vault_id,
        vault_name,
        vault_key,
        export_password,
        Argon2Params::default(),
    )
}

/// Igual que [`export_vault_key`], pero permitiendo elegir los parametros
/// de Argon2id (por ejemplo, parametros mas ligeros en los tests).
pub fn export_vault_key_with_params(
    vault_id: Uuid,
    vault_name: &str,
    vault_key: &VaultKey,
    export_password: &[u8],
    params: Argon2Params,
) -> Result<Vec<u8>, ExportError> {
    validate_export_password(export_password)?;
    let salt = master_key::random_salt();
    let export_key = derive_master_key(export_password, &salt, &params)?;
    let nonce = crypto::random_nonce();

    if vault_name.is_empty() || vault_name.len() > MAX_EXPORT_NAME_LEN {
        return Err(ExportError::Serialization);
    }
    let body = ExportedVaultBody {
        vault_id,
        vault_name: vault_name.to_string(),
        vault_key: *vault_key.as_bytes(),
    };
    let body_bytes =
        Zeroizing::new(serialization::encode(&body).map_err(|_| ExportError::Serialization)?);
    if body_bytes.len() > MAX_EXPORT_SEALED_LEN.saturating_sub(16) {
        return Err(ExportError::Serialization);
    }

    let header = build_header(OPACKEY_VERSION, &salt, &params, &nonce);
    let sealed = crypto::seal(export_key.as_bytes(), &nonce, &header, &body_bytes)?;
    if sealed.len() > MAX_EXPORT_SEALED_LEN {
        return Err(ExportError::Serialization);
    }

    let mut out = Vec::with_capacity(header.len() + 4 + sealed.len());
    out.extend_from_slice(&header);
    out.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
    out.extend_from_slice(&sealed);
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::modules::import;

    fn fast_params() -> Argon2Params {
        Argon2Params {
            memory_kib: 8 * 1024,
            iterations: 1,
            parallelism: 1,
        }
    }

    #[test]
    fn unicode_export_password_uses_character_count_for_policy() {
        let password = "🙂".repeat(MAX_EXPORT_PASSWORD_LEN);
        assert!(validate_export_password(password.as_bytes()).is_ok());

        let too_long = "🙂".repeat(MAX_EXPORT_PASSWORD_LEN + 1);
        assert!(matches!(
            validate_export_password(too_long.as_bytes()),
            Err(ExportError::WeakPassword)
        ));
    }

    #[test]
    fn export_then_import_roundtrip() {
        let vault_key = VaultKey::generate();
        let original_bytes = *vault_key.as_bytes();
        let id = Uuid::new_v4();

        let bytes = export_vault_key_with_params(
            id,
            "Personal",
            &vault_key,
            b"frase de exportacion larga",
            fast_params(),
        )
        .unwrap();
        assert_eq!(u16::from_le_bytes([bytes[4], bytes[5]]), OPACKEY_VERSION);

        let imported = import::import_vault_key(&bytes, b"frase de exportacion larga").unwrap();
        assert_eq!(imported.vault_id, id);
        assert_eq!(imported.vault_name, "Personal");
        assert_eq!(imported.vault_key.as_bytes(), &original_bytes);
    }

    #[test]
    fn legacy_v1_export_is_importable() {
        let vault_key = VaultKey::generate();
        let original_bytes = *vault_key.as_bytes();
        let id = Uuid::new_v4();
        let password = b"legacy-password";
        let params = fast_params();
        let salt = master_key::random_salt();
        let export_key = derive_master_key(password, &salt, &params).unwrap();
        let nonce = crypto::random_nonce();

        let mut body = Vec::new();
        body.extend_from_slice(&16u64.to_le_bytes());
        body.extend_from_slice(id.as_bytes());
        body.extend_from_slice(&8u64.to_le_bytes());
        body.extend_from_slice(b"Personal");
        body.extend_from_slice(vault_key.as_bytes());

        let header = build_header(OPACKEY_VERSION_LEGACY_V1, &salt, &params, &nonce);
        let sealed = crypto::seal(export_key.as_bytes(), &nonce, &header, &body).unwrap();

        let mut bytes = header;
        bytes.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&sealed);

        let imported = import::import_vault_key(&bytes, password).unwrap();
        assert_eq!(imported.vault_id, id);
        assert_eq!(imported.vault_name, "Personal");
        assert_eq!(imported.vault_key.as_bytes(), &original_bytes);
    }

    #[test]
    fn weak_export_password_is_rejected() {
        let vault_key = VaultKey::generate();
        assert!(matches!(
            export_vault_key_with_params(
                Uuid::new_v4(),
                "Personal",
                &vault_key,
                b"corta",
                fast_params(),
            ),
            Err(ExportError::WeakPassword)
        ));
    }

    #[test]
    fn wrong_export_password_is_rejected() {
        let vault_key = VaultKey::generate();
        let id = Uuid::new_v4();
        let bytes = export_vault_key_with_params(
            id,
            "Personal",
            &vault_key,
            b"correcta-segura",
            fast_params(),
        )
        .unwrap();

        assert!(import::import_vault_key(&bytes, b"incorrecta-no-coincide").is_err());
    }

    #[test]
    fn tampered_opackey_is_rejected() {
        let vault_key = VaultKey::generate();
        let id = Uuid::new_v4();
        let mut bytes = export_vault_key_with_params(
            id,
            "Personal",
            &vault_key,
            b"correcta-segura",
            fast_params(),
        )
        .unwrap();
        let last = bytes.len() - 1;
        bytes[last] ^= 0xFF;

        assert!(import::import_vault_key(&bytes, b"correcta-segura").is_err());
    }
}
