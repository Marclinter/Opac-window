//! Capa 1: primitivas criptograficas de bajo nivel.
//!
//! Este modulo es intencionadamente "tonto": no sabe nada de bovedas,
//! contrasenas ni PIN. Solo sabe sellar y abrir bytes con ChaCha20-Poly1305,
//! y generar bytes aleatorios seguros (claves, nonces, IDs).
//!
//! Regla del README (seccion 8): "No se implementaran algoritmos
//! criptograficos propios." Todo pasa por la crate `chacha20poly1305`.

use chacha20poly1305::aead::{Aead, Payload, array::Array};
use chacha20poly1305::{ChaCha20Poly1305, KeyInit};
use rand::{TryRng, rngs::SysRng};
use thiserror::Error;

/// Longitud de clave para ChaCha20-Poly1305 (256 bits).
pub const KEY_LEN: usize = 32;

/// Longitud de nonce para ChaCha20-Poly1305 (96 bits).
pub const NONCE_LEN: usize = 12;

/// Longitud usada para identificadores aleatorios de archivo (file_id) en el
/// formato `.opac`. No es un requisito de la primitiva AEAD, es una eleccion
/// de formato (README, seccion 10).
pub const FILE_ID_LEN: usize = 16;

#[derive(Debug, Error, PartialEq, Eq)]
pub enum CryptoError {
    /// La autenticacion AEAD fallo: el ciphertext, el nonce o los datos
    /// asociados (AAD) no coinciden con lo que se sello originalmente.
    ///
    /// Segun el README (secciones 8, 17, 25): si esto ocurre, el archivo o
    /// almacen implicado DEBE rechazarse por completo. Nunca se debe
    /// producir ni devolver un resultado parcialmente descifrado.
    #[error(
        "fallo de autenticacion: los datos han sido modificados o la clave/nonce/AAD no son correctos"
    )]
    AuthenticationFailed,
}

/// Sella (cifra + autentica) `plaintext` con `key`/`nonce`, ligando el
/// resultado a `aad` (datos asociados autenticados pero no cifrados, por
/// ejemplo la cabecera publica de un archivo `.opac`).
///
/// El resultado incluye el tag de autenticacion al final (asi es como
/// funciona la API de la crate `chacha20poly1305`), por lo que en el
/// formato en disco no hace falta guardar el tag por separado.
pub fn seal(
    key: &[u8; KEY_LEN],
    nonce: &[u8; NONCE_LEN],
    aad: &[u8],
    plaintext: &[u8],
) -> Result<Vec<u8>, CryptoError> {
    let key_array = Array(*key);
    let nonce_array = Array(*nonce);
    let cipher = ChaCha20Poly1305::new(&key_array);
    cipher
        .encrypt(
            &nonce_array,
            Payload {
                msg: plaintext,
                aad,
            },
        )
        .map_err(|_| CryptoError::AuthenticationFailed)
}

/// Abre (verifica + descifra) datos previamente sellados con [`seal`].
///
/// Si la autenticacion falla (dato modificado, clave incorrecta, nonce
/// incorrecto o AAD distinto), devuelve `Err(CryptoError::AuthenticationFailed)`
/// y NO produce ningun byte de texto plano parcial.
pub fn open(
    key: &[u8; KEY_LEN],
    nonce: &[u8; NONCE_LEN],
    aad: &[u8],
    sealed: &[u8],
) -> Result<Vec<u8>, CryptoError> {
    let key_array = Array(*key);
    let nonce_array = Array(*nonce);
    let cipher = ChaCha20Poly1305::new(&key_array);
    cipher
        .decrypt(&nonce_array, Payload { msg: sealed, aad })
        .map_err(|_| CryptoError::AuthenticationFailed)
}

/// Genera un nonce aleatorio de 96 bits usando un RNG criptografico del
/// sistema operativo (`OsRng`).
pub fn random_nonce() -> [u8; NONCE_LEN] {
    let mut n = [0u8; NONCE_LEN];
    fill_os_random(&mut n);
    n
}

/// Genera una clave aleatoria de 256 bits usando `OsRng`.
///
/// Se usa tanto para la Vault Key (README, seccion 9) como para cualquier
/// otra clave simetrica que deba generarse al azar (nunca derivarse de una
/// contrasena directamente).
pub fn random_key() -> [u8; KEY_LEN] {
    let mut k = [0u8; KEY_LEN];
    fill_os_random(&mut k);
    k
}

/// Genera un identificador aleatorio de archivo (usado en la cabecera
/// `.opac` como `file_id`, README seccion 10).
pub fn random_file_id() -> [u8; FILE_ID_LEN] {
    let mut id = [0u8; FILE_ID_LEN];
    fill_os_random(&mut id);
    id
}

fn fill_os_random(dst: &mut [u8]) {
    let mut rng = SysRng;
    rng.try_fill_bytes(dst)
        .expect("system secure random source unavailable");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn seal_then_open_roundtrip() {
        let key = random_key();
        let nonce = random_nonce();
        let aad = b"contexto-de-prueba";
        let plaintext = b"hola mundo cifrado";

        let sealed = seal(&key, &nonce, aad, plaintext).unwrap();
        let opened = open(&key, &nonce, aad, &sealed).unwrap();

        assert_eq!(opened, plaintext);
    }

    #[test]
    fn wrong_key_fails_authentication() {
        let key = random_key();
        let other_key = random_key();
        let nonce = random_nonce();
        let aad = b"aad";
        let sealed = seal(&key, &nonce, aad, b"secreto").unwrap();

        assert_eq!(
            open(&other_key, &nonce, aad, &sealed),
            Err(CryptoError::AuthenticationFailed)
        );
    }

    #[test]
    fn tampered_ciphertext_fails_authentication() {
        let key = random_key();
        let nonce = random_nonce();
        let aad = b"aad";
        let mut sealed = seal(&key, &nonce, aad, b"secreto").unwrap();

        let last = sealed.len() - 1;
        sealed[last] ^= 0xFF;

        assert_eq!(
            open(&key, &nonce, aad, &sealed),
            Err(CryptoError::AuthenticationFailed)
        );
    }

    #[test]
    fn tampered_aad_fails_authentication() {
        let key = random_key();
        let nonce = random_nonce();
        let sealed = seal(&key, &nonce, b"aad-original", b"secreto").unwrap();

        assert_eq!(
            open(&key, &nonce, b"aad-modificado", &sealed),
            Err(CryptoError::AuthenticationFailed)
        );
    }

    #[test]
    fn wrong_nonce_fails_authentication() {
        let key = random_key();
        let nonce = random_nonce();
        let other_nonce = random_nonce();
        let aad = b"aad";
        let sealed = seal(&key, &nonce, aad, b"secreto").unwrap();

        assert_eq!(
            open(&key, &other_nonce, aad, &sealed),
            Err(CryptoError::AuthenticationFailed)
        );
    }
}
