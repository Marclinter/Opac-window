//! Perfiles locales de Opac Window.
//!
//! Cada perfil tiene su propio Key Store cifrado con una contraseña distinta.
//! El catálogo global contiene únicamente identificadores y el tipo de almacenamiento;
//! el nombre real del perfil se conserva dentro del Key Store cifrado.
//! Las Cajas siguen protegidas por su propio Key Store y Vault Key.

use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
#[cfg(windows)]
use std::os::windows::fs::OpenOptionsExt;

use crate::modules::persistence::ExclusiveFileLock;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use thiserror::Error;
use uuid::Uuid;

const PROFILE_CATALOG_MAGIC: &[u8; 4] = b"OPPF";
const PROFILE_CATALOG_VERSION_LEGACY_V1: u16 = 1;
const PROFILE_CATALOG_VERSION: u16 = 2;
const PROFILE_CATALOG_MAX_LEN: usize = 1024 * 1024;
const PROFILE_NAME_MAX_LEN: usize = 128;
const CATALOG_SUFFIX_NEW: &str = ".new";

fn guard_storage_exists(profile_id: Uuid) -> bool {
    opac_guard::guard_storage_exists(profile_id)
}

fn legacy_profile_id() -> Uuid {
    Uuid::from_bytes(*b"OPAC-LEGACY-PROF")
}

#[derive(Debug, Error)]
pub enum ProfileError {
    #[error(transparent)]
    Io(#[from] io::Error),
    #[error("el catálogo de perfiles está corrupto o ha sido manipulado")]
    Corrupt,
    #[error("el nombre del perfil no es válido")]
    InvalidName,
    #[error("ya existe un perfil con ese identificador")]
    AlreadyExists,
    #[error("no existe ese perfil")]
    NotFound,
    #[error("no se puede eliminar el perfil mientras OPAC Guard siga activado para ese usuario")]
    GuardActive,
    #[error("el catálogo de perfiles ya está abierto por otra instancia de Opac Window")]
    WriterLocked,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum ProfileStorage {
    Dedicated,
    LegacyDefault,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProfileRecord {
    pub id: Uuid,
    pub name: String,
    pub storage: ProfileStorage,
}

#[derive(Debug, Clone, Default)]
struct ProfileCatalogBody {
    profiles: Vec<ProfileRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct LegacyStoredProfileRecordV1 {
    id: Uuid,
    name: String,
    storage: ProfileStorage,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct LegacyStoredProfileCatalogBodyV1 {
    profiles: Vec<LegacyStoredProfileRecordV1>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct StoredProfileRecordV2 {
    id: Uuid,
    storage: ProfileStorage,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
struct StoredProfileCatalogBodyV2 {
    profiles: Vec<StoredProfileRecordV2>,
}

#[derive(Debug)]
pub struct ProfileCatalog {
    path: PathBuf,
    body: ProfileCatalogBody,
    writer_lock: Option<ExclusiveFileLock>,
}

impl ProfileCatalog {
    pub fn empty(path: PathBuf) -> Self {
        Self {
            path,
            body: ProfileCatalogBody::default(),
            writer_lock: None,
        }
    }

    pub fn default_path() -> Option<PathBuf> {
        crate::modules::vault_fs::default_vaults_root().map(|root| root.join("profiles.oprp"))
    }

    pub fn load_or_create() -> Result<Self, ProfileError> {
        let path = Self::default_path().ok_or_else(|| {
            ProfileError::Io(io::Error::new(
                io::ErrorKind::NotFound,
                "no se pudo determinar la carpeta local de Opac Window",
            ))
        })?;

        let mut bootstrap = Self {
            path: path.clone(),
            body: ProfileCatalogBody::default(),
            writer_lock: None,
        };
        bootstrap.ensure_parent()?;
        let writer_lock = ExclusiveFileLock::acquire(path.clone()).map_err(|error| {
            if error.kind() == io::ErrorKind::AlreadyExists {
                ProfileError::WriterLocked
            } else {
                ProfileError::Io(error)
            }
        })?;

        if path.exists() {
            let mut catalog = Self::load(&path)?;
            catalog.writer_lock = Some(writer_lock);
            catalog.ensure_legacy_profile()?;
            return Ok(catalog);
        }

        bootstrap.writer_lock = Some(writer_lock);
        bootstrap.ensure_legacy_profile()?;
        bootstrap.save()?;
        Ok(bootstrap)
    }

    pub fn list(&self) -> Vec<ProfileRecord> {
        self.body.profiles.clone()
    }

    /// Etiqueta no sensible para el selector. Los nombres reales de perfil
    /// no se muestran mientras el perfil está bloqueado y no se persisten en
    /// el catálogo global.
    pub fn slot_label(&self, id: Uuid) -> Option<String> {
        self.body
            .profiles
            .iter()
            .position(|profile| profile.id == id)
            .map(|index| {
                if matches!(
                    self.body.profiles[index].storage,
                    ProfileStorage::LegacyDefault
                ) {
                    "Usuario original".to_owned()
                } else {
                    format!("Usuario {}", index + 1)
                }
            })
    }

    /// Indica si existe el Key Store legacy en la ubicacion historica.
    /// Se usa unicamente para ofrecer una ruta de recuperacion explicita; no
    /// se toma como sustituto automatico del almacenamiento de un perfil.
    pub fn legacy_default_store_exists(&self) -> bool {
        crate::modules::vault_fs::default_vaults_root()
            .map(|root| path_entry_exists(&root.join("keystore.opks")).unwrap_or(false))
            .unwrap_or(false)
    }

    pub fn dedicated_store_exists(&self, profile: &ProfileRecord) -> Result<bool, ProfileError> {
        if !matches!(profile.storage, ProfileStorage::Dedicated) {
            return Ok(false);
        }
        Ok(path_entry_exists(&self.dedicated_path_for(profile)?)?)
    }

    pub fn path_for(&self, profile: &ProfileRecord) -> Result<PathBuf, ProfileError> {
        match profile.storage {
            ProfileStorage::LegacyDefault => crate::modules::vault_fs::default_vaults_root()
                .map(|root| root.join("keystore.opks"))
                .ok_or_else(|| {
                    ProfileError::Io(io::Error::new(
                        io::ErrorKind::NotFound,
                        "no se pudo determinar el almacenamiento local",
                    ))
                }),
            ProfileStorage::Dedicated => {
                let root = self.profiles_root()?;
                Ok(dedicated_store_path(&root, profile.id))
            }
        }
    }

    pub fn root_for(&self, profile: &ProfileRecord) -> Result<PathBuf, ProfileError> {
        match profile.storage {
            ProfileStorage::Dedicated => self.dedicated_root_for(profile),
            ProfileStorage::LegacyDefault => crate::modules::vault_fs::default_vaults_root()
                .ok_or_else(|| {
                    ProfileError::Io(io::Error::new(
                        io::ErrorKind::NotFound,
                        "no se pudo determinar el almacenamiento local",
                    ))
                }),
        }
    }

    /// Devuelve el almacenamiento fisico que debe usar un perfil ya migrado.
    /// No cambia el registro del catalogo.
    pub fn dedicated_root_for(&self, profile: &ProfileRecord) -> Result<PathBuf, ProfileError> {
        let root = self.profiles_root()?;
        Ok(root.join(profile.id.simple().to_string()))
    }

    pub fn dedicated_path_for(&self, profile: &ProfileRecord) -> Result<PathBuf, ProfileError> {
        Ok(self.dedicated_root_for(profile)?.join("keystore.opks"))
    }

    /// Marca un perfil existente como dedicado despues de que la sesion haya
    /// terminado de mover su almacenamiento con exito.
    pub fn promote_to_dedicated(&mut self, id: Uuid) -> Result<ProfileRecord, ProfileError> {
        {
            let profile = self
                .body
                .profiles
                .iter_mut()
                .find(|profile| profile.id == id)
                .ok_or(ProfileError::NotFound)?;
            profile.storage = ProfileStorage::Dedicated;
        }

        if let Err(error) = self.save() {
            if let Some(profile) = self
                .body
                .profiles
                .iter_mut()
                .find(|profile| profile.id == id)
            {
                profile.storage = ProfileStorage::LegacyDefault;
            }
            return Err(error);
        }

        self.body
            .profiles
            .iter()
            .find(|profile| profile.id == id)
            .cloned()
            .ok_or(ProfileError::NotFound)
    }

    pub fn vaults_root_for(&self, profile: &ProfileRecord) -> Result<PathBuf, ProfileError> {
        let root = self.root_for(profile)?;
        let vaults = match profile.storage {
            ProfileStorage::Dedicated => root.join("vaults"),
            ProfileStorage::LegacyDefault => root.join("vaults"),
        };
        if !vaults.exists() {
            fs::create_dir_all(&vaults)?;
        }
        ensure_safe_directory(&vaults)?;
        crate::modules::vault_fs::set_private_directory_permissions(&vaults)?;
        Ok(vaults)
    }

    pub fn create_dedicated_profile(&mut self, name: &str) -> Result<ProfileRecord, ProfileError> {
        let normalized = normalize_profile_name(name)?;
        let record = ProfileRecord {
            id: Uuid::new_v4(),
            name: normalized,
            storage: ProfileStorage::Dedicated,
        };
        if self.body.profiles.iter().any(|item| item.id == record.id) {
            return Err(ProfileError::AlreadyExists);
        }

        let profile_dir = self.profiles_root()?.join(record.id.simple().to_string());
        ensure_safe_parent(&profile_dir)?;
        fs::create_dir_all(&profile_dir)?;
        ensure_safe_directory(&profile_dir)?;
        crate::modules::vault_fs::set_private_directory_permissions(&profile_dir)?;
        let vaults_dir = profile_dir.join("vaults");
        fs::create_dir_all(&vaults_dir)?;
        ensure_safe_directory(&vaults_dir)?;
        crate::modules::vault_fs::set_private_directory_permissions(&vaults_dir)?;

        self.body.profiles.push(record.clone());
        if let Err(error) = self.save() {
            self.body.profiles.retain(|item| item.id != record.id);
            let _ = fs::remove_dir_all(&profile_dir);
            return Err(error);
        }
        Ok(record)
    }

    /// Reserva el directorio dedicado de un perfil legacy sin tocar aun el
    /// registro del catalogo. Se usa durante la migracion autenticada.
    pub fn prepare_dedicated_storage(
        &self,
        profile: &ProfileRecord,
    ) -> Result<PathBuf, ProfileError> {
        let root = self.dedicated_root_for(profile)?;
        if path_entry_exists(&root)? {
            ensure_safe_directory(&root).map_err(ProfileError::Io)?;
            let keystore = root.join("keystore.opks");
            let vaults = root.join("vaults");
            if path_entry_exists(&keystore)? {
                return Err(ProfileError::AlreadyExists);
            }
            if path_entry_exists(&vaults)? {
                ensure_safe_directory(&vaults).map_err(ProfileError::Io)?;
                if fs::read_dir(&vaults)?.next().is_some() {
                    return Err(ProfileError::AlreadyExists);
                }
            }
            return Ok(root);
        }
        ensure_safe_parent(&root)?;
        fs::create_dir(&root)?;
        ensure_safe_directory(&root)?;
        let vaults = root.join("vaults");
        fs::create_dir(&vaults)?;
        ensure_safe_directory(&vaults)?;
        crate::modules::vault_fs::set_private_directory_permissions(&vaults)?;
        Ok(root)
    }

    pub fn remove_dedicated_storage(&self, profile: &ProfileRecord) -> Result<(), ProfileError> {
        if guard_storage_exists(profile.id) {
            return Err(ProfileError::GuardActive);
        }
        let root = self.dedicated_root_for(profile)?;
        if path_entry_exists(&root)? {
            ensure_safe_directory(&root).map_err(ProfileError::Io)?;
            fs::remove_dir_all(root)?;
        }
        Ok(())
    }

    pub fn remove_profile_record(&mut self, id: Uuid) -> Result<(), ProfileError> {
        if guard_storage_exists(id) {
            return Err(ProfileError::GuardActive);
        }
        let original_len = self.body.profiles.len();
        self.body.profiles.retain(|item| item.id != id);
        if self.body.profiles.len() == original_len {
            return Err(ProfileError::NotFound);
        }
        self.save()
    }

    pub fn save(&self) -> Result<(), ProfileError> {
        self.ensure_parent()?;
        let _transient_lock = if self.writer_lock.is_none() {
            Some(
                ExclusiveFileLock::acquire(self.path.clone()).map_err(|error| {
                    if error.kind() == io::ErrorKind::AlreadyExists {
                        ProfileError::WriterLocked
                    } else {
                        ProfileError::Io(error)
                    }
                })?,
            )
        } else {
            None
        };
        if catalog_path_is_unsafe(&self.path)? {
            return Err(ProfileError::Corrupt);
        }
        let contains_legacy = self
            .body
            .profiles
            .iter()
            .any(|profile| matches!(profile.storage, ProfileStorage::LegacyDefault));
        let (version, payload) = if contains_legacy {
            // Durante una migracion antigua conservamos temporalmente el formato V1
            // para no perder los nombres de los perfiles que aun no han sido
            // autenticados. En cuanto ya no queda ningun perfil legacy, la
            // siguiente escritura pasa a V2 y elimina esos nombres del catalogo.
            let legacy = LegacyStoredProfileCatalogBodyV1 {
                profiles: self
                    .body
                    .profiles
                    .iter()
                    .map(|profile| LegacyStoredProfileRecordV1 {
                        id: profile.id,
                        name: profile.name.clone(),
                        storage: profile.storage.clone(),
                    })
                    .collect(),
            };
            (
                PROFILE_CATALOG_VERSION_LEGACY_V1,
                postcard::to_allocvec(&legacy).map_err(|_| ProfileError::Corrupt)?,
            )
        } else {
            let stored = StoredProfileCatalogBodyV2 {
                profiles: self
                    .body
                    .profiles
                    .iter()
                    .map(|profile| StoredProfileRecordV2 {
                        id: profile.id,
                        storage: profile.storage.clone(),
                    })
                    .collect(),
            };
            (
                PROFILE_CATALOG_VERSION,
                postcard::to_allocvec(&stored).map_err(|_| ProfileError::Corrupt)?,
            )
        };
        if payload.len() > PROFILE_CATALOG_MAX_LEN {
            return Err(ProfileError::Corrupt);
        }

        let mut bytes = Vec::with_capacity(4 + 2 + 4 + payload.len());
        bytes.extend_from_slice(PROFILE_CATALOG_MAGIC);
        bytes.extend_from_slice(&version.to_le_bytes());
        bytes.extend_from_slice(&(payload.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&payload);

        let staged_path = self.path.with_extension(format!(
            "{}{}",
            self.path
                .extension()
                .and_then(|ext| ext.to_str())
                .unwrap_or("oprp"),
            CATALOG_SUFFIX_NEW
        ));
        if path_entry_exists(&staged_path)? {
            remove_if_exists(&staged_path)?;
        }
        let mut options = OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        let mut file = options.open(&staged_path)?;
        file.write_all(&bytes)?;
        file.sync_all()?;
        drop(file);

        ensure_safe_existing_file(&self.path)?;
        let backup_path = self.path.with_extension(format!(
            "{}{}",
            self.path
                .extension()
                .and_then(|ext| ext.to_str())
                .unwrap_or("oprp"),
            ".bak"
        ));
        if path_entry_exists(&backup_path)? {
            remove_if_exists(&backup_path)?;
        }
        if self.path.exists() {
            fs::rename(&self.path, &backup_path)?;
        }
        if let Err(error) = fs::rename(&staged_path, &self.path) {
            if self.path.exists() {
                let _ = fs::remove_file(&self.path);
            }
            if backup_path.exists() {
                let _ = fs::rename(&backup_path, &self.path);
            }
            return Err(ProfileError::Io(error));
        }
        sync_parent_dir(&self.path);
        let _ = remove_if_exists(&backup_path);
        Ok(())
    }

    fn load(path: &Path) -> Result<Self, ProfileError> {
        ensure_safe_existing_file(path)?;
        let mut options = OpenOptions::new();
        options.read(true);
        #[cfg(windows)]
        options.custom_flags(0x0020_0000);
        let file = options.open(path)?;
        ensure_safe_opened_file(&file)?;
        let len = file.metadata()?.len();
        let max_len = (10 + PROFILE_CATALOG_MAX_LEN) as u64;
        if len > max_len {
            return Err(ProfileError::Corrupt);
        }
        let hard_limit = max_len.saturating_add(1);
        let mut bytes = Vec::with_capacity(len as usize);
        file.take(hard_limit).read_to_end(&mut bytes)?;
        if bytes.len() as u64 > max_len {
            return Err(ProfileError::Corrupt);
        }
        if bytes.len() < 10 || &bytes[..4] != PROFILE_CATALOG_MAGIC {
            return Err(ProfileError::Corrupt);
        }
        let version = u16::from_le_bytes([bytes[4], bytes[5]]);
        if version != PROFILE_CATALOG_VERSION_LEGACY_V1 && version != PROFILE_CATALOG_VERSION {
            return Err(ProfileError::Corrupt);
        }
        let payload_len = u32::from_le_bytes([bytes[6], bytes[7], bytes[8], bytes[9]]) as usize;
        if payload_len > PROFILE_CATALOG_MAX_LEN || bytes.len() != 10 + payload_len {
            return Err(ProfileError::Corrupt);
        }
        let body = match version {
            PROFILE_CATALOG_VERSION_LEGACY_V1 => {
                let (legacy, remainder) =
                    postcard::take_from_bytes::<LegacyStoredProfileCatalogBodyV1>(&bytes[10..])
                        .map_err(|_| ProfileError::Corrupt)?;
                if !remainder.is_empty() {
                    return Err(ProfileError::Corrupt);
                }
                ProfileCatalogBody {
                    profiles: legacy
                        .profiles
                        .into_iter()
                        .map(|profile| ProfileRecord {
                            id: profile.id,
                            name: profile.name,
                            storage: profile.storage,
                        })
                        .collect(),
                }
            }
            PROFILE_CATALOG_VERSION => {
                let (stored, remainder) =
                    postcard::take_from_bytes::<StoredProfileCatalogBodyV2>(&bytes[10..])
                        .map_err(|_| ProfileError::Corrupt)?;
                if !remainder.is_empty() {
                    return Err(ProfileError::Corrupt);
                }
                if stored.profiles.len() > 1024 {
                    return Err(ProfileError::Corrupt);
                }
                ProfileCatalogBody {
                    profiles: stored
                        .profiles
                        .into_iter()
                        .map(|profile| ProfileRecord {
                            id: profile.id,
                            name: String::new(),
                            storage: profile.storage,
                        })
                        .collect(),
                }
            }
            _ => return Err(ProfileError::Corrupt),
        };
        validate_body(&body)?;
        Ok(Self {
            path: path.to_path_buf(),
            body,
            writer_lock: None,
        })
    }

    fn ensure_legacy_profile(&mut self) -> Result<(), ProfileError> {
        let Some(default_store) =
            crate::modules::vault_fs::default_vaults_root().map(|root| root.join("keystore.opks"))
        else {
            return Ok(());
        };
        if !default_store.exists() {
            return Ok(());
        }
        let id = legacy_profile_id();
        if self.body.profiles.iter().any(|profile| profile.id == id) {
            return Ok(());
        }
        self.body.profiles.insert(
            0,
            ProfileRecord {
                id,
                name: "Perfil principal".to_owned(),
                storage: ProfileStorage::LegacyDefault,
            },
        );
        Ok(())
    }

    fn profiles_root(&self) -> Result<PathBuf, ProfileError> {
        let root = self
            .path
            .parent()
            .filter(|parent| !parent.as_os_str().is_empty())
            .map(Path::to_path_buf)
            .or_else(crate::modules::vault_fs::default_vaults_root)
            .ok_or_else(|| {
                ProfileError::Io(io::Error::new(
                    io::ErrorKind::NotFound,
                    "no se pudo determinar el almacenamiento local",
                ))
            })?;
        let profiles = root.join("profiles");
        if !profiles.exists() {
            fs::create_dir_all(&profiles)?;
            crate::modules::vault_fs::set_private_directory_permissions(&profiles)?;
        }
        ensure_safe_directory(&profiles)?;
        Ok(profiles)
    }

    fn ensure_parent(&self) -> Result<(), ProfileError> {
        if let Some(parent) = self.path.parent() {
            fs::create_dir_all(parent)?;
            ensure_safe_directory(parent)?;
            crate::modules::vault_fs::set_private_directory_permissions(parent)?;
        }
        Ok(())
    }
}

fn dedicated_store_path(root: &Path, id: Uuid) -> PathBuf {
    root.join(id.simple().to_string()).join("keystore.opks")
}

fn validate_body(body: &ProfileCatalogBody) -> Result<(), ProfileError> {
    if body.profiles.len() > 1024 {
        return Err(ProfileError::Corrupt);
    }
    let mut ids = std::collections::HashSet::new();
    let mut legacy_count = 0usize;
    for profile in &body.profiles {
        if !ids.insert(profile.id) {
            return Err(ProfileError::Corrupt);
        }
        if matches!(profile.storage, ProfileStorage::LegacyDefault) {
            legacy_count += 1;
            if legacy_count > 1 {
                return Err(ProfileError::Corrupt);
            }
        }
        if matches!(profile.storage, ProfileStorage::LegacyDefault)
            && profile.id != legacy_profile_id()
        {
            return Err(ProfileError::Corrupt);
        }
        if profile.name.is_empty() && matches!(profile.storage, ProfileStorage::Dedicated) {
            continue;
        }
        if normalize_profile_name(&profile.name).is_err() {
            return Err(ProfileError::Corrupt);
        }
    }
    Ok(())
}

fn normalize_profile_name(name: &str) -> Result<String, ProfileError> {
    if name.chars().any(|ch| ch.is_control()) {
        return Err(ProfileError::InvalidName);
    }
    let name = name.trim();
    if name.is_empty() || name.len() > PROFILE_NAME_MAX_LEN {
        return Err(ProfileError::InvalidName);
    }
    if name.chars().any(|ch| ch.is_control()) {
        return Err(ProfileError::InvalidName);
    }
    Ok(name.to_owned())
}

fn path_entry_exists(path: &Path) -> Result<bool, io::Error> {
    match fs::symlink_metadata(path) {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(error),
    }
}

fn catalog_path_is_unsafe(path: &Path) -> Result<bool, io::Error> {
    if !path.exists() {
        return Ok(false);
    }
    let metadata = fs::symlink_metadata(path)?;
    Ok(metadata.file_type().is_symlink() || is_reparse_point(&metadata) || !metadata.is_file())
}

fn ensure_safe_directory(path: &Path) -> Result<(), io::Error> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || is_reparse_point(&metadata) || !metadata.is_dir() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "entrada de filesystem no segura",
        ));
    }
    Ok(())
}

fn ensure_safe_file(path: &Path) -> Result<(), io::Error> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || is_reparse_point(&metadata) || !metadata.is_file() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "entrada de filesystem no segura",
        ));
    }
    Ok(())
}

fn ensure_safe_existing_file(path: &Path) -> Result<(), ProfileError> {
    if path.exists() {
        ensure_safe_file(path).map_err(ProfileError::Io)?;
    }
    Ok(())
}

fn ensure_safe_opened_file(file: &File) -> Result<(), ProfileError> {
    let metadata = file.metadata()?;
    if metadata.file_type().is_symlink() || is_reparse_point(&metadata) || !metadata.is_file() {
        return Err(ProfileError::Io(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "entrada de catálogo abierta desde un objeto no seguro",
        )));
    }
    Ok(())
}

fn ensure_safe_parent(path: &Path) -> Result<(), ProfileError> {
    if let Some(parent) = path.parent()
        && parent.exists()
    {
        ensure_safe_directory(parent).map_err(ProfileError::Io)?;
    }
    Ok(())
}

fn is_reparse_point(metadata: &fs::Metadata) -> bool {
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0400;
        metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0
    }
    #[cfg(not(windows))]
    {
        let _ = metadata;
        false
    }
}

fn remove_if_exists(path: &Path) -> Result<(), ProfileError> {
    match fs::remove_file(path) {
        Ok(()) => Ok(()),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(ProfileError::Io(error)),
    }
}

fn sync_parent_dir(path: &Path) {
    if let Some(parent) = path.parent()
        && let Ok(dir) = File::open(parent)
    {
        let _ = dir.sync_all();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn oversized_catalog_is_rejected_before_full_read() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let mut file = std::fs::File::create(&path).unwrap();
        let len = (PROFILE_CATALOG_MAX_LEN + 11) as u32;
        file.write_all(b"OPPF").unwrap();
        file.write_all(&PROFILE_CATALOG_VERSION.to_le_bytes())
            .unwrap();
        file.write_all(&len.to_le_bytes()).unwrap();
        file.write_all(&[0u8; 32]).unwrap();
        file.sync_all().unwrap();
        assert!(matches!(
            ProfileCatalog::load(&path),
            Err(ProfileError::Corrupt)
        ));
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn second_catalog_writer_is_rejected_while_first_is_alive() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let _first_lock = ExclusiveFileLock::acquire(path.clone()).unwrap();
        let second_lock = ExclusiveFileLock::acquire(path.clone());
        assert!(second_lock.is_err());
        drop(_first_lock);
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn creates_distinct_dedicated_profiles() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let mut catalog = ProfileCatalog {
            path,
            body: ProfileCatalogBody::default(),
            writer_lock: None,
        };
        let a = catalog.create_dedicated_profile("Alice").unwrap();
        let b = catalog.create_dedicated_profile("Bob").unwrap();
        assert_ne!(a.id, b.id);
        assert_ne!(a.name, b.name);
        assert_eq!(a.storage, ProfileStorage::Dedicated);
        assert_eq!(b.storage, ProfileStorage::Dedicated);
        assert_eq!(catalog.list().len(), 2);
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn invalid_profile_names_are_rejected() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let mut catalog = ProfileCatalog {
            path: root.join("profiles.oprp"),
            body: ProfileCatalogBody::default(),
            writer_lock: None,
        };
        assert!(matches!(
            catalog.create_dedicated_profile("   "),
            Err(ProfileError::InvalidName)
        ));
        assert!(matches!(
            catalog.create_dedicated_profile("a\n"),
            Err(ProfileError::InvalidName)
        ));
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn catalog_roundtrip_keeps_only_non_sensitive_profile_metadata() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let mut catalog = ProfileCatalog {
            path: path.clone(),
            body: ProfileCatalogBody::default(),
            writer_lock: None,
        };
        catalog.create_dedicated_profile("Usuario").unwrap();
        let loaded = ProfileCatalog::load(&path).unwrap();
        assert_eq!(loaded.list()[0].id, catalog.list()[0].id);
        assert_eq!(loaded.list()[0].storage, ProfileStorage::Dedicated);
        assert!(loaded.list()[0].name.is_empty());
        let raw = std::fs::read(&path).unwrap();
        assert!(!raw.windows("Usuario".len()).any(|w| w == b"Usuario"));
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn new_catalog_does_not_persist_profile_names() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let mut catalog = ProfileCatalog {
            path: path.clone(),
            body: ProfileCatalogBody::default(),
            writer_lock: None,
        };
        catalog
            .create_dedicated_profile("Nombre Super Privado")
            .unwrap();
        let raw = std::fs::read(&path).unwrap();
        assert!(
            !raw.windows("Nombre Super Privado".len())
                .any(|w| w == b"Nombre Super Privado")
        );
        assert_eq!(
            u16::from_le_bytes([raw[4], raw[5]]),
            PROFILE_CATALOG_VERSION
        );
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn legacy_catalog_can_be_read_but_new_saves_strip_names() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let old_body = LegacyStoredProfileCatalogBodyV1 {
            profiles: vec![LegacyStoredProfileRecordV1 {
                id: Uuid::new_v4(),
                name: "Nombre Antiguo Privado".into(),
                storage: ProfileStorage::Dedicated,
            }],
        };
        let payload = postcard::to_allocvec(&old_body).unwrap();
        let mut bytes = Vec::new();
        bytes.extend_from_slice(PROFILE_CATALOG_MAGIC);
        bytes.extend_from_slice(&PROFILE_CATALOG_VERSION_LEGACY_V1.to_le_bytes());
        bytes.extend_from_slice(&(payload.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&payload);
        std::fs::write(&path, bytes).unwrap();

        let catalog = ProfileCatalog::load(&path).unwrap();
        assert_eq!(catalog.list()[0].name, "Nombre Antiguo Privado");
        catalog.save().unwrap();
        let raw = std::fs::read(&path).unwrap();
        assert_eq!(
            u16::from_le_bytes([raw[4], raw[5]]),
            PROFILE_CATALOG_VERSION
        );
        assert!(
            !raw.windows("Nombre Antiguo Privado".len())
                .any(|w| w == b"Nombre Antiguo Privado")
        );
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn guard_active_blocks_profile_record_removal() {
        let error = ProfileError::GuardActive;
        assert_eq!(
            error.to_string(),
            "no se puede eliminar el perfil mientras OPAC Guard siga activado para ese usuario"
        );
    }

    #[test]
    fn profile_catalog_does_not_persist_profile_name_or_password_material() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let catalog = ProfileCatalog {
            path: path.clone(),
            body: ProfileCatalogBody {
                profiles: vec![ProfileRecord {
                    id: Uuid::new_v4(),
                    name: "Usuario Ultra Privado".into(),
                    storage: ProfileStorage::Dedicated,
                }],
            },
            writer_lock: None,
        };
        let password = b"PASSWORD_SENTINEL_PROFILE_93af";
        catalog.save().unwrap();
        let raw = std::fs::read(&path).unwrap();
        assert!(
            !raw.windows("Usuario Ultra Privado".len())
                .any(|w| w == b"Usuario Ultra Privado")
        );
        assert!(!raw.windows(password.len()).any(|w| w == password));
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn dedicated_profile_paths_are_distinct_and_under_managed_root() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let a = ProfileRecord {
            id: Uuid::new_v4(),
            name: "A".into(),
            storage: ProfileStorage::Dedicated,
        };
        let b = ProfileRecord {
            id: Uuid::new_v4(),
            name: "B".into(),
            storage: ProfileStorage::Dedicated,
        };
        let profile_root = root.join("profiles");
        let pa = dedicated_store_path(&profile_root, a.id);
        let pb = dedicated_store_path(&profile_root, b.id);
        assert_ne!(pa, pb);
        assert!(
            pa.file_name()
                .and_then(|name| name.to_str())
                .is_some_and(|name| name == "keystore.opks")
        );
        assert!(
            pb.file_name()
                .and_then(|name| name.to_str())
                .is_some_and(|name| name == "keystore.opks")
        );
        assert_ne!(pa.parent(), pb.parent());
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn dedicated_profile_roots_are_separate_and_have_private_vaults_dir() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let mut catalog = ProfileCatalog {
            path,
            body: ProfileCatalogBody::default(),
            writer_lock: None,
        };
        let a = catalog.create_dedicated_profile("Alice").unwrap();
        let b = catalog.create_dedicated_profile("Bob").unwrap();
        let a_root = catalog.root_for(&a).unwrap();
        let b_root = catalog.root_for(&b).unwrap();
        assert_ne!(a_root, b_root);
        assert!(a_root.join("keystore.opks").ends_with("keystore.opks"));
        assert!(a_root.join("vaults").is_dir());
        assert!(b_root.join("vaults").is_dir());
        assert!(!a_root.join("vaults").starts_with(&b_root));
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn promoting_profile_makes_it_dedicated() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let id = legacy_profile_id();
        let mut catalog = ProfileCatalog {
            path,
            body: ProfileCatalogBody {
                profiles: vec![ProfileRecord {
                    id,
                    name: "Perfil principal".into(),
                    storage: ProfileStorage::LegacyDefault,
                }],
            },
            writer_lock: None,
        };
        let promoted = catalog.promote_to_dedicated(id).unwrap();
        assert_eq!(promoted.storage, ProfileStorage::Dedicated);
        assert!(
            catalog
                .root_for(&promoted)
                .unwrap()
                .starts_with(root.join("profiles"))
        );
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn catalog_rejects_duplicate_profile_ids() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let duplicate = Uuid::new_v4();
        let body = StoredProfileCatalogBodyV2 {
            profiles: vec![
                StoredProfileRecordV2 {
                    id: duplicate,
                    storage: ProfileStorage::Dedicated,
                },
                StoredProfileRecordV2 {
                    id: duplicate,
                    storage: ProfileStorage::Dedicated,
                },
            ],
        };
        let payload = postcard::to_allocvec(&body).unwrap();
        let mut bytes = Vec::new();
        bytes.extend_from_slice(PROFILE_CATALOG_MAGIC);
        bytes.extend_from_slice(&PROFILE_CATALOG_VERSION.to_le_bytes());
        bytes.extend_from_slice(&(payload.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&payload);
        std::fs::write(&path, bytes).unwrap();

        assert!(matches!(
            ProfileCatalog::load(&path),
            Err(ProfileError::Corrupt)
        ));
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn catalog_rejects_legacy_profile_with_control_character_name() {
        let root = tempfile_dir();
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("profiles.oprp");
        let body = LegacyStoredProfileCatalogBodyV1 {
            profiles: vec![LegacyStoredProfileRecordV1 {
                id: Uuid::new_v4(),
                name: "Nombre\nMalicioso".into(),
                storage: ProfileStorage::Dedicated,
            }],
        };
        let payload = postcard::to_allocvec(&body).unwrap();
        let mut bytes = Vec::new();
        bytes.extend_from_slice(PROFILE_CATALOG_MAGIC);
        bytes.extend_from_slice(&PROFILE_CATALOG_VERSION_LEGACY_V1.to_le_bytes());
        bytes.extend_from_slice(&(payload.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&payload);
        std::fs::write(&path, bytes).unwrap();

        assert!(matches!(
            ProfileCatalog::load(&path),
            Err(ProfileError::Corrupt)
        ));
        std::fs::remove_dir_all(root).ok();
    }

    #[test]
    fn legacy_profile_id_is_stable() {
        assert_eq!(legacy_profile_id(), legacy_profile_id());
        assert_eq!(legacy_profile_id().as_bytes().len(), 16);
    }

    fn tempfile_dir() -> PathBuf {
        let mut root = std::env::temp_dir();
        root.push(format!("opac-profile-test-{}", Uuid::new_v4().simple()));
        root
    }
}
