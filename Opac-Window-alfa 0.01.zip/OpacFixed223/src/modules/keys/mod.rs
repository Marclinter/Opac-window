//! Capa 3 (parte 2): la Vault Key de cada Caja Fuerte.
//!
//! Segun el README (seccion 9): cada Caja Fuerte tiene UNA Vault Key de 256
//! bits, generada al azar (nunca derivada de la contrasena). Todos los
//! archivos de esa Caja Fuerte se cifran con la misma Vault Key (cada uno
//! con su propio nonce). Esto permite cambiar la contrasena maestra o el
//! PIN sin tener que volver a cifrar los archivos (seccion 15/16).

use zeroize::Zeroizing;

use crate::modules::crypto::{KEY_LEN, random_key};

/// Clave simetrica de 256 bits propia de una Caja Fuerte.
///
/// No implementa `Clone`/`Copy`/`Debug` a proposito: una Vault Key no
/// deberia duplicarse "por accidente" ni imprimirse en un log.
pub struct VaultKey(pub(crate) Zeroizing<[u8; KEY_LEN]>);

impl VaultKey {
    /// Genera una Vault Key nueva con un generador criptografico seguro.
    pub fn generate() -> Self {
        VaultKey(Zeroizing::new(random_key()))
    }

    /// Reconstruye una Vault Key a partir de bytes ya existentes (por
    /// ejemplo, tras desprotegerla tal y como estaba guardada en el Key
    /// Store). No genera nada nuevo: simplemente envuelve los bytes.
    pub fn from_bytes(bytes: [u8; KEY_LEN]) -> Self {
        VaultKey(Zeroizing::new(bytes))
    }

    pub fn as_bytes(&self) -> &[u8; KEY_LEN] {
        &self.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn two_generated_keys_are_different() {
        let a = VaultKey::generate();
        let b = VaultKey::generate();
        assert_ne!(a.as_bytes(), b.as_bytes());
    }

    #[test]
    fn from_bytes_roundtrip() {
        let original = VaultKey::generate();
        let copy_of_bytes = *original.as_bytes();
        let rebuilt = VaultKey::from_bytes(copy_of_bytes);
        assert_eq!(original.as_bytes(), rebuilt.as_bytes());
    }
}
