//! Protección opcional de la Vault Key mediante un PIN/passcode.
//!
//! En una aplicación local-first no existe un servidor que pueda aplicar
//! rate limiting contra un atacante que copie el Key Store. Por eso el PIN
//! debe tener suficiente entropía por sí mismo y Argon2id se configura con
//! parámetros resistentes a ataques offline. El estado de intentos de la GUI
//! puede añadir fricción durante una sesión, pero no sustituye esta propiedad.

use argon2::{Algorithm, Argon2, Params, Version};
use thiserror::Error;
use zeroize::Zeroizing;

use crate::modules::crypto::{self, CryptoError, KEY_LEN, NONCE_LEN};
use crate::modules::keys::VaultKey;
use crate::modules::master_key::{Argon2Params, MasterKeyError, SALT_LEN, random_salt};

const PIN_WRAP_CONTEXT: &[u8] = b"opac-window:vault-key-pin-wrap:v1";
pub const MIN_PIN_LEN: usize = 8;
pub const MIN_NUMERIC_PIN_LEN: usize = 10;
pub const MAX_PIN_LEN: usize = 128;

#[derive(Debug, Error)]
pub enum PinError {
    #[error(transparent)]
    Crypto(#[from] CryptoError),
    #[error("los parametros de Argon2id para el PIN no son validos")]
    InvalidParams,
    #[error("fallo al derivar la clave del PIN (Argon2id)")]
    DerivationFailed,
    #[error("PIN demasiado corto; use al menos 8 caracteres, o 10 digitos si es solo numerico")]
    WeakPin,
    #[error("los datos de proteccion por PIN estan corruptos")]
    Malformed,
}

pub struct PinProtection {
    pub pin_salt: [u8; SALT_LEN],
    pub nonce: [u8; NONCE_LEN],
    pub wrapped_vault_key: Vec<u8>,
    pub argon2_params: Argon2Params,
}

fn validate_pin(pin: &[u8]) -> Result<(), PinError> {
    let length = std::str::from_utf8(pin)
        .map(|text| text.chars().count())
        .unwrap_or(pin.len());
    if !(MIN_PIN_LEN..=MAX_PIN_LEN).contains(&length) {
        return Err(PinError::WeakPin);
    }
    if pin.iter().all(|b| b.is_ascii_digit()) && length < MIN_NUMERIC_PIN_LEN {
        return Err(PinError::WeakPin);
    }
    Ok(())
}

fn derive_pin_key(
    pin: &[u8],
    salt: &[u8; SALT_LEN],
    params: &Argon2Params,
) -> Result<Zeroizing<[u8; KEY_LEN]>, PinError> {
    validate_pin(pin)?;
    params.validate().map_err(|e| match e {
        MasterKeyError::InvalidParams => PinError::InvalidParams,
        MasterKeyError::DerivationFailed => PinError::DerivationFailed,
        MasterKeyError::WeakPassword => PinError::WeakPin,
    })?;

    let argon_params = Params::new(
        params.memory_kib,
        params.iterations,
        params.parallelism,
        Some(KEY_LEN),
    )
    .map_err(|_| PinError::InvalidParams)?;

    let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, argon_params);
    let mut out = Zeroizing::new([0u8; KEY_LEN]);
    argon2
        .hash_password_into(pin, salt, &mut out[..])
        .map_err(|_| PinError::DerivationFailed)?;
    Ok(out)
}

pub fn protect(
    vault_key: &VaultKey,
    pin: &[u8],
    params: Argon2Params,
) -> Result<PinProtection, PinError> {
    validate_pin(pin)?;
    let pin_salt = random_salt();
    let pin_key = derive_pin_key(pin, &pin_salt, &params)?;
    let nonce = crypto::random_nonce();
    let wrapped_vault_key = crypto::seal(&pin_key, &nonce, PIN_WRAP_CONTEXT, vault_key.as_bytes())?;

    Ok(PinProtection {
        pin_salt,
        nonce,
        wrapped_vault_key,
        argon2_params: params,
    })
}

pub fn unlock(protection: &PinProtection, pin: &[u8]) -> Result<VaultKey, PinError> {
    let pin_key = derive_pin_key(pin, &protection.pin_salt, &protection.argon2_params)?;
    let plain = Zeroizing::new(crypto::open(
        &pin_key,
        &protection.nonce,
        PIN_WRAP_CONTEXT,
        &protection.wrapped_vault_key,
    )?);

    if plain.len() != KEY_LEN {
        return Err(PinError::Malformed);
    }

    let mut key_bytes = [0u8; KEY_LEN];
    key_bytes.copy_from_slice(&plain);
    Ok(VaultKey::from_bytes(key_bytes))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fast_params() -> Argon2Params {
        Argon2Params {
            memory_kib: 8 * 1024,
            iterations: 1,
            parallelism: 1,
        }
    }

    #[test]
    fn unicode_pin_uses_character_count_for_policy() {
        let pin = "🙂".repeat(MIN_PIN_LEN);
        assert!(validate_pin(pin.as_bytes()).is_ok());

        let too_long = "🙂".repeat(MAX_PIN_LEN + 1);
        assert!(matches!(
            validate_pin(too_long.as_bytes()),
            Err(PinError::WeakPin)
        ));
    }

    #[test]
    fn correct_pin_recovers_same_vault_key() {
        let vault_key = VaultKey::generate();
        let original_bytes = *vault_key.as_bytes();
        let protection = protect(&vault_key, b"1234567890", fast_params()).unwrap();
        let recovered = unlock(&protection, b"1234567890").unwrap();
        assert_eq!(recovered.as_bytes(), &original_bytes);
    }

    #[test]
    fn weak_numeric_pin_is_rejected() {
        let vault_key = VaultKey::generate();
        assert!(matches!(
            protect(&vault_key, b"1234", fast_params()),
            Err(PinError::WeakPin)
        ));
    }

    #[test]
    fn incorrect_pin_fails() {
        let vault_key = VaultKey::generate();
        let protection = protect(&vault_key, b"1234567890", fast_params()).unwrap();
        assert!(matches!(
            unlock(&protection, b"0000000000"),
            Err(PinError::Crypto(_))
        ));
    }

    #[test]
    fn changing_pin_does_not_change_vault_key() {
        let vault_key = VaultKey::generate();
        let original_bytes = *vault_key.as_bytes();
        let protection_old = protect(&vault_key, b"1111111111", fast_params()).unwrap();
        let recovered_with_old = unlock(&protection_old, b"1111111111").unwrap();
        let protection_new = protect(&recovered_with_old, b"2222222222", fast_params()).unwrap();
        let recovered_with_new = unlock(&protection_new, b"2222222222").unwrap();
        assert_eq!(recovered_with_new.as_bytes(), &original_bytes);
        assert!(unlock(&protection_new, b"1111111111").is_err());
    }
}
