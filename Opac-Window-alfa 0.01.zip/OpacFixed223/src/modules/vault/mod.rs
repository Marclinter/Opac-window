//! Capa 2: gestion de claves de las Cajas Fuertes (README, seccion 7: "2.
//! Gestion de claves de las Cajas Fuertes"; secciones 9, 13, 15, 16).
//!
//! Este modulo junta las piezas de `master_key`, `keys` y `pin` en un
//! **Key Store**: un unico archivo cifrado y autenticado (`keystore.opks`,
//! seccion 13) que contiene el registro de todas las Cajas Fuertes: su
//! nombre, ubicacion y su Vault Key (en claro o protegida por PIN).
//!
//! Formato en disco de `keystore.opks` (todo menos el salt y los
//! parametros de Argon2id va dentro del bloque sellado):
//!
//! ```text
//! [4]  magic             b"OPKS"
//! [2]  version (u16 LE)
//! [16] salt              salt de Argon2id para la contrasena maestra
//! [4]  argon2 memory_kib (u32 LE)
//! [4]  argon2 iterations (u32 LE)
//! [4]  argon2 parallelism(u32 LE)
//! [12] nonce
//! [4]  sealed_len (u32 LE)
//! [sealed_len] cuerpo sellado (AEAD) con la Master Key
//! ```
//!
//! El salt y los parametros de Argon2id van en claro porque son
//! imprescindibles para poder derivar la Master Key la proxima vez, antes
//! incluso de saber si la contrasena es correcta. Todo lo demas (nombres,
//! ubicaciones, Vault Keys...) va dentro del bloque cifrado.

use serde::{Deserialize, Serialize};
use thiserror::Error;
use uuid::Uuid;
use zeroize::{Zeroize, Zeroizing};

use crate::modules::crypto::{self, CryptoError, NONCE_LEN};
use crate::modules::export::{self, ExportError};
use crate::modules::import::{self, ImportError};
use crate::modules::keys::VaultKey;
use crate::modules::master_key::{
    self, Argon2Params, MasterKey, MasterKeyError, SALT_LEN, derive_master_key,
};
use crate::modules::pin::{self, PinError, PinProtection};
use crate::modules::serialization::{self, legacy_bincode::Reader as LegacyReader};

pub const KEYSTORE_MAGIC: &[u8; 4] = b"OPKS";
pub const KEYSTORE_VERSION_LEGACY_V1: u16 = 1;
pub const KEYSTORE_VERSION_LEGACY_V2: u16 = 2;
pub const KEYSTORE_VERSION_LEGACY_V3: u16 = 3;
pub const KEYSTORE_VERSION: u16 = 4;
const MAX_KEYSTORE_SEALED_LEN: usize = 16 * 1024 * 1024;
const MAX_VAULTS: usize = 4096;
const MAX_NAME_LEN: usize = 4096;
const MAX_LOCATION_LEN: usize = 8192;

#[derive(Serialize, Deserialize)]
struct StoredVaultKey([u8; 32]);

impl Drop for StoredVaultKey {
    fn drop(&mut self) {
        self.0.zeroize();
    }
}

#[derive(Debug, Error)]
pub enum VaultError {
    #[error(transparent)]
    Crypto(#[from] CryptoError),
    #[error(transparent)]
    MasterKey(#[from] MasterKeyError),
    #[error(transparent)]
    Pin(#[from] PinError),
    #[error(transparent)]
    Export(#[from] ExportError),
    #[error(transparent)]
    Import(#[from] ImportError),
    #[error(transparent)]
    VaultFs(#[from] crate::modules::vault_fs::VaultFsError),
    #[error("el Key Store esta corrupto o ha sido manipulado")]
    Corrupt,
    #[error("version de Key Store no soportada: {0}")]
    UnsupportedVersion(u16),
    #[error("no se encontro ninguna Caja Fuerte con ese identificador")]
    NotFound,
    #[error("esta Caja Fuerte requiere un PIN")]
    PinRequired,
    #[error("esta Caja Fuerte no tiene PIN configurado")]
    NoPinConfigured,
    #[error("esta Caja Fuerte ya tiene un PIN configurado")]
    PinAlreadyConfigured,
    #[error("ya existe localmente una Caja Fuerte con ese identificador")]
    AlreadyExists,
    #[error("error de (de)serializacion interna")]
    Serialization,
}

/// Como esta protegida la Vault Key de una entrada del Key Store.
#[derive(Serialize, Deserialize)]
enum StoredKeyProtection {
    /// Protegida unicamente por el cifrado del propio Key Store (Master Key).
    None { vault_key: StoredVaultKey },
    /// Ademas envuelta con una clave derivada de un PIN (README, seccion 14).
    Pin {
        pin_salt: [u8; SALT_LEN],
        nonce: [u8; NONCE_LEN],
        wrapped_vault_key: Vec<u8>,
        argon2_memory_kib: u32,
        argon2_iterations: u32,
        argon2_parallelism: u32,
    },
}

/// Preferencia de acceso a los archivos de una Caja Fuerte.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum VaultAccessMode {
    /// Solo descifra el archivo cuando el usuario lo utiliza.
    #[default]
    OnDemand,
    /// Descifra todos los archivos al abrir la Caja Fuerte y los conserva en
    /// una carpeta temporal de la sesion mientras la Caja siga abierta.
    PreloadAll,
}

/// Un registro de Caja Fuerte tal y como se guarda dentro del Key Store.
#[derive(Serialize, Deserialize)]
struct VaultRecord {
    id: Uuid,
    name: String,
    location: String,
    protection: StoredKeyProtection,
    access_mode: VaultAccessMode,
}

/// Registro de la representacion Postcard V2, anterior a `access_mode`.
#[derive(Serialize, Deserialize)]
struct LegacyPostcardVaultRecord {
    id: Uuid,
    name: String,
    location: String,
    protection: StoredKeyProtection,
}

#[derive(Serialize, Deserialize, Default)]
struct LegacyPostcardKeyStoreBody {
    vaults: Vec<LegacyPostcardVaultRecord>,
}

/// Representacion del Key Store V3 antes de anadir la vinculacion del
/// almacenamiento al perfil. Solo se conserva para lectura de datos existentes.
#[derive(Serialize, Deserialize, Default)]
struct LegacyPostcardKeyStoreBodyV3 {
    vaults: Vec<VaultRecord>,
}

/// Informacion publica (no sensible) de una Caja Fuerte, para mostrar en
/// la GUI sin exponer la Vault Key.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VaultInfo {
    pub id: Uuid,
    pub name: String,
    pub location: String,
    pub has_pin: bool,
    pub access_mode: VaultAccessMode,
}

#[derive(Serialize, Deserialize, Default)]
struct StoredGuardPrivateKey([u8; 32]);

impl Drop for StoredGuardPrivateKey {
    fn drop(&mut self) {
        self.0.zeroize();
    }
}

#[derive(Serialize, Deserialize, Default)]
struct KeyStoreBody {
    vaults: Vec<VaultRecord>,
    /// Identidad criptograficamente vinculada a un perfil dedicado.
    /// `None` se conserva solo para compatibilidad con Key Stores anteriores;
    /// los perfiles nuevos la establecen durante `create_scoped`.
    #[serde(default)]
    profile_id: Option<Uuid>,
    /// Nombre privado del perfil. Vive dentro del Key Store cifrado y nunca
    /// se persiste en el catalogo global de perfiles.
    #[serde(default)]
    profile_name: Option<String>,
    /// Identidad criptografica opcional de OPAC Guard. La clave privada vive
    /// exclusivamente dentro del Key Store cifrado; la publica se replica
    /// en la configuracion administrativa del Guard para autenticar comandos.
    #[serde(default)]
    guard_private_key: Option<StoredGuardPrivateKey>,
    #[serde(default)]
    guard_public_key: Option<[u8; 32]>,
}

/// El Key Store completo, ya cargado y desbloqueado en memoria.
pub struct KeyStore {
    salt: [u8; SALT_LEN],
    argon2_params: Argon2Params,
    body: KeyStoreBody,
}

impl KeyStore {
    /// Vincula este Key Store a un perfil local concreto. La identidad queda
    /// dentro del cuerpo autenticado del Key Store, por lo que un atacante no
    /// puede intercambiar dos Key Stores protegidos con la misma contrasena y
    /// hacer que uno aparezca como si perteneciera al otro perfil.
    pub(crate) fn bind_profile_id(&mut self, profile_id: Uuid) -> Result<(), VaultError> {
        if let Some(existing) = self.body.profile_id {
            if existing != profile_id {
                return Err(VaultError::Corrupt);
            }
            return Ok(());
        }
        self.body.profile_id = Some(profile_id);
        Ok(())
    }

    pub(crate) fn profile_id(&self) -> Option<Uuid> {
        self.body.profile_id
    }

    pub(crate) fn profile_name(&self) -> Option<&str> {
        self.body.profile_name.as_deref()
    }

    pub(crate) fn set_profile_name(&mut self, name: &str) -> Result<(), VaultError> {
        let name = name.trim();
        if name.is_empty() || name.len() > MAX_NAME_LEN || name.chars().any(char::is_control) {
            return Err(VaultError::Serialization);
        }
        self.body.profile_name = Some(name.to_owned());
        Ok(())
    }

    pub(crate) fn guard_identity(&self) -> Option<([u8; 32], [u8; 32])> {
        let private = self.body.guard_private_key.as_ref()?.0;
        let public = self.body.guard_public_key?;
        Some((private, public))
    }

    pub(crate) fn set_guard_identity(
        &mut self,
        private_key: [u8; 32],
        public_key: [u8; 32],
    ) -> Result<(), VaultError> {
        if self.body.guard_private_key.is_some() || self.body.guard_public_key.is_some() {
            return Err(VaultError::AlreadyExists);
        }
        let expected_public = ed25519_dalek::SigningKey::from_bytes(&private_key)
            .verifying_key()
            .to_bytes();
        if expected_public != public_key {
            return Err(VaultError::Corrupt);
        }
        self.body.guard_private_key = Some(StoredGuardPrivateKey(private_key));
        self.body.guard_public_key = Some(public_key);
        Ok(())
    }

    pub(crate) fn clear_guard_identity(&mut self) {
        self.body.guard_private_key = None;
        self.body.guard_public_key = None;
    }

    /// Crea un Key Store nuevo y vacio, protegido con la contrasena
    /// maestra indicada. Devuelve tambien la Master Key ya derivada, lista
    /// para usarse (por ejemplo, para guardar el Key Store con [`KeyStore::to_bytes`]).
    pub fn create_new(master_password: &[u8]) -> Result<(Self, MasterKey), VaultError> {
        Self::create_new_with_params(master_password, Argon2Params::default())
    }

    pub fn create_new_with_params(
        master_password: &[u8],
        argon2_params: Argon2Params,
    ) -> Result<(Self, MasterKey), VaultError> {
        master_key::validate_master_password(master_password)?;
        let salt = master_key::random_salt();
        let master_key = derive_master_key(master_password, &salt, &argon2_params)?;
        let store = KeyStore {
            salt,
            argon2_params,
            body: KeyStoreBody::default(),
        };
        Ok((store, master_key))
    }

    /// Crea una Caja Fuerte nueva (sin PIN) dentro de este Key Store y
    /// devuelve su identificador. Todas las rutas de alta validan ahora los
    /// mismos invariantes para impedir dos registros sobre la misma ubicación.
    pub fn create_vault(&mut self, name: &str, location: &str) -> Result<Uuid, VaultError> {
        validate_vault_registration(name, location)?;
        ensure_unique_vault_location(&self.body.vaults, location)?;

        let vault_key = VaultKey::generate();
        let id = Uuid::new_v4();
        self.body.vaults.push(VaultRecord {
            id,
            name: name.trim().to_owned(),
            location: location.to_owned(),
            protection: StoredKeyProtection::None {
                vault_key: StoredVaultKey(*vault_key.as_bytes()),
            },
            access_mode: VaultAccessMode::default(),
        });
        Ok(id)
    }

    /// Crea una Caja Fuerte nueva reutilizando una Vault Key ya existente.
    /// La ubicacion representa una Caja nueva, inicialmente vacia, por lo que
    /// la misma clave puede utilizarse para crear contenido interoperable en
    /// otro dispositivo sin tocar ningun archivo de otras Cajas.
    pub fn create_vault_with_key(
        &mut self,
        name: &str,
        location: &str,
        vault_key: [u8; 32],
    ) -> Result<Uuid, VaultError> {
        validate_vault_registration(name, location)?;
        ensure_unique_vault_location(&self.body.vaults, location)?;
        let id = Uuid::new_v4();
        self.body.vaults.push(VaultRecord {
            id,
            name: name.trim().to_owned(),
            location: location.to_owned(),
            protection: StoredKeyProtection::None {
                vault_key: StoredVaultKey(vault_key),
            },
            access_mode: VaultAccessMode::default(),
        });
        Ok(id)
    }

    /// Crea una Caja Fuerte nueva protegida ademas con PIN.
    pub fn create_vault_with_pin(
        &mut self,
        name: &str,
        location: &str,
        pin: &[u8],
    ) -> Result<Uuid, VaultError> {
        self.create_vault_with_pin_with_params(name, location, pin, Argon2Params::default())
    }

    /// Variante con parámetros explícitos para tests/benchmarking y para una
    /// futura calibración por hardware. La aplicación normal debe usar
    /// `create_vault_with_pin`, que toma los parámetros por defecto seguros.
    pub fn create_vault_with_pin_with_params(
        &mut self,
        name: &str,
        location: &str,
        pin: &[u8],
        params: Argon2Params,
    ) -> Result<Uuid, VaultError> {
        validate_vault_registration(name, location)?;
        ensure_unique_vault_location(&self.body.vaults, location)?;
        let vault_key = VaultKey::generate();
        let protection = pin::protect(&vault_key, pin, params)?;
        let id = Uuid::new_v4();
        self.body.vaults.push(VaultRecord {
            id,
            name: name.trim().to_owned(),
            location: location.to_owned(),
            protection: pin_protection_to_stored(protection),
            access_mode: VaultAccessMode::default(),
        });
        Ok(id)
    }

    /// Lista, sin desbloquear nada, la informacion publica de todas las
    /// Cajas Fuertes registradas.
    pub fn list_vaults(&self) -> Vec<VaultInfo> {
        self.body
            .vaults
            .iter()
            .map(|record| VaultInfo {
                id: record.id,
                name: record.name.clone(),
                location: record.location.clone(),
                has_pin: matches!(record.protection, StoredKeyProtection::Pin { .. }),
                access_mode: record.access_mode,
            })
            .collect()
    }

    /// Elimina el registro de una Caja Fuerte del Key Store. El borrado
    /// fisico de su carpeta se coordina desde `KeyStoreSession` para poder
    /// mantener un orden seguro entre metadata y filesystem.
    pub(crate) fn remove_vault(&mut self, id: Uuid) -> Result<(), VaultError> {
        let Some(index) = self.body.vaults.iter().position(|record| record.id == id) else {
            return Err(VaultError::NotFound);
        };
        self.body.vaults.remove(index);
        Ok(())
    }

    /// Actualiza únicamente la ubicación física de una Caja Fuerte.
    /// La Vault Key, su protección y el identificador permanecen intactos.
    pub(crate) fn set_vault_location(
        &mut self,
        id: Uuid,
        location: &str,
    ) -> Result<(), VaultError> {
        if location.trim().is_empty() || location.len() > MAX_LOCATION_LEN {
            return Err(VaultError::Serialization);
        }
        let record = self
            .body
            .vaults
            .iter_mut()
            .find(|record| record.id == id)
            .ok_or(VaultError::NotFound)?;
        record.location = location.to_owned();
        Ok(())
    }

    /// Comprueba una Vault Key contra el registro cuando la Caja no tiene PIN.
    /// Una Caja con PIN se valida mediante la autenticacion previa por PIN y
    /// no expone su Vault Key almacenada en el Key Store.
    pub(crate) fn vault_key_matches(
        &self,
        id: Uuid,
        vault_key: &[u8; 32],
    ) -> Result<bool, VaultError> {
        let record = self
            .body
            .vaults
            .iter()
            .find(|record| record.id == id)
            .ok_or(VaultError::NotFound)?;
        match &record.protection {
            StoredKeyProtection::None { vault_key: stored } => Ok(stored.0 == *vault_key),
            StoredKeyProtection::Pin { .. } => Ok(false),
        }
    }

    /// Recupera la Vault Key de una Caja Fuerte. Si esta protegida con PIN,
    /// `pin` es obligatorio; si no lo esta, se ignora cualquier PIN pasado.
    /// Añade protección por PIN a una Caja Fuerte que todavía no la tiene.
    /// La Vault Key no cambia: únicamente pasa de estar protegida por la
    /// Master Key del Key Store a estar además envuelta con una clave derivada
    /// del PIN. Los archivos `.opac` permanecen intactos.
    pub fn add_pin(&mut self, id: Uuid, pin: &[u8]) -> Result<(), VaultError> {
        let index = self
            .body
            .vaults
            .iter()
            .position(|record| record.id == id)
            .ok_or(VaultError::NotFound)?;

        let current = &self.body.vaults[index].protection;
        let vault_key = match current {
            StoredKeyProtection::None { vault_key } => VaultKey::from_bytes(vault_key.0),
            StoredKeyProtection::Pin { .. } => return Err(VaultError::PinAlreadyConfigured),
        };

        let protection = pin::protect(&vault_key, pin, Argon2Params::default())?;
        self.body.vaults[index].protection = pin_protection_to_stored(protection);
        Ok(())
    }

    pub fn unlock_vault(&self, id: Uuid, pin: Option<&[u8]>) -> Result<VaultKey, VaultError> {
        let record = self
            .body
            .vaults
            .iter()
            .find(|record| record.id == id)
            .ok_or(VaultError::NotFound)?;

        match &record.protection {
            StoredKeyProtection::None { vault_key } => Ok(VaultKey::from_bytes(vault_key.0)),
            StoredKeyProtection::Pin { .. } => {
                let pin = pin.ok_or(VaultError::PinRequired)?;
                let protection = stored_to_pin_protection(&record.protection)
                    .expect("la variante ya se comprobo arriba");
                Ok(pin::unlock(&protection, pin)?)
            }
        }
    }

    /// Cambia el PIN de una Caja Fuerte ya protegida por PIN. Requiere el
    /// PIN antiguo. Los archivos `.opac` de esa Caja Fuerte no se tocan
    /// (README, seccion 16): solo se vuelve a envolver la Vault Key.
    pub fn change_pin(
        &mut self,
        id: Uuid,
        old_pin: &[u8],
        new_pin: &[u8],
    ) -> Result<(), VaultError> {
        let index = self
            .body
            .vaults
            .iter()
            .position(|record| record.id == id)
            .ok_or(VaultError::NotFound)?;

        let old_protection = stored_to_pin_protection(&self.body.vaults[index].protection)
            .ok_or(VaultError::NoPinConfigured)?;
        let vault_key = pin::unlock(&old_protection, old_pin)?;

        let new_protection = pin::protect(&vault_key, new_pin, old_protection.argon2_params)?;
        self.body.vaults[index].protection = pin_protection_to_stored(new_protection);
        Ok(())
    }

    /// Cambia y persiste la preferencia de acceso de una Caja Fuerte. La
    /// Vault Key y los archivos `.opac` permanecen intactos.
    pub fn set_vault_access_mode(
        &mut self,
        id: Uuid,
        mode: VaultAccessMode,
    ) -> Result<(), VaultError> {
        let record = self
            .body
            .vaults
            .iter_mut()
            .find(|record| record.id == id)
            .ok_or(VaultError::NotFound)?;
        record.access_mode = mode;
        Ok(())
    }

    /// Cambia la contrasena maestra. Solo re-protege el propio Key Store
    /// (se deriva una nueva Master Key con un salt nuevo); ninguna Vault
    /// Key ni ningun archivo `.opac` se modifica (README, seccion 15).
    pub fn change_master_password(
        &mut self,
        new_password: &[u8],
    ) -> Result<MasterKey, MasterKeyError> {
        master_key::validate_master_password(new_password)?;
        let new_salt = master_key::random_salt();
        let new_master_key = derive_master_key(new_password, &new_salt, &self.argon2_params)?;
        self.salt = new_salt;
        Ok(new_master_key)
    }

    /// Exporta la Vault Key de una Caja Fuerte para llevarla a otro
    /// dispositivo (README, seccion 18, funcionalidad implementada). Si la Caja Fuerte
    /// tiene PIN, hace falta indicarlo para poder recuperar primero la
    /// Vault Key en claro. El `.opackey` resultante NO lleva esa
    /// proteccion por PIN: el dispositivo de destino decide si quiere
    /// volver a protegerla (ver comentario de `modules::export`).
    pub fn export_vault(
        &self,
        id: Uuid,
        pin: Option<&[u8]>,
        export_password: &[u8],
    ) -> Result<Vec<u8>, VaultError> {
        self.export_vault_with_params(id, pin, export_password, Argon2Params::default())
    }

    pub fn export_vault_with_params(
        &self,
        id: Uuid,
        pin: Option<&[u8]>,
        export_password: &[u8],
        params: Argon2Params,
    ) -> Result<Vec<u8>, VaultError> {
        let record = self
            .body
            .vaults
            .iter()
            .find(|record| record.id == id)
            .ok_or(VaultError::NotFound)?;
        let vault_key = self.unlock_vault(id, pin)?;
        let bytes = export::export_vault_key_with_params(
            id,
            &record.name,
            &vault_key,
            export_password,
            params,
        )?;
        Ok(bytes)
    }

    /// Importa una Vault Key exportada desde otro dispositivo y la anade
    /// como una Caja Fuerte mas de este Key Store, sin PIN por defecto
    /// (README, seccion 18: la importacion nunca modifica ninguna Caja
    /// Fuerte ya existente). `location` es la carpeta local (en ESTE
    /// dispositivo) donde vivira esta Caja Fuerte; puede ser distinta a
    /// la que tenia en el dispositivo de origen.
    pub fn import_vault(
        &mut self,
        data: &[u8],
        export_password: &[u8],
        location: &str,
    ) -> Result<Uuid, VaultError> {
        let imported = import::import_vault_key(data, export_password)?;

        validate_vault_registration(&imported.vault_name, location)?;
        if self.body.vaults.iter().any(|r| r.id == imported.vault_id) {
            return Err(VaultError::AlreadyExists);
        }
        ensure_unique_vault_location(&self.body.vaults, location)?;

        self.body.vaults.push(VaultRecord {
            id: imported.vault_id,
            name: imported.vault_name,
            location: location.to_string(),
            protection: StoredKeyProtection::None {
                vault_key: StoredVaultKey(*imported.vault_key.as_bytes()),
            },
            access_mode: VaultAccessMode::default(),
        });
        Ok(imported.vault_id)
    }

    /// Registra una Caja Fuerte ya existente usando su Vault Key portable.
    /// La clave autentica todos los elementos gestionados antes de persistir
    /// el registro local. La Vault Key no se re-cifra ni se modifica.
    pub fn import_vault_with_key(
        &mut self,
        name: &str,
        location: &str,
        vault_key: [u8; 32],
    ) -> Result<Uuid, VaultError> {
        validate_vault_registration(name, location)?;
        let location_path = std::path::Path::new(location);
        crate::modules::vault_fs::validate_vault_access(location_path, &vault_key)
            .map_err(VaultError::from)?;
        ensure_unique_vault_location(&self.body.vaults, location)?;
        let id = Uuid::new_v4();
        self.body.vaults.push(VaultRecord {
            id,
            name: name.trim().to_string(),
            location: location.to_string(),
            protection: StoredKeyProtection::None {
                vault_key: StoredVaultKey(vault_key),
            },
            access_mode: VaultAccessMode::default(),
        });
        Ok(id)
    }

    /// Serializa y sella el Key Store completo, listo para escribirse a
    /// disco como `keystore.opks`.
    pub(crate) fn from_bytes_with_master_key(
        data: &[u8],
        master_key: &MasterKey,
    ) -> Result<Self, VaultError> {
        parse_keystore_bytes_with_key(data, master_key)
    }

    /// Serializa y sella el Key Store completo, listo para escribirse a
    /// disco como `keystore.opks`.
    pub fn to_bytes(&self, master_key: &MasterKey) -> Result<Vec<u8>, VaultError> {
        validate_keystore_body(&self.body)?;
        let plaintext = Zeroizing::new(
            serialization::encode(&self.body).map_err(|_| VaultError::Serialization)?,
        );
        if plaintext.len() > MAX_KEYSTORE_SEALED_LEN.saturating_sub(16) {
            return Err(VaultError::Corrupt);
        }
        let nonce = crypto::random_nonce();
        let header =
            build_keystore_header(KEYSTORE_VERSION, &self.salt, &self.argon2_params, &nonce);

        let sealed = crypto::seal(master_key.as_bytes(), &nonce, &header, &plaintext)?;

        let mut out = Vec::with_capacity(header.len() + 4 + sealed.len());
        out.extend_from_slice(&header);
        out.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        out.extend_from_slice(&sealed);
        Ok(out)
    }

    /// Abre un Key Store previamente serializado con [`KeyStore::to_bytes`],
    /// usando la contrasena maestra.
    pub fn from_bytes(
        data: &[u8],
        master_password: &[u8],
    ) -> Result<(Self, MasterKey), VaultError> {
        let header = parse_keystore_header(data)?;
        let master_key = derive_master_key(master_password, &header.salt, &header.argon2_params)?;
        let header_bytes = build_keystore_header(
            header.version,
            &header.salt,
            &header.argon2_params,
            &header.nonce,
        );
        let sealed = &data[header.sealed_pos..];
        let plaintext = Zeroizing::new(crypto::open(
            master_key.as_bytes(),
            &header.nonce,
            &header_bytes,
            sealed,
        )?);
        let body = decode_keystore_body(header.version, &plaintext)?;
        validate_keystore_body(&body)?;
        Ok((
            KeyStore {
                salt: header.salt,
                argon2_params: header.argon2_params,
                body,
            },
            master_key,
        ))
    }
}

#[derive(Debug, Clone, Copy)]
struct ParsedKeyStoreHeader {
    version: u16,
    salt: [u8; SALT_LEN],
    argon2_params: Argon2Params,
    nonce: [u8; NONCE_LEN],
    sealed_pos: usize,
}

fn parse_keystore_header(data: &[u8]) -> Result<ParsedKeyStoreHeader, VaultError> {
    const FIXED_HEADER_LEN: usize = 4 + 2 + SALT_LEN + 4 + 4 + 4 + NONCE_LEN;
    if data.len() < FIXED_HEADER_LEN + 4 {
        return Err(VaultError::Corrupt);
    }

    let mut pos = 0usize;
    if &data[pos..pos + 4] != KEYSTORE_MAGIC {
        return Err(VaultError::Corrupt);
    }
    pos += 4;

    let version = u16::from_le_bytes([data[pos], data[pos + 1]]);
    pos += 2;
    if version != KEYSTORE_VERSION_LEGACY_V1
        && version != KEYSTORE_VERSION_LEGACY_V2
        && version != KEYSTORE_VERSION_LEGACY_V3
        && version != KEYSTORE_VERSION
    {
        return Err(VaultError::UnsupportedVersion(version));
    }

    let mut salt = [0u8; SALT_LEN];
    salt.copy_from_slice(&data[pos..pos + SALT_LEN]);
    pos += SALT_LEN;

    let memory_kib = u32::from_le_bytes(
        data[pos..pos + 4]
            .try_into()
            .map_err(|_| VaultError::Corrupt)?,
    );
    pos += 4;
    let iterations = u32::from_le_bytes(
        data[pos..pos + 4]
            .try_into()
            .map_err(|_| VaultError::Corrupt)?,
    );
    pos += 4;
    let parallelism = u32::from_le_bytes(
        data[pos..pos + 4]
            .try_into()
            .map_err(|_| VaultError::Corrupt)?,
    );
    pos += 4;
    let argon2_params = Argon2Params {
        memory_kib,
        iterations,
        parallelism,
    };

    let mut nonce = [0u8; NONCE_LEN];
    nonce.copy_from_slice(&data[pos..pos + NONCE_LEN]);
    pos += NONCE_LEN;

    let sealed_len = u32::from_le_bytes(
        data[pos..pos + 4]
            .try_into()
            .map_err(|_| VaultError::Corrupt)?,
    ) as usize;
    pos += 4;
    if !(16..=MAX_KEYSTORE_SEALED_LEN).contains(&sealed_len) {
        return Err(VaultError::Corrupt);
    }
    if sealed_len > data.len().saturating_sub(pos) || pos + sealed_len != data.len() {
        return Err(VaultError::Corrupt);
    }

    Ok(ParsedKeyStoreHeader {
        version,
        salt,
        argon2_params,
        nonce,
        sealed_pos: pos,
    })
}

fn decode_keystore_body(version: u16, plaintext: &[u8]) -> Result<KeyStoreBody, VaultError> {
    if plaintext.len() > MAX_KEYSTORE_SEALED_LEN.saturating_sub(16) {
        return Err(VaultError::Corrupt);
    }
    match version {
        KEYSTORE_VERSION => {
            let (body, remainder) = postcard::take_from_bytes::<KeyStoreBody>(plaintext)
                .map_err(|_| VaultError::Corrupt)?;
            if !remainder.is_empty() {
                return Err(VaultError::Corrupt);
            }
            Ok(body)
        }
        KEYSTORE_VERSION_LEGACY_V3 => {
            let (legacy, remainder) =
                postcard::take_from_bytes::<LegacyPostcardKeyStoreBodyV3>(plaintext)
                    .map_err(|_| VaultError::Corrupt)?;
            if !remainder.is_empty() {
                return Err(VaultError::Corrupt);
            }
            Ok(KeyStoreBody {
                vaults: legacy.vaults,
                profile_id: None,
                profile_name: None,
                ..KeyStoreBody::default()
            })
        }
        KEYSTORE_VERSION_LEGACY_V2 => {
            let (legacy, remainder) =
                postcard::take_from_bytes::<LegacyPostcardKeyStoreBody>(plaintext)
                    .map_err(|_| VaultError::Corrupt)?;
            if !remainder.is_empty() {
                return Err(VaultError::Corrupt);
            }
            Ok(KeyStoreBody {
                vaults: legacy
                    .vaults
                    .into_iter()
                    .map(|record| VaultRecord {
                        id: record.id,
                        name: record.name,
                        location: record.location,
                        protection: record.protection,
                        access_mode: VaultAccessMode::default(),
                    })
                    .collect(),
                profile_id: None,
                profile_name: None,
                ..KeyStoreBody::default()
            })
        }
        KEYSTORE_VERSION_LEGACY_V1 => decode_legacy_keystore_body(plaintext),
        _ => Err(VaultError::UnsupportedVersion(version)),
    }
}

fn parse_keystore_bytes_with_key(
    data: &[u8],
    master_key: &MasterKey,
) -> Result<KeyStore, VaultError> {
    let parsed = parse_keystore_header(data)?;
    let header = build_keystore_header(
        parsed.version,
        &parsed.salt,
        &parsed.argon2_params,
        &parsed.nonce,
    );
    let sealed = &data[parsed.sealed_pos..];
    let plaintext = Zeroizing::new(crypto::open(
        master_key.as_bytes(),
        &parsed.nonce,
        &header,
        sealed,
    )?);
    let body = decode_keystore_body(parsed.version, &plaintext)?;
    validate_keystore_body(&body)?;
    Ok(KeyStore {
        salt: parsed.salt,
        argon2_params: parsed.argon2_params,
        body,
    })
}

fn decode_legacy_keystore_body(data: &[u8]) -> Result<KeyStoreBody, VaultError> {
    let mut reader = LegacyReader::new(data);
    let count = reader
        .sequence_len(MAX_VAULTS)
        .map_err(|_| VaultError::Corrupt)?;
    let mut vaults = Vec::with_capacity(count);

    for _ in 0..count {
        let id = reader.uuid().map_err(|_| VaultError::Corrupt)?;
        let name = reader
            .string(MAX_NAME_LEN)
            .map_err(|_| VaultError::Corrupt)?;
        let location = reader
            .string(MAX_LOCATION_LEN)
            .map_err(|_| VaultError::Corrupt)?;
        let protection = match reader.u32().map_err(|_| VaultError::Corrupt)? {
            0 => StoredKeyProtection::None {
                vault_key: StoredVaultKey(reader.fixed::<32>().map_err(|_| VaultError::Corrupt)?),
            },
            1 => {
                let pin_salt = reader
                    .fixed::<SALT_LEN>()
                    .map_err(|_| VaultError::Corrupt)?;
                let nonce = reader
                    .fixed::<NONCE_LEN>()
                    .map_err(|_| VaultError::Corrupt)?;
                let wrapped_vault_key = reader.bytes(32 + 16).map_err(|_| VaultError::Corrupt)?;
                let argon2_memory_kib = reader.u32().map_err(|_| VaultError::Corrupt)?;
                let argon2_iterations = reader.u32().map_err(|_| VaultError::Corrupt)?;
                let argon2_parallelism = reader.u32().map_err(|_| VaultError::Corrupt)?;
                StoredKeyProtection::Pin {
                    pin_salt,
                    nonce,
                    wrapped_vault_key,
                    argon2_memory_kib,
                    argon2_iterations,
                    argon2_parallelism,
                }
            }
            _ => return Err(VaultError::Corrupt),
        };
        vaults.push(VaultRecord {
            id,
            name,
            location,
            protection,
            access_mode: VaultAccessMode::default(),
        });
    }

    reader.finish().map_err(|_| VaultError::Corrupt)?;
    let body = KeyStoreBody {
        vaults,
        profile_id: None,
        profile_name: None,
        ..KeyStoreBody::default()
    };
    validate_keystore_body(&body)?;
    Ok(body)
}

fn validate_keystore_body(body: &KeyStoreBody) -> Result<(), VaultError> {
    if body.vaults.len() > MAX_VAULTS {
        return Err(VaultError::Corrupt);
    }
    if let Some(profile_name) = &body.profile_name
        && (profile_name.is_empty()
            || profile_name.len() > MAX_NAME_LEN
            || profile_name.chars().any(char::is_control))
    {
        return Err(VaultError::Corrupt);
    }
    let mut ids = std::collections::HashSet::with_capacity(body.vaults.len());
    let mut locations = std::collections::HashSet::with_capacity(body.vaults.len());
    for record in &body.vaults {
        if !ids.insert(record.id) {
            return Err(VaultError::Corrupt);
        }
        if record.name.trim().is_empty()
            || record.name.len() > MAX_NAME_LEN
            || record.name.chars().any(char::is_control)
            || !locations.insert(record.location.as_str())
            || record.location.trim().is_empty()
            || record.location.len() > MAX_LOCATION_LEN
            || record.location.chars().any(char::is_control)
        {
            return Err(VaultError::Corrupt);
        }
        match &record.protection {
            StoredKeyProtection::None { .. } => {}
            StoredKeyProtection::Pin {
                wrapped_vault_key,
                argon2_memory_kib,
                argon2_iterations,
                argon2_parallelism,
                ..
            } => {
                if wrapped_vault_key.len() != 32 + 16 {
                    return Err(VaultError::Corrupt);
                }
                let params = Argon2Params {
                    memory_kib: *argon2_memory_kib,
                    iterations: *argon2_iterations,
                    parallelism: *argon2_parallelism,
                };
                params.validate().map_err(|_| VaultError::Corrupt)?;
            }
        }
    }
    Ok(())
}

fn build_keystore_header(
    version: u16,
    salt: &[u8; SALT_LEN],
    params: &Argon2Params,
    nonce: &[u8; NONCE_LEN],
) -> Vec<u8> {
    let mut header = Vec::with_capacity(4 + 2 + SALT_LEN + 12 + NONCE_LEN);
    header.extend_from_slice(KEYSTORE_MAGIC);
    header.extend_from_slice(&version.to_le_bytes());
    header.extend_from_slice(salt);
    header.extend_from_slice(&params.memory_kib.to_le_bytes());
    header.extend_from_slice(&params.iterations.to_le_bytes());
    header.extend_from_slice(&params.parallelism.to_le_bytes());
    header.extend_from_slice(nonce);
    header
}

fn validate_vault_registration(name: &str, location: &str) -> Result<(), VaultError> {
    if name.trim().is_empty() || name.len() > MAX_NAME_LEN || name.chars().any(char::is_control) {
        return Err(VaultError::Serialization);
    }
    if location.trim().is_empty()
        || location.len() > MAX_LOCATION_LEN
        || location.chars().any(char::is_control)
    {
        return Err(VaultError::Serialization);
    }
    Ok(())
}

fn ensure_unique_vault_location(vaults: &[VaultRecord], location: &str) -> Result<(), VaultError> {
    if vaults.iter().any(|record| record.location == location) {
        return Err(VaultError::AlreadyExists);
    }
    Ok(())
}

fn pin_protection_to_stored(protection: PinProtection) -> StoredKeyProtection {
    StoredKeyProtection::Pin {
        pin_salt: protection.pin_salt,
        nonce: protection.nonce,
        wrapped_vault_key: protection.wrapped_vault_key,
        argon2_memory_kib: protection.argon2_params.memory_kib,
        argon2_iterations: protection.argon2_params.iterations,
        argon2_parallelism: protection.argon2_params.parallelism,
    }
}

fn stored_to_pin_protection(protection: &StoredKeyProtection) -> Option<PinProtection> {
    match protection {
        StoredKeyProtection::Pin {
            pin_salt,
            nonce,
            wrapped_vault_key,
            argon2_memory_kib,
            argon2_iterations,
            argon2_parallelism,
        } => Some(PinProtection {
            pin_salt: *pin_salt,
            nonce: *nonce,
            wrapped_vault_key: wrapped_vault_key.clone(),
            argon2_params: Argon2Params {
                memory_kib: *argon2_memory_kib,
                iterations: *argon2_iterations,
                parallelism: *argon2_parallelism,
            },
        }),
        StoredKeyProtection::None { .. } => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fast_params() -> Argon2Params {
        Argon2Params {
            memory_kib: 8 * 1024,
            iterations: 1,
            parallelism: 1,
        }
    }

    #[test]
    fn create_vault_with_pin_rejects_invalid_metadata_and_duplicate_location() {
        let (mut store, _) =
            KeyStore::create_new_with_params(b"correct horse battery staple", fast_params())
                .unwrap();
        assert!(
            store
                .create_vault_with_pin_with_params("   ", "C:/vault", b"1234567890", fast_params())
                .is_err()
        );
        assert!(
            store
                .create_vault_with_pin_with_params("Caja", "   ", b"1234567890", fast_params())
                .is_err()
        );
        store
            .create_vault_with_pin_with_params("Caja", "C:/vault", b"1234567890", fast_params())
            .unwrap();
        assert!(matches!(
            store.create_vault_with_pin_with_params(
                "Otra",
                "C:/vault",
                b"1234567890",
                fast_params()
            ),
            Err(VaultError::AlreadyExists)
        ));
    }

    #[test]
    fn create_vault_rejects_invalid_metadata_and_duplicate_location() {
        let (mut store, _) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        assert!(store.create_vault("   ", "D:/Privado").is_err());
        assert!(store.create_vault("Personal", "   ").is_err());
        assert!(
            store
                .create_vault("Nombre\nInvalido", "D:/Privado")
                .is_err()
        );
        assert!(store.create_vault("Personal", "D:/Privado").is_ok());
        assert!(matches!(
            store.create_vault("Otra", "D:/Privado"),
            Err(VaultError::AlreadyExists)
        ));
    }

    #[test]
    fn persisted_keystore_rejects_duplicate_vault_locations() {
        let (mut store, master_key) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let first = store.create_vault("Primera", "D:/Privado").unwrap();
        let duplicate = VaultRecord {
            id: Uuid::new_v4(),
            name: "Segunda".into(),
            location: "D:/Privado".into(),
            protection: StoredKeyProtection::None {
                vault_key: StoredVaultKey(*VaultKey::generate().as_bytes()),
            },
            access_mode: VaultAccessMode::default(),
        };
        store.body.vaults.push(duplicate);
        assert!(matches!(
            store.to_bytes(&master_key),
            Err(VaultError::Corrupt)
        ));
        assert_eq!(store.body.vaults[0].id, first);
    }

    #[test]
    fn create_vault_and_unlock_without_pin() {
        let (mut store, _mk) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let id = store.create_vault("Personal", "D:/Privado").unwrap();

        let key = store.unlock_vault(id, None).unwrap();
        assert_eq!(key.as_bytes().len(), 32);
    }

    #[test]
    fn new_vault_defaults_to_on_demand_access() {
        let (mut store, _mk) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let id = store.create_vault("Personal", "D:/Privado").unwrap();
        assert_eq!(
            store.list_vaults()[0].access_mode,
            VaultAccessMode::OnDemand
        );
        store
            .set_vault_access_mode(id, VaultAccessMode::PreloadAll)
            .unwrap();
        assert_eq!(
            store.list_vaults()[0].access_mode,
            VaultAccessMode::PreloadAll
        );
    }

    #[test]
    fn legacy_postcard_v2_defaults_to_on_demand_access() {
        let password = b"contrasena-legacy-postcard";
        let params = fast_params();
        let salt = master_key::random_salt();
        let master_key = derive_master_key(password, &salt, &params).unwrap();
        let id = Uuid::new_v4();
        let body = LegacyPostcardKeyStoreBody {
            vaults: vec![LegacyPostcardVaultRecord {
                id,
                name: "Legacy".into(),
                location: "D:/Legacy".into(),
                protection: StoredKeyProtection::None {
                    vault_key: StoredVaultKey(*VaultKey::generate().as_bytes()),
                },
            }],
        };
        let plaintext = postcard::to_allocvec(&body).unwrap();
        let nonce = crypto::random_nonce();
        let header = build_keystore_header(KEYSTORE_VERSION_LEGACY_V2, &salt, &params, &nonce);
        let sealed = crypto::seal(master_key.as_bytes(), &nonce, &header, &plaintext).unwrap();
        let mut bytes = header;
        bytes.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&sealed);

        let (loaded, _) = KeyStore::from_bytes(&bytes, password).unwrap();
        assert_eq!(
            loaded.list_vaults()[0].access_mode,
            VaultAccessMode::OnDemand
        );
    }

    #[test]
    fn old_vault_key_wire_shape_remains_readable() {
        let password = b"contrasena-legacy";
        let params = fast_params();
        let salt = master_key::random_salt();
        let master_key = derive_master_key(password, &salt, &params).unwrap();
        let vault_key = VaultKey::generate();
        let id = Uuid::new_v4();

        let mut plaintext = Vec::new();
        plaintext.extend_from_slice(&1u64.to_le_bytes());
        plaintext.extend_from_slice(&(16u64).to_le_bytes());
        plaintext.extend_from_slice(id.as_bytes());
        plaintext.extend_from_slice(&(6u64).to_le_bytes());
        plaintext.extend_from_slice(b"Legacy");
        plaintext.extend_from_slice(&(9u64).to_le_bytes());
        plaintext.extend_from_slice(b"D:/Legacy");
        plaintext.extend_from_slice(&0u32.to_le_bytes());
        plaintext.extend_from_slice(vault_key.as_bytes());

        let nonce = crypto::random_nonce();
        let header = build_keystore_header(KEYSTORE_VERSION_LEGACY_V1, &salt, &params, &nonce);
        let sealed = crypto::seal(master_key.as_bytes(), &nonce, &header, &plaintext).unwrap();

        let mut bytes = header;
        bytes.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&sealed);

        let (loaded, _) = KeyStore::from_bytes(&bytes, password).unwrap();
        let recovered = loaded.unlock_vault(id, None).unwrap();
        assert_eq!(recovered.as_bytes(), vault_key.as_bytes());
    }

    #[test]
    fn legacy_pin_vault_is_still_readable() {
        let password = b"contrasena-legacy-pin";
        let params = fast_params();
        let salt = master_key::random_salt();
        let master_key = derive_master_key(password, &salt, &params).unwrap();
        let vault_key = VaultKey::generate();
        let pin = b"1234567890";
        let protection = pin::protect(&vault_key, pin, params).unwrap();
        let id = Uuid::new_v4();

        let mut plaintext = Vec::new();
        plaintext.extend_from_slice(&1u64.to_le_bytes());
        plaintext.extend_from_slice(&16u64.to_le_bytes());
        plaintext.extend_from_slice(id.as_bytes());
        plaintext.extend_from_slice(&3u64.to_le_bytes());
        plaintext.extend_from_slice(b"PIN");
        plaintext.extend_from_slice(&6u64.to_le_bytes());
        plaintext.extend_from_slice(b"D:/PIN");
        plaintext.extend_from_slice(&1u32.to_le_bytes());
        plaintext.extend_from_slice(&protection.pin_salt);
        plaintext.extend_from_slice(&protection.nonce);
        plaintext.extend_from_slice(&(protection.wrapped_vault_key.len() as u64).to_le_bytes());
        plaintext.extend_from_slice(&protection.wrapped_vault_key);
        plaintext.extend_from_slice(&protection.argon2_params.memory_kib.to_le_bytes());
        plaintext.extend_from_slice(&protection.argon2_params.iterations.to_le_bytes());
        plaintext.extend_from_slice(&protection.argon2_params.parallelism.to_le_bytes());

        let nonce = crypto::random_nonce();
        let header = build_keystore_header(KEYSTORE_VERSION_LEGACY_V1, &salt, &params, &nonce);
        let sealed = crypto::seal(master_key.as_bytes(), &nonce, &header, &plaintext).unwrap();

        let mut bytes = header;
        bytes.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&sealed);

        let (loaded, _) = KeyStore::from_bytes(&bytes, password).unwrap();
        let recovered = loaded.unlock_vault(id, Some(pin)).unwrap();
        assert_eq!(recovered.as_bytes(), vault_key.as_bytes());
    }

    #[test]
    fn profile_name_is_encrypted_inside_keystore_and_roundtrips() {
        let (mut store, master) =
            KeyStore::create_new_with_params(b"contrasena-perfil-muy-larga", fast_params())
                .unwrap();
        store
            .set_profile_name("Nombre privado del usuario")
            .unwrap();
        let bytes = store.to_bytes(&master).unwrap();
        assert!(
            !bytes
                .windows("Nombre privado del usuario".len())
                .any(|window| window == b"Nombre privado del usuario")
        );
        let (loaded, _) = KeyStore::from_bytes(&bytes, b"contrasena-perfil-muy-larga").unwrap();
        assert_eq!(loaded.profile_name(), Some("Nombre privado del usuario"));
    }

    #[test]
    fn keystore_roundtrip_to_and_from_bytes() {
        let (mut store, master_key) =
            KeyStore::create_new_with_params(b"contrasena-larga", fast_params()).unwrap();
        let id = store.create_vault("Trabajo", "C:/Trabajo").unwrap();
        let original_key = store.unlock_vault(id, None).unwrap();

        let bytes = store.to_bytes(&master_key).unwrap();
        assert_eq!(u16::from_le_bytes([bytes[4], bytes[5]]), KEYSTORE_VERSION);

        let (loaded_store, _loaded_master_key) =
            KeyStore::from_bytes(&bytes, b"contrasena-larga").unwrap();
        let loaded_key = loaded_store.unlock_vault(id, None).unwrap();

        assert_eq!(original_key.as_bytes(), loaded_key.as_bytes());
    }

    #[test]
    fn legacy_keystore_is_rewritten_as_postcard_v3() {
        let password = b"legacy-migrate";
        let params = fast_params();
        let salt = master_key::random_salt();
        let master_key = derive_master_key(password, &salt, &params).unwrap();
        let vault_key = VaultKey::generate();
        let id = Uuid::new_v4();

        let mut plaintext = Vec::new();
        plaintext.extend_from_slice(&1u64.to_le_bytes());
        // bincode 1.x + serde para Uuid serializa los bytes como una secuencia:
        // longitud u64 seguida de los 16 bytes del UUID.
        plaintext.extend_from_slice(&16u64.to_le_bytes());
        plaintext.extend_from_slice(id.as_bytes());
        plaintext.extend_from_slice(&7u64.to_le_bytes());
        plaintext.extend_from_slice(b"Legacy2");
        plaintext.extend_from_slice(&6u64.to_le_bytes());
        plaintext.extend_from_slice(b"D:/Old");
        plaintext.extend_from_slice(&0u32.to_le_bytes());
        plaintext.extend_from_slice(vault_key.as_bytes());

        let nonce = crypto::random_nonce();
        let header = build_keystore_header(KEYSTORE_VERSION_LEGACY_V1, &salt, &params, &nonce);
        let sealed = crypto::seal(master_key.as_bytes(), &nonce, &header, &plaintext).unwrap();
        let mut bytes = header;
        bytes.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        bytes.extend_from_slice(&sealed);

        let (loaded, loaded_master) = KeyStore::from_bytes(&bytes, password).unwrap();
        assert_eq!(
            loaded.unlock_vault(id, None).unwrap().as_bytes(),
            vault_key.as_bytes()
        );

        let rewritten = loaded.to_bytes(&loaded_master).unwrap();
        assert_eq!(
            u16::from_le_bytes([rewritten[4], rewritten[5]]),
            KEYSTORE_VERSION
        );
        let (reloaded, _) = KeyStore::from_bytes(&rewritten, password).unwrap();
        assert_eq!(
            reloaded.unlock_vault(id, None).unwrap().as_bytes(),
            vault_key.as_bytes()
        );
    }

    #[test]
    fn wrong_master_password_is_rejected() {
        let (store, master_key) =
            KeyStore::create_new_with_params(b"correcta-segura", fast_params()).unwrap();
        let bytes = store.to_bytes(&master_key).unwrap();

        let result = KeyStore::from_bytes(&bytes, b"incorrecta");
        assert!(matches!(
            result,
            Err(VaultError::Crypto(CryptoError::AuthenticationFailed))
        ));
    }

    #[test]
    fn attacker_controlled_argon2_parameters_are_bounded_before_kdf() {
        let (store, master_key) =
            KeyStore::create_new_with_params(b"correcta-segura", fast_params()).unwrap();
        let mut bytes = store.to_bytes(&master_key).unwrap();

        // En el encabezado, memory_kib empieza tras magic + version + salt.
        let memory_pos = 4 + 2 + SALT_LEN;
        bytes[memory_pos..memory_pos + 4].copy_from_slice(&u32::MAX.to_le_bytes());

        assert!(matches!(
            KeyStore::from_bytes(&bytes, b"correcta-segura"),
            Err(VaultError::MasterKey(MasterKeyError::InvalidParams))
        ));
    }

    #[test]
    fn tampered_keystore_is_rejected() {
        let (store, master_key) =
            KeyStore::create_new_with_params(b"correcta-segura", fast_params()).unwrap();
        let mut bytes = store.to_bytes(&master_key).unwrap();
        let last = bytes.len() - 1;
        bytes[last] ^= 0xFF;

        let result = KeyStore::from_bytes(&bytes, b"correcta-segura");
        assert!(matches!(
            result,
            Err(VaultError::Crypto(CryptoError::AuthenticationFailed))
        ));
    }

    #[test]
    fn vault_with_pin_requires_pin() {
        let (mut store, _mk) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let id = store
            .create_vault_with_pin_with_params(
                "Personal",
                "D:/Privado",
                b"4321432143",
                fast_params(),
            )
            .unwrap();

        assert!(matches!(
            store.unlock_vault(id, None),
            Err(VaultError::PinRequired)
        ));
        assert!(store.unlock_vault(id, Some(b"0000000000")).is_err());
        assert!(store.unlock_vault(id, Some(b"4321432143")).is_ok());
    }

    #[test]
    fn guard_identity_roundtrips_inside_authenticated_keystore() {
        let (mut store, master_key) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let private = [7u8; 32];
        let signing = ed25519_dalek::SigningKey::from_bytes(&private);
        let public = signing.verifying_key().to_bytes();
        store.set_guard_identity(private, public).unwrap();

        let bytes = store.to_bytes(&master_key).unwrap();
        let (reloaded, _) = KeyStore::from_bytes(&bytes, b"contrasena-segura").unwrap();
        assert_eq!(reloaded.guard_identity(), Some((private, public)));
    }

    #[test]
    fn guard_identity_cannot_be_replaced_in_place() {
        let (mut store, _master) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let private_a = [1u8; 32];
        let public_a = ed25519_dalek::SigningKey::from_bytes(&private_a)
            .verifying_key()
            .to_bytes();
        let private_b = [2u8; 32];
        let public_b = ed25519_dalek::SigningKey::from_bytes(&private_b)
            .verifying_key()
            .to_bytes();

        store.set_guard_identity(private_a, public_a).unwrap();
        assert!(matches!(
            store.set_guard_identity(private_b, public_b),
            Err(VaultError::AlreadyExists)
        ));
        assert_eq!(store.guard_identity(), Some((private_a, public_a)));
    }

    #[test]
    fn guard_identity_can_be_cleared_after_deactivation() {
        let (mut store, _master) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let private = [9u8; 32];
        let public = ed25519_dalek::SigningKey::from_bytes(&private)
            .verifying_key()
            .to_bytes();
        store.set_guard_identity(private, public).unwrap();
        store.clear_guard_identity();
        assert!(store.guard_identity().is_none());
    }

    #[test]
    fn guard_identity_rejects_mismatched_public_key() {
        let (mut store, _master) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        assert!(matches!(
            store.set_guard_identity([1u8; 32], [2u8; 32]),
            Err(VaultError::Corrupt)
        ));
        assert!(store.guard_identity().is_none());
    }

    #[test]
    fn multiple_independent_vaults() {
        let (mut store, _mk) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let id_a = store.create_vault("Personal", "D:/Personal").unwrap();
        let id_b = store.create_vault("Archivo", "D:/Archivo").unwrap();

        let key_a = store.unlock_vault(id_a, None).unwrap();
        let key_b = store.unlock_vault(id_b, None).unwrap();

        assert_ne!(key_a.as_bytes(), key_b.as_bytes());
    }

    #[test]
    fn change_master_password_does_not_change_vault_keys() {
        let (mut store, master_key) =
            KeyStore::create_new_with_params(b"vieja-segura", fast_params()).unwrap();
        let id = store.create_vault("Personal", "D:/Personal").unwrap();
        let key_before = store.unlock_vault(id, None).unwrap();
        let bytes_before = store.to_bytes(&master_key).unwrap();

        let new_master_key = store.change_master_password(b"nueva-segura").unwrap();
        let key_after = store.unlock_vault(id, None).unwrap();

        assert_eq!(key_before.as_bytes(), key_after.as_bytes());

        // El keystore antiguo (cifrado con la contrasena vieja) ya no debe
        // poder abrirse con la nueva contrasena, y viceversa.
        assert!(KeyStore::from_bytes(&bytes_before, b"nueva-segura").is_err());
        let bytes_after = store.to_bytes(&new_master_key).unwrap();
        assert!(KeyStore::from_bytes(&bytes_after, b"vieja-segura").is_err());
    }

    #[test]
    fn create_vault_with_existing_key_reuses_exact_key() {
        let (mut store, _mk) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let key = [0x5au8; 32];
        let id = store
            .create_vault_with_key("Interoperable", "D:/Interoperable", key)
            .unwrap();
        assert_eq!(store.unlock_vault(id, None).unwrap().as_bytes(), &key);
        assert_eq!(store.list_vaults()[0].name, "Interoperable");
    }

    #[test]
    fn import_vault_with_raw_key_registers_existing_vault() {
        let base = std::env::temp_dir().join(format!("opac_raw_key_import_{}", Uuid::new_v4()));
        std::fs::create_dir_all(&base).unwrap();
        let source_store_path = base.join("source.opks");
        let destination_store_path = base.join("destination.opks");
        let vault_path = base.join("vault");
        let source_file = base.join("secreto.txt");
        std::fs::write(&source_file, b"secreto portable").unwrap();

        let mut source = KeyStore::create_new_with_params(
            b"password-largo-de-prueba",
            Argon2Params {
                memory_kib: 8 * 1024,
                iterations: 1,
                parallelism: 1,
            },
        )
        .unwrap()
        .0;
        let id = source
            .create_vault("Origen", vault_path.to_string_lossy().as_ref())
            .unwrap();
        let key = source.unlock_vault(id, None).unwrap();
        crate::modules::vault_fs::create_vault_folder(&vault_path).unwrap();
        crate::modules::vault_fs::encrypt_file_into_vault(
            &vault_path,
            key.as_bytes(),
            &source_file,
        )
        .unwrap();

        let (mut destination, _mk) = KeyStore::create_new_with_params(
            b"otra-password-larga",
            Argon2Params {
                memory_kib: 8 * 1024,
                iterations: 1,
                parallelism: 1,
            },
        )
        .unwrap();
        let imported = destination
            .import_vault_with_key("Importada", &vault_path.to_string_lossy(), *key.as_bytes())
            .unwrap();
        assert_eq!(
            destination.unlock_vault(imported, None).unwrap().as_bytes(),
            key.as_bytes()
        );

        let _ = std::fs::remove_file(source_store_path);
        let _ = std::fs::remove_file(destination_store_path);
        std::fs::remove_dir_all(base).ok();
    }

    #[test]
    fn export_and_import_between_two_keystores() {
        // Simulamos "dispositivo A": crea una Caja Fuerte y la exporta.
        let (mut store_a, _mk_a) =
            KeyStore::create_new_with_params(b"contrasena-a-segura", fast_params()).unwrap();
        let id = store_a.create_vault("Personal", "D:/Privado").unwrap();
        let original_key = store_a.unlock_vault(id, None).unwrap();

        let opackey_bytes = store_a
            .export_vault_with_params(id, None, b"frase-de-viaje", fast_params())
            .unwrap();

        // "Dispositivo B": Key Store completamente distinto, contrasena
        // maestra distinta, que importa esa misma Caja Fuerte.
        let (mut store_b, _mk_b) =
            KeyStore::create_new_with_params(b"contrasena-b-segura", fast_params()).unwrap();
        let imported_id = store_b
            .import_vault(&opackey_bytes, b"frase-de-viaje", "E:/OtraRuta")
            .unwrap();

        assert_eq!(imported_id, id);
        let imported_key = store_b.unlock_vault(imported_id, None).unwrap();
        assert_eq!(original_key.as_bytes(), imported_key.as_bytes());

        let vaults_b = store_b.list_vaults();
        assert_eq!(vaults_b.len(), 1);
        assert_eq!(vaults_b[0].name, "Personal");
        assert_eq!(vaults_b[0].location, "E:/OtraRuta");
    }

    #[test]
    fn adding_pin_preserves_vault_key_and_requires_it() {
        let (mut store, _master) = KeyStore::create_new_with_params(
            b"master-password",
            Argon2Params {
                memory_kib: 8 * 1024,
                iterations: 1,
                parallelism: 1,
            },
        )
        .unwrap();
        let id = store.create_vault("Personal", "D:/Personal").unwrap();
        let original = store.unlock_vault(id, None).unwrap();
        let original_bytes = *original.as_bytes();

        store.add_pin(id, b"Ab3dEf7g").unwrap();
        assert!(matches!(
            store.unlock_vault(id, None),
            Err(VaultError::PinRequired)
        ));
        let recovered = store.unlock_vault(id, Some(b"Ab3dEf7g")).unwrap();
        assert_eq!(recovered.as_bytes(), &original_bytes);
        assert!(matches!(
            store.add_pin(id, b"Xy9zK2lm"),
            Err(VaultError::PinAlreadyConfigured)
        ));
    }

    #[test]
    fn importing_same_vault_twice_is_rejected() {
        let (mut store_a, _mk) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let id = store_a.create_vault("Personal", "D:/Privado").unwrap();
        let opackey_bytes = store_a
            .export_vault_with_params(id, None, b"frase-de-viaje", fast_params())
            .unwrap();

        let (mut store_b, _mk_b) =
            KeyStore::create_new_with_params(b"contrasena-b-segura", fast_params()).unwrap();
        store_b
            .import_vault(&opackey_bytes, b"frase-de-viaje", "E:/Ruta")
            .unwrap();

        assert!(matches!(
            store_b.import_vault(&opackey_bytes, b"frase-de-viaje", "E:/Ruta"),
            Err(VaultError::AlreadyExists)
        ));
    }

    #[test]
    fn importing_distinct_vaults_to_the_same_location_is_rejected() {
        let (mut source_a, _) =
            KeyStore::create_new_with_params(b"contrasena-a-segura", fast_params()).unwrap();
        let id_a = source_a.create_vault("A", "D:/A").unwrap();
        let export_a = source_a
            .export_vault_with_params(id_a, None, b"frase-a-segura-1", fast_params())
            .unwrap();

        let (mut source_b, _) =
            KeyStore::create_new_with_params(b"contrasena-b-segura", fast_params()).unwrap();
        let id_b = source_b.create_vault("B", "D:/B").unwrap();
        let export_b = source_b
            .export_vault_with_params(id_b, None, b"frase-b-segura-2", fast_params())
            .unwrap();

        let (mut destination, _) =
            KeyStore::create_new_with_params(b"contrasena-destino", fast_params()).unwrap();
        destination
            .import_vault(&export_a, b"frase-a-segura-1", "D:/Compartida")
            .unwrap();
        assert!(matches!(
            destination.import_vault(&export_b, b"frase-b-segura-2", "D:/Compartida"),
            Err(VaultError::AlreadyExists)
        ));
    }

    #[test]
    fn change_pin_does_not_change_vault_key() {
        let (mut store, _mk) =
            KeyStore::create_new_with_params(b"contrasena-segura", fast_params()).unwrap();
        let id = store
            .create_vault_with_pin_with_params(
                "Personal",
                "D:/Personal",
                b"1111111111",
                fast_params(),
            )
            .unwrap();
        let key_before = store.unlock_vault(id, Some(b"1111111111")).unwrap();

        store.change_pin(id, b"1111111111", b"2222222222").unwrap();

        assert!(store.unlock_vault(id, Some(b"1111111111")).is_err());
        let key_after = store.unlock_vault(id, Some(b"2222222222")).unwrap();
        assert_eq!(key_before.as_bytes(), key_after.as_bytes());
    }
}
