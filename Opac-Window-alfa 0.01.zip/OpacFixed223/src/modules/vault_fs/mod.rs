//! Acceso al sistema de archivos de una Caja Fuerte.
//!
//! V2 es el formato canónico para todas las nuevas escrituras. V1 solamente
//! se acepta al leer instalaciones antiguas y puede migrarse explícitamente
//! con `migrate_legacy_v1_file` sin cambiar la Vault Key.
//!
//! Las escrituras usan temporales de nombre aleatorio y `create_new`, evitando
//! carreras de creación de archivos predecibles. Los descifrados nunca
//! escriben directamente sobre el destino final.

use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Seek, SeekFrom, Write};
#[cfg(unix)]
use std::os::unix::fs::OpenOptionsExt;
#[cfg(windows)]
use std::os::windows::fs::OpenOptionsExt;
use std::path::{Path, PathBuf};
#[cfg(windows)]
use std::process::Command;

use thiserror::Error;

use crate::modules::crypto::{self, KEY_LEN};
use crate::modules::files;
use crate::modules::opac_format::{self, DEFAULT_CHUNKING_THRESHOLD, OpacError, OpacMetadata};

/// Umbral recomendado para activar el streaming por chunks en V2.
/// Se conserva este nombre como API pública porque ya formaba parte del núcleo original.
pub const CHUNKED_THRESHOLD: u64 = DEFAULT_CHUNKING_THRESHOLD;

const OPAC_EXTENSION: &str = "opac";
const FOLDER_MARKER_FILENAME: &str = ".opac-folder";
const FOLDER_MARKER_MAX_BYTES: u64 = 128 * 1024;
const TEMP_ATTEMPTS: usize = 32;

#[derive(Debug, Error)]
pub enum VaultFsError {
    #[error(transparent)]
    Io(#[from] io::Error),
    #[error(transparent)]
    Opac(#[from] OpacError),
    #[error("la ruta indicada existe pero no es una carpeta")]
    NotADirectory,
    #[error("el destino ya existe; se evita sobrescribirlo implicitamente")]
    DestinationExists,
    #[error("la ruta no pertenece a la carpeta de la Caja Fuerte")]
    InvalidVaultPath,
    #[error("la ruta contiene un enlace simbolico o punto de reanalisis no permitido")]
    UnsafeFilesystemEntry,
}

pub fn validate_vault_access(
    vault_folder: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<(), VaultFsError> {
    // The physical root itself has no plaintext identity marker. For a non-empty
    // vault, every managed entry is authenticated with the supplied Vault Key.
    // Empty roots cannot provide cryptographic proof, but are safe to attach: no
    // protected content exists yet.
    ensure_safe_directory(vault_folder)?;

    fn walk(root: &Path, current: &Path, vault_key: &[u8; KEY_LEN]) -> Result<(), VaultFsError> {
        for entry in fs::read_dir(current)? {
            let entry = entry?;
            let path = entry.path();
            let file_type = entry.file_type()?;
            if file_type.is_symlink() {
                return Err(VaultFsError::UnsafeFilesystemEntry);
            }
            if file_type.is_dir() {
                ensure_safe_directory(&path)?;
                let marker = folder_marker_path(&path);
                if path_exists_including_symlink(&marker) {
                    read_folder_metadata(&path, vault_key)?;
                    walk(root, &path, vault_key)?;
                } else {
                    return Err(VaultFsError::InvalidVaultPath);
                }
            } else if file_type.is_file() {
                if path.file_name().and_then(|name| name.to_str()) == Some(FOLDER_MARKER_FILENAME) {
                    if current == root {
                        return Err(VaultFsError::InvalidVaultPath);
                    }
                    // The containing directory was authenticated before the
                    // recursive walk descended into it. The marker itself is
                    // therefore a managed metadata entry, not a plaintext file.
                    continue;
                }
                if path.extension().and_then(|extension| extension.to_str()) != Some(OPAC_EXTENSION)
                {
                    return Err(VaultFsError::InvalidVaultPath);
                }
                ensure_safe_regular_file(&path)?;
                read_file_metadata_for_listing(&path, vault_key)?;
            } else {
                return Err(VaultFsError::UnsafeFilesystemEntry);
            }
        }
        Ok(())
    }

    walk(vault_folder, vault_folder, vault_key)?;
    Ok(())
}

pub fn create_vault_folder(path: &Path) -> Result<(), VaultFsError> {
    if path.exists() {
        ensure_safe_directory(path)?;
        set_private_directory_permissions(path)?;
        return Ok(());
    }
    fs::create_dir_all(path)?;
    ensure_safe_directory(path)?;
    set_private_directory_permissions(path)?;
    Ok(())
}

pub fn default_vaults_root() -> Option<PathBuf> {
    #[cfg(target_os = "windows")]
    {
        if let Ok(local_app_data) = std::env::var("LOCALAPPDATA") {
            return Some(PathBuf::from(local_app_data).join("OpacWindow"));
        }
        if let Ok(appdata) = std::env::var("APPDATA") {
            return Some(PathBuf::from(appdata).join("OpacWindow"));
        }
    }

    #[cfg(not(target_os = "windows"))]
    {
        if let Ok(xdg_data_home) = std::env::var("XDG_DATA_HOME") {
            return Some(PathBuf::from(xdg_data_home).join("OpacWindow"));
        }
        if let Ok(home) = std::env::var("HOME") {
            return Some(PathBuf::from(home).join(".local/share/OpacWindow"));
        }
    }

    None
}

fn path_exists_including_symlink(path: &Path) -> bool {
    fs::symlink_metadata(path).is_ok()
}

pub fn set_private_directory_permissions(path: &Path) -> io::Result<()> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "directorio no seguro para almacenamiento privado",
        ));
    }

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(path, fs::Permissions::from_mode(0o700))?;
    }

    #[cfg(windows)]
    {
        let user_sid = opac_guard::current_user_sid().map_err(io::Error::other)?;
        if !user_sid.starts_with("S-1-") {
            return Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "SID de usuario no valido para proteger el almacenamiento",
            ));
        }
        let user = format!("*{user_sid}:(OI)(CI)F");
        let system = "*S-1-5-18:(OI)(CI)F";
        let status = hidden_command(system32_tool("icacls.exe"))
            .arg(path)
            .args(["/inheritance:r", "/grant:r", &user, system])
            .status()?;
        if !status.success() {
            return Err(io::Error::other(
                "no se pudieron asegurar las ACL del almacenamiento privado",
            ));
        }
    }

    Ok(())
}

/// Lanza una herramienta de consola de Windows (icacls, sc) sin crear una
/// ventana de consola. Sin esto, cada llamada desde un proceso GUI muestra un
/// cmd que aparece y desaparece al instante.
#[cfg(windows)]
fn hidden_command(program: impl AsRef<std::ffi::OsStr>) -> Command {
    use std::os::windows::process::CommandExt;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    let mut command = Command::new(program);
    command.creation_flags(CREATE_NO_WINDOW);
    command
}

#[cfg(windows)]
fn system32_directory() -> io::Result<PathBuf> {
    let root = std::env::var_os("SystemRoot")
        .or_else(|| std::env::var_os("WINDIR"))
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(r"C:\Windows"));
    let dir = root.join("System32");
    if !dir.is_dir() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            "no se encontro System32 de Windows",
        ));
    }
    Ok(dir)
}

#[cfg(windows)]
fn system32_tool(name: &str) -> PathBuf {
    system32_directory()
        .map(|dir| dir.join(name))
        .unwrap_or_else(|_| PathBuf::from(r"C:\Windows\System32").join(name))
}

fn is_reparse_or_symlink(metadata: &fs::Metadata) -> bool {
    if metadata.file_type().is_symlink() {
        return true;
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0400;
        metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0
    }
    #[cfg(not(windows))]
    {
        false
    }
}

fn ensure_safe_directory(path: &Path) -> Result<(), VaultFsError> {
    let metadata = fs::symlink_metadata(path)?;
    if is_reparse_or_symlink(&metadata) {
        return Err(VaultFsError::UnsafeFilesystemEntry);
    }
    if !metadata.is_dir() {
        return Err(VaultFsError::NotADirectory);
    }
    Ok(())
}

/// Valida una carpeta que el usuario ha elegido como contenedor sin cambiar
/// sus permisos. La proteccion privada se aplica exclusivamente a la nueva
/// carpeta de la Caja Fuerte.
pub fn validate_safe_directory(path: &Path) -> Result<(), VaultFsError> {
    ensure_safe_directory(path)
}

fn ensure_safe_regular_file(path: &Path) -> Result<(), VaultFsError> {
    let metadata = fs::symlink_metadata(path)?;
    if is_reparse_or_symlink(&metadata) {
        return Err(VaultFsError::UnsafeFilesystemEntry);
    }
    if !metadata.is_file() {
        return Err(VaultFsError::UnsafeFilesystemEntry);
    }
    Ok(())
}

fn opaque_filename(id: &[u8]) -> String {
    let mut s = String::with_capacity(id.len() * 2 + 1 + OPAC_EXTENSION.len());
    for byte in id {
        s.push_str(&format!("{byte:02x}"));
    }
    s.push('.');
    s.push_str(OPAC_EXTENSION);
    s
}

fn create_unique_temp_file(
    dest_path: &Path,
    purpose: &str,
) -> Result<(PathBuf, File), VaultFsError> {
    let parent = dest_path.parent().ok_or_else(|| {
        io::Error::new(
            io::ErrorKind::InvalidInput,
            "el destino no tiene carpeta padre",
        )
    })?;
    ensure_safe_directory(parent)?;
    let base = dest_path
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| "archivo".to_string());

    for _ in 0..TEMP_ATTEMPTS {
        let id = crypto::random_file_id();
        let temp_name = format!(".{base}.{purpose}.{}-tmp", opaque_filename(&id));
        let temp_path = parent.join(temp_name);
        let mut options = OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        options.mode(0o600);
        let result = options.open(&temp_path);
        match result {
            Ok(file) => return Ok((temp_path, file)),
            Err(e) if e.kind() == io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(VaultFsError::Io(e)),
        }
    }

    Err(VaultFsError::Io(io::Error::new(
        io::ErrorKind::AlreadyExists,
        "no se pudo reservar un nombre temporal unico",
    )))
}

pub(crate) fn open_safe_regular_file(path: &Path) -> Result<File, VaultFsError> {
    ensure_safe_regular_file(path)?;
    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(windows)]
    {
        const FILE_FLAG_OPEN_REPARSE_POINT: u32 = 0x0020_0000;
        options.custom_flags(FILE_FLAG_OPEN_REPARSE_POINT);
    }
    let file = options.open(path)?;
    let metadata = file.metadata()?;
    if is_reparse_or_symlink(&metadata) || !metadata.is_file() {
        return Err(VaultFsError::UnsafeFilesystemEntry);
    }
    Ok(file)
}

fn read_bounded_file(path: &Path, max_len: u64) -> Result<Vec<u8>, VaultFsError> {
    let file = open_safe_regular_file(path)?;
    let len = file.metadata()?.len();
    if len > max_len {
        return Err(VaultFsError::Opac(OpacError::Corrupt));
    }
    let mut data = Vec::with_capacity(len as usize);
    let hard_limit = max_len.saturating_add(1);
    file.take(hard_limit).read_to_end(&mut data)?;
    if data.len() as u64 > max_len {
        return Err(VaultFsError::Opac(OpacError::Corrupt));
    }
    Ok(data)
}

fn metadata_from_open_file(path: &Path, file: &File) -> Result<OpacMetadata, VaultFsError> {
    let metadata_fs = file.metadata()?;
    if !metadata_fs.is_file() {
        return Err(VaultFsError::Io(io::Error::new(
            io::ErrorKind::InvalidInput,
            "la entrada de origen no es un archivo regular",
        )));
    }

    let original_name = path
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_default();
    if original_name.is_empty() {
        return Err(VaultFsError::Io(io::Error::new(
            io::ErrorKind::InvalidInput,
            "el archivo de origen no tiene nombre de archivo",
        )));
    }

    Ok(OpacMetadata {
        original_name,
        original_size: metadata_fs.len(),
        created_unix: metadata_fs
            .created()
            .ok()
            .and_then(files::system_time_to_unix_for_core),
        modified_unix: metadata_fs
            .modified()
            .ok()
            .and_then(files::system_time_to_unix_for_core),
    })
}

fn peek_opac_version(opac_path: &Path) -> Result<u16, VaultFsError> {
    let mut file = open_safe_regular_file(opac_path)?;
    let mut head = [0u8; 6];
    std::io::Read::read_exact(&mut file, &mut head)
        .map_err(|_| VaultFsError::Opac(OpacError::Truncated))?;
    if &head[..4] != opac_format::OPAC_MAGIC {
        return Err(VaultFsError::Opac(OpacError::BadMagic));
    }
    Ok(u16::from_le_bytes([head[4], head[5]]))
}

/// Cifra cualquier archivo nuevo siempre en V2. Los archivos de hasta
/// `CHUNKED_THRESHOLD` usan un único chunk; los mayores usan chunks de
/// `DEFAULT_CHUNK_SIZE`. El origen se abre una sola vez para evitar TOCTOU
/// entre la consulta del tamaño y la lectura de contenido.
pub fn encrypt_file_into_vault(
    vault_folder: &Path,
    vault_key: &[u8; KEY_LEN],
    source_path: &Path,
) -> Result<PathBuf, VaultFsError> {
    encrypt_file_into_vault_folder(vault_folder, vault_folder, vault_key, source_path)
}

/// Cifra un archivo en una carpeta gestionada por la Caja Fuerte.
///
/// `vault_folder` es la raíz física de la Caja y `target_folder` debe ser
/// esa raíz o una carpeta creada por Opac Window dentro de ella. El nombre
/// visible del archivo sigue viviendo autenticado dentro del `.opac`; el
/// nombre físico continúa siendo aleatorio.
pub fn encrypt_file_into_vault_folder(
    vault_folder: &Path,
    target_folder: &Path,
    vault_key: &[u8; KEY_LEN],
    source_path: &Path,
) -> Result<PathBuf, VaultFsError> {
    encrypt_file_into_vault_folder_with_progress(
        vault_folder,
        target_folder,
        vault_key,
        source_path,
        |_completed, _total| {},
    )
}

pub fn encrypt_file_into_vault_folder_with_progress<F: FnMut(u64, u64)>(
    vault_folder: &Path,
    target_folder: &Path,
    vault_key: &[u8; KEY_LEN],
    source_path: &Path,
    on_chunk_progress: F,
) -> Result<PathBuf, VaultFsError> {
    encrypt_file_into_vault_folder_with_progress_and_parallelism(
        vault_folder,
        target_folder,
        vault_key,
        source_path,
        1,
        on_chunk_progress,
    )
}

pub fn encrypt_file_into_vault_folder_with_progress_and_parallelism<F: FnMut(u64, u64)>(
    vault_folder: &Path,
    target_folder: &Path,
    vault_key: &[u8; KEY_LEN],
    source_path: &Path,
    parallel_workers: usize,
    on_chunk_progress: F,
) -> Result<PathBuf, VaultFsError> {
    create_vault_folder(vault_folder)?;
    validate_vault_path(vault_folder, target_folder)?;
    ensure_safe_target_folder(vault_folder, target_folder)?;
    ensure_safe_regular_file(source_path)?;

    let mut src = open_safe_regular_file(source_path)?;
    let metadata = metadata_from_open_file(source_path, &src)?;
    if visible_name_exists_in_folder(target_folder, vault_key, &metadata.original_name)? {
        return Err(VaultFsError::DestinationExists);
    }

    let disk_id = crypto::random_file_id();
    let final_path = target_folder.join(opaque_filename(&disk_id));
    let (tmp_path, mut tmp_file) = create_unique_temp_file(&final_path, "encrypt")?;

    let outcome = (|| -> Result<(), VaultFsError> {
        opac_format::encrypt_v2_auto_with_parallel_progress(
            vault_key,
            metadata,
            &mut src,
            &mut tmp_file,
            parallel_workers,
            on_chunk_progress,
        )?;
        tmp_file.sync_all()?;
        Ok(())
    })();
    drop(tmp_file);

    let outcome = match outcome {
        Ok(()) => {
            let mut verification_file = open_safe_regular_file(&tmp_path)?;
            opac_format::verify_v2_chunk_sequence(vault_key, &mut verification_file)?;
            Ok(())
        }
        Err(error) => Err(error),
    };

    match outcome {
        Ok(()) => {
            ensure_safe_target_folder(vault_folder, target_folder)?;
            if path_exists_including_symlink(&final_path) {
                let _ = fs::remove_file(&tmp_path);
                return Err(VaultFsError::DestinationExists);
            }
            fs::rename(&tmp_path, &final_path)?;
            sync_folder(target_folder);
            Ok(final_path)
        }
        Err(e) => {
            let _ = fs::remove_file(&tmp_path);
            Err(e)
        }
    }
}

fn folder_marker_path(folder: &Path) -> PathBuf {
    folder.join(FOLDER_MARKER_FILENAME)
}

fn validate_visible_name(name: &str) -> Result<(), VaultFsError> {
    if name.trim().is_empty()
        || name == "."
        || name == ".."
        || name
            .chars()
            .any(|ch| ch.is_control() || ch == '/' || ch == '\\' || ch == '\0')
    {
        return Err(VaultFsError::InvalidVaultPath);
    }
    Ok(())
}

pub fn validate_vault_path(vault_folder: &Path, path: &Path) -> Result<(), VaultFsError> {
    let relative = path
        .strip_prefix(vault_folder)
        .map_err(|_| VaultFsError::InvalidVaultPath)?;
    if relative
        .components()
        .any(|component| !matches!(component, std::path::Component::Normal(_)))
    {
        return Err(VaultFsError::InvalidVaultPath);
    }

    let mut cursor = vault_folder.to_path_buf();
    ensure_safe_directory(&cursor)?;
    for component in relative.components() {
        cursor.push(component.as_os_str());
        let metadata = fs::symlink_metadata(&cursor)?;
        if is_reparse_or_symlink(&metadata) {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
        if metadata.is_dir() {
            if cursor != vault_folder {
                let marker = folder_marker_path(&cursor);
                ensure_safe_regular_file(&marker)?;
            }
            continue;
        }
        if cursor == path {
            break;
        }
        return Err(VaultFsError::InvalidVaultPath);
    }
    Ok(())
}

fn ensure_safe_target_folder(vault_folder: &Path, folder: &Path) -> Result<(), VaultFsError> {
    validate_vault_path(vault_folder, folder)?;
    ensure_safe_directory(folder)?;
    if folder != vault_folder {
        let marker = folder_marker_path(folder);
        ensure_safe_regular_file(&marker)?;
    }
    Ok(())
}

fn write_encrypted_content(
    output_path: &Path,
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    content: &[u8],
) -> Result<(), VaultFsError> {
    let (tmp_path, mut tmp_file) = create_unique_temp_file(output_path, "write")?;
    let result = (|| -> Result<(), VaultFsError> {
        opac_format::encrypt_v2_auto(
            vault_key,
            metadata,
            &mut io::Cursor::new(content),
            &mut tmp_file,
        )?;
        tmp_file.sync_all()?;
        Ok(())
    })();
    match result {
        Ok(()) => {
            drop(tmp_file);
            if path_exists_including_symlink(output_path) {
                let _ = fs::remove_file(&tmp_path);
                return Err(VaultFsError::DestinationExists);
            }
            fs::rename(&tmp_path, output_path)?;
            Ok(())
        }
        Err(error) => {
            let _ = fs::remove_file(&tmp_path);
            Err(error)
        }
    }
}

fn read_folder_metadata(
    folder: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<OpacMetadata, VaultFsError> {
    let marker = folder_marker_path(folder);
    ensure_safe_regular_file(&marker)?;
    let metadata = fs::metadata(&marker)?;
    if metadata.len() > FOLDER_MARKER_MAX_BYTES {
        return Err(VaultFsError::Io(io::Error::new(
            io::ErrorKind::InvalidData,
            "el marcador de carpeta es demasiado grande",
        )));
    }
    let data = read_bounded_file(&marker, FOLDER_MARKER_MAX_BYTES)?;
    let decrypted = opac_format::decrypt(vault_key, &data)?;
    if !decrypted.content.is_empty() {
        return Err(VaultFsError::InvalidVaultPath);
    }
    Ok(decrypted.metadata)
}

fn visible_name_exists_in_folder(
    folder: &Path,
    vault_key: &[u8; KEY_LEN],
    name: &str,
) -> Result<bool, VaultFsError> {
    visible_name_exists_in_folder_except(folder, vault_key, name, None)
}

fn visible_name_exists_in_folder_except(
    folder: &Path,
    vault_key: &[u8; KEY_LEN],
    name: &str,
    excluded_path: Option<&Path>,
) -> Result<bool, VaultFsError> {
    validate_visible_name(name)?;
    for entry in fs::read_dir(folder)? {
        let entry = entry?;
        let path = entry.path();
        if excluded_path.is_some_and(|excluded| excluded == path) {
            continue;
        }
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            continue;
        }
        if file_type.is_dir() {
            if path_exists_including_symlink(&folder_marker_path(&path)) {
                let metadata = read_folder_metadata(&path, vault_key)?;
                if metadata.original_name == name {
                    return Ok(true);
                }
            }
            continue;
        }
        if file_type.is_file()
            && path.extension().and_then(|extension| extension.to_str()) == Some(OPAC_EXTENSION)
            && path.file_name().and_then(|filename| filename.to_str())
                != Some(FOLDER_MARKER_FILENAME)
        {
            ensure_safe_regular_file(&path)?;
            let metadata = read_file_metadata_for_listing(&path, vault_key)?;
            if metadata.original_name == name {
                return Ok(true);
            }
        }
    }
    Ok(false)
}

fn read_file_metadata_for_listing(
    opac_path: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<OpacMetadata, VaultFsError> {
    let mut file = open_safe_regular_file(opac_path)?;
    let mut head = [0u8; 6];
    file.read_exact(&mut head)
        .map_err(|_| VaultFsError::Opac(OpacError::Truncated))?;
    if &head[..4] != opac_format::OPAC_MAGIC {
        return Err(VaultFsError::Opac(OpacError::BadMagic));
    }
    let version = u16::from_le_bytes([head[4], head[5]]);
    file.rewind()?;
    if version == opac_format::OPAC_VERSION {
        return Ok(opac_format::read_metadata_only(vault_key, &mut file)?);
    }
    if version == opac_format::OPAC_VERSION_LEGACY_V1 {
        let data = read_bounded_file(opac_path, opac_format::MAX_LEGACY_V1_FILE_SIZE)?;
        return Ok(opac_format::decrypt(vault_key, &data)?.metadata);
    }
    Err(VaultFsError::Opac(OpacError::UnsupportedVersion(version)))
}

/// Lista las carpetas gestionadas por Opac Window. El nombre físico de cada
/// carpeta es opaco; el nombre visible procede del marcador cifrado.
pub fn list_vault_folders(
    vault_folder: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<Vec<(PathBuf, OpacMetadata)>, VaultFsError> {
    ensure_safe_directory(vault_folder)?;
    let mut out = Vec::new();
    collect_managed_folders(vault_folder, vault_key, &mut out)?;
    out.sort_by(|a, b| a.0.cmp(&b.0));
    Ok(out)
}

fn collect_managed_folders(
    current: &Path,
    vault_key: &[u8; KEY_LEN],
    out: &mut Vec<(PathBuf, OpacMetadata)>,
) -> Result<(), VaultFsError> {
    for entry in fs::read_dir(current)? {
        let entry = entry?;
        let path = entry.path();
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            continue;
        }
        if !file_type.is_dir() {
            continue;
        }
        ensure_safe_directory(&path)?;
        let marker = folder_marker_path(&path);
        if !path_exists_including_symlink(&marker) {
            continue;
        }
        let metadata = read_folder_metadata(&path, vault_key)?;
        out.push((path.clone(), metadata));
        collect_managed_folders(&path, vault_key, out)?;
    }
    Ok(())
}

pub fn create_folder(
    vault_folder: &Path,
    parent_folder: &Path,
    name: &str,
    vault_key: &[u8; KEY_LEN],
) -> Result<PathBuf, VaultFsError> {
    create_vault_folder(vault_folder)?;
    ensure_safe_target_folder(vault_folder, parent_folder)?;
    validate_visible_name(name)?;
    if visible_name_exists_in_folder(parent_folder, vault_key, name)? {
        return Err(VaultFsError::DestinationExists);
    }

    let mut directory = None;
    for _ in 0..TEMP_ATTEMPTS {
        let candidate = parent_folder.join(hex_id(&crypto::random_file_id()));
        if path_exists_including_symlink(&candidate) {
            continue;
        }
        match fs::create_dir(&candidate) {
            Ok(()) => {
                #[cfg(unix)]
                set_private_directory_permissions(&candidate)?;
                // En Windows la carpeta nueva hereda las ACL privadas del
                // directorio raiz de la Caja Fuerte (OI/CI). Volver a invocar
                // icacls aqui introduce una operacion externa por cada nivel
                // y puede fallar con rutas profundamente anidadas.
                directory = Some(candidate);
                break;
            }
            Err(error) if error.kind() == io::ErrorKind::AlreadyExists => continue,
            Err(error) => return Err(VaultFsError::Io(error)),
        }
    }
    let directory = directory.ok_or_else(|| {
        VaultFsError::Io(io::Error::new(
            io::ErrorKind::AlreadyExists,
            "no se pudo reservar una carpeta opaca unica",
        ))
    })?;

    let metadata = OpacMetadata {
        original_name: name.to_owned(),
        original_size: 0,
        created_unix: Some(unix_now()),
        modified_unix: Some(unix_now()),
    };
    let marker = folder_marker_path(&directory);
    if let Err(error) = write_encrypted_content(&marker, vault_key, metadata, &[]) {
        let _ = fs::remove_dir(&directory);
        return Err(error);
    }
    sync_folder(parent_folder);
    Ok(directory)
}

pub fn create_text_file(
    vault_folder: &Path,
    parent_folder: &Path,
    name: &str,
    vault_key: &[u8; KEY_LEN],
) -> Result<PathBuf, VaultFsError> {
    create_vault_folder(vault_folder)?;
    ensure_safe_target_folder(vault_folder, parent_folder)?;
    let base = name.trim();
    validate_visible_name(base)?;
    let visible_name = if base.to_ascii_lowercase().ends_with(".md") {
        base.to_owned()
    } else {
        format!("{base}.md")
    };
    validate_visible_name(&visible_name)?;
    if visible_name_exists_in_folder(parent_folder, vault_key, &visible_name)? {
        return Err(VaultFsError::DestinationExists);
    }
    let file_path = parent_folder.join(opaque_filename(&crypto::random_file_id()));
    let metadata = OpacMetadata {
        original_name: visible_name,
        original_size: 0,
        created_unix: Some(unix_now()),
        modified_unix: Some(unix_now()),
    };
    write_encrypted_content(&file_path, vault_key, metadata, &[])?;
    sync_folder(parent_folder);
    Ok(file_path)
}

fn hex_id(id: &[u8]) -> String {
    id.iter().map(|byte| format!("{byte:02x}")).collect()
}

fn unix_now() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|duration| duration.as_secs())
        .unwrap_or(0)
}

/// Moves a file to another managed folder without changing its opaque disk
/// name or ciphertext.
pub fn move_file(
    vault_folder: &Path,
    opac_path: &Path,
    destination_folder: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<PathBuf, VaultFsError> {
    validate_vault_path(vault_folder, opac_path)?;
    validate_vault_path(vault_folder, destination_folder)?;
    ensure_safe_regular_file(opac_path)?;
    ensure_safe_target_folder(vault_folder, destination_folder)?;
    if opac_path
        .extension()
        .and_then(|extension| extension.to_str())
        != Some(OPAC_EXTENSION)
    {
        return Err(VaultFsError::InvalidVaultPath);
    }
    let metadata = read_file_metadata_for_listing(opac_path, vault_key)?;
    if let Some(parent) = opac_path.parent()
        && parent == destination_folder
    {
        return Ok(opac_path.to_path_buf());
    }
    if visible_name_exists_in_folder(destination_folder, vault_key, &metadata.original_name)? {
        return Err(VaultFsError::DestinationExists);
    }
    let destination = destination_folder.join(
        opac_path
            .file_name()
            .ok_or(VaultFsError::InvalidVaultPath)?,
    );
    if path_exists_including_symlink(&destination) {
        return Err(VaultFsError::DestinationExists);
    }
    let old_parent = opac_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    fs::rename(opac_path, &destination)?;
    sync_folder(old_parent);
    sync_folder(destination_folder);
    Ok(destination)
}

/// Moves a managed folder to another managed folder. A folder may never be
/// moved into itself or one of its descendants.
pub fn move_folder(
    vault_folder: &Path,
    folder_path: &Path,
    destination_parent: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<PathBuf, VaultFsError> {
    validate_vault_path(vault_folder, folder_path)?;
    validate_vault_path(vault_folder, destination_parent)?;
    ensure_safe_target_folder(vault_folder, destination_parent)?;
    if folder_path == vault_folder
        || folder_path.strip_prefix(vault_folder).is_err()
        || destination_parent.strip_prefix(folder_path).is_ok()
    {
        return Err(VaultFsError::InvalidVaultPath);
    }
    ensure_safe_directory(folder_path)?;
    let metadata = read_folder_metadata(folder_path, vault_key)?;
    let current_parent = folder_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    if current_parent == destination_parent {
        return Ok(folder_path.to_path_buf());
    }
    if visible_name_exists_in_folder(destination_parent, vault_key, &metadata.original_name)? {
        return Err(VaultFsError::DestinationExists);
    }
    let name = folder_path
        .file_name()
        .ok_or(VaultFsError::InvalidVaultPath)?;
    let destination = destination_parent.join(name);
    if path_exists_including_symlink(&destination) {
        return Err(VaultFsError::DestinationExists);
    }
    fs::rename(folder_path, &destination)?;
    sync_folder(folder_path.parent().ok_or(VaultFsError::InvalidVaultPath)?);
    sync_folder(destination_parent);
    Ok(destination)
}

fn validate_folder_tree_for_recursive_delete(
    folder_path: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<(), VaultFsError> {
    ensure_safe_directory(folder_path)?;
    read_folder_metadata(folder_path, vault_key)?;
    for entry in fs::read_dir(folder_path)? {
        let entry = entry?;
        let path = entry.path();
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
        if file_type.is_dir() {
            let marker = folder_marker_path(&path);
            ensure_safe_directory(&path)?;
            ensure_safe_regular_file(&marker)?;
            validate_folder_tree_for_recursive_delete(&path, vault_key)?;
        } else if file_type.is_file() {
            if path.file_name().and_then(|name| name.to_str()) == Some(FOLDER_MARKER_FILENAME) {
                ensure_safe_regular_file(&path)?;
                let metadata = fs::metadata(&path)?;
                if metadata.len() > FOLDER_MARKER_MAX_BYTES {
                    return Err(VaultFsError::Io(io::Error::new(
                        io::ErrorKind::InvalidData,
                        "el marcador de carpeta es demasiado grande",
                    )));
                }
                continue;
            }
            if path.extension().and_then(|extension| extension.to_str()) != Some(OPAC_EXTENSION) {
                return Err(VaultFsError::InvalidVaultPath);
            }
            ensure_safe_regular_file(&path)?;
            let _ = read_file_metadata_for_listing(&path, vault_key)?;
        } else {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
    }
    Ok(())
}

fn delete_folder_tree(folder_path: &Path) -> Result<(), VaultFsError> {
    ensure_safe_directory(folder_path)?;
    let entries = fs::read_dir(folder_path)?.collect::<Result<Vec<_>, _>>()?;
    for entry in entries {
        let path = entry.path();
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
        if file_type.is_dir() {
            // Defense in depth: do not trust the earlier whole-tree validation.
            // The directory may have changed between validation and deletion.
            ensure_safe_directory(&path)?;
            ensure_safe_regular_file(&folder_marker_path(&path))?;
            delete_folder_tree(&path)?;
        } else if file_type.is_file() {
            // Defense in depth against TOCTOU: an unmanaged file introduced
            // after validate_folder_tree_for_recursive_delete() must never be
            // silently deleted by an OPAC recursive-delete operation.
            let is_marker =
                path.file_name().and_then(|name| name.to_str()) == Some(FOLDER_MARKER_FILENAME);
            let is_opac =
                path.extension().and_then(|extension| extension.to_str()) == Some(OPAC_EXTENSION);
            if !is_marker && !is_opac {
                return Err(VaultFsError::InvalidVaultPath);
            }
            ensure_safe_regular_file(&path)?;
            if is_marker {
                let metadata = fs::metadata(&path)?;
                if metadata.len() > FOLDER_MARKER_MAX_BYTES {
                    return Err(VaultFsError::Io(io::Error::new(
                        io::ErrorKind::InvalidData,
                        "el marcador de carpeta es demasiado grande",
                    )));
                }
            }
            fs::remove_file(&path)?;
        } else {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
    }
    fs::remove_dir(folder_path)?;
    Ok(())
}

/// Copia una Caja Fuerte durante una migracion de perfil sin descifrarla.
/// No intenta autenticar el contenido porque esta operacion se realiza sobre
/// un Key Store ya desbloqueado y debe funcionar tambien para Cajas con PIN
/// cuyo PIN no se ha introducido. Solo permite la estructura fisica gestionada
/// (.opac y .opac-folder), sin enlaces simbolicos ni otros tipos de entrada.
pub(crate) fn ensure_migratable_vault_root(path: &Path) -> Result<(), VaultFsError> {
    ensure_migratable_directory(path, true)
}

fn ensure_migratable_directory(path: &Path, is_root: bool) -> Result<(), VaultFsError> {
    ensure_safe_directory(path)?;
    if !is_root {
        let marker = folder_marker_path(path);
        ensure_safe_regular_file(&marker)?;
    }
    for entry in fs::read_dir(path)? {
        let entry = entry?;
        let child = entry.path();
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
        if file_type.is_dir() {
            ensure_migratable_directory(&child, false)?;
        } else if file_type.is_file() {
            let name = child.file_name().and_then(|n| n.to_str());
            let is_marker = name == Some(FOLDER_MARKER_FILENAME);
            let is_opac = child.extension().and_then(|e| e.to_str()) == Some(OPAC_EXTENSION);
            if (!is_root && is_marker) || is_opac {
                ensure_safe_regular_file(&child)?;
            } else {
                return Err(VaultFsError::InvalidVaultPath);
            }
        } else {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
    }
    Ok(())
}

pub fn delete_unmanaged_vault_root_for_migration(path: &Path) -> Result<(), VaultFsError> {
    ensure_migratable_vault_root(path)?;
    let parent = path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    fs::remove_dir_all(path)?;
    sync_folder(parent);
    Ok(())
}

pub fn copy_vault_root_for_migration(
    source: &Path,
    destination: &Path,
) -> Result<(), VaultFsError> {
    ensure_safe_directory(source)?;
    if path_exists_including_symlink(destination) {
        return Err(VaultFsError::DestinationExists);
    }
    let parent = destination.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    ensure_safe_directory(parent)?;
    fs::create_dir(destination)?;
    if let Err(error) = copy_migration_tree(source, destination) {
        let _ = fs::remove_dir_all(destination);
        return Err(error);
    }
    sync_folder(parent);
    Ok(())
}

fn copy_migration_tree(source: &Path, destination: &Path) -> Result<(), VaultFsError> {
    ensure_safe_directory(source)?;
    ensure_safe_directory(destination)?;
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        let path = entry.path();
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
        if file_type.is_dir() {
            let source_marker = folder_marker_path(&path);
            ensure_safe_regular_file(&source_marker)?;
            let child = destination.join(path.file_name().ok_or(VaultFsError::InvalidVaultPath)?);
            ensure_absent(&child)?;
            fs::create_dir(&child)?;
            ensure_safe_directory(&child)?;
            copy_migration_tree(&path, &child)?;
        } else if file_type.is_file() {
            let name = path.file_name().ok_or(VaultFsError::InvalidVaultPath)?;
            let is_marker = name.to_str() == Some(FOLDER_MARKER_FILENAME);
            let is_opac = path.extension().and_then(|ext| ext.to_str()) == Some(OPAC_EXTENSION);
            if !is_marker && !is_opac {
                return Err(VaultFsError::InvalidVaultPath);
            }
            let child = destination.join(name);
            ensure_absent(&child)?;
            copy_regular_file_securely(&path, &child)?;
        } else {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
    }
    Ok(())
}

/// Copia una Caja Fuerte existente sin descifrarla: valida primero el arbol
/// con la Vault Key y despues copia exclusivamente entradas gestionadas.
/// El ciphertext se preserva byte a byte.
pub fn copy_vault_root(
    source: &Path,
    destination: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<(), VaultFsError> {
    validate_vault_access(source, vault_key)?;
    if path_exists_including_symlink(destination) {
        return Err(VaultFsError::DestinationExists);
    }
    let destination_parent = destination.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    ensure_safe_directory(destination_parent)?;
    fs::create_dir(destination)?;
    if let Err(error) = copy_managed_tree(source, destination) {
        let _ = fs::remove_dir_all(destination);
        return Err(error);
    }
    ensure_safe_directory(destination_parent)?;
    if let Err(error) = validate_vault_access(destination, vault_key) {
        let _ = fs::remove_dir_all(destination);
        return Err(error);
    }
    sync_folder(destination_parent);
    Ok(())
}

fn copy_managed_tree(source: &Path, destination: &Path) -> Result<(), VaultFsError> {
    ensure_safe_directory(source)?;
    ensure_safe_directory(destination)?;
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        let path = entry.path();
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
        if file_type.is_dir() {
            let name = path.file_name().ok_or(VaultFsError::InvalidVaultPath)?;
            if name == ".opac-folder" {
                return Err(VaultFsError::InvalidVaultPath);
            }
            let target = destination.join(name);
            ensure_absent(&target)?;
            fs::create_dir(&target)?;
            ensure_safe_directory(&target)?;
            copy_managed_tree(&path, &target)?;
        } else if file_type.is_file() {
            let name = path.file_name().ok_or(VaultFsError::InvalidVaultPath)?;
            let is_marker = name.to_str() == Some(FOLDER_MARKER_FILENAME);
            let is_opac = path.extension().and_then(|ext| ext.to_str()) == Some(OPAC_EXTENSION);
            if !is_marker && !is_opac {
                return Err(VaultFsError::InvalidVaultPath);
            }
            let target = destination.join(name);
            ensure_absent(&target)?;
            copy_regular_file_securely(&path, &target)?;
        } else {
            return Err(VaultFsError::UnsafeFilesystemEntry);
        }
    }
    Ok(())
}

fn copy_regular_file_securely(source: &Path, destination: &Path) -> Result<(), VaultFsError> {
    let mut source_file = open_safe_regular_file(source)?;
    if path_exists_including_symlink(destination) {
        return Err(VaultFsError::DestinationExists);
    }
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    options.mode(0o600);
    #[cfg(windows)]
    options.custom_flags(0x0020_0000);
    let mut destination_file = options.open(destination)?;
    if let Err(error) = io::copy(&mut source_file, &mut destination_file) {
        drop(destination_file);
        let _ = fs::remove_file(destination);
        return Err(VaultFsError::Io(error));
    }
    destination_file.sync_all()?;
    Ok(())
}

fn ensure_absent(path: &Path) -> Result<(), VaultFsError> {
    if path_exists_including_symlink(path) {
        return Err(VaultFsError::DestinationExists);
    }
    Ok(())
}

/// Elimina la carpeta raiz completa de una Caja Fuerte. Antes de borrar
/// valida todo el arbol y autentica las entradas gestionadas con la Vault Key.
/// La raiz nunca se trata como una carpeta ordinaria movible dentro de la UI.
pub fn delete_vault_root(
    vault_folder: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<(), VaultFsError> {
    ensure_safe_directory(vault_folder)?;
    validate_vault_access(vault_folder, vault_key)?;
    let parent = vault_folder
        .parent()
        .ok_or(VaultFsError::InvalidVaultPath)?;
    delete_folder_tree(vault_folder)?;
    sync_folder(parent);
    Ok(())
}

pub fn delete_folder(
    vault_folder: &Path,
    folder_path: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<(), VaultFsError> {
    validate_vault_path(vault_folder, folder_path)?;
    if folder_path == vault_folder {
        return Err(VaultFsError::InvalidVaultPath);
    }
    // Primero validamos todo el árbol. Así un elemento inesperado o inseguro
    // aborta la operación antes de borrar nada.
    validate_folder_tree_for_recursive_delete(folder_path, vault_key)?;
    let parent = folder_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    delete_folder_tree(folder_path)?;
    sync_folder(parent);
    Ok(())
}

fn ensure_export_destination_parent(
    vault_folder: &Path,
    destination_parent: &Path,
) -> Result<(), VaultFsError> {
    ensure_safe_directory(destination_parent)?;
    let vault_abs = fs::canonicalize(vault_folder).unwrap_or_else(|_| vault_folder.to_path_buf());
    let destination_abs =
        fs::canonicalize(destination_parent).unwrap_or_else(|_| destination_parent.to_path_buf());
    if destination_abs == vault_abs || destination_abs.strip_prefix(&vault_abs).is_ok() {
        return Err(VaultFsError::InvalidVaultPath);
    }
    Ok(())
}

fn export_folder_tree(
    folder_path: &Path,
    destination_path: &Path,
    vault_key: &[u8; KEY_LEN],
    files_count: &mut usize,
    folders_count: &mut usize,
) -> Result<(), VaultFsError> {
    ensure_safe_directory(folder_path)?;
    let metadata = read_folder_metadata(folder_path, vault_key)?;
    validate_visible_name(&metadata.original_name)?;
    if path_exists_including_symlink(destination_path) {
        return Err(VaultFsError::DestinationExists);
    }
    fs::create_dir(destination_path)?;
    *folders_count += 1;

    let result = (|| -> Result<(), VaultFsError> {
        for entry in fs::read_dir(folder_path)? {
            let entry = entry?;
            let source = entry.path();
            let file_type = entry.file_type()?;
            if file_type.is_symlink() {
                return Err(VaultFsError::UnsafeFilesystemEntry);
            }
            if file_type.is_dir() {
                let child_metadata = read_folder_metadata(&source, vault_key)?;
                validate_visible_name(&child_metadata.original_name)?;
                let child_destination = destination_path.join(&child_metadata.original_name);
                export_folder_tree(
                    &source,
                    &child_destination,
                    vault_key,
                    files_count,
                    folders_count,
                )?;
            } else if file_type.is_file() {
                if source.file_name().and_then(|name| name.to_str()) == Some(FOLDER_MARKER_FILENAME)
                {
                    continue;
                }
                if source.extension().and_then(|extension| extension.to_str())
                    != Some(OPAC_EXTENSION)
                {
                    return Err(VaultFsError::InvalidVaultPath);
                }
                ensure_safe_regular_file(&source)?;
                let file_metadata = read_file_metadata_for_listing(&source, vault_key)?;
                validate_visible_name(&file_metadata.original_name)?;
                let destination = destination_path.join(&file_metadata.original_name);
                decrypt_file_from_vault(&source, vault_key, &destination)?;
                *files_count += 1;
            } else {
                return Err(VaultFsError::UnsafeFilesystemEntry);
            }
        }
        Ok(())
    })();

    if result.is_err() {
        let _ = fs::remove_dir_all(destination_path);
    }
    result
}

/// Exporta una carpeta y todo su contenido, conservando su estructura visible.
/// El contenido se descifra únicamente hacia la carpeta de destino elegida por el usuario.
pub fn export_folder_to_directory(
    vault_folder: &Path,
    folder_path: &Path,
    destination_parent: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<(usize, usize), VaultFsError> {
    validate_vault_path(vault_folder, folder_path)?;
    if folder_path == vault_folder {
        return Err(VaultFsError::InvalidVaultPath);
    }
    ensure_export_destination_parent(vault_folder, destination_parent)?;
    let metadata = read_folder_metadata(folder_path, vault_key)?;
    validate_visible_name(&metadata.original_name)?;
    let destination_root = destination_parent.join(&metadata.original_name);
    if path_exists_including_symlink(&destination_root) {
        return Err(VaultFsError::DestinationExists);
    }
    let mut files_count = 0;
    let mut folders_count = 0;
    export_folder_tree(
        folder_path,
        &destination_root,
        vault_key,
        &mut files_count,
        &mut folders_count,
    )?;
    Ok((files_count, folders_count))
}

/// Descifra un `.opac` V1 legacy o V2 canónico a un archivo nuevo.
/// El destino debe no existir para evitar sobrescrituras implícitas.
pub fn decrypt_file_from_vault(
    opac_path: &Path,
    vault_key: &[u8; KEY_LEN],
    dest_path: &Path,
) -> Result<OpacMetadata, VaultFsError> {
    ensure_safe_regular_file(opac_path)?;
    if path_exists_including_symlink(dest_path) {
        return Err(VaultFsError::DestinationExists);
    }
    let destination_parent = dest_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    ensure_safe_directory(destination_parent)?;

    let version = peek_opac_version(opac_path)?;
    let (tmp_path, mut tmp_file) = create_unique_temp_file(dest_path, "decrypt")?;

    let outcome = (|| -> Result<OpacMetadata, VaultFsError> {
        let metadata = if version == opac_format::OPAC_VERSION {
            let mut src = open_safe_regular_file(opac_path)?;
            opac_format::decrypt_chunked(vault_key, &mut src, &mut tmp_file)?
        } else if version == opac_format::OPAC_VERSION_LEGACY_V1 {
            let data = read_bounded_file(opac_path, opac_format::MAX_LEGACY_V1_FILE_SIZE)?;
            let decrypted = opac_format::decrypt(vault_key, &data)?;
            tmp_file.write_all(&decrypted.content)?;
            decrypted.metadata
        } else {
            return Err(VaultFsError::Opac(OpacError::UnsupportedVersion(version)));
        };
        tmp_file.sync_all()?;
        Ok(metadata)
    })();

    match outcome {
        Ok(metadata) => {
            drop(tmp_file);
            ensure_safe_directory(destination_parent)?;
            if path_exists_including_symlink(dest_path) {
                let _ = fs::remove_file(&tmp_path);
                return Err(VaultFsError::DestinationExists);
            }
            match fs::rename(&tmp_path, dest_path) {
                Ok(()) => Ok(metadata),
                Err(e) => {
                    let _ = fs::remove_file(&tmp_path);
                    Err(VaultFsError::Io(e))
                }
            }
        }
        Err(e) => {
            let _ = fs::remove_file(&tmp_path);
            Err(e)
        }
    }
}

/// Reemplaza el contenido de un `.opac` existente conservando su ruta de
/// disco. El contenido nuevo siempre se escribe como V2 y se sincroniza antes
/// de publicar la nueva versión. La versión anterior se conserva brevemente
/// como backup cifrado para poder hacer rollback si el segundo rename falla.
pub fn replace_file_content(
    vault_folder: &Path,
    opac_path: &Path,
    vault_key: &[u8; KEY_LEN],
    content: &[u8],
) -> Result<OpacMetadata, VaultFsError> {
    create_vault_folder(vault_folder)?;
    validate_vault_path(vault_folder, opac_path)?;
    if opac_path.extension().and_then(|e| e.to_str()) != Some(OPAC_EXTENSION) {
        return Err(VaultFsError::InvalidVaultPath);
    }
    ensure_safe_regular_file(opac_path)?;

    let version = peek_opac_version(opac_path)?;
    let metadata = if version == opac_format::OPAC_VERSION {
        let mut file = open_safe_regular_file(opac_path)?;
        opac_format::read_metadata_only(vault_key, &mut file)?
    } else if version == opac_format::OPAC_VERSION_LEGACY_V1 {
        let data = read_bounded_file(opac_path, opac_format::MAX_LEGACY_V1_FILE_SIZE)?;
        opac_format::decrypt(vault_key, &data)?.metadata
    } else {
        return Err(VaultFsError::Opac(OpacError::UnsupportedVersion(version)));
    };

    let new_metadata = OpacMetadata {
        original_name: metadata.original_name,
        original_size: content.len() as u64,
        created_unix: metadata.created_unix,
        modified_unix: std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .ok()
            .map(|d| d.as_secs()),
    };

    let (tmp_path, mut tmp_file) = create_unique_temp_file(opac_path, "edit")?;
    let outcome = (|| -> Result<(), VaultFsError> {
        opac_format::encrypt_v2_auto(
            vault_key,
            new_metadata.clone(),
            &mut std::io::Cursor::new(content),
            &mut tmp_file,
        )?;
        tmp_file.sync_all()?;
        Ok(())
    })();

    if let Err(error) = outcome {
        let _ = fs::remove_file(&tmp_path);
        return Err(error);
    }
    drop(tmp_file);

    let parent = opac_path.parent().ok_or_else(|| {
        io::Error::new(
            io::ErrorKind::InvalidInput,
            "el archivo .opac no tiene carpeta padre",
        )
    })?;
    let base = opac_path
        .file_name()
        .map(|name| name.to_string_lossy().to_string())
        .unwrap_or_else(|| "archivo.opac".to_string());

    let backup_path = {
        let mut selected = None;
        for _ in 0..TEMP_ATTEMPTS {
            let candidate = parent.join(format!(
                ".{base}.backup-{}-edit.bak",
                crypto::random_file_id()
                    .iter()
                    .map(|b| format!("{b:02x}"))
                    .collect::<String>()
            ));
            if !path_exists_including_symlink(&candidate) {
                selected = Some(candidate);
                break;
            }
        }
        selected.ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::AlreadyExists,
                "no se pudo reservar un nombre de backup unico",
            )
        })?
    };

    if let Err(error) = fs::rename(opac_path, &backup_path) {
        let _ = fs::remove_file(&tmp_path);
        return Err(VaultFsError::Io(error));
    }

    if let Err(error) = fs::rename(&tmp_path, opac_path) {
        let _ = fs::rename(&backup_path, opac_path);
        let _ = fs::remove_file(&tmp_path);
        return Err(VaultFsError::Io(error));
    }

    // El backup solo contiene el `.opac` cifrado anterior. Si el borrado
    // falla, dejamos esa copia cifrada intacta: no expone plaintext, pero
    // evitamos fingir que la limpieza fue completa.
    if let Err(error) = fs::remove_file(&backup_path) {
        sync_folder(parent);
        return Err(VaultFsError::Io(error));
    }
    sync_folder(parent);
    Ok(new_metadata)
}

/// Renombra un archivo gestionado sin cambiar su nombre físico opaco.
/// El contenido V2 se procesa chunk a chunk y se vuelve a sellar con la misma
/// Vault Key y el nuevo nombre visible. La operación conserva la ruta física
/// del `.opac` y evita materializar todo el contenido en memoria.
pub fn rename_file(
    vault_folder: &Path,
    opac_path: &Path,
    vault_key: &[u8; KEY_LEN],
    new_name: &str,
) -> Result<OpacMetadata, VaultFsError> {
    create_vault_folder(vault_folder)?;
    validate_vault_path(vault_folder, opac_path)?;
    ensure_safe_regular_file(opac_path)?;
    if opac_path.extension().and_then(|e| e.to_str()) != Some(OPAC_EXTENSION)
        || opac_path.file_name().and_then(|n| n.to_str()) == Some(FOLDER_MARKER_FILENAME)
    {
        return Err(VaultFsError::InvalidVaultPath);
    }
    validate_visible_name(new_name)?;

    let version = peek_opac_version(opac_path)?;
    let parent = opac_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;

    if version == opac_format::OPAC_VERSION {
        let mut source = open_safe_regular_file(opac_path)?;
        let current = opac_format::read_metadata_only(vault_key, &mut source)?;
        source.seek(SeekFrom::Start(0))?;
        if current.original_name != new_name
            && visible_name_exists_in_folder_except(parent, vault_key, new_name, Some(opac_path))?
        {
            return Err(VaultFsError::DestinationExists);
        }
        if current.original_name == new_name {
            return Ok(current);
        }
        let metadata = OpacMetadata {
            original_name: new_name.to_owned(),
            original_size: current.original_size,
            created_unix: current.created_unix,
            modified_unix: Some(unix_now()),
        };
        let (tmp_path, mut tmp_file) = create_unique_temp_file(opac_path, "rename")?;
        let outcome = opac_format::rewrite_v2_metadata(
            vault_key,
            metadata.clone(),
            &mut source,
            &mut tmp_file,
        );
        if let Err(error) = outcome {
            let _ = fs::remove_file(&tmp_path);
            return Err(VaultFsError::Opac(error));
        }
        tmp_file.sync_all()?;
        drop(tmp_file);
        drop(source);
        publish_temp_replacement(&tmp_path, opac_path, "rename")?;
        return Ok(metadata);
    }

    if version != opac_format::OPAC_VERSION_LEGACY_V1 {
        return Err(VaultFsError::Opac(OpacError::UnsupportedVersion(version)));
    }

    let data = read_bounded_file(opac_path, opac_format::MAX_LEGACY_V1_FILE_SIZE)?;
    let decrypted = opac_format::decrypt(vault_key, &data)?;
    if decrypted.metadata.original_name != new_name
        && visible_name_exists_in_folder_except(parent, vault_key, new_name, Some(opac_path))?
    {
        return Err(VaultFsError::DestinationExists);
    }
    if decrypted.metadata.original_name == new_name {
        return Ok(decrypted.metadata);
    }
    let content = decrypted.content;
    let metadata = OpacMetadata {
        original_name: new_name.to_owned(),
        original_size: content.len() as u64,
        created_unix: decrypted.metadata.created_unix,
        modified_unix: Some(unix_now()),
    };
    replace_encrypted_file(opac_path, vault_key, metadata.clone(), &content)?;
    Ok(metadata)
}

/// Renombra una carpeta gestionada cambiando únicamente su marcador cifrado.
/// La carpeta física y todo su contenido permanecen en la misma ubicación.
pub fn rename_folder(
    vault_folder: &Path,
    folder_path: &Path,
    vault_key: &[u8; KEY_LEN],
    new_name: &str,
) -> Result<OpacMetadata, VaultFsError> {
    validate_vault_path(vault_folder, folder_path)?;
    if folder_path == vault_folder {
        return Err(VaultFsError::InvalidVaultPath);
    }
    ensure_safe_directory(folder_path)?;
    validate_visible_name(new_name)?;
    let parent = folder_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    let current = read_folder_metadata(folder_path, vault_key)?;
    if current.original_name != new_name
        && visible_name_exists_in_folder_except(parent, vault_key, new_name, Some(folder_path))?
    {
        return Err(VaultFsError::DestinationExists);
    }
    let metadata = OpacMetadata {
        original_name: new_name.to_owned(),
        original_size: 0,
        created_unix: current.created_unix,
        modified_unix: Some(unix_now()),
    };
    replace_encrypted_file(
        &folder_marker_path(folder_path),
        vault_key,
        metadata.clone(),
        &[],
    )?;
    Ok(metadata)
}

fn replace_encrypted_file(
    output_path: &Path,
    vault_key: &[u8; KEY_LEN],
    metadata: OpacMetadata,
    content: &[u8],
) -> Result<(), VaultFsError> {
    let (tmp_path, mut tmp_file) = create_unique_temp_file(output_path, "rename")?;
    let outcome = (|| -> Result<(), VaultFsError> {
        opac_format::encrypt_v2_auto(
            vault_key,
            metadata,
            &mut io::Cursor::new(content),
            &mut tmp_file,
        )?;
        tmp_file.sync_all()?;
        Ok(())
    })();
    if let Err(error) = outcome {
        let _ = fs::remove_file(&tmp_path);
        return Err(error);
    }
    drop(tmp_file);

    publish_temp_replacement(&tmp_path, output_path, "rename")
}

fn publish_temp_replacement(
    tmp_path: &Path,
    output_path: &Path,
    purpose: &str,
) -> Result<(), VaultFsError> {
    let parent = output_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    let base = output_path
        .file_name()
        .map(|name| name.to_string_lossy().to_string())
        .ok_or(VaultFsError::InvalidVaultPath)?;
    let backup_path = {
        let mut selected = None;
        for _ in 0..TEMP_ATTEMPTS {
            let candidate = parent.join(format!(
                ".{base}.backup-{}-{purpose}.bak",
                crypto::random_file_id()
                    .iter()
                    .map(|b| format!("{b:02x}"))
                    .collect::<String>()
            ));
            if !path_exists_including_symlink(&candidate) {
                selected = Some(candidate);
                break;
            }
        }
        selected.ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::AlreadyExists,
                "no se pudo reservar un backup temporal unico",
            )
        })?
    };

    fs::rename(output_path, &backup_path)?;
    if let Err(error) = fs::rename(tmp_path, output_path) {
        let _ = fs::rename(&backup_path, output_path);
        let _ = fs::remove_file(tmp_path);
        return Err(VaultFsError::Io(error));
    }
    if let Err(error) = fs::remove_file(&backup_path) {
        sync_folder(parent);
        return Err(VaultFsError::Io(error));
    }
    sync_folder(parent);
    Ok(())
}

/// Copia un archivo V1 legacy a un nuevo `.opac` V2 y, solo después de
/// haber sellado y sincronizado el V2, elimina el V1. Devuelve la nueva ruta.
///
/// No reemplaza el archivo antiguo en caliente: así, ante un corte de luz o
/// un error de sistema, el V1 original sigue disponible y el V2 válido queda
/// como copia adicional. Esto es más seguro y portable que depender de un
/// "rename-and-replace" atómico, que no tiene la misma semántica en Windows
/// y Unix mediante la API estándar de Rust.
pub fn migrate_legacy_v1_file(
    opac_path: &Path,
    vault_folder: &Path,
    vault_key: &[u8; KEY_LEN],
) -> Result<PathBuf, VaultFsError> {
    validate_vault_path(vault_folder, opac_path)?;
    ensure_safe_regular_file(opac_path)?;
    if peek_opac_version(opac_path)? != opac_format::OPAC_VERSION_LEGACY_V1 {
        return Ok(opac_path.to_path_buf());
    }

    create_vault_folder(vault_folder)?;
    let data = read_bounded_file(opac_path, opac_format::MAX_LEGACY_V1_FILE_SIZE)?;
    let decrypted = opac_format::decrypt(vault_key, &data)?;
    let target_folder = opac_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    ensure_safe_target_folder(vault_folder, target_folder)?;
    // El propio V1 que estamos migrando ya ocupa el nombre visible; no debe
    // bloquear su propia sustitucion. Solo cuentan otros hermanos.
    if visible_name_exists_in_folder_except(
        target_folder,
        vault_key,
        &decrypted.metadata.original_name,
        Some(opac_path),
    )? {
        return Err(VaultFsError::DestinationExists);
    }

    let disk_id = crypto::random_file_id();
    let final_path = target_folder.join(opaque_filename(&disk_id));
    let (tmp_path, mut tmp_file) = create_unique_temp_file(&final_path, "migrate")?;

    let outcome = (|| -> Result<(), VaultFsError> {
        opac_format::encrypt_v2_auto(
            vault_key,
            decrypted.metadata,
            &mut std::io::Cursor::new(decrypted.content.as_slice()),
            &mut tmp_file,
        )?;
        tmp_file.sync_all()?;
        Ok(())
    })();

    match outcome {
        Ok(()) => {
            drop(tmp_file);
            fs::rename(&tmp_path, &final_path)?;
            if let Err(e) = fs::remove_file(opac_path) {
                let _ = fs::remove_file(&final_path);
                sync_folder(target_folder);
                return Err(VaultFsError::Io(e));
            }
            sync_folder(target_folder);
            Ok(final_path)
        }
        Err(e) => {
            let _ = fs::remove_file(&tmp_path);
            Err(e)
        }
    }
}

/// Elimina un `.opac` validado y sincroniza el directorio en Unix cuando
/// el sistema lo permite. En Windows la API estandar no expone un equivalente
/// portable de sync del directorio, por lo que el borrado se considera
/// confirmado cuando la operacion de filesystem termina correctamente.
pub fn delete_vault_file(vault_folder: &Path, opac_path: &Path) -> Result<(), VaultFsError> {
    validate_vault_path(vault_folder, opac_path)?;
    if opac_path.extension().and_then(|e| e.to_str()) != Some(OPAC_EXTENSION) {
        return Err(VaultFsError::InvalidVaultPath);
    }
    ensure_safe_regular_file(opac_path)?;
    let parent = opac_path.parent().ok_or(VaultFsError::InvalidVaultPath)?;
    fs::remove_file(opac_path)?;
    sync_folder(parent);
    Ok(())
}

fn sync_folder(path: &Path) {
    #[cfg(unix)]
    {
        if let Ok(dir) = File::open(path) {
            let _ = dir.sync_all();
        }
    }

    #[cfg(not(unix))]
    {
        let _ = path;
    }
}

pub fn list_vault_files(vault_folder: &Path) -> Result<Vec<PathBuf>, VaultFsError> {
    ensure_safe_directory(vault_folder)?;
    let mut out = Vec::new();
    collect_managed_files(vault_folder, &mut out)?;
    out.sort();
    Ok(out)
}

fn collect_managed_files(current: &Path, out: &mut Vec<PathBuf>) -> Result<(), VaultFsError> {
    for entry in fs::read_dir(current)? {
        let entry = entry?;
        let path = entry.path();
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            continue;
        }
        if file_type.is_file()
            && path.extension().and_then(|e| e.to_str()) == Some(OPAC_EXTENSION)
            && ensure_safe_regular_file(&path).is_ok()
        {
            if path.file_name().and_then(|n| n.to_str()) != Some(FOLDER_MARKER_FILENAME) {
                out.push(path);
            }
            continue;
        }
        if file_type.is_dir() {
            ensure_safe_directory(&path)?;
            if path_exists_including_symlink(&folder_marker_path(&path)) {
                collect_managed_files(&path, out)?;
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::modules::crypto::random_key;
    use uuid::Uuid;

    fn temp_dir_for_test() -> PathBuf {
        std::env::temp_dir().join(format!("opac_vault_fs_test_{}", Uuid::new_v4()))
    }

    fn temp_root() -> PathBuf {
        temp_dir_for_test()
    }

    #[test]
    fn create_vault_folder_is_idempotent() {
        let dir = temp_dir_for_test();
        create_vault_folder(&dir).unwrap();
        create_vault_folder(&dir).unwrap();
        assert!(dir.is_dir());
        fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn new_files_are_always_v2() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("secreto.txt");
        fs::write(&source, b"contenido confidencial de prueba").unwrap();
        let key = crypto::random_key();

        let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();
        assert_eq!(
            peek_opac_version(&opac_path).unwrap(),
            opac_format::OPAC_VERSION
        );

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn small_files_are_v2_without_chunking_many_blocks() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("pequeno.txt");
        fs::write(&source, b"contenido pequeno").unwrap();
        let key = crypto::random_key();

        let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();
        let blob = fs::read(&opac_path).unwrap();
        let chunk_size = u32::from_le_bytes(blob[32..36].try_into().unwrap());
        assert_eq!(chunk_size as u64, fs::metadata(&source).unwrap().len());

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn migrate_legacy_v1_to_v2_preserves_content_and_key() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        fs::create_dir_all(&vault_folder).unwrap();
        let old_path = vault_folder.join("legacy.opac");
        let key = crypto::random_key();
        let content = b"contenido legacy que debe migrarse";
        let metadata = OpacMetadata {
            original_name: "legacy.txt".to_string(),
            original_size: content.len() as u64,
            created_unix: Some(1_700_000_000),
            modified_unix: Some(1_700_000_100),
        };

        let file_id = crypto::random_file_id();
        let nonce = crypto::random_nonce();
        let header = opac_format::OPAC_MAGIC.to_vec();
        let mut header = header;
        header.extend_from_slice(&opac_format::OPAC_VERSION_LEGACY_V1.to_le_bytes());
        header.extend_from_slice(&0u16.to_le_bytes());
        header.extend_from_slice(&file_id);
        header.extend_from_slice(&nonce);

        let metadata_bytes = {
            let mut out = Vec::new();
            out.extend_from_slice(&(metadata.original_name.len() as u64).to_le_bytes());
            out.extend_from_slice(metadata.original_name.as_bytes());
            out.extend_from_slice(&metadata.original_size.to_le_bytes());
            match metadata.created_unix {
                None => out.push(0),
                Some(value) => {
                    out.push(1);
                    out.extend_from_slice(&value.to_le_bytes());
                }
            }
            match metadata.modified_unix {
                None => out.push(0),
                Some(value) => {
                    out.push(1);
                    out.extend_from_slice(&value.to_le_bytes());
                }
            }
            out
        };
        let mut inner = Vec::with_capacity(4 + metadata_bytes.len() + content.len());
        inner.extend_from_slice(&(metadata_bytes.len() as u32).to_le_bytes());
        inner.extend_from_slice(&metadata_bytes);
        inner.extend_from_slice(content);
        let sealed = crypto::seal(&key, &nonce, &header, &inner).unwrap();

        let mut blob = header;
        blob.extend_from_slice(&(sealed.len() as u32).to_le_bytes());
        blob.extend_from_slice(&sealed);
        fs::write(&old_path, &blob).unwrap();

        assert_eq!(
            peek_opac_version(&old_path).unwrap(),
            opac_format::OPAC_VERSION_LEGACY_V1
        );
        let migrated = migrate_legacy_v1_file(&old_path, &vault_folder, &key).unwrap();

        assert!(!old_path.exists());
        assert_ne!(migrated, old_path);
        assert_eq!(
            peek_opac_version(&migrated).unwrap(),
            opac_format::OPAC_VERSION
        );

        let recovered = opac_format::decrypt(&key, &fs::read(&migrated).unwrap()).unwrap();
        assert_eq!(recovered.metadata, metadata);
        assert_eq!(recovered.content.as_slice(), content);

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn renaming_file_preserves_content_and_opaque_disk_path() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("antes.txt");
        let content = b"contenido que debe permanecer igual";
        fs::write(&source, content).unwrap();
        let key = crypto::random_key();

        let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();
        let before_path = opac_path.clone();
        let metadata = rename_file(&vault_folder, &opac_path, &key, "despues.txt").unwrap();

        assert_eq!(opac_path, before_path);
        assert_eq!(metadata.original_name, "despues.txt");
        let recovered = opac_format::decrypt(&key, &fs::read(&opac_path).unwrap()).unwrap();
        assert_eq!(recovered.metadata.original_name, "despues.txt");
        assert_eq!(recovered.content.as_slice(), content);

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn renaming_folder_preserves_children_and_disk_path() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let key = crypto::random_key();
        create_vault_folder(&vault_folder).unwrap();
        let folder = create_folder(&vault_folder, &vault_folder, "Vieja", &key).unwrap();
        let source = base.join("nota.md");
        fs::write(&source, b"hola").unwrap();
        let child = encrypt_file_into_vault_folder(&vault_folder, &folder, &key, &source).unwrap();
        let child_before = fs::read(&child).unwrap();

        let marker_path = folder_marker_path(&folder);
        rename_folder(&vault_folder, &folder, &key, "Nueva").unwrap();

        assert!(folder.exists());
        assert_eq!(
            read_folder_metadata(&folder, &key).unwrap().original_name,
            "Nueva"
        );
        assert_eq!(fs::read(&child).unwrap(), child_before);

        fs::remove_dir_all(&base).ok();
        assert!(!marker_path.exists());
    }

    #[test]
    fn replace_file_content_preserves_path_and_writes_new_ciphertext() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("secreto.txt");
        fs::write(&source, b"contenido antiguo confidencial").unwrap();
        let key = crypto::random_key();

        let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();
        let before = fs::read(&opac_path).unwrap();
        let metadata = replace_file_content(
            &vault_folder,
            &opac_path,
            &key,
            b"contenido nuevo confidencial",
        )
        .unwrap();

        assert_eq!(metadata.original_name, "secreto.txt");
        assert_eq!(
            metadata.original_size,
            b"contenido nuevo confidencial".len() as u64
        );
        assert!(opac_path.exists());
        let after = fs::read(&opac_path).unwrap();
        assert_ne!(before, after);
        assert!(
            !after
                .windows(b"contenido nuevo confidencial".len())
                .any(|w| w == b"contenido nuevo confidencial")
        );

        let destination = base.join("salida.txt");
        let recovered = decrypt_file_from_vault(&opac_path, &key, &destination).unwrap();
        assert_eq!(recovered.original_name, "secreto.txt");
        assert_eq!(
            fs::read(destination).unwrap(),
            b"contenido nuevo confidencial"
        );

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn replace_file_content_rejects_invalid_path_without_touching_ciphertext() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("secreto.txt");
        fs::write(&source, b"contenido antiguo").unwrap();
        let key = crypto::random_key();
        let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();
        let before = fs::read(&opac_path).unwrap();

        assert!(matches!(
            replace_file_content(&vault_folder, &source, &key, b"no tocar"),
            Err(VaultFsError::InvalidVaultPath)
        ));
        assert_eq!(fs::read(&opac_path).unwrap(), before);

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn roundtrip_small_file() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("secreto.txt");
        fs::write(&source, b"contenido confidencial de prueba").unwrap();
        let key = crypto::random_key();
        let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();

        let dest = base.join("recuperado.txt");
        let metadata = decrypt_file_from_vault(&opac_path, &key, &dest).unwrap();
        assert_eq!(metadata.original_name, "secreto.txt");
        assert_eq!(
            fs::read(&dest).unwrap(),
            b"contenido confidencial de prueba"
        );
        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn wrong_key_leaves_no_partial_destination_file() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("secreto.txt");
        fs::write(&source, b"contenido confidencial").unwrap();
        let key = crypto::random_key();
        let other_key = crypto::random_key();
        let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();
        let dest = base.join("no_deberia_existir.txt");
        assert!(decrypt_file_from_vault(&opac_path, &other_key, &dest).is_err());
        assert!(!dest.exists());
        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn existing_destination_is_not_overwritten() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("secreto.txt");
        fs::write(&source, b"contenido").unwrap();
        let key = crypto::random_key();
        let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();
        let dest = base.join("dest.txt");
        fs::write(&dest, b"no tocar").unwrap();
        assert!(matches!(
            decrypt_file_from_vault(&opac_path, &key, &dest),
            Err(VaultFsError::DestinationExists)
        ));
        assert_eq!(fs::read(&dest).unwrap(), b"no tocar");
        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn dangling_destination_symlink_is_not_overwritten_on_unix() {
        #[cfg(unix)]
        {
            use std::os::unix::fs::symlink;

            let base = temp_dir_for_test();
            fs::create_dir_all(&base).unwrap();
            let vault_folder = base.join("caja");
            let source = base.join("secreto.txt");
            let destination = base.join("dest.txt");
            let target = base.join("target.txt");
            fs::write(&source, b"contenido").unwrap();
            symlink(&target, &destination).unwrap();
            let key = crypto::random_key();
            let opac_path = encrypt_file_into_vault(&vault_folder, &key, &source).unwrap();

            assert!(matches!(
                decrypt_file_from_vault(&opac_path, &key, &destination),
                Err(VaultFsError::DestinationExists)
            ));
            assert!(destination.is_symlink());
            assert!(!target.exists());
            fs::remove_dir_all(&base).ok();
        }
    }

    #[cfg(unix)]
    #[test]
    fn symlink_opac_is_not_listed_or_deleted() {
        use std::os::unix::fs::symlink;

        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        fs::create_dir_all(&vault_folder).unwrap();
        let outside = base.join("outside.opac");
        let link = vault_folder.join("fake.opac");
        fs::write(&outside, b"no tocar").unwrap();
        symlink(&outside, &link).unwrap();

        assert!(list_vault_files(&vault_folder).unwrap().is_empty());
        let key = crypto::random_key();
        assert!(matches!(
            delete_vault_file(&vault_folder, &link),
            Err(VaultFsError::UnsafeFilesystemEntry)
        ));
        assert!(outside.exists());
        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn list_vault_files_ignores_non_opac_entries() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        fs::write(base.join("notas.txt"), b"no es un .opac").unwrap();
        let source = base.join("secreto.txt");
        fs::write(&source, b"contenido").unwrap();
        let key = crypto::random_key();
        encrypt_file_into_vault(&base, &key, &source).unwrap();
        let files = list_vault_files(&base).unwrap();
        assert_eq!(files.len(), 1);
        assert_eq!(files[0].extension().and_then(|e| e.to_str()), Some("opac"));
        fs::remove_dir_all(&base).ok();
    }
    #[test]
    fn validate_vault_access_requires_the_correct_key() {
        let root = std::env::temp_dir().join(format!("opac_validate_key_{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let vault = root.join("vault");
        let source = root.join("secreto.txt");
        fs::write(&source, b"solo con la clave correcta").unwrap();

        let key = random_key();
        create_vault_folder(&vault).unwrap();
        let folder = create_folder(&vault, &vault, "Nivel 1", &key).unwrap();
        encrypt_file_into_vault_folder(&vault, &folder, &key, &source).unwrap();
        validate_vault_access(&vault, &key).unwrap();

        let mut wrong = key;
        wrong[31] ^= 0xa5;
        assert!(validate_vault_access(&vault, &wrong).is_err());

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn validate_vault_access_accepts_authenticated_folder_markers() {
        let root = std::env::temp_dir().join(format!("opac_validate_marker_{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let vault = root.join("vault");
        let key = crypto::random_key();
        create_vault_folder(&vault).unwrap();
        let nested = create_folder(&vault, &vault, "Nivel 1", &key).unwrap();
        let deeper = create_folder(&vault, &nested, "Nivel 2", &key).unwrap();
        create_folder(&vault, &deeper, "Nivel 3", &key).unwrap();

        validate_vault_access(&vault, &key).unwrap();

        let root_marker = folder_marker_path(&vault);
        fs::write(&root_marker, b"marker en raiz no gestionado").unwrap();
        assert!(matches!(
            validate_vault_access(&vault, &key),
            Err(VaultFsError::InvalidVaultPath)
        ));

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn folders_and_nested_files_roundtrip() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("foto.txt");
        fs::write(&source, b"archivo dentro de una carpeta").unwrap();
        let key = crypto::random_key();

        let folder = create_folder(&vault_folder, &vault_folder, "Documentos", &key).unwrap();
        let nested = create_folder(&vault_folder, &folder, "Notas", &key).unwrap();
        let imported =
            encrypt_file_into_vault_folder(&vault_folder, &nested, &key, &source).unwrap();

        let folders = list_vault_folders(&vault_folder, &key).unwrap();
        assert_eq!(folders.len(), 2);
        assert!(
            folders
                .iter()
                .any(|(path, meta)| path == &folder && meta.original_name == "Documentos")
        );
        assert!(
            folders
                .iter()
                .any(|(path, meta)| path == &nested && meta.original_name == "Notas")
        );

        let files = list_vault_files(&vault_folder).unwrap();
        assert_eq!(files, vec![imported.clone()]);
        let destination = base.join("recuperado.txt");
        let metadata = decrypt_file_from_vault(&imported, &key, &destination).unwrap();
        assert_eq!(metadata.original_name, "foto.txt");
        assert_eq!(
            fs::read(destination).unwrap(),
            b"archivo dentro de una carpeta"
        );

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn move_file_and_folder_out_of_nested_parent_preserves_ciphertext() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("nota.txt");
        fs::write(&source, b"contenido para mover fuera de una carpeta").unwrap();
        let key = crypto::random_key();

        let parent = create_folder(&vault_folder, &vault_folder, "Padre", &key).unwrap();
        let nested = create_folder(&vault_folder, &parent, "Hija", &key).unwrap();
        let sibling = create_folder(&vault_folder, &vault_folder, "Hermana", &key).unwrap();
        let file = encrypt_file_into_vault_folder(&vault_folder, &nested, &key, &source).unwrap();
        let ciphertext_before = fs::read(&file).unwrap();

        let moved_to_root = move_file(&vault_folder, &file, &vault_folder, &key).unwrap();
        assert_eq!(moved_to_root.parent(), Some(vault_folder.as_path()));
        assert_eq!(fs::read(&moved_to_root).unwrap(), ciphertext_before);

        let moved_back = move_file(&vault_folder, &moved_to_root, &sibling, &key).unwrap();
        assert_eq!(fs::read(&moved_back).unwrap(), ciphertext_before);

        let nested_marker_before = fs::read(nested.join(FOLDER_MARKER_FILENAME)).unwrap();
        let moved_folder = move_folder(&vault_folder, &nested, &sibling, &key).unwrap();
        assert_eq!(moved_folder.parent(), Some(sibling.as_path()));
        assert_eq!(
            fs::read(moved_folder.join(FOLDER_MARKER_FILENAME)).unwrap(),
            nested_marker_before
        );

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn move_file_and_folder_preserves_plaintext_identity() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let source = base.join("nota.txt");
        fs::write(&source, b"contenido que no debe alterarse al mover").unwrap();
        let key = crypto::random_key();

        let first = create_folder(&vault_folder, &vault_folder, "Primera", &key).unwrap();
        let second = create_folder(&vault_folder, &vault_folder, "Segunda", &key).unwrap();
        let file = encrypt_file_into_vault_folder(&vault_folder, &first, &key, &source).unwrap();
        let ciphertext_before_move = fs::read(&file).unwrap();
        let moved_file = move_file(&vault_folder, &file, &second, &key).unwrap();
        assert_eq!(moved_file.file_name(), file.file_name());
        assert!(!file.exists());
        assert_eq!(fs::read(&moved_file).unwrap(), ciphertext_before_move);

        let nested_target = create_folder(&vault_folder, &second, "Subcarpeta", &key).unwrap();
        let nested_name = nested_target.file_name().unwrap().to_os_string();
        let folder_marker_before_move = fs::read(second.join(FOLDER_MARKER_FILENAME)).unwrap();
        let moved_folder = move_folder(&vault_folder, &second, &first, &key).unwrap();
        assert_eq!(moved_folder.file_name(), second.file_name());
        assert!(moved_folder.join(".opac-folder").exists());
        let moved_nested_target = moved_folder.join(nested_name);
        assert!(moved_nested_target.join(".opac-folder").exists());
        assert_eq!(
            fs::read(moved_folder.join(FOLDER_MARKER_FILENAME)).unwrap(),
            folder_marker_before_move
        );
        assert!(moved_folder.join(moved_file.file_name().unwrap()).exists());

        let destination = base.join("recuperado.txt");
        decrypt_file_from_vault(
            &moved_folder.join(moved_file.file_name().unwrap()),
            &key,
            &destination,
        )
        .unwrap();
        assert_eq!(
            fs::read(destination).unwrap(),
            b"contenido que no debe alterarse al mover"
        );

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn sensitive_visible_names_are_not_exposed_at_rest() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let key = crypto::random_key();
        let secret_folder_name = "PRIVADO-9d8a7c1e";
        let secret_file_name = "PORNO-7c3b2a1f.pdf";
        let source = base.join(secret_file_name);
        fs::write(&source, b"contenido confidencial").unwrap();

        let folder = create_folder(&vault_folder, &vault_folder, secret_folder_name, &key).unwrap();
        let _file = encrypt_file_into_vault_folder(&vault_folder, &folder, &key, &source).unwrap();

        fn assert_tree_hides_name(path: &Path, forbidden_a: &[u8], forbidden_b: &[u8]) {
            for entry in fs::read_dir(path).unwrap() {
                let entry = entry.unwrap();
                let child = entry.path();
                let name_bytes = child
                    .file_name()
                    .and_then(|name| name.to_str())
                    .unwrap_or_default()
                    .as_bytes()
                    .to_vec();
                assert!(
                    !name_bytes
                        .windows(forbidden_a.len())
                        .any(|w| w == forbidden_a)
                );
                assert!(
                    !name_bytes
                        .windows(forbidden_b.len())
                        .any(|w| w == forbidden_b)
                );
                if child.is_dir() {
                    assert_tree_hides_name(&child, forbidden_a, forbidden_b);
                } else {
                    let bytes = fs::read(&child).unwrap();
                    assert!(!bytes.windows(forbidden_a.len()).any(|w| w == forbidden_a));
                    assert!(!bytes.windows(forbidden_b.len()).any(|w| w == forbidden_b));
                }
            }
        }

        assert_tree_hides_name(
            &vault_folder,
            secret_folder_name.as_bytes(),
            secret_file_name.as_bytes(),
        );
        assert!(!vault_folder.join(secret_folder_name).exists());
        assert!(folder.join(".opac-folder").exists());

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn moving_folder_rejects_duplicate_visible_name() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let key = crypto::random_key();

        let first_parent = create_folder(&vault_folder, &vault_folder, "Primera", &key).unwrap();
        let second_parent = create_folder(&vault_folder, &vault_folder, "Segunda", &key).unwrap();
        let _existing = create_folder(&vault_folder, &first_parent, "Documentos", &key).unwrap();
        let moving = create_folder(&vault_folder, &second_parent, "Documentos", &key).unwrap();

        assert!(matches!(
            move_folder(&vault_folder, &moving, &first_parent, &key),
            Err(VaultFsError::DestinationExists)
        ));
        assert!(moving.exists());

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn deleting_non_empty_folder_recursively_removes_all_managed_contents() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let key = crypto::random_key();
        let folder = create_folder(&vault_folder, &vault_folder, "Temporal", &key).unwrap();
        let child = create_folder(&vault_folder, &folder, "Hijo", &key).unwrap();
        let grandchild = create_folder(&vault_folder, &child, "Nieto", &key).unwrap();
        let source = base.join("secreto.txt");
        fs::write(&source, b"contenido confidencial").unwrap();
        let encrypted =
            encrypt_file_into_vault_folder(&vault_folder, &grandchild, &key, &source).unwrap();
        assert!(encrypted.exists());

        delete_folder(&vault_folder, &folder, &key).unwrap();

        assert!(!folder.exists());
        assert!(!child.exists());
        assert!(!grandchild.exists());
        assert!(!encrypted.exists());
        assert!(list_vault_files(&vault_folder).unwrap().is_empty());
        assert!(list_vault_folders(&vault_folder, &key).unwrap().is_empty());

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn copy_vault_root_preserves_ciphertext_and_authenticates_destination() {
        let root = temp_root();
        fs::create_dir_all(&root).unwrap();
        let source = root.join("source");
        let destination = root.join("destination");
        let key = random_key();
        create_vault_folder(&source).unwrap();
        let child = create_folder(&source, &source, "Nivel", &key).unwrap();
        let file_source = root.join("payload.txt");
        fs::write(&file_source, b"contenido secreto de prueba").unwrap();
        let opac = encrypt_file_into_vault(&source, &key, &file_source).unwrap();
        let original = fs::read(&opac).unwrap();

        copy_vault_root(&source, &destination, &key).unwrap();
        validate_vault_access(&destination, &key).unwrap();
        let copied_files = list_vault_files(&destination).unwrap();
        assert_eq!(copied_files.len(), 1);
        assert_eq!(fs::read(&copied_files[0]).unwrap(), original);
        let copied_folders = list_vault_folders(&destination, &key).unwrap();
        assert_eq!(copied_folders.len(), 1);
        assert_eq!(copied_folders[0].0.file_name(), child.file_name(),);

        fs::remove_dir_all(root).ok();
    }

    #[test]
    fn delete_vault_root_recursively_removes_authenticated_tree() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("vault");
        create_vault_folder(&vault_folder).unwrap();
        let key = crypto::random_key();
        let source = base.join("secreto.bin");
        fs::write(&source, b"contenido confidencial de la caja completa").unwrap();

        let level1 = create_folder(&vault_folder, &vault_folder, "Nivel1", &key).unwrap();
        let level2 = create_folder(&vault_folder, &level1, "Nivel2", &key).unwrap();
        let _opac = encrypt_file_into_vault_folder(&vault_folder, &level2, &key, &source).unwrap();
        assert!(level2.exists());
        assert!(list_vault_files(&vault_folder).unwrap().len() == 1);

        delete_vault_root(&vault_folder, &key).unwrap();
        assert!(!vault_folder.exists());

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn delete_folder_recursively_removes_nested_contents_only_after_validation() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let key = crypto::random_key();
        let root = create_folder(&vault_folder, &vault_folder, "Borrar", &key).unwrap();
        let child = create_folder(&vault_folder, &root, "Hijo", &key).unwrap();
        let source = base.join("secreto.txt");
        fs::write(
            &source,
            b"contenido privado que debe desaparecer de la caja",
        )
        .unwrap();
        let nested_file =
            encrypt_file_into_vault_folder(&vault_folder, &child, &key, &source).unwrap();
        assert!(nested_file.exists());
        assert!(root.exists());
        delete_folder(&vault_folder, &root, &key).unwrap();
        assert!(!root.exists());
        assert!(list_vault_files(&vault_folder).unwrap().is_empty());
        assert!(list_vault_folders(&vault_folder, &key).unwrap().is_empty());
        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn export_folder_recursively_preserves_structure_and_content() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let export_parent = base.join("exportado");
        fs::create_dir_all(&export_parent).unwrap();
        let key = crypto::random_key();
        let root = create_folder(&vault_folder, &vault_folder, "Proyecto", &key).unwrap();
        let child = create_folder(&vault_folder, &root, "Notas", &key).unwrap();
        let deeper = create_folder(&vault_folder, &child, "Privado", &key).unwrap();

        let txt = base.join("nota.txt");
        let md = base.join("manual.md");
        fs::write(&txt, b"texto de prueba").unwrap();
        fs::write(&md, b"# Markdown\ncontenido").unwrap();
        let encrypted_txt =
            encrypt_file_into_vault_folder(&vault_folder, &root, &key, &txt).unwrap();
        let encrypted_md =
            encrypt_file_into_vault_folder(&vault_folder, &deeper, &key, &md).unwrap();
        let txt_ciphertext_before = fs::read(&encrypted_txt).unwrap();
        let md_ciphertext_before = fs::read(&encrypted_md).unwrap();

        let (files, folders) =
            export_folder_to_directory(&vault_folder, &root, &export_parent, &key).unwrap();
        assert_eq!(files, 2);
        assert_eq!(folders, 3);
        assert_eq!(
            fs::read(export_parent.join("Proyecto").join("nota.txt")).unwrap(),
            b"texto de prueba"
        );
        assert_eq!(
            fs::read(
                export_parent
                    .join("Proyecto")
                    .join("Notas")
                    .join("Privado")
                    .join("manual.md")
            )
            .unwrap(),
            b"# Markdown\ncontenido"
        );
        assert!(
            !export_parent
                .join("Proyecto")
                .join("nota.txt")
                .extension()
                .is_some_and(|e| e == "opac")
        );
        assert_eq!(fs::read(&encrypted_txt).unwrap(), txt_ciphertext_before);
        assert_eq!(fs::read(&encrypted_md).unwrap(), md_ciphertext_before);
        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn export_folder_refuses_destination_inside_vault() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let key = crypto::random_key();
        let root = create_folder(&vault_folder, &vault_folder, "Proyecto", &key).unwrap();
        assert!(matches!(
            export_folder_to_directory(&vault_folder, &root, &vault_folder, &key),
            Err(VaultFsError::InvalidVaultPath)
        ));
        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn delete_folder_tree_defensively_rejects_unmanaged_files() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let folder = base.join("folder");
        fs::create_dir_all(&folder).unwrap();
        let marker = folder.join(FOLDER_MARKER_FILENAME);
        fs::write(&marker, b"marker").unwrap();
        let unmanaged = folder.join("not-managed.txt");
        fs::write(&unmanaged, b"must survive").unwrap();

        assert!(matches!(
            delete_folder_tree(&folder),
            Err(VaultFsError::InvalidVaultPath)
        ));
        assert!(unmanaged.exists());
        assert!(folder.exists());

        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn delete_folder_refuses_unmanaged_plaintext_entries_without_partial_delete() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let key = crypto::random_key();
        let folder = create_folder(&vault_folder, &vault_folder, "Protegida", &key).unwrap();
        let child = create_folder(&vault_folder, &folder, "Interna", &key).unwrap();
        let unexpected = child.join("no-deberia-estar-en-claro.txt");
        fs::write(&unexpected, b"dato sensible").unwrap();

        assert!(matches!(
            delete_folder(&vault_folder, &folder, &key),
            Err(VaultFsError::InvalidVaultPath)
        ));
        assert!(folder.exists());
        assert!(child.exists());
        assert_eq!(fs::read(&unexpected).unwrap(), b"dato sensible");
        fs::remove_dir_all(&base).ok();
    }

    #[test]
    fn export_folder_refuses_unmanaged_plaintext_entries_without_partial_export() {
        let base = temp_dir_for_test();
        fs::create_dir_all(&base).unwrap();
        let vault_folder = base.join("caja");
        let export_parent = base.join("destino");
        fs::create_dir_all(&export_parent).unwrap();
        let key = crypto::random_key();
        let folder = create_folder(&vault_folder, &vault_folder, "Exportar", &key).unwrap();
        let unexpected = folder.join("plaintext-nota.txt");
        fs::write(&unexpected, b"no exportes esto").unwrap();

        assert!(matches!(
            export_folder_to_directory(&vault_folder, &folder, &export_parent, &key),
            Err(VaultFsError::InvalidVaultPath)
        ));
        assert!(!export_parent.join("Exportar").exists());
        fs::remove_dir_all(&base).ok();
    }
}
