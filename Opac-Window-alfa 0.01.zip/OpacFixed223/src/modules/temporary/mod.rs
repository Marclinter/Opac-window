//! Infraestructura de apoyo para descifrados temporales.
//!
//! La materializacion concreta de plaintext para previsualizaciones reside en
//! `gui.rs` y `vault_fs`: usa carpetas por sesion, permisos restrictivos en
//! sistemas que los soportan, marcadores de proceso y limpieza de sesiones
//! huerfanas. Este modulo conserva el punto conceptual de documentacion para
//! no duplicar la logica de acceso al formato `.opac`.
