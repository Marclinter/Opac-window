//! Importacion de Vault Keys exportadas con `modules::export` (README,
//! seccion 18, funcionalidad implementada: "Importacion de claves", "Validacion de
//! archivos de transferencia").
//!
//! Antes de confiar en NADA del contenido de un `.opackey`, se verifica su
//! autenticacion (mismo principio que en `opac_format` y `vault`: fallo de
//! autenticacion => rechazo total, nunca un dato parcial). Igual que en
//! `export`, la derivacion de la clave a partir de la contrasena de
//! exportacion reutiliza `master_key::derive_master_key` en vez de
//! reimplementar Argon2id aqui.

use thiserror::Error;
use uuid::Uuid;
use zeroize::Zeroizing;

use crate::modules::crypto::{self, CryptoError, NONCE_LEN};
use crate::modules::export::{
    self, ExportedVaultBody, OPACKEY_MAGIC, OPACKEY_VERSION, OPACKEY_VERSION_LEGACY_V1,
};
use crate::modules::keys::VaultKey;
use crate::modules::master_key::{Argon2Params, MasterKeyError, SALT_LEN, derive_master_key};
use crate::modules::serialization::legacy_bincode::Reader as LegacyReader;

#[derive(Debug, Error)]
pub enum ImportError {
    #[error(transparent)]
    Crypto(#[from] CryptoError),
    #[error(transparent)]
    MasterKey(#[from] MasterKeyError),
    #[error("no es un archivo .opackey valido (magic incorrecto)")]
    BadMagic,
    #[error("version de .opackey no soportada: {0}")]
    UnsupportedVersion(u16),
    #[error("el archivo .opackey esta truncado o es demasiado corto")]
    Truncated,
    #[error("los datos importados estan corruptos")]
    Corrupt,
}

fn decode_legacy_exported_body(data: &[u8]) -> Result<ExportedVaultBody, ImportError> {
    let mut reader = LegacyReader::new(data);
    let vault_id = reader.uuid().map_err(|_| ImportError::Corrupt)?;
    let vault_name = reader.string(4096).map_err(|_| ImportError::Corrupt)?;
    let vault_key = reader.fixed::<32>().map_err(|_| ImportError::Corrupt)?;
    reader.finish().map_err(|_| ImportError::Corrupt)?;
    Ok(ExportedVaultBody {
        vault_id,
        vault_name,
        vault_key,
    })
}

/// Resultado de importar un archivo `.opackey`: la Caja Fuerte que
/// describia (id y nombre originales en el dispositivo de origen) y su
/// Vault Key, lista para registrarse en el `KeyStore` local (README,
/// seccion 18: anadir la Caja Fuerte importada sin modificar ninguna
/// Caja Fuerte existente).
pub struct ImportedVault {
    pub vault_id: Uuid,
    pub vault_name: String,
    pub vault_key: VaultKey,
}

/// Verifica y descifra un archivo `.opackey`, devolviendo la Caja Fuerte
/// que describia. Si la contrasena de exportacion es incorrecta, o el
/// archivo ha sido manipulado o truncado, se rechaza por completo.
pub fn import_vault_key(data: &[u8], export_password: &[u8]) -> Result<ImportedVault, ImportError> {
    const FIXED_LEN: usize = 4 + 2 + SALT_LEN + 4 + 4 + 4 + NONCE_LEN;
    const MAX_EXPORT_SEALED_LEN: usize = 64 * 1024;
    const MAX_EXPORT_NAME_LEN: usize = 4096;
    const MAX_EXPORT_FILE_SIZE: usize = FIXED_LEN + 4 + MAX_EXPORT_SEALED_LEN;
    if data.len() < FIXED_LEN + 4 {
        return Err(ImportError::Truncated);
    }
    if data.len() > MAX_EXPORT_FILE_SIZE {
        return Err(ImportError::Corrupt);
    }

    let mut pos = 0usize;
    if &data[0..4] != OPACKEY_MAGIC {
        return Err(ImportError::BadMagic);
    }
    pos += 4;

    let version = u16::from_le_bytes([data[pos], data[pos + 1]]);
    pos += 2;
    if version != OPACKEY_VERSION && version != OPACKEY_VERSION_LEGACY_V1 {
        return Err(ImportError::UnsupportedVersion(version));
    }
    if version == OPACKEY_VERSION {
        export::validate_export_password(export_password).map_err(|_| ImportError::Corrupt)?;
    }

    let mut salt = [0u8; SALT_LEN];
    salt.copy_from_slice(&data[pos..pos + SALT_LEN]);
    pos += SALT_LEN;

    let memory_kib = u32::from_le_bytes([data[pos], data[pos + 1], data[pos + 2], data[pos + 3]]);
    pos += 4;
    let iterations = u32::from_le_bytes([data[pos], data[pos + 1], data[pos + 2], data[pos + 3]]);
    pos += 4;
    let parallelism = u32::from_le_bytes([data[pos], data[pos + 1], data[pos + 2], data[pos + 3]]);
    pos += 4;
    let params = Argon2Params {
        memory_kib,
        iterations,
        parallelism,
    };

    let mut nonce = [0u8; NONCE_LEN];
    nonce.copy_from_slice(&data[pos..pos + NONCE_LEN]);
    pos += NONCE_LEN;

    let sealed_len = u32::from_le_bytes(
        data[pos..pos + 4]
            .try_into()
            .map_err(|_| ImportError::Truncated)?,
    ) as usize;
    pos += 4;
    if !(16..=MAX_EXPORT_SEALED_LEN).contains(&sealed_len) {
        return Err(ImportError::Corrupt);
    }
    if sealed_len > data.len().saturating_sub(pos) || pos + sealed_len != data.len() {
        return Err(ImportError::Truncated);
    }
    let sealed = &data[pos..pos + sealed_len];

    let export_key = derive_master_key(export_password, &salt, &params)?;

    let header = &data[0..FIXED_LEN];
    let plaintext = Zeroizing::new(crypto::open(export_key.as_bytes(), &nonce, header, sealed)?);

    if plaintext.len() > MAX_EXPORT_SEALED_LEN.saturating_sub(16) {
        return Err(ImportError::Corrupt);
    }
    let body = if version == OPACKEY_VERSION {
        let (body, remainder) = postcard::take_from_bytes::<ExportedVaultBody>(&plaintext)
            .map_err(|_| ImportError::Corrupt)?;
        if !remainder.is_empty() {
            return Err(ImportError::Corrupt);
        }
        body
    } else {
        decode_legacy_exported_body(&plaintext)?
    };
    if body.vault_name.is_empty() || body.vault_name.len() > MAX_EXPORT_NAME_LEN {
        return Err(ImportError::Corrupt);
    }

    // `ExportedVaultBody` implementa `Drop` para limpiar la Vault Key.
    // Por ello no podemos mover directamente `vault_name` fuera de `body`.
    // La cadena es un dato pequeño de metadata, así que hacemos una copia
    // y dejamos que `body` se destruya normalmente para ejecutar su limpieza.
    let vault_id = body.vault_id;
    let vault_name = body.vault_name.clone();
    let vault_key = VaultKey::from_bytes(body.vault_key);

    Ok(ImportedVault {
        vault_id,
        vault_name,
        vault_key,
    })
}
