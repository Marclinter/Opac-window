//! # opac_window_core
//!
//! Nucleo criptografico y de almacenamiento de **Opac Window**, extraido
//! del README del proyecto. Implementa las secciones 7 a 19 del diseno:
//!
//! - Cifrado de archivos con ChaCha20-Poly1305, en el formato binario
//!   versionado `.opac` (`modules::opac_format`). V2 es el formato canónico;
//!   V1 solo se conserva para lectura de archivos antiguos.
//! - Vault Key aleatoria de 256 bits por Caja Fuerte (`modules::keys`).
//! - Master Key derivada de la contrasena maestra con Argon2id
//!   (`modules::master_key`).
//! - Key Store cifrado y autenticado (`modules::vault`) que guarda el
//!   registro de Cajas Fuertes (nombre, ubicacion, Vault Key).
//! - Proteccion opcional de la Vault Key mediante PIN (`modules::pin`).
//! - Serialización Postcard para nuevas estructuras persistentes; lectores legacy acotados
//!   para los datos históricos que usaban bincode 1.x (`modules::serialization`).
//! - Formato V2 para todas las escrituras nuevas: un único chunk hasta 8 MiB
//!   y streaming por chunks para archivos mayores (`modules::opac_format`).
//! - La carpeta fisica de cada Caja Fuerte en disco: creacion, y
//!   cifrado/descifrado de archivos dentro de ella (`modules::vault_fs`).
//! - Persistencia crash-safe del Key Store (`modules::persistence`) y una API
//!   de sesiones para la GUI (`modules::session`), incluyendo la preferencia
//!   por Caja Fuerte de descifrar bajo demanda o preparar todos los archivos al abrir.
//! - Exportacion/importacion de Vault Keys entre dispositivos
//!   (`modules::export`, `modules::import`, funcionalidad implementada).
//!
//! Limitaciones deliberadas:
//! - El descifrado para abrir archivos con aplicaciones externas se realiza
//!   mediante copias temporales gestionadas por la GUI. El borrado seguro de
//!   plaintext en SSD no puede garantizarse de forma portable.
//! - La GUI nativa vive en el binario `opac_window` y consume este crate; no
//!   duplica lógica criptográfica.
//!
//! La GUI no debe implementar lógica criptográfica propia: todo pasa por los
//! tipos públicos de este crate.

#[cfg(all(windows, target_env = "msvc", not(target_feature = "crt-static")))]
compile_error!(
    "Opac Window requires the static MSVC CRT; build Windows/MSVC targets with target-feature=+crt-static"
);

pub mod modules;

// Reexports comodos para quien use esta libreria desde fuera (por ejemplo,
// la futura GUI) sin tener que escribir la ruta completa cada vez.
pub use modules::export::ExportError;
pub use modules::import::{ImportError, ImportedVault};
pub use modules::keys::VaultKey;
pub use modules::master_key::{Argon2Params, MasterKey};
pub use modules::opac_format::{
    DEFAULT_CHUNK_SIZE, DEFAULT_CHUNKING_THRESHOLD, OPAC_VERSION, OPAC_VERSION_LEGACY_V1,
    OpacError, OpacMetadata,
};
pub use modules::persistence::{KeyStoreFile, PersistenceError};
pub use modules::profiles::{ProfileCatalog, ProfileError, ProfileRecord, ProfileStorage};
pub use modules::session::{KeyStoreSession, SessionError, VaultSession};
pub use modules::vault::{KeyStore, VaultAccessMode, VaultError, VaultInfo};
pub use modules::vault_fs::{CHUNKED_THRESHOLD, VaultFsError};
