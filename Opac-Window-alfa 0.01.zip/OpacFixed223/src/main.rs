#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod embedded_guard;
mod gui;
#[cfg(target_os = "windows")]
mod video_preview;

fn main() -> eframe::Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    if let Some(code) =
        opac_guard::handle_embedded_admin_command(&args, embedded_guard::OPAC_GUARD_EXE)
    {
        std::process::exit(code);
    }

    let icon = eframe::icon_data::from_png_bytes(include_bytes!("../assets/opac_window.png"))
        .expect("Opac Window icon must be a valid embedded PNG");

    let native_options = eframe::NativeOptions {
        viewport: eframe::egui::ViewportBuilder::default()
            .with_inner_size([1120.0, 720.0])
            .with_min_inner_size([900.0, 580.0])
            .with_drag_and_drop(true)
            .with_icon(std::sync::Arc::new(icon)),
        centered: true,
        persist_window: false,
        ..Default::default()
    };

    eframe::run_native(
        "Opac Window",
        native_options,
        Box::new(|cc| Ok(Box::new(gui::OpacApp::new(cc)))),
    )
}
