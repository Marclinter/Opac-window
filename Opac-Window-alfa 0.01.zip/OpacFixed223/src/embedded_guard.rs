//! Bytes of the OPAC Guard executable produced at build time and embedded in
//! the main GUI binary. The payload is materialized only when the user enables
//! OPAC Guard and an elevated helper installs the Windows service.

#[cfg(windows)]
pub const OPAC_GUARD_EXE: &[u8] =
    include_bytes!(concat!(env!("OUT_DIR"), "/opac_guard_payload.bin"));

#[cfg(not(windows))]
pub const OPAC_GUARD_EXE: &[u8] = &[];
