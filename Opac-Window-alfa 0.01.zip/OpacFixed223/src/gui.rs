use std::collections::{BTreeMap, HashMap, HashSet, VecDeque};
use std::fs;
use std::fs::OpenOptions;
use std::io::{self, Cursor, Read, Write};
#[cfg(windows)]
use std::os::windows::fs::OpenOptionsExt;
use std::path::{Path, PathBuf};
#[cfg(any(target_os = "linux", target_os = "macos"))]
use std::process::Command;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver};
use std::sync::{Arc, Mutex};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant, SystemTime};

use arboard::Clipboard;
use eframe::App;
use eframe::egui::{
    self, Align, Align2, Color32, Context, FontId, Key, Layout, PointerButton, RichText, Sense,
    TextStyle,
};

use egui_commonmark::{CommonMarkCache, CommonMarkViewer};
use futures_executor::block_on;
use image::ImageReader;
use pdfboss_core::Document as PdfDocument;
use pdfboss_render::render_page as render_pdf_page;
#[cfg(target_os = "windows")]
use raw_window_handle::{HasWindowHandle, RawWindowHandle};
use rfd::{AsyncFileDialog, FileDialog};
use rodio::{Decoder, DeviceSinkBuilder, MixerDeviceSink, Player, Source};
use uuid::Uuid;
#[cfg(target_os = "windows")]
use windows_sys::Win32::Foundation::GetLastError;
#[cfg(target_os = "windows")]
use windows_sys::Win32::System::Threading::{
    GetExitCodeProcess, OpenProcess, PROCESS_QUERY_LIMITED_INFORMATION,
};
#[cfg(target_os = "windows")]
use windows_sys::Win32::UI::Shell::ShellExecuteW;
#[cfg(target_os = "windows")]
use windows_sys::Win32::UI::WindowsAndMessaging::{
    SW_SHOWNORMAL, SetWindowDisplayAffinity, WDA_EXCLUDEFROMCAPTURE, WDA_NONE,
};
use zeroize::Zeroizing;

use opac_window_core::{
    KeyStore, KeyStoreSession, MasterKey, OpacMetadata, ProfileCatalog, ProfileError,
    ProfileStorage, SessionError, VaultAccessMode, VaultError, VaultSession,
};

use opac_guard as guard;

#[cfg(target_os = "windows")]
use crate::video_preview;

const PREVIEW_MAX_BYTES: u64 = 512 * 1024;
const IMAGE_PREVIEW_MAX_BYTES: u64 = 32 * 1024 * 1024;
const IMAGE_PREVIEW_MAX_PIXELS: u64 = 16 * 1024 * 1024;
const IMAGE_PREVIEW_MAX_DIMENSION: u32 = 8192;
const IMAGE_PREVIEW_MAX_ALLOC: u64 = 128 * 1024 * 1024;
const AUDIO_PREVIEW_MAX_BYTES: u64 = 1024 * 1024 * 1024;
const VIDEO_PREVIEW_MAX_BYTES: u64 = 512 * 1024 * 1024;
const PDF_PREVIEW_MAX_BYTES: u64 = 16 * 1024 * 1024;
const PDF_PREVIEW_RENDER_PAGES: usize = 3;
const PDF_RENDER_MAX_PIXELS: f64 = 6_000_000.0;
const PDF_RENDER_MAX_DIMENSION: f32 = 2400.0;
const AUTO_LOCK_IDLE: Duration = Duration::from_secs(10 * 60);
const SCREEN_CAPTURE_SETTING_KEY: &str = "opac.block_screen_captures";
const LEFT_DRAG_SETTING_KEY: &str = "opac.internal_drag_with_left_button";
const DARK_MODE_SETTING_KEY: &str = "opac.dark_mode";
const SESSION_TEMP_DIR_PREFIX: &str = "OpacWindow-session-";
const SESSION_TEMP_MARKER: &str = ".session-info";
const SESSION_TEMP_ORPHAN_AGE: Duration = Duration::from_secs(10 * 60);
const CLIPBOARD_SECRET_TTL: Duration = Duration::from_secs(30);
const PIN_BACKOFF_BASE: Duration = Duration::from_secs(1);
const PIN_BACKOFF_MAX: Duration = Duration::from_secs(30);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Screen {
    Setup,
    ProfileSelect,
    Unlock,
    Main,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum PreviewKind {
    None,
    Text,
    Markdown,
    Pdf,
    Image,
    Audio,
    Video,
    Unsupported,
}

#[derive(Debug, Default)]
struct PinBackoffState {
    failed_attempts: u32,
    retry_after: Option<Instant>,
}

#[derive(Debug)]
struct AudioPreviewTask {
    cancel: std::sync::Arc<AtomicBool>,
    receiver: Receiver<AudioPreviewEvent>,
    preview_path: PathBuf,
    handle: Option<JoinHandle<()>>,
}

/// Reposicionamiento del audio del vídeo en segundo plano: se crea un `Player`
/// nuevo que descarta (sin seek del demuxer) el audio anterior a `requested`.
#[cfg(target_os = "windows")]
struct VideoAudioSeekTask {
    requested: Duration,
    was_playing: bool,
    receiver: Receiver<Result<Player, String>>,
    handle: Option<JoinHandle<()>>,
}

#[cfg(target_os = "windows")]
#[derive(Debug)]
struct CancelledVideoCleanupTask {
    preview_path: Option<PathBuf>,
    handle: JoinHandle<()>,
}

struct PdfPreviewPage {
    size: [usize; 2],
    rgba: Option<Zeroizing<Vec<u8>>>,
    texture: Option<egui::TextureHandle>,
}

#[derive(Debug)]
enum AudioPreviewEvent {
    Ready {
        source_path: PathBuf,
        preview_path: PathBuf,
        owns_temp: bool,
    },
    Failed {
        source_path: PathBuf,
        preview_path: PathBuf,
        message: String,
    },
}

#[derive(Debug, Clone)]
struct FolderEntry {
    disk_path: PathBuf,
    metadata: OpacMetadata,
}

#[derive(Debug, Clone)]
struct FileEntry {
    disk_path: PathBuf,
    metadata: OpacMetadata,
}

#[derive(Debug)]
struct ImportTask {
    total: usize,
    completed: usize,
    total_bytes: u64,
    completed_bytes: u64,
    current: Option<String>,
    current_bytes_completed: u64,
    current_bytes_total: u64,
    current_chunks_completed: u64,
    current_chunks_total: u64,
    per_source_bytes: HashMap<PathBuf, u64>,
    target_folder: PathBuf,
    active_workers: usize,
    results: Vec<(String, Result<PathBuf, String>)>,
    receiver: Receiver<ImportEvent>,
    handle: Option<JoinHandle<()>>,
}

#[derive(Debug)]
struct UnlockTask {
    receiver: Receiver<Result<(KeyStore, MasterKey), String>>,
    prepared: Option<opac_window_core::modules::session::PreparedScopedOpen>,
    handle: Option<JoinHandle<()>>,
}

#[derive(Debug)]
/// Descifrado de una copia temporal para abrirla con la aplicación
/// predeterminada. Se ejecuta fuera del hilo de la GUI para no congelarla.
struct ExternalOpenTask {
    temp: PathBuf,
    receiver: Receiver<Result<(), String>>,
    handle: Option<JoinHandle<()>>,
}

struct PreloadTask {
    total: usize,
    completed: usize,
    current: Option<String>,
    cache_dir: PathBuf,
    receiver: Receiver<PreloadEvent>,
    handle: Option<JoinHandle<()>>,
}

#[derive(Debug)]
enum PreloadEvent {
    Started {
        name: String,
    },
    Finished {
        source_path: PathBuf,
        cache_path: PathBuf,
        result: Result<(), String>,
    },
}

#[derive(Debug)]
enum ImportEvent {
    Started {
        source_path: PathBuf,
        name: String,
        total_chunks: u64,
        total_bytes: u64,
        worker_units: usize,
    },
    ChunkProgress {
        source_path: PathBuf,
        name: String,
        completed: u64,
        total: u64,
        bytes_completed: u64,
    },
    Finished {
        source_path: PathBuf,
        source_name: String,
        total_bytes: u64,
        worker_units: usize,
        result: Result<PathBuf, String>,
    },
}

pub struct OpacApp {
    screen: Screen,
    profile_catalog: ProfileCatalog,
    profile_catalog_error: Option<String>,
    pending_profile_id: Option<Uuid>,
    unlock_password_focus_pending: bool,
    active_profile_id: Option<Uuid>,
    active_profile_name: Option<String>,
    show_new_profile: bool,
    new_profile_name: String,
    new_profile_password: Zeroizing<String>,
    new_profile_password_confirm: Zeroizing<String>,
    session: Option<KeyStoreSession>,
    vault: Option<VaultSession>,
    vault_pin_authenticated: bool,
    selected_vault_id: Option<Uuid>,
    selected_file: Option<PathBuf>,
    files: Vec<FileEntry>,
    folders: Vec<FolderEntry>,
    current_folder: Option<PathBuf>,
    expanded_folders: HashSet<PathBuf>,
    folder_drop_rects: Vec<(PathBuf, egui::Rect)>,
    drop_target_folder: Option<PathBuf>,

    master_password: Zeroizing<String>,
    master_password_confirm: Zeroizing<String>,
    unlock_task: Option<UnlockTask>,
    long_operation_started_at: Option<Instant>,
    new_vault_name: String,
    new_vault_parent: Option<PathBuf>,
    new_vault_use_imported_key: bool,
    new_vault_imported_key: Zeroizing<String>,

    show_new_vault: bool,
    show_new_folder: bool,
    new_folder_name: String,
    new_folder_parent: Option<PathBuf>,
    show_new_text_file: bool,
    new_text_file_name: String,
    new_text_file_parent: Option<PathBuf>,
    show_vault_key: bool,
    show_key_unlock: bool,
    key_unlock_value: Zeroizing<String>,
    pending_key_vault: Option<Uuid>,
    show_external_key_import: bool,
    external_key_value: Zeroizing<String>,
    external_vault_name: String,
    external_vault_path: Option<PathBuf>,
    show_pin_prompt: bool,
    pending_pin_vault: Option<Uuid>,
    pin_value: Zeroizing<String>,
    pin_backoff: HashMap<Uuid, PinBackoffState>,
    show_add_pin: bool,
    pending_pin_add_vault: Option<Uuid>,
    show_delete_confirm: bool,
    pending_delete_file: Option<PathBuf>,
    show_delete_vault_confirm: bool,
    pending_delete_vault: Option<Uuid>,
    show_folder_delete_confirm: bool,
    pending_delete_folder: Option<PathBuf>,
    show_folder_export_confirm: bool,
    pending_export_folder: Option<PathBuf>,
    show_rename: bool,
    pending_rename_path: Option<PathBuf>,
    rename_name: String,
    new_pin_value: Zeroizing<String>,
    new_pin_confirm: Zeroizing<String>,
    drop_active: bool,

    preview_text: Option<Zeroizing<String>>,
    preview_kind: PreviewKind,
    preview_image: Option<egui::ColorImage>,
    preview_image_texture: Option<egui::TextureHandle>,
    preview_image_size: Option<[usize; 2]>,
    preview_pdf_page_count: Option<usize>,
    preview_pdf_pages: Vec<PdfPreviewPage>,
    editing_text: bool,
    edit_original_text: Option<Zeroizing<String>>,
    markdown_cache: CommonMarkCache,
    audio_output: Option<MixerDeviceSink>,
    audio_player: Option<Player>,
    audio_preview_path: Option<PathBuf>,
    audio_preview_owned: bool,
    audio_duration: Option<Duration>,
    audio_error: Option<String>,
    audio_task: Option<AudioPreviewTask>,
    #[cfg(target_os = "windows")]
    video_task: Option<video_preview::VideoPreviewTask>,
    #[cfg(target_os = "windows")]
    video_preview_path: Option<PathBuf>,
    #[cfg(target_os = "windows")]
    video_preview_owned: bool,
    #[cfg(target_os = "windows")]
    video_texture: Option<egui::TextureHandle>,
    #[cfg(target_os = "windows")]
    video_size: Option<[usize; 2]>,
    #[cfg(target_os = "windows")]
    video_position: Duration,
    #[cfg(target_os = "windows")]
    video_duration: Option<Duration>,
    #[cfg(target_os = "windows")]
    video_seek_override: Option<Duration>,
    #[cfg(target_os = "windows")]
    video_finished: bool,
    #[cfg(target_os = "windows")]
    video_error: Option<String>,
    #[cfg(target_os = "windows")]
    video_audio_output: Option<MixerDeviceSink>,
    #[cfg(target_os = "windows")]
    video_audio_player: Option<Player>,
    #[cfg(target_os = "windows")]
    video_audio_start_pending: bool,
    /// Instante del vídeo en el que empieza el `Player` actual. `Player::get_pos`
    /// cuenta desde 0 en cada Player nuevo, así que el reloj maestro es
    /// `video_audio_base + get_pos()`.
    #[cfg(target_os = "windows")]
    video_audio_base: Duration,
    #[cfg(target_os = "windows")]
    video_audio_seek_task: Option<VideoAudioSeekTask>,
    #[cfg(target_os = "windows")]
    video_audio_error: Option<String>,
    #[cfg(target_os = "windows")]
    cancelled_video_cleanup: Vec<CancelledVideoCleanupTask>,
    audio_volume: f32,
    manual_import_dialog: Option<Receiver<Option<Vec<PathBuf>>>>,
    status: Option<String>,
    status_error: bool,
    temp_exports: Vec<PathBuf>,
    session_temp_dir: Option<PathBuf>,
    deferred_temp_dirs: Vec<PathBuf>,
    deferred_temp_files: Vec<PathBuf>,
    clipboard_secret: Option<Zeroizing<String>>,
    clipboard_clear_deadline: Option<Instant>,
    import_task: Option<ImportTask>,
    preload_task: Option<PreloadTask>,
    external_open_task: Option<ExternalOpenTask>,
    preload_cache_dir: Option<PathBuf>,
    preloaded_files: std::collections::HashMap<PathBuf, PathBuf>,
    last_activity: Instant,
    auto_lock_pending: bool,
    show_settings: bool,
    show_guard_disable_prompt: bool,
    guard_disable_password: Zeroizing<String>,
    guard_service_status: guard::GuardServiceStatus,
    guard_client: Option<guard::GuardClient>,
    guard_operation: Option<Receiver<Result<(), String>>>,
    guard_operation_kind: Option<GuardOperationKind>,
    block_screen_captures: bool,
    dark_mode: bool,
    internal_drag_with_left_button: bool,
    screen_capture_protection_applied: bool,
    #[cfg(target_os = "windows")]
    screen_capture_protected_hwnd: Option<isize>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum GuardOperationKind {
    Install,
    Uninstall,
}

enum AudioAction {
    Play,
    Pause,
    Stop,
    Restart,
    Seek(Duration),
}

impl OpacApp {
    pub fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let dark_mode = cc
            .storage
            .and_then(|storage| eframe::get_value::<bool>(storage, DARK_MODE_SETTING_KEY))
            .unwrap_or(true);
        configure_theme(&cc.egui_ctx, dark_mode);

        let catalog_result = ProfileCatalog::load_or_create();
        let (profile_catalog, profile_catalog_error) = match catalog_result {
            Ok(catalog) => (catalog, None),
            Err(error) => {
                let fallback = ProfileCatalog::default_path()
                    .unwrap_or_else(|| PathBuf::from("profiles.oprp"));
                (
                    ProfileCatalog::empty(fallback),
                    Some(format!("No se pudo abrir el catálogo de perfiles: {error}")),
                )
            }
        };
        let has_profiles = !profile_catalog.list().is_empty();
        let block_screen_captures = cc
            .storage
            .and_then(|storage| eframe::get_value::<bool>(storage, SCREEN_CAPTURE_SETTING_KEY))
            .unwrap_or(false);
        let internal_drag_with_left_button = cc
            .storage
            .and_then(|storage| eframe::get_value::<bool>(storage, LEFT_DRAG_SETTING_KEY))
            .unwrap_or(false);

        let _ = cleanup_orphaned_session_temp_dirs();
        let mut app = Self {
            screen: if has_profiles || profile_catalog_error.is_some() {
                Screen::ProfileSelect
            } else {
                Screen::Setup
            },
            profile_catalog,
            profile_catalog_error,
            pending_profile_id: None,
            unlock_password_focus_pending: false,
            active_profile_id: None,
            active_profile_name: None,
            show_new_profile: false,
            new_profile_name: String::new(),
            new_profile_password: Zeroizing::new(String::new()),
            new_profile_password_confirm: Zeroizing::new(String::new()),
            session: None,
            vault: None,
            vault_pin_authenticated: false,
            selected_vault_id: None,
            selected_file: None,
            files: Vec::new(),
            folders: Vec::new(),
            current_folder: None,
            expanded_folders: HashSet::new(),
            folder_drop_rects: Vec::new(),
            drop_target_folder: None,
            master_password: Zeroizing::new(String::new()),
            master_password_confirm: Zeroizing::new(String::new()),
            unlock_task: None,
            long_operation_started_at: None,
            new_vault_name: String::new(),
            new_vault_parent: None,
            new_vault_use_imported_key: false,
            new_vault_imported_key: Zeroizing::new(String::new()),
            show_new_vault: false,
            show_new_folder: false,
            new_folder_name: String::new(),
            new_folder_parent: None,
            show_new_text_file: false,
            new_text_file_name: String::new(),
            new_text_file_parent: None,
            show_vault_key: false,
            show_key_unlock: false,
            key_unlock_value: Zeroizing::new(String::new()),
            pending_key_vault: None,
            show_external_key_import: false,
            external_key_value: Zeroizing::new(String::new()),
            external_vault_name: String::new(),
            external_vault_path: None,
            show_pin_prompt: false,
            pending_pin_vault: None,
            pin_value: Zeroizing::new(String::new()),
            pin_backoff: HashMap::new(),
            show_add_pin: false,
            pending_pin_add_vault: None,
            show_delete_confirm: false,
            pending_delete_file: None,
            show_delete_vault_confirm: false,
            pending_delete_vault: None,
            show_folder_delete_confirm: false,
            pending_delete_folder: None,
            show_folder_export_confirm: false,
            pending_export_folder: None,
            show_rename: false,
            pending_rename_path: None,
            rename_name: String::new(),
            new_pin_value: Zeroizing::new(String::new()),
            new_pin_confirm: Zeroizing::new(String::new()),
            drop_active: false,
            preview_text: None,
            preview_kind: PreviewKind::None,
            preview_image: None,
            preview_image_texture: None,
            preview_image_size: None,
            preview_pdf_page_count: None,
            preview_pdf_pages: Vec::new(),
            editing_text: false,
            edit_original_text: None,
            markdown_cache: CommonMarkCache::default(),
            audio_output: None,
            audio_player: None,
            audio_preview_path: None,
            audio_preview_owned: false,
            audio_duration: None,
            audio_error: None,
            audio_task: None,
            #[cfg(target_os = "windows")]
            video_task: None,
            #[cfg(target_os = "windows")]
            video_preview_path: None,
            #[cfg(target_os = "windows")]
            video_preview_owned: false,
            #[cfg(target_os = "windows")]
            video_texture: None,
            #[cfg(target_os = "windows")]
            video_size: None,
            #[cfg(target_os = "windows")]
            video_position: Duration::ZERO,
            #[cfg(target_os = "windows")]
            video_duration: None,
            #[cfg(target_os = "windows")]
            video_seek_override: None,
            #[cfg(target_os = "windows")]
            video_finished: false,
            #[cfg(target_os = "windows")]
            video_error: None,
            #[cfg(target_os = "windows")]
            video_audio_output: None,
            #[cfg(target_os = "windows")]
            video_audio_player: None,
            #[cfg(target_os = "windows")]
            video_audio_start_pending: false,
            #[cfg(target_os = "windows")]
            video_audio_base: Duration::ZERO,
            #[cfg(target_os = "windows")]
            video_audio_seek_task: None,
            #[cfg(target_os = "windows")]
            video_audio_error: None,
            #[cfg(target_os = "windows")]
            cancelled_video_cleanup: Vec::new(),
            audio_volume: 0.85,
            manual_import_dialog: None,
            status: None,
            status_error: false,
            temp_exports: Vec::new(),
            session_temp_dir: None,
            deferred_temp_dirs: Vec::new(),
            deferred_temp_files: Vec::new(),
            clipboard_secret: None,
            clipboard_clear_deadline: None,
            import_task: None,
            preload_task: None,
            external_open_task: None,
            preload_cache_dir: None,
            preloaded_files: std::collections::HashMap::new(),
            last_activity: Instant::now(),
            auto_lock_pending: false,
            show_settings: false,
            show_guard_disable_prompt: false,
            guard_disable_password: Zeroizing::new(String::new()),
            guard_service_status: guard::GuardServiceStatus::Missing,
            guard_client: None,
            guard_operation: None,
            guard_operation_kind: None,
            block_screen_captures,
            dark_mode,
            internal_drag_with_left_button,
            screen_capture_protection_applied: false,
            #[cfg(target_os = "windows")]
            screen_capture_protected_hwnd: None,
        };

        if app.block_screen_captures {
            #[cfg(target_os = "windows")]
            if let Some(window) = cc.winit_window()
                && set_screen_capture_protection(window.as_ref(), true).is_ok()
            {
                app.screen_capture_protection_applied = true;
            }
        }

        app
    }

    fn setup_screen(&mut self, ui: &mut egui::Ui) {
        egui::CentralPanel::default().show(ui, |ui| {
            ui.vertical_centered(|ui| {
                ui.add_space(80.0);
                ui.label(RichText::new("OPAC WINDOW").font(FontId::proportional(30.0)).strong());
                ui.add_space(8.0);
                ui.label(RichText::new("Tu espacio local para archivos privados").color(Color32::from_rgb(158, 149, 168)));
                ui.add_space(36.0);

                egui::Frame::group(ui.style())
                    .fill(theme_neutral(self.dark_mode, (25, 22, 31), (255, 253, 255)))
                    .stroke(egui::Stroke::new(1.0_f32, theme_neutral(self.dark_mode, (65, 55, 78), (225, 219, 229))))
                    .corner_radius(egui::CornerRadius::same(12))
                    .inner_margin(egui::Margin::symmetric(28, 22))
                    .show(ui, |ui| {
                        ui.set_width(420.0);
                        ui.label(RichText::new("Crear primer usuario").size(18.0).strong());
                        ui.add_space(10.0);
                        ui.label("Crea el primer usuario local. Cada usuario tendrá su propio Key Store y sus propias Cajas Fuertes.");
                        ui.add_space(18.0);

                        ui.label("Nombre de usuario");
                        let profile_name = ui.add(
                            egui::TextEdit::singleline(&mut self.new_profile_name)
                                .desired_width(ui.available_width().max(1.0))
                                .hint_text("Ej.: Ana, Carlos...")
                        );
                        ui.add_space(8.0);
                        ui.label("Contraseña maestra");
                        let password = ui.add(
                            egui::TextEdit::singleline(&mut *self.master_password)
                                .password(true)
                                .char_limit(512)
                                .desired_width(ui.available_width().max(1.0))
                                .hint_text("12-512 caracteres"),
                        );
                        ui.add_space(8.0);
                        ui.label("Repite la contraseña");
                        let confirm = ui.add(
                            egui::TextEdit::singleline(&mut *self.master_password_confirm)
                                .password(true)
                                .char_limit(512)
                                .desired_width(ui.available_width().max(1.0)),
                        );
                        ui.add_space(16.0);

                        let can_submit = !self.new_profile_name.trim().is_empty()
                            && !self.master_password.is_empty()
                            && !self.master_password_confirm.is_empty();
                        let clicked = ui
                            .add_enabled(can_submit, egui::Button::new(RichText::new("Empezar").strong()).min_size([120.0, 36.0].into()))
                            .clicked();

                        if clicked
                            || (confirm.lost_focus()
                                && ui.input(|i| i.key_pressed(Key::Enter)))
                            || (password.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                            || (profile_name.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                        {
                            self.create_installation();
                        }
                    });
            });
        });
    }

    fn create_installation(&mut self) {
        let profile_name = self.new_profile_name.trim().to_owned();
        if profile_name.is_empty() {
            self.set_error("Escribe un nombre para el usuario.");
            return;
        }
        if self.master_password.chars().count() < 12 || self.master_password.chars().count() > 512 {
            self.set_error("Usa una contraseña maestra de entre 12 y 512 caracteres.");
            return;
        }
        if self.master_password.as_str() != self.master_password_confirm.as_str() {
            self.set_error("Las contraseñas no coinciden.");
            return;
        }

        let profile = match self.profile_catalog.create_dedicated_profile(&profile_name) {
            Ok(profile) => profile,
            Err(error) => {
                self.set_error(format_profile_error(&error));
                return;
            }
        };
        let path = match self.profile_catalog.path_for(&profile) {
            Ok(path) => path,
            Err(error) => {
                let _ = self.profile_catalog.remove_profile_record(profile.id);
                self.set_error(format_profile_error(&error));
                return;
            }
        };
        let password = Zeroizing::new(self.master_password.as_bytes().to_vec());
        let profile_root = self
            .profile_catalog
            .root_for(&profile)
            .map_err(|error| format_profile_error(&error));
        let profile_root = match profile_root {
            Ok(root) => root,
            Err(error) => {
                let _ = self.profile_catalog.remove_profile_record(profile.id);
                self.set_error(error);
                return;
            }
        };
        match KeyStoreSession::create_scoped_named(
            path.clone(),
            profile_root,
            &profile_name,
            &password,
        ) {
            Ok(session) => {
                self.session = Some(session);
                self.active_profile_id = Some(profile.id);
                self.active_profile_name = Some(profile.name.clone());
                self.pending_profile_id = None;
                self.master_password.clear();
                self.master_password_confirm.clear();
                self.new_profile_name.clear();
                self.screen = Screen::Main;
                self.set_ok("Usuario creado. Crea tu primera Caja Fuerte.".into());
            }
            Err(error) => {
                let _ = self.profile_catalog.remove_profile_record(profile.id);
                if let Some(dir) = path.parent() {
                    let _ = fs::remove_dir_all(dir);
                }
                self.set_error(format_error(&error));
            }
        }
    }

    fn profile_select_screen(&mut self, ui: &mut egui::Ui) {
        egui::CentralPanel::default().show(ui, |ui| {
            ui.vertical_centered(|ui| {
                ui.add_space(70.0);
                ui.label(RichText::new("OPAC WINDOW").font(FontId::proportional(30.0)).strong());
                ui.add_space(8.0);
                ui.label(RichText::new("Selecciona tu usuario").color(Color32::from_rgb(158, 149, 168)));
                ui.add_space(28.0);
                egui::Frame::group(ui.style())
                    .fill(theme_neutral(self.dark_mode, (25, 22, 31), (255, 253, 255)))
                    .stroke(egui::Stroke::new(1.0, theme_neutral(self.dark_mode, (65, 55, 78), (225, 219, 229))))
                    .corner_radius(egui::CornerRadius::same(12))
                    .inner_margin(egui::Margin::symmetric(28, 22))
                    .show(ui, |ui| {
                        ui.set_width(460.0);
                        if let Some(error) = &self.profile_catalog_error {
                            ui.label(RichText::new(error).color(Color32::from_rgb(232, 145, 145)));
                            ui.label("No se puede abrir ni modificar el catálogo de perfiles hasta resolver el problema.");
                        } else {
                            for profile in self.profile_catalog.list() {
                                let label = self
                                    .profile_catalog
                                    .slot_label(profile.id)
                                    .unwrap_or_else(|| "Usuario".to_owned());
                                if ui.add_sized([ui.available_width().max(1.0), 42.0], egui::Button::new(RichText::new(format!("👤  {label}")).size(16.0))).clicked() {
                                    self.pending_profile_id = Some(profile.id);
                                    self.master_password.clear();
                                    self.unlock_password_focus_pending = true;
                                    self.screen = Screen::Unlock;
                                }
                                ui.add_space(6.0);
                            }
                            ui.add_space(10.0);
                            if ui.button("+  Nuevo usuario").clicked() {
                                self.new_profile_name.clear();
                                self.new_profile_password.clear();
                                self.new_profile_password_confirm.clear();
                                self.show_new_profile = true;
                            }
                        }
                    });
            });
        });
        if self.show_new_profile {
            self.new_profile_dialog(ui.ctx());
        }
    }

    fn new_profile_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        let mut create = false;
        egui::Window::new("Nuevo usuario")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("Cada usuario tendrá un Key Store independiente.");
                ui.add_space(10.0);
                ui.label("Nombre de usuario");
                let name_response = ui.add(
                    egui::TextEdit::singleline(&mut self.new_profile_name).desired_width(420.0),
                );
                ui.add_space(8.0);
                ui.label("Contraseña");
                let password_response = ui.add(
                    egui::TextEdit::singleline(&mut *self.new_profile_password)
                        .password(true)
                        .char_limit(512)
                        .desired_width(420.0),
                );
                ui.add_space(8.0);
                ui.label("Repite la contraseña");
                let confirm_response = ui.add(
                    egui::TextEdit::singleline(&mut *self.new_profile_password_confirm)
                        .password(true)
                        .char_limit(512)
                        .desired_width(420.0),
                );
                ui.add_space(14.0);
                if ui.button(RichText::new("Crear usuario").strong()).clicked()
                    || (confirm_response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                    || (password_response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                    || (name_response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                {
                    create = true;
                }
                if ui.button("Cancelar").clicked() {
                    close = true;
                }
            });
        if create && self.create_profile_from_dialog() {
            close = true;
        }
        if close {
            self.show_new_profile = false;
            self.new_profile_name.clear();
            self.new_profile_password.clear();
            self.new_profile_password_confirm.clear();
        }
    }

    fn create_profile_from_dialog(&mut self) -> bool {
        let name = self.new_profile_name.trim().to_owned();
        if name.is_empty() {
            self.set_error("Escribe un nombre para el usuario.");
            return false;
        }
        if self.new_profile_password.chars().count() < 12
            || self.new_profile_password.chars().count() > 512
        {
            self.set_error("Usa una contraseña de entre 12 y 512 caracteres.");
            return false;
        }
        if self.new_profile_password.as_str() != self.new_profile_password_confirm.as_str() {
            self.set_error("Las contraseñas no coinciden.");
            return false;
        }
        let profile = match self.profile_catalog.create_dedicated_profile(&name) {
            Ok(profile) => profile,
            Err(error) => {
                self.set_error(format_profile_error(&error));
                return false;
            }
        };
        let path = match self.profile_catalog.path_for(&profile) {
            Ok(path) => path,
            Err(error) => {
                let _ = self.profile_catalog.remove_profile_record(profile.id);
                self.set_error(format_profile_error(&error));
                return false;
            }
        };
        let password = Zeroizing::new(self.new_profile_password.as_bytes().to_vec());
        let profile_root = match self.profile_catalog.root_for(&profile) {
            Ok(root) => root,
            Err(error) => {
                let _ = self.profile_catalog.remove_profile_record(profile.id);
                self.set_error(format_profile_error(&error));
                return false;
            }
        };
        match KeyStoreSession::create_scoped_named(path.clone(), profile_root, &name, &password) {
            Ok(session) => {
                self.session = Some(session);
                self.active_profile_id = Some(profile.id);
                self.active_profile_name = Some(profile.name.clone());
                self.pending_profile_id = None;
                self.new_profile_password.clear();
                self.new_profile_password_confirm.clear();
                self.master_password.clear();
                self.screen = Screen::Main;
                self.set_ok(format!("Usuario «{}» creado.", profile.name));
                true
            }
            Err(error) => {
                let _ = self.profile_catalog.remove_profile_record(profile.id);
                if let Some(dir) = path.parent() {
                    let _ = fs::remove_dir_all(dir);
                }
                self.set_error(format_error(&error));
                false
            }
        }
    }

    fn poll_unlock_task(&mut self) {
        let Some(mut task) = self.unlock_task.take() else {
            return;
        };

        match task.receiver.try_recv() {
            Ok(result) => {
                if let Some(handle) = task.handle.take() {
                    let _ = handle.join();
                }
                self.long_operation_started_at = None;
                match result {
                    Ok((store, master_key)) => {
                        let Some(prepared) = task.prepared.take() else {
                            self.set_error(
                                "El proceso de desbloqueo no conservó su estado de apertura.",
                            );
                            return;
                        };
                        let session = match prepared.finish(store, master_key) {
                            Ok(session) => session,
                            Err(error) => {
                                self.set_error(format!(
                                    "No se pudo finalizar el desbloqueo: {error}"
                                ));
                                return;
                            }
                        };
                        let Some(profile_id) = self.pending_profile_id else {
                            self.set_error("El usuario seleccionado ya no está disponible.");
                            return;
                        };
                        let profile_name = match session.profile_name() {
                            Some(name) => name.to_owned(),
                            None => self
                                .profile_catalog
                                .slot_label(profile_id)
                                .unwrap_or_else(|| "Usuario".to_owned()),
                        };
                        self.session = Some(session);
                        self.active_profile_id = Some(profile_id);
                        self.active_profile_name = Some(profile_name);
                        self.pending_profile_id = None;
                        self.screen = Screen::Main;
                        self.last_activity = Instant::now();
                        self.auto_lock_pending = false;
                        self.status = Some("Usuario desbloqueado.".into());
                        self.status_error = false;
                        self.selected_vault_id = None;
                        self.vault = None;
                        self.vault_pin_authenticated = false;
                        self.refresh_files();
                        self.ensure_guard_client();
                    }
                    Err(error) => {
                        self.set_error(format!("No se pudo desbloquear el usuario: {}", error));
                    }
                }
            }
            Err(mpsc::TryRecvError::Empty) => {
                self.unlock_task = Some(task);
            }
            Err(mpsc::TryRecvError::Disconnected) => {
                if let Some(handle) = task.handle.take() {
                    let _ = handle.join();
                }
                self.long_operation_started_at = None;
                self.set_error("El proceso de desbloqueo terminó sin devolver un resultado.");
            }
        }
    }

    fn unlock_screen(&mut self, ui: &mut egui::Ui) {
        egui::CentralPanel::default().show(ui, |ui| {
            ui.vertical_centered(|ui| {
                ui.add_space(100.0);
                ui.label(RichText::new("OPAC WINDOW").font(FontId::proportional(30.0)).strong());
                ui.add_space(8.0);
                ui.label(RichText::new("Desbloquear usuario").color(Color32::from_rgb(158, 149, 168)));
                ui.add_space(10.0);
                if let Some(profile_id) = self.pending_profile_id
                    && let Some(label) = self.profile_catalog.slot_label(profile_id)
                {
                    ui.label(RichText::new(label).strong());
                }
                ui.add_space(22.0);

                egui::Frame::group(ui.style())
                    .fill(theme_neutral(self.dark_mode, (25, 22, 31), (255, 253, 255)))
                    .stroke(egui::Stroke::new(1.0_f32, theme_neutral(self.dark_mode, (65, 55, 78), (225, 219, 229))))
                    .corner_radius(egui::CornerRadius::same(12))
                    .inner_margin(egui::Margin::symmetric(28, 22))
                    .show(ui, |ui| {
                        ui.set_width(420.0);
                        ui.label("Contraseña maestra");
                        let response = ui.add(
                            egui::TextEdit::singleline(&mut *self.master_password)
                                .id_salt("unlock-master-password")
                                .password(true)
                                .char_limit(512)
                                .desired_width(ui.available_width().max(1.0))
                                .hint_text("Introduce tu contraseña"),
                        );
                        if self.unlock_password_focus_pending {
                            response.request_focus();
                            self.unlock_password_focus_pending = false;
                        }
                        ui.add_space(14.0);
                        let unlock_in_progress = self.unlock_task.is_some();
                        let clicked = ui
                            .add_enabled(
                                !unlock_in_progress,
                                egui::Button::new(RichText::new("Desbloquear").strong()),
                            )
                            .clicked();

                        if unlock_in_progress
                            && self.long_operation_started_at.is_some_and(|since| {
                                long_operation_spinner_visible(since, Instant::now())
                            })
                        {
                            ui.add_space(8.0);
                            ui.horizontal(|ui| {
                                ui.spinner();
                                ui.label("Procesando contraseña…");
                            });
                        }

                        if clicked
                            || (response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                        {
                            self.unlock_installation();
                        }

                        ui.add_space(8.0);
                        if !unlock_in_progress && self.legacy_recovery_available() {
                            if ui.button("⚠  Recuperar instalación anterior").clicked() {
                                self.recover_legacy_installation();
                            }
                            ui.label(
                                RichText::new(
                                    "Solo aparece si este usuario no tiene su Key Store dedicado y se conserva la instalación anterior.",
                                )
                                .small()
                                .color(Color32::from_rgb(150, 140, 160)),
                            );
                            ui.add_space(4.0);
                        }
                        if !unlock_in_progress
                            && (ui.button("← Volver a selección de usuarios").clicked()
                                || ui.input(|i| i.key_pressed(Key::Escape)))
                        {
                            self.cancel_profile_unlock();
                        }
                    });
            });
        });
    }

    fn legacy_recovery_available(&self) -> bool {
        let Some(profile_id) = self.pending_profile_id else {
            return false;
        };
        let Some(profile) = self
            .profile_catalog
            .list()
            .into_iter()
            .find(|profile| profile.id == profile_id)
        else {
            return false;
        };
        matches!(profile.storage, ProfileStorage::Dedicated)
            && self.profile_catalog.legacy_default_store_exists()
            && !self
                .profile_catalog
                .dedicated_store_exists(&profile)
                .unwrap_or(false)
    }

    fn recover_legacy_installation(&mut self) {
        let Some(profile_id) = self.pending_profile_id else {
            self.set_error("Selecciona un usuario antes de recuperar la instalación anterior.");
            return;
        };
        let Some(profile) = self
            .profile_catalog
            .list()
            .into_iter()
            .find(|profile| profile.id == profile_id)
        else {
            self.set_error("El usuario seleccionado ya no existe.");
            self.screen = Screen::ProfileSelect;
            return;
        };
        if !matches!(profile.storage, ProfileStorage::Dedicated) {
            self.set_error("Este usuario ya utiliza el almacenamiento original.");
            return;
        }
        if self
            .profile_catalog
            .dedicated_store_exists(&profile)
            .unwrap_or(true)
        {
            self.set_error("El Key Store dedicado de este usuario ya existe; no se puede usar esta recuperación.");
            return;
        }

        let Some(root) = ProfileCatalog::default_path() else {
            self.set_error("No se pudo determinar el almacenamiento local de Opac Window.");
            return;
        };
        let legacy_store_path = root.join("keystore.opks");
        if !legacy_store_path.exists() {
            self.set_error("No se encontró la instalación anterior de Opac Window.");
            return;
        }

        let password = Zeroizing::new(self.master_password.as_bytes().to_vec());
        let mut session = match KeyStoreSession::open(&legacy_store_path, &password) {
            Ok(session) => session,
            Err(error) => {
                self.master_password.clear();
                self.set_error(format!(
                    "No se pudo abrir la instalación anterior con esta contraseña: {}",
                    format_error(&error)
                ));
                return;
            }
        };

        let dedicated_root = match self.profile_catalog.root_for(&profile) {
            Ok(root) => root,
            Err(error) => {
                self.master_password.clear();
                self.set_error(format_profile_error(&error));
                return;
            }
        };
        let cleanup = match session.migrate_to_profile_root(dedicated_root) {
            Ok(cleanup) => cleanup,
            Err(error) => {
                self.master_password.clear();
                self.set_error(format!(
                    "No se pudo recuperar la instalación anterior: {}",
                    format_error(&error)
                ));
                return;
            }
        };

        let profile_name = session
            .profile_name()
            .map(str::to_owned)
            .filter(|name| !name.is_empty())
            .or_else(|| {
                if profile.name.is_empty() {
                    None
                } else {
                    Some(profile.name.clone())
                }
            })
            .unwrap_or_else(|| "Usuario".to_owned());

        if let Err(error) = session.set_profile_name(&profile_name) {
            self.master_password.clear();
            self.set_error(format!(
                "La recuperación creó el almacenamiento, pero no pudo guardar el nombre del usuario: {}",
                format_error(&error)
            ));
            return;
        }

        for source in &cleanup.1 {
            let _ = opac_window_core::modules::vault_fs::delete_unmanaged_vault_root_for_migration(
                source,
            );
        }
        let _ = fs::remove_file(&cleanup.0);

        self.session = Some(session);
        self.active_profile_id = Some(profile.id);
        self.active_profile_name = Some(profile_name);
        self.pending_profile_id = None;
        self.master_password.clear();
        self.screen = Screen::Main;
        self.last_activity = Instant::now();
        self.auto_lock_pending = false;
        self.status =
            Some("Usuario original recuperado y migrado al almacenamiento dedicado.".into());
        self.status_error = false;
        self.selected_vault_id = None;
        self.vault = None;
        self.vault_pin_authenticated = false;
        self.refresh_files();
        self.ensure_guard_client();
    }

    fn cancel_profile_unlock(&mut self) {
        self.master_password.clear();
        self.pending_profile_id = None;
        self.unlock_password_focus_pending = false;
        self.screen = Screen::ProfileSelect;
        self.set_ok("Volviste a la selección de usuarios.".into());
    }

    fn unlock_installation(&mut self) {
        let Some(profile_id) = self.pending_profile_id else {
            self.set_error("Selecciona un usuario antes de desbloquear.");
            return;
        };
        let Some(profile) = self
            .profile_catalog
            .list()
            .into_iter()
            .find(|profile| profile.id == profile_id)
        else {
            self.set_error("El usuario seleccionado ya no existe.");
            self.screen = Screen::ProfileSelect;
            return;
        };
        let path = match self.profile_catalog.path_for(&profile) {
            Ok(path) => path,
            Err(error) => {
                self.set_error(format_profile_error(&error));
                return;
            }
        };
        let password = Zeroizing::new(self.master_password.as_bytes().to_vec());
        let profile_root = match self.profile_catalog.root_for(&profile) {
            Ok(root) => root,
            Err(error) => {
                self.set_error(format_profile_error(&error));
                return;
            }
        };
        if self.unlock_task.is_some() {
            return;
        }

        if matches!(profile.storage, ProfileStorage::Dedicated) {
            let password = Zeroizing::new(self.master_password.as_bytes().to_vec());
            self.master_password.clear();
            let prepared =
                match KeyStoreSession::prepare_scoped_open(path.clone(), profile_root.clone()) {
                    Ok(prepared) => prepared,
                    Err(error) => {
                        self.master_password.clear();
                        self.set_error(format!("No se pudo preparar el desbloqueo: {error}"));
                        return;
                    }
                };
            let path_for_worker = path.clone();
            let profile_root_for_worker = profile_root.clone();
            let (sender, receiver) = mpsc::channel();
            let handle =
                match thread::Builder::new()
                    .name("opac-unlock".to_owned())
                    .spawn(move || {
                        let result = KeyStoreSession::open_scoped_unlocked_parts(
                            path_for_worker,
                            profile_root_for_worker,
                            &password,
                        )
                        .map_err(|error| error.to_string());
                        let _ = sender.send(result);
                    }) {
                    Ok(handle) => handle,
                    Err(error) => {
                        self.set_error(format!("No se pudo iniciar el desbloqueo: {error}"));
                        return;
                    }
                };
            self.unlock_task = Some(UnlockTask {
                receiver,
                prepared: Some(prepared),
                handle: Some(handle),
            });
            self.long_operation_started_at = Some(Instant::now());
            self.set_ok("Desbloqueando usuario…".into());
            return;
        }

        let open_result = if matches!(profile.storage, ProfileStorage::LegacyDefault) {
            match KeyStoreSession::open(path, &password) {
                Ok(mut session) => {
                    let dedicated_root =
                        match self.profile_catalog.prepare_dedicated_storage(&profile) {
                            Ok(root) => root,
                            Err(error) => {
                                self.master_password.clear();
                                self.set_error(format_profile_error(&error));
                                return;
                            }
                        };
                    let cleanup = match session.migrate_to_profile_root(dedicated_root.clone()) {
                        Ok(cleanup) => cleanup,
                        Err(error) => {
                            let _ = self.profile_catalog.remove_dedicated_storage(&profile);
                            self.master_password.clear();
                            self.set_error(format!(
                                "No se pudo migrar el perfil existente: {}",
                                format_error(&error)
                            ));
                            return;
                        }
                    };
                    if let Err(error) = session.set_profile_name(&profile.name) {
                        let _ = self.profile_catalog.remove_dedicated_storage(&profile);
                        self.master_password.clear();
                        self.set_error(format!(
                            "No se pudo proteger el nombre del perfil: {}",
                            format_error(&error)
                        ));
                        return;
                    }
                    match self.profile_catalog.promote_to_dedicated(profile.id) {
                        Ok(_promoted) => {
                            for source in &cleanup.1 {
                                let _ = opac_window_core::modules::vault_fs::delete_unmanaged_vault_root_for_migration(source);
                            }
                            let _ = fs::remove_file(&cleanup.0);
                            Ok(session)
                        }
                        Err(error) => {
                            drop(session);
                            let _ = self.profile_catalog.remove_dedicated_storage(&profile);
                            self.master_password.clear();
                            self.set_error(format_profile_error(&error));
                            return;
                        }
                    }
                }
                Err(error) => Err(error),
            }
        } else {
            KeyStoreSession::open_scoped(path, profile_root, &password)
        };
        match open_result {
            Ok(mut session) => {
                let profile_name = match session.profile_name() {
                    Some(name) => name.to_owned(),
                    None if !profile.name.is_empty() => {
                        let name = profile.name.clone();
                        if let Err(error) = session.set_profile_name(&name) {
                            self.master_password.clear();
                            self.set_error(format!(
                                "No se pudo proteger el nombre del perfil: {}",
                                format_error(&error)
                            ));
                            return;
                        }
                        name
                    }
                    None => self
                        .profile_catalog
                        .slot_label(profile.id)
                        .unwrap_or_else(|| "Usuario".to_owned()),
                };
                self.session = Some(session);
                self.active_profile_id = Some(profile.id);
                self.active_profile_name = Some(profile_name);
                self.master_password.clear();
                self.screen = Screen::Main;
                self.last_activity = Instant::now();
                self.auto_lock_pending = false;
                self.status = Some("Usuario desbloqueado.".into());
                self.status_error = false;
                self.selected_vault_id = None;
                self.vault = None;
                self.vault_pin_authenticated = false;
                self.refresh_files();
                self.ensure_guard_client();
            }
            Err(error) => {
                self.master_password.clear();
                self.set_error(format!(
                    "No se pudo desbloquear el usuario: {}",
                    format_error(&error)
                ));
            }
        }
    }

    fn main_screen(&mut self, ui: &mut egui::Ui) {
        self.folder_drop_rects.clear();

        if self.drop_active {
            let painter = ui.ctx().layer_painter(egui::LayerId::new(
                egui::Order::Foreground,
                egui::Id::new("drop-overlay"),
            ));
            let rect = ui.ctx().content_rect();
            painter.rect_filled(rect, 0.0, Color32::from_rgba_premultiplied(48, 24, 67, 210));
            painter.rect_stroke(
                rect.shrink(14.0),
                18.0,
                egui::Stroke::new(2.0_f32, Color32::from_rgb(188, 126, 226)),
                egui::StrokeKind::Inside,
            );
            painter.text(
                rect.center(),
                Align2::CENTER_CENTER,
                if self.vault.is_some() {
                    self.drop_target_folder
                        .as_ref()
                        .and_then(|path| self.folder_name_for_path(path))
                        .map(|name| format!("Suelta para cifrar en «{name}»"))
                        .unwrap_or_else(|| {
                            "Suelta para cifrar en la raíz de esta Caja Fuerte".to_owned()
                        })
                } else if self.selected_vault_is_locked() {
                    "Desbloquea la Caja Fuerte para añadir archivos".to_owned()
                } else {
                    "Primero selecciona una Caja Fuerte".to_owned()
                },
                FontId::proportional(26.0),
                Color32::from_rgb(245, 236, 251),
            );
        }

        if let Some(task) = &self.preload_task {
            let painter = ui.ctx().layer_painter(egui::LayerId::new(
                egui::Order::Foreground,
                egui::Id::new("preload-overlay"),
            ));
            let rect = ui.ctx().content_rect();
            painter.rect_filled(
                rect,
                0.0,
                theme_rgba_neutral(self.dark_mode, (10, 8, 13), (255, 255, 255), 175),
            );
            let center = rect.center();
            painter.text(
                center - egui::vec2(0.0, 18.0),
                Align2::CENTER_CENTER,
                format!("Preparando {} / {}", task.completed, task.total),
                FontId::proportional(22.0),
                Color32::from_rgb(239, 229, 247),
            );
            if let Some(current) = &task.current {
                painter.text(
                    center + egui::vec2(0.0, 14.0),
                    Align2::CENTER_CENTER,
                    current,
                    FontId::proportional(15.0),
                    Color32::from_rgb(184, 169, 194),
                );
            }
        }

        egui::Panel::top("topbar").exact_size(58.0).show(ui, |ui| {
            ui.horizontal(|ui| {
                ui.add_space(10.0);
                if ui
                    .add(
                        egui::Button::new(RichText::new("⚙").size(20.0))
                            .min_size(egui::vec2(34.0, 34.0)),
                    )
                    .on_hover_text("Ajustes")
                    .clicked()
                {
                    self.guard_service_status = self
                        .active_profile_id
                        .map(guard::service_status)
                        .unwrap_or(guard::GuardServiceStatus::Missing);
                    self.show_settings = true;
                }
                ui.add_space(6.0);
                ui.label(RichText::new("OPAC WINDOW").strong().size(18.0));
                ui.separator();
                if let Some(profile_name) = &self.active_profile_name {
                    ui.label(
                        RichText::new(format!("👤 {profile_name}"))
                            .small()
                            .color(Color32::from_rgb(158, 149, 168)),
                    );
                    ui.separator();
                }
                if let Some(vault) = &self.vault {
                    ui.label(RichText::new(vault.info().name.as_str()).strong());
                } else if let Some(id) = self.selected_vault_id {
                    let name = self
                        .session
                        .as_ref()
                        .and_then(|session| {
                            session.list_vaults().into_iter().find(|info| info.id == id)
                        })
                        .map(|info| info.name);
                    if let Some(name) = name {
                        ui.label(RichText::new(format!("🔒  {name}")).strong());
                    } else {
                        ui.label(
                            RichText::new("Selecciona una Caja Fuerte")
                                .color(Color32::from_rgb(158, 149, 168)),
                        );
                    }
                } else {
                    ui.label(
                        RichText::new("Selecciona una Caja Fuerte")
                            .color(Color32::from_rgb(158, 149, 168)),
                    );
                }

                if self
                    .long_operation_started_at
                    .is_some_and(|since| long_operation_spinner_visible(since, Instant::now()))
                {
                    ui.add_space(8.0);
                    ui.spinner();
                }

                if let Some(task) = &self.import_task {
                    ui.add_space(8.0);
                    ui.spinner();
                    ui.label(
                        RichText::new(format!("Cifrando {}/{}", task.completed, task.total))
                            .color(Color32::from_rgb(201, 168, 224)),
                    );
                } else if let Some(task) = &self.preload_task {
                    ui.add_space(8.0);
                    ui.spinner();
                    ui.label(
                        RichText::new(format!("Preparando {}/{}", task.completed, task.total))
                            .color(Color32::from_rgb(201, 168, 224)),
                    );
                }

                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    if self
                        .vault
                        .as_ref()
                        .is_some_and(|vault| !vault.info().has_pin)
                        && self.import_task.is_none()
                        && self.preload_task.is_none()
                        && self.audio_task.is_none()
                        && !self.video_preview_busy()
                        && ui.button("🔐  Añadir PIN").clicked()
                    {
                        self.begin_add_pin();
                    }
                    if (self.vault.is_some() || self.selected_vault_is_locked())
                        && self.import_task.is_none()
                        && self.preload_task.is_none()
                        && self.audio_task.is_none()
                        && !self.video_preview_busy()
                        && ui.button("🔑  Clave").clicked()
                    {
                        if self.vault.is_some() {
                            self.show_vault_key = true;
                        } else {
                            self.pending_key_vault = self.selected_vault_id;
                            self.key_unlock_value.clear();
                            self.show_key_unlock = true;
                        }
                    }
                    if self.can_delete_current_vault()
                        && self.import_task.is_none()
                        && self.preload_task.is_none()
                        && self.audio_task.is_none()
                        && !self.video_preview_busy()
                        && ui.button("🗑  Eliminar Caja").clicked()
                    {
                        self.request_delete_vault();
                    }
                    if ui
                        .add_enabled(
                            self.import_task.is_none()
                                && self.preload_task.is_none()
                                && self.audio_task.is_none()
                                && !self.video_preview_busy(),
                            egui::Button::new("👤  Cambiar usuario"),
                        )
                        .clicked()
                    {
                        self.switch_user();
                    }
                    if ui
                        .add_enabled(
                            self.import_task.is_none()
                                && self.preload_task.is_none()
                                && self.audio_task.is_none()
                                && !self.video_preview_busy(),
                            egui::Button::new("Bloquear"),
                        )
                        .clicked()
                    {
                        self.lock_all();
                    }
                });
            });
        });

        egui::Panel::bottom("status")
            .exact_size(32.0)
            .show(ui, |ui| {
                ui.horizontal(|ui| {
                    ui.add_space(14.0);
                    let text = self.status.as_deref().unwrap_or("Listo");
                    let color = if self.status_error {
                        Color32::from_rgb(232, 145, 145)
                    } else {
                        Color32::from_rgb(158, 149, 168)
                    };
                    ui.label(RichText::new(text).color(color));
                });
            });

        self.sidebar(ui);

        if self.selected_file.is_some() && self.preview_kind != PreviewKind::None {
            egui::Panel::right("preview")
                .resizable(true)
                .default_size(360.0)
                .show(ui, |ui| self.preview_panel(ui));
        }

        egui::CentralPanel::default().show(ui, |ui| {
            if self.vault.is_none() {
                if self.selected_vault_is_locked() {
                    self.locked_vault_state(ui);
                } else {
                    self.empty_vault_state(ui);
                }
                return;
            }

            self.file_list(ui);
        });

        if self.show_new_vault {
            let ctx = ui.ctx();
            self.new_vault_dialog(ctx);
        }
        if self.show_vault_key {
            let ctx = ui.ctx();
            self.vault_key_dialog(ctx);
        }
        if self.show_key_unlock {
            let ctx = ui.ctx();
            self.key_unlock_dialog(ctx);
        }
        if self.show_external_key_import {
            let ctx = ui.ctx();
            self.external_key_import_dialog(ctx);
        }
        if self.show_pin_prompt {
            let ctx = ui.ctx();
            self.pin_dialog(ctx);
        }
        if self.show_add_pin {
            let ctx = ui.ctx();
            self.add_pin_dialog(ctx);
        }
        if self.show_delete_confirm {
            let ctx = ui.ctx();
            self.delete_confirm_dialog(ctx);
        }
        if self.show_delete_vault_confirm {
            let ctx = ui.ctx();
            self.delete_vault_confirm_dialog(ctx);
        }
        if self.show_folder_delete_confirm {
            let ctx = ui.ctx();
            self.folder_delete_confirm_dialog(ctx);
        }
        if self.show_folder_export_confirm {
            let ctx = ui.ctx();
            self.folder_export_confirm_dialog(ctx);
        }
        if self.show_rename {
            let ctx = ui.ctx();
            self.rename_dialog(ctx);
        }
        if self.show_new_folder {
            let ctx = ui.ctx();
            self.new_folder_dialog(ctx);
        }
        if self.show_new_text_file {
            let ctx = ui.ctx();
            self.new_text_file_dialog(ctx);
        }
    }

    fn sidebar(&mut self, ui: &mut egui::Ui) {
        egui::Panel::left("vaults")
            .resizable(false)
            .default_size(260.0)
            .show(ui, |ui| {
                ui.add_space(14.0);
                ui.horizontal(|ui| {
                    ui.add_space(12.0);
                    ui.label(
                        RichText::new("CAJAS FUERTES")
                            .small()
                            .strong()
                            .color(Color32::from_rgb(158, 149, 168)),
                    );
                });
                ui.add_space(8.0);

                let vaults = self
                    .session
                    .as_ref()
                    .map(|s| s.list_vaults())
                    .unwrap_or_default();

                if vaults.is_empty() {
                    ui.add_space(18.0);
                    ui.label(
                        RichText::new("Todavía no hay cajas.")
                            .color(Color32::from_rgb(158, 149, 168)),
                    );
                    ui.label("Crea la primera desde el botón de abajo.");
                } else {
                    for info in vaults {
                        let selected = self.selected_vault_id == Some(info.id);
                        let text = if info.has_pin {
                            format!("🔒  {}", info.name)
                        } else {
                            format!("◈  {}", info.name)
                        };
                        let enabled = self.import_task.is_none()
                            && self.preload_task.is_none()
                            && self.audio_task.is_none()
                            && !self.video_preview_busy();
                        ui.horizontal(|ui| {
                            let response = ui.add_enabled(
                                enabled,
                                egui::Button::selectable(selected, RichText::new(text).size(15.0)),
                            );
                            if response.clicked() {
                                self.select_vault(info.id);
                            }
                            if !info.has_pin {
                                let pin_button = ui.add_enabled(enabled, egui::Button::new("PIN"));
                                if pin_button.clicked() {
                                    self.begin_add_pin_for(info.id);
                                }
                                pin_button.on_hover_text("Añadir PIN a esta Caja Fuerte");
                            }
                        });
                    }
                }

                ui.with_layout(Layout::bottom_up(Align::Center), |ui| {
                    ui.add_space(12.0);
                    if ui
                        .add_enabled(
                            self.import_task.is_none()
                                && self.preload_task.is_none()
                                && self.audio_task.is_none()
                                && !self.video_preview_busy(),
                            egui::Button::new("🔑  Abrir caja con clave")
                                .min_size([228.0, 38.0].into()),
                        )
                        .clicked()
                    {
                        self.external_vault_name.clear();
                        self.external_key_value.clear();
                        self.external_vault_path = None;
                        self.show_external_key_import = true;
                    }
                    ui.add_space(8.0);
                    if ui
                        .add_enabled(
                            self.import_task.is_none()
                                && self.preload_task.is_none()
                                && self.audio_task.is_none()
                                && !self.video_preview_busy(),
                            egui::Button::new("+  Nueva caja fuerte")
                                .min_size([228.0, 38.0].into()),
                        )
                        .clicked()
                    {
                        self.new_vault_name.clear();
                        self.new_vault_parent = None;
                        self.new_vault_use_imported_key = false;
                        self.new_vault_imported_key.clear();
                        self.show_new_vault = true;
                    }
                    ui.add_space(12.0);
                    ui.label(
                        RichText::new(
                            "Tus cajas se crean sin nombres ni carpetas predeterminadas.",
                        )
                        .small()
                        .color(Color32::from_rgb(158, 149, 168)),
                    );
                });
            });
    }

    fn guard_roots(&self) -> Vec<PathBuf> {
        // OPAC Guard se vincula al usuario de OPAC activo. Solo se protege
        // su raiz dedicada; nunca el almacenamiento global ni el de otro usuario.
        self.session
            .as_ref()
            .and_then(|session| session.profile_root())
            .map(|root| vec![root.to_path_buf()])
            .unwrap_or_default()
    }

    fn guard_release_path(&self, path: &Path) -> Result<bool, String> {
        if !matches!(
            self.guard_service_status,
            guard::GuardServiceStatus::Running
        ) {
            return Ok(false);
        }
        let client = self
            .guard_client
            .as_ref()
            .ok_or_else(|| "OPAC Guard esta activo, pero no hay un canal autenticado para autorizar la operacion".to_owned())?;
        client.set_path_in_use(path.to_path_buf())?;
        Ok(true)
    }

    fn guard_reprotect(&self, path: &Path, was_released: bool) -> Result<(), String> {
        if !was_released {
            return Ok(());
        }
        let client = self.guard_client.as_ref().ok_or_else(|| {
            "OPAC Guard no esta disponible para confirmar la reproteccion".to_owned()
        })?;
        client.set_path_protected(path.to_path_buf())
    }

    fn guard_rearm_all(&mut self) {
        if matches!(
            self.guard_service_status,
            guard::GuardServiceStatus::Running
        ) {
            if let Some(client) = self.guard_client.as_ref() {
                if let Err(error) = client.set_locked() {
                    self.set_error(format!(
                        "OPAC Guard no pudo confirmar el rearme completo: {error}"
                    ));
                }
            } else {
                self.set_error("OPAC Guard esta activo, pero no existe un canal autenticado para confirmar el rearme completo.");
            }
        }
    }

    fn ensure_guard_client(&mut self) -> bool {
        let Some(profile_id) = self.active_profile_id else {
            self.guard_service_status = guard::GuardServiceStatus::Missing;
            return false;
        };
        self.guard_service_status = guard::service_status(profile_id);
        if !matches!(
            self.guard_service_status,
            guard::GuardServiceStatus::Running
        ) {
            return false;
        }
        if self.guard_client.is_none() {
            let Some((private_key, _public_key)) = self
                .session
                .as_ref()
                .and_then(|session| session.guard_identity())
            else {
                self.set_error("OPAC Guard figura como activo, pero el perfil no contiene una identidad criptográfica utilizable. No se habilita el canal del Guard.");
                return false;
            };
            self.guard_client = Some(guard::GuardClient::start(profile_id, true, *private_key));
        }
        true
    }

    fn shutdown_guard_client(&mut self) {
        if let Some(mut client) = self.guard_client.take() {
            client.shutdown();
        }
    }

    fn request_guard_disable(&mut self) {
        self.guard_disable_password.clear();
        self.show_guard_disable_prompt = true;
    }

    fn confirm_guard_disable(&mut self) -> bool {
        if self.guard_operation.is_some() {
            self.set_error("Ya hay una operación de OPAC Guard en curso.");
            return false;
        }
        let Some(profile_id) = self.active_profile_id else {
            self.set_error("No hay un usuario de OPAC activo.");
            return false;
        };
        let Some(profile) = self
            .profile_catalog
            .list()
            .into_iter()
            .find(|profile| profile.id == profile_id)
        else {
            self.set_error("El usuario de OPAC que activó este Guard ya no existe.");
            return false;
        };

        let path = match self.profile_catalog.path_for(&profile) {
            Ok(path) => path,
            Err(error) => {
                self.set_error(format_profile_error(&error));
                return false;
            }
        };
        let profile_root = match self.profile_catalog.root_for(&profile) {
            Ok(root) => root,
            Err(error) => {
                self.set_error(format_profile_error(&error));
                return false;
            }
        };

        let Some((private_key, _public_key)) = self
            .session
            .as_ref()
            .and_then(|session| session.guard_identity())
        else {
            self.set_error("Este perfil no contiene la identidad criptográfica de OPAC Guard.");
            return false;
        };
        let private_key = *private_key;
        let password = Zeroizing::new(self.guard_disable_password.as_bytes().to_vec());
        self.guard_disable_password.clear();

        // El cliente local no necesita permanecer conectado mientras el helper
        // elevado detiene y elimina el servicio. Cerrarlo antes evita conservar
        // innecesariamente un canal IPC abierto durante la desinstalación.
        self.shutdown_guard_client();

        let (sender, receiver) = mpsc::channel();
        self.guard_operation = Some(receiver);
        self.guard_operation_kind = Some(GuardOperationKind::Uninstall);
        self.show_guard_disable_prompt = false;
        self.set_ok("Desactivando OPAC Guard: autenticando y deteniendo el servicio…".to_owned());

        let _guard_thread = thread::spawn(move || {
            // La derivación/verificación de la contraseña puede ser costosa; se
            // hace fuera del hilo de la GUI para que la ventana nunca se bloquee
            // durante la desactivación. No intentamos abrir una segunda sesion,
            // porque la sesion activa ya mantiene el lock exclusivo del Key Store.
            let result = match KeyStoreSession::authenticate_scoped(path, profile_root, &password) {
                Ok(()) => guard::uninstall_service_elevated(profile_id, private_key),
                Err(_) => Err(
                    "No se pudo autenticar el usuario de OPAC para desactivar OPAC Guard."
                        .to_owned(),
                ),
            };
            let _ = sender.send(result);
        });
        true
    }

    fn internal_drag_button(&self) -> PointerButton {
        if self.internal_drag_with_left_button {
            PointerButton::Primary
        } else {
            PointerButton::Secondary
        }
    }

    fn poll_guard_operation(&mut self) {
        let Some(result) = self
            .guard_operation
            .as_ref()
            .map(|receiver| receiver.try_recv())
        else {
            return;
        };
        match result {
            Ok(result) => {
                self.guard_operation = None;
                let operation = self
                    .guard_operation_kind
                    .take()
                    .unwrap_or(GuardOperationKind::Install);
                match (operation, result) {
                    (GuardOperationKind::Install, Ok(())) => {
                        if let Some(profile_id) = self.active_profile_id {
                            self.guard_service_status = guard::service_status(profile_id);
                            if !matches!(
                                self.guard_service_status,
                                guard::GuardServiceStatus::Running
                            ) {
                                self.set_error(format!("La instalación elevada terminó, pero el servicio no está ejecutándose: {:?}.", self.guard_service_status));
                                return;
                            }
                        }
                        if !self.ensure_guard_client() {
                            return;
                        }
                        self.set_ok("OPAC Guard activado. La protección queda armada continuamente y solo se abre una excepción temporal para operaciones autenticadas.".to_owned());
                    }
                    (GuardOperationKind::Install, Err(error)) => {
                        if let Some(profile_id) = self.active_profile_id {
                            self.guard_service_status = guard::service_status(profile_id);
                        }
                        self.set_error(error);
                    }
                    (GuardOperationKind::Uninstall, Ok(())) => {
                        if let Some(profile_id) = self.active_profile_id {
                            self.guard_service_status = guard::service_status(profile_id);
                            if !matches!(
                                self.guard_service_status,
                                guard::GuardServiceStatus::Missing
                            ) {
                                let state = self.guard_service_status;
                                let _ = self.ensure_guard_client();
                                self.set_error(format!("La desactivación terminó, pero Windows todavía muestra OPAC Guard como {:?}.", state));
                                return;
                            }
                        }
                        self.guard_service_status = guard::GuardServiceStatus::Missing;
                        if let Some(session) = self.session.as_mut()
                            && let Err(error) = session.clear_guard_identity()
                        {
                            self.set_error(format!(
                                "OPAC Guard se desactivó correctamente, pero no se pudo rotar su identidad criptográfica: {}",
                                format_error(&error)
                            ));
                            return;
                        }
                        self.set_ok("OPAC Guard desactivado. La desactivación y la rotación de identidad fueron autenticadas con el usuario de OPAC.".to_owned());
                    }
                    (GuardOperationKind::Uninstall, Err(error)) => {
                        if let Some(profile_id) = self.active_profile_id {
                            self.guard_service_status = guard::service_status(profile_id);
                        }
                        // Si la autenticación o la desinstalación fallan, la sesión
                        // vuelve a tener su cliente local siempre que el servicio
                        // siga ejecutándose.
                        let _ = self.ensure_guard_client();
                        self.set_error(error);
                    }
                }
            }
            Err(mpsc::TryRecvError::Disconnected) => {
                self.guard_operation = None;
                self.guard_operation_kind = None;
                if let Some(profile_id) = self.active_profile_id {
                    self.guard_service_status = guard::service_status(profile_id);
                    if matches!(
                        self.guard_service_status,
                        guard::GuardServiceStatus::Running
                    ) {
                        let _ = self.ensure_guard_client();
                    }
                }
                self.set_error("La operación elevada de OPAC Guard terminó sin devolver un resultado al proceso principal.");
            }
            Err(mpsc::TryRecvError::Empty) => {}
        }
    }

    fn settings_window(&mut self, ctx: &Context) {
        let mut settings_open = self.show_settings;
        let mut close = false;
        let escape_pressed = ctx.input(|input| input.key_pressed(Key::Escape));
        egui::Window::new("Ajustes")
            .open(&mut settings_open)
            .collapsible(false)
            .resizable(false)
            .default_size([470.0, 560.0])
            .show(ctx, |ui| {
                ui.heading("Ajustes");
                ui.add_space(10.0);
                ui.label(RichText::new("OPAC Guard").size(18.0).strong());
                ui.add_space(6.0);
                ui.label("Protege continuamente los archivos cifrados del usuario de OPAC activo. Solo libera una ruta concreta durante una operación autenticada que realmente necesite escribir, mover o borrar; la lectura y las vistas previas no desactivan la protección.");
                ui.add_space(10.0);

                let status = match self.guard_service_status {
                    guard::GuardServiceStatus::Running => "Activo · protección persistente habilitada".to_owned(),
                    guard::GuardServiceStatus::Stopped => "Instalado, pero detenido".to_owned(),
                    guard::GuardServiceStatus::Missing => "No instalado".to_owned(),
                    guard::GuardServiceStatus::Other(state) => format!("En proceso de cambio de estado ({state})"),
                    guard::GuardServiceStatus::Unavailable(error) => format!("No se puede consultar el servicio (Win32 {error})"),
                };
                ui.label(RichText::new(status).strong());
                if let Some(message) = self.status.as_deref() {
                    let color = if self.status_error {
                        ui.visuals().error_fg_color
                    } else {
                        ui.visuals().strong_text_color()
                    };
                    egui::Frame::group(ui.style()).show(ui, |ui| {
                        ui.label(RichText::new(message).color(color));
                    });
                }
                ui.add_space(6.0);
                ui.label(RichText::new("Esta activación afecta solo al usuario de OPAC seleccionado. Las excepciones de uso son temporales, verificadas por el Guard y vuelven a protegerse al terminar; al bloquear o cerrar, el Guard rearma toda la raíz.\n\nNota: al desactivar OPAC Guard, Windows puede tardar un tiempo en detener y eliminar el servicio. La interfaz seguirá respondiendo mientras termina la operación.").small());
                ui.add_space(16.0);

                ui.horizontal(|ui| {
                    if matches!(self.guard_service_status, guard::GuardServiceStatus::Running) {
                        let deactivating = matches!(self.guard_operation_kind, Some(GuardOperationKind::Uninstall));
                        let response = ui.add_enabled(
                            !deactivating,
                            egui::Button::new(if deactivating { "🛡 Desactivando…" } else { "Desactivar" }),
                        );
                        if response.clicked() {
                            self.request_guard_disable();
                        }
                    } else {
                        let activating = self.guard_operation.is_some();
                        let response = ui.add_enabled(
                            !activating,
                            egui::Button::new(if activating {
                                "🛡 Activando…"
                            } else {
                                "🛡 Activar como administrador"
                            }),
                        );
                        if response.clicked() {
                            let Some(profile_id) = self.active_profile_id else {
                                self.set_error("No hay un usuario de OPAC activo.");
                                return;
                            };
                            let roots = self.guard_roots();
                            let Some(session) = self.session.as_mut() else {
                                self.set_error("No hay una sesion autenticada para activar OPAC Guard.");
                                return;
                            };
                            let identity = match session.ensure_guard_identity() {
                                Ok(identity) => identity,
                                Err(error) => {
                                    self.set_error(format!("No se pudo preparar la identidad de OPAC Guard: {error}"));
                                    return;
                                }
                            };
                            let (public_key, config_signature) = match guard::guard_config_signature(
                                profile_id,
                                &roots,
                                &identity.0,
                            ) {
                                Ok(value) => value,
                                Err(error) => {
                                    self.set_error(format!("No se pudo autenticar la configuracion de OPAC Guard: {error}"));
                                    return;
                                }
                            };
                            let (sender, receiver) = mpsc::channel();
                            self.guard_operation = Some(receiver);
                            self.guard_operation_kind = Some(GuardOperationKind::Install);
                            self.set_ok("Solicitando permisos de administrador y preparando OPAC Guard…".to_owned());
                            let _guard_thread = thread::spawn(move || {
                                let result = guard::install_service_elevated(
                                    profile_id,
                                    &roots,
                                    public_key,
                                    config_signature,
                                );
                                let _ = sender.send(result);
                            });
                        }
                    }
                    if ui.button("↻ Comprobar estado").clicked()
                        && self.guard_operation.is_none()
                        && let Some(profile_id) = self.active_profile_id
                    {
                        let status = guard::service_status(profile_id);
                        self.guard_service_status = status;
                        if let guard::GuardServiceStatus::Unavailable(error) = status {
                            self.set_error(format!("No se pudo consultar el servicio de OPAC Guard (error Win32 {error})."));
                        } else {
                            self.set_ok(format!("Estado de OPAC Guard actualizado: {status:?}."));
                        }
                    }
                });
                if let Some(kind) = self.guard_operation_kind {
                    ui.add_space(6.0);
                    let message = match kind {
                        GuardOperationKind::Install => "La solicitud de UAC sigue en curso. Esta ventana permanece disponible para mostrar el resultado de la instalación.",
                        GuardOperationKind::Uninstall => "La desactivación está en curso. Puedes seguir usando la interfaz; OPAC mostrará aquí el resultado cuando Windows termine.",
                    };
                    ui.label(RichText::new(message).small());
                }

                ui.add_space(18.0);
                ui.separator();
                ui.add_space(10.0);
                ui.label(RichText::new("Apariencia").size(18.0).strong());
                ui.add_space(6.0);
                ui.label("Elige el modo de apariencia de OPAC. El modo oscuro es el predeterminado.");
                let previous_dark_mode = self.dark_mode;
                ui.horizontal(|ui| {
                    ui.radio_value(&mut self.dark_mode, true, "Modo oscuro");
                    ui.radio_value(&mut self.dark_mode, false, "Modo claro");
                });
                if self.dark_mode != previous_dark_mode {
                    configure_theme(ctx, self.dark_mode);
                }

                ui.add_space(16.0);
                ui.separator();
                ui.add_space(10.0);
                ui.label(RichText::new("Arrastre interno para ordenar").size(18.0).strong());
                ui.add_space(6.0);
                ui.label("Elige qué botón del ratón inicia el arrastre de archivos y carpetas dentro de la Caja Fuerte.");
                ui.horizontal(|ui| {
                    ui.radio_value(
                        &mut self.internal_drag_with_left_button,
                        true,
                        "Clic izquierdo",
                    );
                    ui.radio_value(
                        &mut self.internal_drag_with_left_button,
                        false,
                        "Clic derecho",
                    );
                });
                ui.label(
                    RichText::new(if self.internal_drag_with_left_button {
                        "Arrastre interno: clic izquierdo + movimiento. El clic derecho conserva el menú contextual."
                    } else {
                        "Arrastre interno: clic derecho + movimiento. El clic izquierdo conserva la selección y apertura."
                    })
                    .small(),
                );

                ui.add_space(14.0);
                ui.separator();
                ui.add_space(10.0);
                ui.label(RichText::new("Protección de capturas de pantalla").size(18.0).strong());
                ui.add_space(6.0);
                ui.add_enabled(
                    cfg!(target_os = "windows"),
                    egui::Checkbox::new(
                        &mut self.block_screen_captures,
                        "No permitir capturas de pantalla de OPAC",
                    ),
                );
                ui.label(
                    RichText::new(
                        "Excluye la ventana completa de capturas y grabaciones compatibles con Windows, incluso al seleccionar una región o la ventana de OPAC. Es independiente de OPAC Guard.",
                    )
                    .small(),
                );
                ui.label(
                    RichText::new(
                        "No protege frente a cámaras, fotografías o métodos que no respeten la protección de ventana de Windows.",
                    )
                    .small(),
                );
                if !cfg!(target_os = "windows") {
                    ui.label(RichText::new("Esta función solo está disponible en Windows.").small());
                } else if self.screen_capture_protection_applied {
                    ui.label(RichText::new("Estado: capturas bloqueadas para esta ventana.").small());
                } else if self.block_screen_captures {
                    ui.label(RichText::new("Estado: pendiente de aplicar en la ventana nativa.").small());
                }

                ui.add_space(14.0);
                if ui.button("Cerrar").clicked() {
                    close = true;
                }
            });

        if escape_pressed && !self.show_guard_disable_prompt {
            close = true;
        }
        if close {
            settings_open = false;
        }
        self.show_settings = settings_open;

        if self.show_guard_disable_prompt {
            let mut close_prompt = false;
            egui::Window::new("Desactivar OPAC Guard")
                .collapsible(false)
                .resizable(false)
                .default_size([430.0, 210.0])
                .show(ctx, |ui| {
                    ui.heading("Confirmar desactivación");
                    ui.add_space(8.0);
                    ui.label(
                        "Para desactivar OPAC Guard debes volver a autenticar el usuario de OPAC que lo activó.",
                    );
                    ui.add_space(8.0);
                    ui.label(
                        RichText::new("La contraseña se verifica contra el Key Store cifrado y no se entrega al servicio Guard.")
                            .small(),
                    );
                    ui.add_space(12.0);
                    let response = ui.add(
                        egui::TextEdit::singleline(&mut *self.guard_disable_password)
                            .password(true)
                            .desired_width(ui.available_width().max(1.0))
                            .hint_text("Contraseña maestra del usuario"),
                    );
                    ui.add_space(14.0);
                    ui.horizontal(|ui| {
                        if ui.button("Cancelar").clicked() {
                            self.guard_disable_password.clear();
                            close_prompt = true;
                        }
                        if (ui.button(RichText::new("Desactivar").strong()).clicked()
                            || (response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter))))
                            && self.confirm_guard_disable()
                        {
                            close_prompt = true;
                        }
                    });
                });
            if close_prompt {
                self.show_guard_disable_prompt = false;
            }
            if close {
                self.show_settings = false;
            }
        }
    }

    fn vault_root_path(&self) -> PathBuf {
        self.vault
            .as_ref()
            .map(|vault| vault.location().to_path_buf())
            .unwrap_or_default()
    }

    fn file_children(&self, parent: &Path) -> Vec<FileEntry> {
        let mut children = self
            .files
            .iter()
            .filter(|entry| entry.disk_path.parent() == Some(parent))
            .cloned()
            .collect::<Vec<_>>();
        children.sort_by_key(|entry| entry.metadata.original_name.to_lowercase());
        children
    }

    fn folder_children(&self, parent: &Path) -> Vec<FolderEntry> {
        let mut children = self
            .folders
            .iter()
            .filter(|folder| folder.disk_path.parent() == Some(parent))
            .cloned()
            .collect::<Vec<_>>();
        children.sort_by_key(|folder| folder.metadata.original_name.to_lowercase());
        children
    }

    fn select_folder(&mut self, folder: Option<PathBuf>) {
        if !self.save_pending_edit() {
            return;
        }
        let root = self.vault_root_path();
        if let Some(path) = &folder
            && path != &root
            && !self.folders.iter().any(|entry| &entry.disk_path == path)
        {
            return;
        }
        self.current_folder = folder;
        self.selected_file = None;
        self.stop_audio_preview();
        self.clear_preview_state();
        self.editing_text = false;
        self.edit_original_text = None;
        self.markdown_cache = CommonMarkCache::default();
    }

    fn folder_name_for_path(&self, path: &Path) -> Option<String> {
        if path == self.vault_root_path().as_path() {
            return Some("raíz".to_owned());
        }
        self.folders
            .iter()
            .find(|folder| folder.disk_path == path)
            .map(|folder| folder.metadata.original_name.clone())
    }

    fn selected_vault_is_locked(&self) -> bool {
        self.selected_vault_id
            .and_then(|id| {
                self.session.as_ref().and_then(|session| {
                    session.list_vaults().into_iter().find(|info| info.id == id)
                })
            })
            .is_some_and(|info| info.has_pin)
            && self.vault.is_none()
    }

    fn can_delete_current_vault(&self) -> bool {
        self.vault
            .as_ref()
            .is_some_and(|vault| !vault.info().has_pin || self.vault_pin_authenticated)
    }

    fn locked_vault_state(&mut self, ui: &mut egui::Ui) {
        let name = self
            .selected_vault_id
            .and_then(|id| {
                self.session.as_ref().and_then(|session| {
                    session.list_vaults().into_iter().find(|info| info.id == id)
                })
            })
            .map(|info| info.name);

        ui.vertical_centered(|ui| {
            ui.add_space(125.0);
            ui.label(RichText::new("🔒").size(44.0));
            ui.add_space(12.0);
            ui.label(RichText::new("Caja Fuerte protegida").size(25.0).strong());
            if let Some(name) = name {
                ui.add_space(6.0);
                ui.label(RichText::new(name).color(Color32::from_rgb(158, 149, 168)));
            }
            ui.add_space(12.0);
            ui.label(
                RichText::new(
                    "Los archivos y la clave permanecen protegidos hasta introducir el PIN.",
                )
                .color(Color32::from_rgb(186, 176, 194)),
            );
            ui.add_space(20.0);
            ui.vertical_centered(|ui| {
                if ui
                    .add(
                        egui::Button::new(
                            RichText::new("Introduzca PIN para ver los archivos").strong(),
                        )
                        .min_size([310.0, 44.0].into()),
                    )
                    .clicked()
                {
                    self.pending_pin_vault = self.selected_vault_id;
                    self.pin_value.clear();
                    self.show_pin_prompt = true;
                }
            });
            ui.add_space(8.0);
            if ui
                .button(RichText::new("o desbloquear con Clave portable").small())
                .clicked()
            {
                self.pending_key_vault = self.selected_vault_id;
                self.key_unlock_value.clear();
                self.show_key_unlock = true;
            }
        });
    }

    fn empty_vault_state(&mut self, ui: &mut egui::Ui) {
        ui.vertical_centered(|ui| {
            ui.add_space(120.0);
            ui.label(RichText::new("Tu espacio privado").size(24.0).strong());
            ui.add_space(8.0);
            ui.label(
                RichText::new("Crea una Caja Fuerte y luego arrastra archivos aquí.")
                    .color(Color32::from_rgb(158, 149, 168)),
            );
            ui.add_space(22.0);
            if ui
                .add(
                    egui::Button::new(
                        RichText::new("+  Nueva caja fuerte")
                            .size(16.0)
                            .color(Color32::from_rgb(186, 143, 230)),
                    )
                    .frame(false),
                )
                .clicked()
            {
                self.new_vault_name.clear();
                self.new_vault_parent = None;
                self.new_vault_use_imported_key = false;
                self.new_vault_imported_key.clear();
                self.show_new_vault = true;
            }
            ui.add_space(6.0);
            ui.label(
                RichText::new("También puedes arrastrar archivos directamente sobre la ventana.")
                    .small()
                    .color(Color32::from_rgb(150, 140, 160)),
            );
        });
    }

    fn file_list(&mut self, ui: &mut egui::Ui) {
        let vault_name = self
            .vault
            .as_ref()
            .map(|v| v.info().name.clone())
            .unwrap_or_default();
        let root = self.vault_root_path();
        self.expanded_folders.retain(|path| {
            path == &root || self.folders.iter().any(|folder| &folder.disk_path == path)
        });

        ui.add_space(16.0);
        ui.horizontal(|ui| {
            ui.add_space(18.0);
            ui.label(RichText::new(&vault_name).size(22.0).strong());
            ui.label(
                RichText::new(format!(
                    "{} archivos · {} carpetas",
                    self.files.len(),
                    self.folders.len()
                ))
                .color(Color32::from_rgb(158, 149, 168)),
            );
            ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                self.access_mode_selector(ui);
            });
        });

        ui.add_space(8.0);
        ui.horizontal(|ui| {
            ui.add_space(18.0);
            let enabled = self.import_task.is_none()
                && self.preload_task.is_none()
                && self.audio_task.is_none()
                && !self.video_preview_busy();
            ui.add_enabled_ui(enabled, |ui| {
                ui.scope(|ui| {
                    ui.style_mut().spacing.button_padding = egui::vec2(11.0, 7.0);
                    let plus_response =
                        ui.menu_button(RichText::new("+").size(28.0).strong(), |ui| {
                            ui.set_min_width(230.0);
                            if ui.button("Nueva carpeta").clicked() {
                                self.begin_new_folder(self.current_folder.clone());
                                ui.close();
                            }
                            if ui.button("Nuevo archivo de texto").clicked() {
                                self.begin_new_text_file(self.current_folder.clone());
                                ui.close();
                            }
                            if ui.button("Importar archivos…").clicked() {
                                self.import_files_manually();
                                ui.close();
                            }
                        });
                    plus_response
                        .response
                        .on_hover_text("Crear carpeta o archivo Markdown");
                });
            });
            ui.label(
                RichText::new(format!("Destino actual: {}", self.folder_breadcrumb()))
                    .small()
                    .color(Color32::from_rgb(145, 136, 153)),
            );
        });
        ui.add_space(8.0);

        if let Some(task) = &self.import_task {
            let total_progress = if task.total_bytes == 0 {
                1.0
            } else {
                task.completed_bytes.min(task.total_bytes) as f32 / task.total_bytes as f32
            };
            let current_progress = if task.current_bytes_total == 0 {
                0.0
            } else {
                task.current_bytes_completed.min(task.current_bytes_total) as f32
                    / task.current_bytes_total as f32
            };
            egui::Frame::new()
                .fill(theme_neutral(self.dark_mode, (24, 21, 30), (251, 249, 252)))
                .stroke(egui::Stroke::new(
                    1.0,
                    theme_neutral(self.dark_mode, (52, 44, 61), (222, 217, 226)),
                ))
                .corner_radius(egui::CornerRadius::same(10))
                .inner_margin(egui::Margin::symmetric(12, 8))
                .show(ui, |ui| {
                    ui.vertical(|ui| {
                        let current = task
                            .current
                            .as_deref()
                            .unwrap_or("Preparando siguiente archivo…");
                        ui.label(
                            RichText::new(format!(
                                "Progreso total · {}/{} archivos · cifrando: {current}",
                                task.completed, task.total
                            ))
                            .size(14.0),
                        );
                        ui.add(
                            egui::ProgressBar::new(total_progress)
                                .desired_width(ui.available_width().max(120.0))
                                .desired_height(8.0)
                                .text(format!(
                                    "{} / {}",
                                    format_bytes(task.completed_bytes),
                                    format_bytes(task.total_bytes)
                                )),
                        );

                        if task.current_bytes_total > 0 {
                            ui.add_space(4.0);
                            if task.current_chunks_total > 1 {
                                ui.label(
                                    RichText::new(format!(
                                        "Archivo actual · {} / {} · chunks {}/{}",
                                        format_bytes(task.current_bytes_completed),
                                        format_bytes(task.current_bytes_total),
                                        task.current_chunks_completed,
                                        task.current_chunks_total
                                    ))
                                    .small(),
                                );
                            } else {
                                ui.label(
                                    RichText::new(format!(
                                        "Archivo actual · {} / {}",
                                        format_bytes(task.current_bytes_completed),
                                        format_bytes(task.current_bytes_total)
                                    ))
                                    .small(),
                                );
                            }
                            ui.add(
                                egui::ProgressBar::new(current_progress)
                                    .desired_width(ui.available_width().max(120.0))
                                    .desired_height(6.0)
                                    .show_percentage(),
                            );
                        }
                    });
                });
            ui.add_space(8.0);
        }

        let drop_fill = if self.drop_active {
            Color32::from_rgb(46, 30, 61)
        } else {
            theme_neutral(self.dark_mode, (24, 21, 30), (251, 249, 252))
        };
        egui::Frame::new()
            .fill(drop_fill)
            .stroke(egui::Stroke::new(
                1.0_f32,
                if self.drop_active {
                    Color32::from_rgb(171, 106, 222)
                } else {
                    theme_neutral(self.dark_mode, (52, 44, 61), (222, 217, 226))
                },
            ))
            .corner_radius(egui::CornerRadius::same(12))
            .inner_margin(egui::Margin::symmetric(12, 8))
            .show(ui, |ui| {
                let hint_text = if self.drop_active {
                    if let Some(name) = self.drop_target_folder.as_ref().and_then(|path| self.folder_name_for_path(path)) {
                        format!("Suelta para cifrar en «{name}»")
                    } else {
                        "Suelta para cifrar en la raíz".to_owned()
                    }
                } else if let Some(task) = &self.import_task {
                    if let Some(current) = &task.current {
                        format!("Cifrando: {current}")
                    } else {
                        "Cifrado en curso…".to_owned()
                    }
                } else {
                    "Arrastra archivos aquí: sobre una carpeta = dentro de ella · en la raíz = sin carpeta".to_owned()
                };
                let hint_color = if self.drop_active {
                    Color32::from_rgb(224, 194, 242)
                } else {
                    Color32::from_rgb(142, 132, 153)
                };
                ui.label(RichText::new(hint_text).color(hint_color).size(14.0));
            });
        ui.add_space(8.0);

        let tree_frame = egui::Frame::new()
            .fill(theme_neutral(self.dark_mode, (19, 17, 24), (248, 247, 250)))
            .stroke(egui::Stroke::new(
                1.0,
                theme_neutral(self.dark_mode, (44, 38, 51), (220, 216, 225)),
            ))
            .corner_radius(egui::CornerRadius::same(10))
            .inner_margin(egui::Margin::symmetric(10, 8))
            .show(ui, |ui| {
                egui::ScrollArea::vertical()
                    .auto_shrink([false, false])
                    .max_height(ui.available_height().max(180.0))
                    .show(ui, |ui| {
                        self.render_file_tree(ui, &root, 0, &[]);
                    });
            });

        self.handle_internal_drop_to_root(ui.ctx(), tree_frame.response.rect, &root);
    }

    fn handle_internal_drop_to_root(&mut self, ctx: &Context, tree_rect: egui::Rect, root: &Path) {
        if !ctx.input(|input| input.pointer.any_released()) {
            return;
        }
        let Some(pointer) = ctx.input(|input| input.pointer.interact_pos()) else {
            return;
        };
        if !tree_rect.contains(pointer) {
            return;
        }

        // Folder rows and the explicit Raíz row have their own drop handlers.
        // This fallback makes every other point in the tree a valid way to
        // move an item back to the immutable root, so users never have to
        // move it upward level by level.
        if self
            .folder_drop_rects
            .iter()
            .any(|(_, rect)| rect.contains(pointer))
        {
            return;
        }

        let Some(payload) = egui::DragAndDrop::payload::<PathBuf>(ctx) else {
            return;
        };
        let source = payload.as_ref().clone();
        if source == *root {
            return;
        }
        self.move_internal_item(source, root.to_path_buf());
    }

    fn paint_tree_connector(
        ui: &egui::Ui,
        row_rect: egui::Rect,
        depth: usize,
        ancestor_last: &[bool],
        is_last: bool,
        file_row: bool,
        continues_to_children: bool,
    ) {
        let dark_mode = ui.visuals().dark_mode;
        if depth == 0 {
            return;
        }

        const TREE_LEFT: f32 = 10.0;
        const TREE_INDENT: f32 = 20.0;
        const TREE_TOGGLE: f32 = 22.0;
        let stroke =
            egui::Stroke::new(1.0, theme_neutral(dark_mode, (70, 62, 78), (208, 204, 212)));
        let toggle_center_offset = TREE_TOGGLE * 0.5;
        let tree_origin = row_rect.left() + TREE_LEFT;
        let center_y = row_rect.center().y;
        // egui inserts vertical item spacing between sibling rows. Extend the
        // trunks by half that gap so consecutive row segments meet cleanly
        // instead of producing visible breaks in the hierarchy lines.
        let half_row_gap = (ui.spacing().item_spacing.y * 0.5).max(0.0);
        let vertical_top = row_rect.top() - half_row_gap;
        let vertical_bottom = row_rect.bottom() + half_row_gap;

        // Every vertical trunk is anchored to the centerline of its parent
        // disclosure control. Keeping this coordinate system independent of
        // the rendered label avoids the small drift that appeared at depth 2+.
        for (level, ancestor_is_last) in ancestor_last.iter().enumerate() {
            if !ancestor_is_last {
                let x = tree_origin + level as f32 * TREE_INDENT + toggle_center_offset;
                ui.painter().line_segment(
                    [egui::pos2(x, vertical_top), egui::pos2(x, vertical_bottom)],
                    stroke,
                );
            }
        }

        let branch_x = tree_origin + (depth - 1) as f32 * TREE_INDENT + toggle_center_offset;
        let terminal_row = is_last && !continues_to_children;
        let branch_bottom = if terminal_row {
            center_y
        } else {
            vertical_bottom
        };
        ui.painter().line_segment(
            [
                egui::pos2(branch_x, vertical_top),
                egui::pos2(branch_x, branch_bottom),
            ],
            stroke,
        );

        // A terminal branch must finish exactly at its `└` junction. Paint a
        // tiny background guard below the junction so no other segment can
        // visually bleed past the endpoint when adjacent connector trunks
        // share the same row gap.
        if terminal_row {
            let guard_top = center_y + stroke.width + 0.5;
            let guard_bottom = vertical_bottom.max(guard_top);
            ui.painter().rect_filled(
                egui::Rect::from_min_max(
                    egui::pos2(branch_x - stroke.width, guard_top),
                    egui::pos2(branch_x + stroke.width, guard_bottom),
                ),
                0.0,
                theme_neutral(dark_mode, (19, 17, 24), (248, 247, 250)),
            );
        }

        // Files keep the same tree column as folders but have no disclosure
        // button, so the branch ends slightly before the icon rather than
        // floating in the middle of the label.
        let target_x = if file_row {
            tree_origin + depth as f32 * TREE_INDENT + TREE_TOGGLE
        } else {
            tree_origin + depth as f32 * TREE_INDENT + toggle_center_offset
        };
        ui.painter().line_segment(
            [
                egui::pos2(branch_x, center_y),
                egui::pos2(target_x, center_y),
            ],
            stroke,
        );
    }

    fn render_file_tree(
        &mut self,
        ui: &mut egui::Ui,
        parent: &Path,
        depth: usize,
        ancestor_last: &[bool],
    ) {
        let root = self.vault_root_path();
        let is_root = parent == root.as_path();
        let expanded = is_root || self.expanded_folders.contains(parent);
        let children_folders = self.folder_children(parent);
        let children_files = self.file_children(parent);

        if is_root {
            let root_selected = self.current_folder.is_none();
            let (root_inner, internal_drop) = ui.dnd_drop_zone::<PathBuf, _>(
                egui::Frame::new()
                    .fill(Color32::TRANSPARENT)
                    .stroke(egui::Stroke::NONE)
                    .inner_margin(egui::Margin::ZERO),
                |ui| {
                    ui.add(
                        egui::Button::selectable(
                            root_selected,
                            RichText::new("⌂  Raíz").size(16.0).strong(),
                        )
                        .min_size(egui::vec2(ui.available_width(), 34.0))
                        .sense(Sense::click()),
                    )
                },
            );
            let root_response = root_inner.response;
            if root_selected {
                ui.painter().rect_stroke(
                    root_response.rect.expand(1.0),
                    5.0,
                    egui::Stroke::new(1.0, Color32::from_rgb(120, 78, 146)),
                    egui::StrokeKind::Inside,
                );
            }

            // The root is a permanent drop target but never a draggable item.
            // It therefore lets files/folders leave any nested parent without
            // ever allowing the root itself to be moved.
            self.folder_drop_rects
                .push((root.to_path_buf(), root_response.interact_rect));
            if (self.drop_target_folder.as_ref() == Some(&root) && self.drop_active)
                || root_response.dnd_hover_payload::<PathBuf>().is_some()
            {
                ui.painter().rect_stroke(
                    root_response.rect.expand(2.0),
                    5.0,
                    egui::Stroke::new(1.5, Color32::from_rgb(188, 126, 226)),
                    egui::StrokeKind::Inside,
                );
            }
            if root_response.clicked() {
                self.select_folder(None);
            }
            if let Some(payload) = internal_drop {
                self.move_internal_item((*payload).clone(), root.to_path_buf());
            }
        }

        if !expanded {
            return;
        }

        for (index, folder) in children_folders.iter().enumerate() {
            let folder_path = folder.disk_path.clone();
            let has_children = !self.folder_children(&folder_path).is_empty()
                || !self.file_children(&folder_path).is_empty();
            let folder_expanded = self.expanded_folders.contains(&folder_path);
            let is_last = index + 1 == children_folders.len() && children_files.is_empty();
            let selected = self.current_folder.as_ref() == Some(&folder_path);

            let mut toggle_expand = false;
            let mut open_folder = false;
            let mut new_folder_requested = false;
            let mut new_text_requested = false;
            let mut delete_folder_requested = false;
            let mut export_folder_requested = false;
            let mut rename_requested = false;

            let row = ui.horizontal(|ui| {
                ui.add_space(depth as f32 * 20.0 + 10.0);
                let toggle_text = if has_children {
                    if folder_expanded { "⌄" } else { "›" }
                } else {
                    "·"
                };
                let toggle = ui.add(
                    egui::Button::new(RichText::new(toggle_text).size(17.0))
                        .min_size([22.0, 32.0].into()),
                );
                if toggle.clicked() && has_children {
                    toggle_expand = true;
                }
                let folder_button = ui.add(
                    egui::Button::selectable(
                        selected,
                        RichText::new(format!("📁  {}", folder.metadata.original_name)).size(15.5),
                    )
                    .min_size([ui.available_width().max(180.0), 32.0].into())
                    .sense(Sense::click_and_drag()),
                );
                self.folder_drop_rects
                    .push((folder_path.clone(), folder_button.interact_rect));

                if (self.drop_target_folder.as_ref() == Some(&folder_path) && self.drop_active)
                    || folder_button.dnd_hover_payload::<PathBuf>().is_some()
                {
                    ui.painter().rect_stroke(
                        folder_button.rect.expand(2.0),
                        5.0,
                        egui::Stroke::new(1.5, Color32::from_rgb(188, 126, 226)),
                        egui::StrokeKind::Inside,
                    );
                }
                if folder_button.clicked() {
                    toggle_expand = has_children;
                    open_folder = true;
                }
                if folder_button.drag_started_by(self.internal_drag_button()) {
                    folder_button.dnd_set_drag_payload(folder_path.clone());
                }
                if let Some(payload) = folder_button.dnd_release_payload::<PathBuf>() {
                    self.move_internal_item((*payload).clone(), folder_path.clone());
                }
                folder_button.context_menu(|ui| {
                    if ui.button("Abrir carpeta").clicked() {
                        open_folder = true;
                        ui.close();
                    }
                    if ui
                        .button(if folder_expanded {
                            "Contraer"
                        } else {
                            "Desplegar"
                        })
                        .clicked()
                    {
                        toggle_expand = true;
                        ui.close();
                    }
                    ui.separator();
                    if ui.button("Nueva carpeta aquí").clicked() {
                        new_folder_requested = true;
                        ui.close();
                    }
                    if ui.button("Nuevo archivo de texto aquí").clicked() {
                        new_text_requested = true;
                        ui.close();
                    }
                    ui.separator();
                    if ui.button("Renombrar…").clicked() {
                        rename_requested = true;
                        ui.close();
                    }
                    if ui.button("Exportar carpeta…").clicked() {
                        export_folder_requested = true;
                        ui.close();
                    }
                    if ui.button("Eliminar carpeta…").clicked() {
                        delete_folder_requested = true;
                        ui.close();
                    }
                });
            });
            Self::paint_tree_connector(
                ui,
                row.response.rect,
                depth,
                ancestor_last,
                is_last,
                false,
                folder_expanded && has_children,
            );

            if toggle_expand {
                if folder_expanded {
                    self.expanded_folders.remove(&folder_path);
                } else {
                    self.expanded_folders.insert(folder_path.clone());
                }
            }
            if open_folder {
                self.select_folder(Some(folder_path.clone()));
            }
            if new_folder_requested {
                self.begin_new_folder(Some(folder_path.clone()));
            }
            if new_text_requested {
                self.begin_new_text_file(Some(folder_path.clone()));
            }
            if rename_requested {
                self.begin_rename(&folder_path);
            }
            if export_folder_requested {
                self.request_export_folder(&folder_path);
            }
            if delete_folder_requested {
                self.request_delete_folder(&folder_path);
            }

            if folder_expanded {
                let mut child_ancestors = ancestor_last.to_vec();
                child_ancestors.push(is_last);
                self.render_file_tree(ui, &folder_path, depth + 1, &child_ancestors);
            }
        }

        for (index, entry) in children_files.iter().enumerate() {
            let disk_path = entry.disk_path.clone();
            let original_name = entry.metadata.original_name.clone();
            let original_size = entry.metadata.original_size;
            let selected = self.selected_file.as_ref() == Some(&disk_path);
            let is_last = index + 1 == children_files.len();

            let mut export_requested = false;
            let mut delete_requested = false;
            let mut rename_requested = false;

            let row = ui.horizontal(|ui| {
                ui.add_space(depth as f32 * 20.0 + 32.0);
                let file_button = ui.add(
                    egui::Button::selectable(
                        selected,
                        RichText::new(format!("{}  {}", file_icon(&original_name), original_name))
                            .size(15.0),
                    )
                    .min_size([ui.available_width().max(180.0), 32.0].into())
                    .sense(Sense::click_and_drag()),
                );

                if file_button.clicked() {
                    self.select_file_for_preview(disk_path.clone());
                }
                if file_button.double_clicked() {
                    self.open_selected_externally();
                }
                if file_button.drag_started_by(self.internal_drag_button()) {
                    file_button.dnd_set_drag_payload(disk_path.clone());
                }

                file_button.context_menu(|ui| {
                    if ui.button("Abrir").clicked() {
                        self.select_file_for_preview(disk_path.clone());
                        ui.close();
                    }
                    if ui
                        .button("Abrir con la aplicación predeterminada (copia temporal)")
                        .clicked()
                    {
                        self.select_file_for_preview(disk_path.clone());
                        self.open_selected_externally();
                        ui.close();
                    }
                    ui.separator();
                    if ui.button("Renombrar…").clicked() {
                        rename_requested = true;
                        ui.close();
                    }
                    if is_editable_text(&original_name) && ui.button("Editar texto").clicked() {
                        self.select_file_for_preview(disk_path.clone());
                        self.editing_text = true;
                        ui.close();
                    }
                    if ui.button("Exportar…").clicked() {
                        export_requested = true;
                        ui.close();
                    }
                    if ui.button("Eliminar…").clicked() {
                        delete_requested = true;
                        ui.close();
                    }
                    ui.separator();
                    ui.label(RichText::new(format!("Tamaño: {} bytes", original_size)).small());
                });
            });
            Self::paint_tree_connector(
                ui,
                row.response.rect,
                depth,
                ancestor_last,
                is_last,
                true,
                false,
            );

            // Dropping onto a file is intentionally not a move target. Use the
            // folder row or Raíz to choose the destination explicitly.

            if rename_requested {
                self.begin_rename(&disk_path);
            }
            if export_requested {
                self.export_file(&disk_path);
            }
            if delete_requested {
                self.request_delete_file(&disk_path);
            }
        }
    }

    fn folder_breadcrumb(&self) -> String {
        let root = self.vault_root_path();
        let Some(current) = self.current_folder.as_ref() else {
            return "⌂ / Raíz".to_owned();
        };
        let mut chain = Vec::new();
        let mut cursor = Some(current.as_path());
        while let Some(path) = cursor {
            if path == root.as_path() {
                break;
            }
            if let Some(name) = self.folder_name_for_path(path) {
                chain.push(name);
            } else {
                break;
            }
            cursor = path.parent();
        }
        chain.reverse();
        if chain.is_empty() {
            "⌂ / Raíz".to_owned()
        } else {
            format!("⌂ / {}", chain.join(" / "))
        }
    }

    fn preview_panel(&mut self, ui: &mut egui::Ui) {
        ui.add_space(14.0);
        ui.horizontal(|ui| {
            ui.label(RichText::new("Vista previa").size(18.0).strong());
            if self.audio_task.is_some() {
                ui.spinner();
            }
        });
        ui.add_space(6.0);

        let selected_name = self
            .selected_file
            .as_ref()
            .and_then(|path| self.files.iter().find(|entry| &entry.disk_path == path))
            .map(|entry| entry.metadata.original_name.clone());

        if let Some(name) = selected_name {
            ui.horizontal(|ui| {
                ui.label(RichText::new(name.as_str()).color(Color32::from_rgb(210, 203, 216)));
                if is_editable_text(&name)
                    && matches!(self.preview_kind, PreviewKind::Text | PreviewKind::Markdown)
                    && self.preview_text.is_some()
                    && self.import_task.is_none()
                    && self.preload_task.is_none()
                    && self.audio_task.is_none()
                    && !self.video_preview_busy()
                {
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        if self.editing_text {
                            if ui.button("Cancelar").clicked() {
                                self.cancel_text_edit();
                            }
                            if ui.button(RichText::new("Guardar").strong()).clicked() {
                                self.save_text_edit();
                            }
                        } else if ui.button(RichText::new("Editar").strong()).clicked() {
                            self.begin_text_edit();
                        }
                    });
                }
            });
        }
        ui.separator();

        match self.preview_kind {
            PreviewKind::Markdown => {
                if let Some(text) = self.preview_text.as_mut() {
                    if self.editing_text {
                        egui::ScrollArea::vertical()
                            .auto_shrink([false, false])
                            .show(ui, |ui| {
                                ui.add(
                                    egui::TextEdit::multiline(&mut **text)
                                        .font(TextStyle::Monospace)
                                        .desired_width(ui.available_width().max(1.0))
                                        .desired_rows(24),
                                );
                            });
                    } else {
                        ui.style_mut().url_in_tooltip = true;
                        egui::ScrollArea::vertical()
                            .auto_shrink([false, false])
                            .show(ui, |ui| {
                                CommonMarkViewer::new().show(
                                    ui,
                                    &mut self.markdown_cache,
                                    text.as_str(),
                                );
                            });
                    }
                } else {
                    ui.add_space(12.0);
                    ui.label(
                        RichText::new("Este Markdown es demasiado grande para la vista previa.")
                            .color(Color32::from_rgb(184, 169, 194)),
                    );
                }
            }
            PreviewKind::Text => {
                if let Some(text) = self.preview_text.as_mut() {
                    egui::ScrollArea::vertical().show(ui, |ui| {
                        ui.add(
                            egui::TextEdit::multiline(&mut **text)
                                .font(TextStyle::Monospace)
                                .desired_width(ui.available_width().max(1.0))
                                .interactive(self.editing_text),
                        );
                    });
                }
            }
            PreviewKind::Pdf => self.pdf_preview_panel(ui),
            PreviewKind::Image => self.image_preview_panel(ui),
            PreviewKind::Audio => self.audio_preview_panel(ui),
            #[cfg(target_os = "windows")]
            PreviewKind::Video => self.video_preview_panel(ui),
            #[cfg(not(target_os = "windows"))]
            PreviewKind::Video => {
                ui.add_space(12.0);
                ui.label("La vista previa de vídeo integrada está disponible en Windows.");
            }
            PreviewKind::Unsupported => {
                ui.add_space(12.0);
                ui.label(
                    RichText::new("No hay una vista previa integrada para este tipo de archivo.")
                        .color(Color32::from_rgb(184, 169, 194)),
                );
                ui.small(
                    "Abrir externamente crea una copia temporal descifrada dentro del área privada de la sesión.",
                );
                ui.add_space(8.0);
                if ui
                    .button("Abrir con la aplicación predeterminada (copia temporal)")
                    .clicked()
                {
                    self.open_selected_externally();
                }
            }
            PreviewKind::None => {}
        }
    }

    fn pdf_preview_panel(&mut self, ui: &mut egui::Ui) {
        if let Some(page_count) = self.preview_pdf_page_count {
            let rendered_count = self.preview_pdf_pages.len();
            let suffix = if page_count == rendered_count {
                format!(
                    "{page_count} {}",
                    if page_count == 1 {
                        "página"
                    } else {
                        "páginas"
                    }
                )
            } else {
                format!(
                    "{page_count} {} · mostrando las primeras {rendered_count}",
                    if page_count == 1 {
                        "página"
                    } else {
                        "páginas"
                    }
                )
            };
            ui.label(
                RichText::new(format!("PDF · {suffix}")).color(Color32::from_rgb(184, 169, 194)),
            );
            ui.add_space(8.0);
        }

        if self.preview_pdf_pages.is_empty() {
            ui.add_space(12.0);
            ui.label(
                RichText::new("No se pudo preparar una vista visual de este PDF.")
                    .color(Color32::from_rgb(184, 169, 194)),
            );
        } else {
            egui::ScrollArea::vertical()
                .auto_shrink([false, false])
                .show(ui, |ui| {
                    for (index, page) in self.preview_pdf_pages.iter_mut().enumerate() {
                        if page.texture.is_none()
                            && let Some(rgba) = page.rgba.take()
                        {
                            let image = egui::ColorImage::from_rgba_unmultiplied(page.size, &rgba);
                            let texture_name = format!("opac-preview-pdf-{}", Uuid::new_v4());
                            page.texture = Some(ui.ctx().load_texture(
                                texture_name,
                                image,
                                egui::TextureOptions::LINEAR,
                            ));
                        }

                        let Some(texture) = page.texture.as_ref() else {
                            continue;
                        };

                        ui.label(
                            RichText::new(format!("Página {}", index + 1))
                                .small()
                                .color(Color32::from_rgb(150, 140, 160)),
                        );

                        let width = page.size[0] as f32;
                        let height = page.size[1] as f32;
                        let available_width = ui.available_width().max(1.0);
                        let scale = (available_width / width).min(1.0);
                        let size = egui::vec2(width * scale, height * scale);

                        ui.add(
                            egui::Image::from_texture(texture)
                                .fit_to_exact_size(size)
                                .alt_text(format!("Página {} del PDF", index + 1)),
                        );
                        ui.add_space(10.0);
                        ui.separator();
                        ui.add_space(10.0);
                    }
                });
        }

        ui.add_space(8.0);
        if ui
            .button("Abrir PDF con la aplicación predeterminada")
            .clicked()
        {
            self.open_selected_externally();
        }
    }

    fn image_preview_panel(&mut self, ui: &mut egui::Ui) {
        if self.preview_image_texture.is_none()
            && let Some(image) = self.preview_image.take()
        {
            let texture_name = format!("opac-preview-image-{}", Uuid::new_v4());
            let texture = ui
                .ctx()
                .load_texture(texture_name, image, Default::default());
            self.preview_image_texture = Some(texture);
        }

        if let Some([width, height]) = self.preview_image_size {
            ui.label(
                RichText::new(format!("{} × {} px", width, height))
                    .small()
                    .color(Color32::from_rgb(150, 140, 160)),
            );
            ui.add_space(6.0);
        }

        let Some(texture) = self.preview_image_texture.as_ref() else {
            ui.add_space(12.0);
            ui.label(
                RichText::new("No se pudo preparar la vista previa de la imagen.")
                    .color(Color32::from_rgb(184, 169, 194)),
            );
            return;
        };

        egui::ScrollArea::both()
            .auto_shrink([false, false])
            .show(ui, |ui| {
                ui.add(
                    egui::Image::from_texture(texture)
                        .shrink_to_fit()
                        .alt_text("Vista previa de imagen"),
                );
            });
    }

    fn audio_preview_panel(&mut self, ui: &mut egui::Ui) {
        if let Some(task) = &self.audio_task {
            ui.add_space(12.0);
            ui.spinner();
            ui.label("Preparando audio para reproducir…");
            ui.small("El archivo se descifra a una copia temporal autenticada.");
            if ui.button("Cancelar preparación").clicked() {
                task.cancel.store(true, Ordering::Relaxed);
                self.set_ok("Cancelando la preparación del audio…".into());
            }
            return;
        }

        if let Some(error) = self.audio_error.as_deref() {
            ui.add_space(12.0);
            ui.label(RichText::new("No se pudo reproducir este audio.").strong());
            ui.small(error);
            return;
        }

        let Some((position, duration, finished, paused)) =
            self.audio_player.as_ref().map(|player| {
                (
                    player.get_pos(),
                    self.audio_duration.unwrap_or(Duration::ZERO),
                    player.empty(),
                    player.is_paused(),
                )
            })
        else {
            ui.add_space(12.0);
            ui.label(
                RichText::new("Selecciona un archivo de audio compatible para reproducirlo aquí.")
                    .color(Color32::from_rgb(184, 169, 194)),
            );
            return;
        };

        let mut action = None::<AudioAction>;
        ui.add_space(12.0);
        ui.horizontal(|ui| {
            let button_text = if finished || paused { "▶" } else { "⏸" };
            if ui.button(RichText::new(button_text).size(18.0)).clicked() {
                action = Some(if finished {
                    AudioAction::Restart
                } else if paused {
                    AudioAction::Play
                } else {
                    AudioAction::Pause
                });
            }
            if ui.button("■").clicked() {
                action = Some(AudioAction::Stop);
            }
            ui.label(format_audio_time(position));
            ui.label("/");
            ui.label(format_audio_time(duration));
        });

        if duration > Duration::ZERO {
            let max_secs = duration.as_secs_f32().max(0.001);
            let mut seek_secs = position.as_secs_f32().min(max_secs);
            let response = ui.add(
                egui::Slider::new(&mut seek_secs, 0.0..=max_secs)
                    .show_value(false)
                    .text(""),
            );
            if response.drag_stopped() {
                action = Some(AudioAction::Seek(Duration::from_secs_f32(seek_secs)));
            }
        }

        let mut volume = self.audio_volume;
        if ui
            .add(egui::Slider::new(&mut volume, 0.0..=1.0).text("Volumen"))
            .changed()
        {
            self.audio_volume = volume;
            if let Some(player) = self.audio_player.as_ref() {
                player.set_volume(volume);
            }
        }

        match action {
            Some(AudioAction::Play) => {
                if let Some(player) = self.audio_player.as_ref() {
                    player.play();
                }
            }
            Some(AudioAction::Pause) => {
                if let Some(player) = self.audio_player.as_ref() {
                    player.pause();
                }
            }
            Some(AudioAction::Stop) => {
                if let Some(player) = self.audio_player.as_ref() {
                    player.stop();
                }
            }
            Some(AudioAction::Seek(position)) => {
                let result = self
                    .audio_player
                    .as_ref()
                    .map(|player| player.try_seek(position));
                if let Some(Err(error)) = result {
                    self.set_error(format!("No se pudo cambiar la posición del audio: {error}"));
                }
            }
            Some(AudioAction::Restart) => {
                if let Some(path) = self.audio_preview_path.clone()
                    && let Err(error) = self.start_audio_player_from_path(&path)
                {
                    self.set_error(error);
                }
            }
            None => {}
        }
    }

    fn begin_new_folder(&mut self, parent: Option<PathBuf>) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error("Espera a que termine la operación actual antes de crear elementos.");
            return;
        }
        self.new_folder_parent = parent;
        self.new_folder_name.clear();
        self.show_new_folder = true;
    }

    fn begin_new_text_file(&mut self, parent: Option<PathBuf>) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error("Espera a que termine la operación actual antes de crear elementos.");
            return;
        }
        self.new_text_file_parent = parent;
        self.new_text_file_name.clear();
        self.show_new_text_file = true;
    }

    fn new_folder_parent_path(&self) -> PathBuf {
        self.new_folder_parent
            .clone()
            .or_else(|| self.current_folder.clone())
            .unwrap_or_else(|| self.vault_root_path())
    }

    fn new_text_file_parent_path(&self) -> PathBuf {
        self.new_text_file_parent
            .clone()
            .or_else(|| self.current_folder.clone())
            .unwrap_or_else(|| self.vault_root_path())
    }

    fn new_folder_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        let parent_name = self
            .folder_name_for_path(&self.new_folder_parent_path())
            .unwrap_or_else(|| "raíz".to_owned());
        egui::Window::new("Nueva carpeta")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label(format!("Dentro de: {parent_name}"));
                ui.add_space(8.0);
                let response = ui.add(
                    egui::TextEdit::singleline(&mut self.new_folder_name)
                        .desired_width(320.0)
                        .hint_text("Nombre de la carpeta"),
                );
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    if (ui.button(RichText::new("Crear").strong()).clicked()
                        || (response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter))))
                        && self.create_folder_from_dialog()
                    {
                        close = true;
                    }
                });
            });
        if close {
            self.show_new_folder = false;
            self.new_folder_name.clear();
            self.new_folder_parent = None;
        }
    }

    fn create_folder_from_dialog(&mut self) -> bool {
        let name = self.new_folder_name.trim().to_owned();
        if name.is_empty() {
            self.set_error("Escribe un nombre para la carpeta.");
            return false;
        }
        let parent = self.new_folder_parent_path();
        let result = match self.vault.as_ref() {
            Some(vault) => vault.create_folder(&parent, &name),
            None => {
                self.set_error("La Caja Fuerte no está desbloqueada.");
                return false;
            }
        };
        match result {
            Ok(path) => {
                self.refresh_files();
                self.current_folder = Some(path.clone());
                self.selected_file = None;
                self.clear_preview_state();
                self.set_ok(format!("Carpeta «{name}» creada."));
                true
            }
            Err(error) => {
                self.set_error(format!(
                    "No se pudo crear la carpeta: {}",
                    format_error(&error)
                ));
                false
            }
        }
    }

    fn new_text_file_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        let parent_name = self
            .folder_name_for_path(&self.new_text_file_parent_path())
            .unwrap_or_else(|| "raíz".to_owned());
        egui::Window::new("Nuevo archivo de texto")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label(format!("Dentro de: {parent_name}"));
                ui.add_space(8.0);
                let response = ui.add(
                    egui::TextEdit::singleline(&mut self.new_text_file_name)
                        .desired_width(320.0)
                        .hint_text("Nombre del archivo Markdown"),
                );
                ui.add_space(6.0);
                ui.small("Se guardará como archivo .md y se podrá editar en la vista previa.");
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    if (ui.button(RichText::new("Crear").strong()).clicked()
                        || (response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter))))
                        && self.create_text_file_from_dialog()
                    {
                        close = true;
                    }
                });
            });
        if close {
            self.show_new_text_file = false;
            self.new_text_file_name.clear();
            self.new_text_file_parent = None;
        }
    }

    fn create_text_file_from_dialog(&mut self) -> bool {
        let name = self.new_text_file_name.trim().to_owned();
        if name.is_empty() {
            self.set_error("Escribe un nombre para el archivo de texto.");
            return false;
        }
        if !self.save_pending_edit() {
            return false;
        }
        let parent = self.new_text_file_parent_path();
        let result = match self.vault.as_ref() {
            Some(vault) => vault.create_text_file(&parent, &name),
            None => {
                self.set_error("La Caja Fuerte no está desbloqueada.");
                return false;
            }
        };
        match result {
            Ok(path) => {
                let access_mode = self.vault.as_ref().map(|vault| vault.info().access_mode);
                self.stop_audio_preview();
                self.clear_preload_cache();
                self.current_folder = if parent == self.vault_root_path() {
                    None
                } else {
                    Some(parent)
                };
                self.refresh_files();
                self.selected_file = Some(path);
                self.clear_preview_state();
                self.prepare_preview_selected();
                if access_mode == Some(VaultAccessMode::PreloadAll) {
                    self.start_preload_all();
                }
                self.set_ok("Archivo Markdown creado y cifrado.".into());
                true
            }
            Err(error) => {
                self.set_error(format!(
                    "No se pudo crear el archivo: {}",
                    format_error(&error)
                ));
                false
            }
        }
    }

    fn begin_rename(&mut self, path: &Path) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error("Espera a que termine la operación actual antes de renombrar.");
            return;
        }
        let current_name =
            if let Some(folder) = self.folders.iter().find(|folder| folder.disk_path == path) {
                folder.metadata.original_name.clone()
            } else if let Some(file) = self.files.iter().find(|file| file.disk_path == path) {
                file.metadata.original_name.clone()
            } else {
                self.set_error("No se encontró el elemento seleccionado en la Caja Fuerte.");
                return;
            };
        self.pending_rename_path = Some(path.to_path_buf());
        self.rename_name = current_name;
        self.show_rename = true;
    }

    fn rename_dialog(&mut self, ctx: &Context) {
        let Some(path) = self.pending_rename_path.clone() else {
            self.show_rename = false;
            return;
        };
        let is_folder = self.folders.iter().any(|folder| folder.disk_path == path);
        let mut cancel = false;
        let mut confirm = false;
        egui::Window::new("Renombrar")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label(if is_folder {
                    "Cambia el nombre visible de la carpeta. Su contenido no se modifica."
                } else {
                    "Cambia el nombre visible del archivo. El contenido se conserva y se vuelve a sellar."
                });
                ui.add_space(8.0);
                let response = ui.add(
                    egui::TextEdit::singleline(&mut self.rename_name)
                        .desired_width(340.0)
                        .hint_text("Nuevo nombre"),
                );
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        cancel = true;
                    }
                    if (ui.button("Renombrar").clicked()
                        || (response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter))))
                        && !self.rename_name.trim().is_empty()
                    {
                        confirm = true;
                        cancel = true;
                    }
                });
            });
        if confirm {
            self.perform_rename(&path, self.rename_name.trim().to_owned(), is_folder);
        }
        if cancel {
            self.show_rename = false;
            self.pending_rename_path = None;
            self.rename_name.clear();
        }
    }

    fn perform_rename(&mut self, path: &Path, new_name: String, is_folder: bool) {
        if !self.save_pending_edit() {
            return;
        }
        let access_mode = self.vault.as_ref().map(|vault| vault.info().access_mode);
        #[cfg(target_os = "windows")]
        self.stop_video_preview();
        self.stop_audio_preview();
        self.clear_preload_cache();
        let was_released = match self.guard_release_path(path) {
            Ok(value) => value,
            Err(error) => {
                let kind = if is_folder {
                    "de la carpeta"
                } else {
                    "del archivo"
                };
                self.set_error(format!(
                    "OPAC Guard no autorizo el renombrado {kind}: {error}"
                ));
                return;
            }
        };
        let result = match self.vault.as_ref() {
            Some(vault) if is_folder => vault.rename_folder(path, &new_name).map(|_| ()),
            Some(vault) => vault.rename_file(path, &new_name).map(|_| ()),
            None => {
                let _ = self.guard_reprotect(path, was_released);
                self.set_error("La Caja Fuerte no está desbloqueada.");
                return;
            }
        };
        let reprotect_result = self.guard_reprotect(path, was_released);
        match result {
            Ok(()) => {
                self.refresh_files();
                self.clear_preview_state();
                if self.selected_file.is_some() {
                    self.prepare_preview_selected();
                }
                if access_mode == Some(VaultAccessMode::PreloadAll) {
                    self.start_preload_all();
                }
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!("Renombrado a «{new_name}», pero OPAC Guard no pudo reproteger la ruta: {reprotect_error}"));
                } else {
                    self.set_ok(format!("Renombrado a «{new_name}»."));
                }
            }
            Err(error) => {
                self.refresh_files();
                if access_mode == Some(VaultAccessMode::PreloadAll) {
                    self.start_preload_all();
                }
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!("No se pudo renombrar: {}. Además, OPAC Guard no pudo confirmar la reprotección: {reprotect_error}", format_error(&error)));
                } else {
                    self.set_error(format!("No se pudo renombrar: {}", format_error(&error)));
                }
            }
        }
    }

    fn request_delete_vault(&mut self) {
        if !self.can_delete_current_vault() {
            self.set_error("Desbloquea la Caja Fuerte con su PIN antes de eliminarla.");
            return;
        }
        let Some(id) = self.selected_vault_id else {
            self.set_error("No hay una Caja Fuerte seleccionada.");
            return;
        };
        self.pending_delete_vault = Some(id);
        self.show_delete_vault_confirm = true;
    }

    fn delete_vault_confirm_dialog(&mut self, ctx: &Context) {
        let Some(id) = self.pending_delete_vault else {
            self.show_delete_vault_confirm = false;
            return;
        };
        let Some(info) = self
            .session
            .as_ref()
            .and_then(|session| session.list_vaults().into_iter().find(|info| info.id == id))
        else {
            self.show_delete_vault_confirm = false;
            self.pending_delete_vault = None;
            return;
        };
        let files = self.files.len();
        let folders = self.folders.len();
        let mut close = false;
        let mut confirm = false;
        egui::Window::new("Eliminar Caja Fuerte")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label(RichText::new("⚠ ATENCIÓN").strong());
                ui.add_space(6.0);
                ui.label(format!(
                    "La Caja Fuerte «{}» y TODO lo que contiene se eliminarán permanentemente.",
                    info.name
                ));
                ui.label(format!(
                    "Se eliminarán {} archivo(s) y {} carpeta(s).",
                    files, folders
                ));
                ui.add_space(6.0);
                ui.label("Esta acción no se puede deshacer.");
                ui.add_space(14.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    if ui.button("Eliminar Caja Fuerte").clicked() {
                        confirm = true;
                        close = true;
                    }
                });
            });
        if confirm {
            self.delete_current_vault(id);
        }
        if close {
            self.show_delete_vault_confirm = false;
            self.pending_delete_vault = None;
        }
    }

    fn delete_current_vault(&mut self, id: Uuid) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "Espera a que termine la operación actual antes de eliminar la Caja Fuerte.",
            );
            return;
        }
        if !self.can_delete_current_vault() {
            self.set_error("Debes introducir el PIN de la Caja Fuerte antes de eliminarla.");
            return;
        }
        if !self.save_pending_edit() {
            return;
        }

        self.stop_audio_preview();
        #[cfg(target_os = "windows")]
        self.stop_video_preview();
        self.clear_preload_cache();
        self.clear_temp_exports();

        let pin_authenticated = self.vault_pin_authenticated;
        let Some(vault) = self.vault.as_ref() else {
            self.set_error("La Caja Fuerte no está desbloqueada.");
            return;
        };
        if vault.info().id != id {
            self.set_error("La Caja Fuerte seleccionada no coincide con la sesión abierta.");
            return;
        }
        let key = Zeroizing::new(*vault.key_bytes());
        let vault_path = PathBuf::from(vault.info().location.clone());
        let keystore_path = self
            .session
            .as_ref()
            .map(|session| session.storage_path().to_path_buf());

        let was_vault_released = match self.guard_release_path(&vault_path) {
            Ok(value) => value,
            Err(error) => {
                self.set_error(format!(
                    "OPAC Guard no autorizo la eliminacion de la Caja Fuerte: {error}"
                ));
                return;
            }
        };
        let was_keystore_released = match keystore_path.as_deref() {
            Some(path) => match self.guard_release_path(path) {
                Ok(value) => value,
                Err(error) => {
                    let _ = self.guard_reprotect(&vault_path, was_vault_released);
                    self.set_error(format!("OPAC Guard no autorizo la actualizacion del Key Store para eliminar la Caja Fuerte: {error}"));
                    return;
                }
            },
            None => false,
        };

        let result = self
            .session
            .as_mut()
            .ok_or(SessionError::Vault(VaultError::NotFound))
            .and_then(|session| session.delete_vault(id, &key, pin_authenticated));

        let vault_reprotect = self.guard_reprotect(&vault_path, was_vault_released);
        let keystore_reprotect = keystore_path
            .as_deref()
            .map(|path| self.guard_reprotect(path, was_keystore_released))
            .unwrap_or(Ok(()));

        match result {
            Ok(()) => {
                self.vault = None;
                self.vault_pin_authenticated = false;
                self.selected_vault_id = None;
                self.selected_file = None;
                self.files.clear();
                self.folders.clear();
                self.current_folder = None;
                self.folder_drop_rects.clear();
                self.drop_target_folder = None;
                self.clear_preview_state();
                self.editing_text = false;
                self.edit_original_text = None;
                self.markdown_cache = CommonMarkCache::default();
                match (vault_reprotect, keystore_reprotect) {
                    (Ok(()), Ok(())) => self.set_ok("Caja Fuerte y todo su contenido eliminados.".into()),
                    (Err(vault_error), Ok(())) => self.set_error(format!("Caja Fuerte y contenido eliminados, pero OPAC Guard no pudo reproteger la Caja Fuerte: {vault_error}")),
                    (Ok(()), Err(keystore_error)) => self.set_error(format!("Caja Fuerte y contenido eliminados, pero OPAC Guard no pudo reproteger el Key Store: {keystore_error}")),
                    (Err(vault_error), Err(keystore_error)) => self.set_error(format!("Caja Fuerte y contenido eliminados, pero OPAC Guard no pudo reproteger la Caja Fuerte ({vault_error}) ni el Key Store ({keystore_error}).")),
                }
            }
            Err(error) => {
                self.refresh_files();
                let base = format!(
                    "No se pudo eliminar la Caja Fuerte: {}",
                    format_error(&error)
                );
                match (vault_reprotect, keystore_reprotect) {
                    (Ok(()), Ok(())) => self.set_error(base),
                    (Err(vault_error), Ok(())) => self.set_error(format!("{base}. Además, OPAC Guard no pudo confirmar la reprotección de la Caja Fuerte: {vault_error}")),
                    (Ok(()), Err(keystore_error)) => self.set_error(format!("{base}. Además, OPAC Guard no pudo confirmar la reprotección del Key Store: {keystore_error}")),
                    (Err(vault_error), Err(keystore_error)) => self.set_error(format!("{base}. Además, OPAC Guard no pudo confirmar la reprotección de la Caja Fuerte ({vault_error}) ni del Key Store ({keystore_error}).")),
                }
            }
        }
    }

    fn request_delete_folder(&mut self, folder_path: &Path) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "Espera a que termine la operación actual antes de eliminar una carpeta.",
            );
            return;
        }
        if self
            .folders
            .iter()
            .any(|folder| folder.disk_path == folder_path)
        {
            self.pending_delete_folder = Some(folder_path.to_path_buf());
            self.show_folder_delete_confirm = true;
        } else {
            self.set_error("No se encontró la carpeta seleccionada en la Caja Fuerte.");
        }
    }

    fn folder_delete_confirm_dialog(&mut self, ctx: &Context) {
        let Some(folder_path) = self.pending_delete_folder.clone() else {
            self.show_folder_delete_confirm = false;
            return;
        };
        let name = self
            .folders
            .iter()
            .find(|folder| folder.disk_path == folder_path)
            .map(|folder| folder.metadata.original_name.clone())
            .unwrap_or_else(|| folder_path.display().to_string());
        let nested_files = self
            .files
            .iter()
            .filter(|entry| path_is_same_or_descendant(&entry.disk_path, &folder_path))
            .count();
        let nested_folders = self
            .folders
            .iter()
            .filter(|folder| path_is_same_or_descendant(&folder.disk_path, &folder_path))
            .count();

        let mut close = false;
        let mut confirm = false;
        egui::Window::new("Eliminar carpeta")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("⚠ Esta acción eliminará la carpeta y TODO lo que contenga.");
                ui.add_space(6.0);
                ui.label(RichText::new(name.as_str()).strong());
                ui.label(format!(
                    "Incluye {} archivo(s) y {} subcarpeta(s).",
                    nested_files,
                    nested_folders.saturating_sub(1)
                ));
                ui.add_space(6.0);
                ui.label("La eliminación es permanente y no descifra ni exporta el contenido.");
                ui.add_space(14.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    if ui.button("Eliminar todo").clicked() {
                        confirm = true;
                        close = true;
                    }
                });
            });

        if confirm {
            self.delete_folder(&folder_path);
        }
        if close {
            self.show_folder_delete_confirm = false;
            self.pending_delete_folder = None;
        }
    }

    fn delete_folder(&mut self, folder_path: &Path) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "Espera a que termine la operación actual antes de eliminar una carpeta.",
            );
            return;
        }
        if !self.save_pending_edit() {
            return;
        }
        let access_mode = self.vault.as_ref().map(|vault| vault.info().access_mode);
        self.stop_audio_preview();
        self.clear_preload_cache();
        let was_released = match self.guard_release_path(folder_path) {
            Ok(value) => value,
            Err(error) => {
                self.set_error(format!(
                    "OPAC Guard no autorizó el borrado de la carpeta y su contenido: {error}"
                ));
                return;
            }
        };
        let result = match self.vault.as_ref() {
            Some(vault) => vault.delete_folder(folder_path),
            None => {
                let _ = self.guard_reprotect(folder_path, was_released);
                self.set_error("La Caja Fuerte no está desbloqueada.");
                return;
            }
        };
        let reprotect_result = self.guard_reprotect(folder_path, was_released);
        match result {
            Ok(()) => {
                if self
                    .current_folder
                    .as_ref()
                    .is_some_and(|current| path_is_same_or_descendant(current, folder_path))
                {
                    self.current_folder = None;
                }
                if self
                    .selected_file
                    .as_ref()
                    .is_some_and(|selected| path_is_same_or_descendant(selected, folder_path))
                {
                    self.selected_file = None;
                    self.clear_preview_state();
                    self.editing_text = false;
                    self.edit_original_text = None;
                    self.markdown_cache = CommonMarkCache::default();
                }
                self.refresh_files();
                if access_mode == Some(VaultAccessMode::PreloadAll) {
                    self.start_preload_all();
                }
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!("Carpeta y contenido eliminados, pero OPAC Guard no pudo reproteger el árbol: {reprotect_error}"));
                } else {
                    self.set_ok("Carpeta y todo su contenido eliminados.".into());
                }
            }
            Err(error) => {
                self.refresh_files();
                if access_mode == Some(VaultAccessMode::PreloadAll) {
                    self.start_preload_all();
                }
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!("No se pudo eliminar la carpeta: {}. Además, OPAC Guard no pudo confirmar la reprotección del árbol: {reprotect_error}", format_error(&error)));
                } else {
                    self.set_error(format!(
                        "No se pudo eliminar la carpeta: {}",
                        format_error(&error)
                    ));
                }
            }
        }
    }

    fn request_export_folder(&mut self, folder_path: &Path) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "Espera a que termine la operación actual antes de exportar una carpeta.",
            );
            return;
        }
        if self
            .folders
            .iter()
            .any(|folder| folder.disk_path == folder_path)
        {
            self.pending_export_folder = Some(folder_path.to_path_buf());
            self.show_folder_export_confirm = true;
        } else {
            self.set_error("No se encontró la carpeta seleccionada en la Caja Fuerte.");
        }
    }

    fn folder_export_confirm_dialog(&mut self, ctx: &Context) {
        let Some(folder_path) = self.pending_export_folder.clone() else {
            self.show_folder_export_confirm = false;
            return;
        };
        let name = self
            .folders
            .iter()
            .find(|folder| folder.disk_path == folder_path)
            .map(|folder| folder.metadata.original_name.clone())
            .unwrap_or_else(|| folder_path.display().to_string());
        let nested_files = self
            .files
            .iter()
            .filter(|entry| path_is_same_or_descendant(&entry.disk_path, &folder_path))
            .count();
        let nested_folders = self
            .folders
            .iter()
            .filter(|folder| path_is_same_or_descendant(&folder.disk_path, &folder_path))
            .count();

        let mut close = false;
        let mut confirm = false;
        egui::Window::new("Exportar carpeta")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("Exportar esta carpeta descifrará y copiará TODO lo que contenga.");
                ui.add_space(6.0);
                ui.label(RichText::new(name.as_str()).strong());
                ui.label(format!(
                    "Se exportarán {} archivo(s) y {} subcarpeta(s).",
                    nested_files,
                    nested_folders.saturating_sub(1)
                ));
                ui.add_space(6.0);
                ui.label("El contenido exportado quedará fuera de la Caja Fuerte en texto claro.");
                ui.add_space(14.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    if ui.button("Continuar").clicked() {
                        confirm = true;
                        close = true;
                    }
                });
            });

        if confirm {
            self.export_folder(&folder_path);
        }
        if close {
            self.show_folder_export_confirm = false;
            self.pending_export_folder = None;
        }
    }

    fn export_folder(&mut self, folder_path: &Path) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "Espera a que termine la operación actual antes de exportar una carpeta.",
            );
            return;
        }
        if !self.save_pending_edit() {
            return;
        }
        let Some(original_name) = self
            .folders
            .iter()
            .find(|folder| folder.disk_path == folder_path)
            .map(|folder| folder.metadata.original_name.clone())
        else {
            self.set_error("No se encontró la carpeta seleccionada en la Caja Fuerte.");
            return;
        };
        let Some(destination) = FileDialog::new()
            .set_title("Exportar carpeta a")
            .pick_folder()
        else {
            return;
        };
        let root = self.vault_root_path();
        if same_or_descendant_path(&destination, &root) {
            self.set_error("El destino de exportación no puede estar dentro de la Caja Fuerte.");
            return;
        }
        let Some(vault) = self.vault.as_ref() else {
            self.set_error("La Caja Fuerte no está desbloqueada.");
            return;
        };
        match vault.export_folder(folder_path, &destination) {
            Ok((files, folders)) => self.set_ok(format!(
                "Carpeta «{}» exportada: {} archivo(s) y {} subcarpeta(s).",
                original_name, files, folders
            )),
            Err(error) => self.set_error(format!(
                "No se pudo exportar la carpeta: {}",
                format_error(&error)
            )),
        }
    }

    fn move_internal_item(&mut self, source: PathBuf, destination_folder: PathBuf) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error("Espera a que termine la operación actual antes de mover elementos.");
            return;
        }
        if !self.save_pending_edit() {
            return;
        }
        let (root, access_mode) = match self.vault.as_ref() {
            Some(vault) => (vault.location().to_path_buf(), vault.info().access_mode),
            None => return,
        };
        if source == root
            || !path_is_same_or_descendant(&source, &root)
            || !path_is_same_or_descendant(&destination_folder, &root)
        {
            self.set_error("La ruta de origen o destino no pertenece a la Caja Fuerte.");
            return;
        }
        let source_is_folder = self.folders.iter().any(|folder| folder.disk_path == source);
        let source_is_file = self.files.iter().any(|file| file.disk_path == source);
        if !source_is_folder && !source_is_file {
            self.set_error("No se encontró el elemento que intentas mover.");
            return;
        }

        let selected_before = self.selected_file.clone();
        let current_before = self.current_folder.clone();
        self.stop_audio_preview();
        self.clear_preload_cache();

        let was_released = match self.guard_release_path(&source) {
            Ok(value) => value,
            Err(error) => {
                let kind = if source_is_folder {
                    "de la carpeta"
                } else {
                    "del archivo"
                };
                self.set_error(format!(
                    "OPAC Guard no autorizó el movimiento {kind}: {error}"
                ));
                return;
            }
        };

        let result = match self.vault.as_ref() {
            Some(vault) if source_is_folder => vault.move_folder(&source, &destination_folder),
            Some(vault) => vault.move_file(&source, &destination_folder),
            None => {
                let _ = self.guard_reprotect(&source, was_released);
                return;
            }
        };
        let reprotect_result = self.guard_reprotect(&source, was_released);

        match result {
            Ok(new_path) => {
                if source_is_folder {
                    self.current_folder = current_before
                        .map(|current| remap_moved_path(&current, &source, &new_path));
                }
                self.selected_file =
                    selected_before.map(|selected| remap_moved_path(&selected, &source, &new_path));
                self.refresh_files();
                self.clear_preview_state();
                if self.selected_file.is_some() {
                    self.prepare_preview_selected();
                }
                if access_mode == VaultAccessMode::PreloadAll {
                    self.start_preload_all();
                }
                let destination_name = self
                    .folder_name_for_path(&destination_folder)
                    .unwrap_or_else(|| "raíz".to_owned());
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!("Elemento movido a «{destination_name}», pero OPAC Guard no pudo reproteger el origen: {reprotect_error}"));
                } else {
                    self.set_ok(format!("Elemento movido a «{destination_name}»."));
                }
            }
            Err(error) => {
                self.refresh_files();
                self.clear_preview_state();
                if self.selected_file.is_some() {
                    self.prepare_preview_selected();
                }
                if access_mode == VaultAccessMode::PreloadAll {
                    self.start_preload_all();
                }
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!("No se pudo mover el elemento: {}. Además, OPAC Guard no pudo confirmar la reprotección del origen: {reprotect_error}", format_error(&error)));
                } else {
                    self.set_error(format!(
                        "No se pudo mover el elemento: {}",
                        format_error(&error)
                    ));
                }
            }
        }
    }

    fn new_vault_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        let mut cancel_all = false;
        egui::Window::new("Nueva caja fuerte")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("Ponle un nombre y decide dónde guardar la carpeta física.");
                ui.add_space(10.0);
                let input = ui.add(
                    egui::TextEdit::singleline(&mut self.new_vault_name)
                        .desired_width(420.0)
                        .hint_text("Ej.: Personal, Trabajo, Documentos..."),
                );
                ui.add_space(10.0);

                ui.group(|ui| {
                    ui.label(RichText::new("Ubicación de la Caja").strong());
                    ui.add_space(6.0);
                    ui.horizontal(|ui| {
                        let default_selected = self.new_vault_parent.is_none();
                        if ui.selectable_label(default_selected, "Predeterminada").clicked() {
                            self.new_vault_parent = None;
                        }
                        if ui.button("Elegir ubicación…").clicked()
                            && let Some(path) = FileDialog::new()
                                .set_title("Elegir dónde guardar la Caja Fuerte")
                                .set_directory(
                                    self.session
                                        .as_ref()
                                        .and_then(|session| session.profile_root().map(PathBuf::from))
                                        .unwrap_or_else(|| PathBuf::from(".")),
                                )
                                .pick_folder()
                        {
                            self.new_vault_parent = Some(path);
                        }
                    });
                    let location_text = self
                        .new_vault_parent
                        .as_ref()
                        .map(|path| path.display().to_string())
                        .unwrap_or_else(|| "Almacenamiento predeterminado de Opac Window".to_owned());
                    ui.label(RichText::new(location_text).small().color(Color32::from_rgb(158, 149, 168)));
                    ui.small("La carpeta física de la Caja recibe un nombre aleatorio para no revelar el nombre visible.");
                    if self.new_vault_parent.is_some() {
                        ui.small("Con OPAC Guard activo, la ubicación elegida debe estar dentro del almacenamiento privado del usuario.");
                    }
                });

                ui.group(|ui| {
                    ui.label(RichText::new("Vault Key").strong());
                    ui.horizontal(|ui| {
                        if ui.radio(!self.new_vault_use_imported_key, "Generar una clave nueva").clicked() {
                            self.new_vault_use_imported_key = false;
                            self.new_vault_imported_key.clear();
                        }
                        if ui.radio(self.new_vault_use_imported_key, "Usar una clave importada").clicked() {
                            self.new_vault_use_imported_key = true;
                        }
                    });
                    if self.new_vault_use_imported_key {
                        ui.add_space(6.0);
                        ui.add(
                            egui::TextEdit::singleline(&mut *self.new_vault_imported_key)
                                .password(true)
                                .desired_width(420.0)
                                .char_limit(64)
                                .font(TextStyle::Monospace)
                                .hint_text("64 caracteres hexadecimales"),
                        );
                        ui.small("La Caja se crea vacía y reutiliza exactamente esta Vault Key.");
                    }
                });

                ui.small("Para incorporar una Caja existente mediante su clave y conservar su contenido, usa «Abrir caja con clave»." );
                ui.add_space(14.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        cancel_all = true;
                    }
                    if (ui.button(RichText::new("Crear").strong()).clicked()
                        || (input.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter))))
                        && self.create_vault()
                    {
                        close = true;
                    }
                });
            });
        if cancel_all || close {
            self.show_new_vault = false;
            self.new_vault_name.clear();
            self.new_vault_parent = None;
            self.new_vault_use_imported_key = false;
            self.new_vault_imported_key.clear();
        }
    }

    fn vault_key_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        egui::Window::new("Clave de la Caja Fuerte")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                if let Some(vault) = &self.vault {
                    ui.label(RichText::new("Esta es la Vault Key portable de esta Caja Fuerte.").color(Color32::from_rgb(158, 149, 168)));
                    ui.label("Quien la tenga puede descifrar el contenido de la Caja; guárdala como una credencial secreta.");
                    ui.add_space(10.0);
                    let revealed = vault.reveal_vault_key();
                    let key = Zeroizing::new(hex_bytes(&revealed));
                    let mut visible = key.clone();
                    ui.add(
                        egui::TextEdit::multiline(&mut *visible)
                            .font(TextStyle::Monospace)
                            .desired_width(440.0)
                            .desired_rows(3)
                            .interactive(false),
                    );
                    ui.add_space(8.0);
                    if ui.button("Copiar clave").clicked() {
                        let copied = visible.as_str().to_owned();
                        match Clipboard::new().and_then(|mut clipboard| clipboard.set_text(copied.clone())) {
                            Ok(()) => {
                                self.clipboard_secret = Some(Zeroizing::new(copied));
                                self.clipboard_clear_deadline = Some(Instant::now() + CLIPBOARD_SECRET_TTL);
                                self.set_ok("Clave copiada al portapapeles; se limpiará automáticamente en 30 segundos si nadie la reemplaza.".into());
                            }
                            Err(_) => self.set_error("No se pudo copiar la clave al portapapeles."),
                        }
                    }
                }
                ui.add_space(10.0);
                if ui.button("Cerrar").clicked() {
                    close = true;
                }
            });
        if close {
            self.show_vault_key = false;
        }
    }

    fn key_unlock_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        egui::Window::new("Desbloquear con Clave portable")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("Introduce los 64 caracteres hexadecimales de la Vault Key.");
                ui.label(
                    RichText::new("Esta clave puede sustituir al PIN para abrir la Caja.")
                        .small()
                        .color(Color32::from_rgb(158, 149, 168)),
                );
                ui.add_space(10.0);
                let response = ui.add(
                    egui::TextEdit::singleline(&mut *self.key_unlock_value)
                        .password(true)
                        .desired_width(440.0)
                        .char_limit(64)
                        .font(TextStyle::Monospace)
                        .hint_text("64 caracteres hexadecimales"),
                );
                ui.add_space(10.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    if ui.button(RichText::new("Desbloquear").strong()).clicked()
                        || (response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                    {
                        match parse_portable_key(self.key_unlock_value.as_str()) {
                            Ok(key) => {
                                let result = match (self.pending_key_vault, self.session.as_ref()) {
                                    (Some(id), Some(session)) => {
                                        session.open_vault_with_key(id, key)
                                    }
                                    _ => Err(SessionError::Vault(VaultError::NotFound)),
                                };
                                match result {
                                    Ok(vault) => {
                                        self.stop_audio_preview();
                                        self.clear_preload_cache();
                                        self.selected_vault_id = self.pending_key_vault;
                                        let access_mode = vault.info().access_mode;
                                        let has_pin = vault.info().has_pin;
                                        self.vault = Some(vault);
                                        self.vault_pin_authenticated = !has_pin;
                                        self.current_folder = None;
                                        self.folder_drop_rects.clear();
                                        self.drop_target_folder = None;
                                        self.selected_file = None;
                                        self.clear_preview_state();
                                        self.editing_text = false;
                                        self.edit_original_text = None;
                                        self.refresh_files();
                                        self.set_ok(
                                            "Caja Fuerte desbloqueada con la Clave portable."
                                                .into(),
                                        );
                                        self.key_unlock_value.clear();
                                        self.pending_key_vault = None;
                                        close = true;
                                        if access_mode == VaultAccessMode::PreloadAll {
                                            self.start_preload_all();
                                        }
                                    }
                                    Err(error) => {
                                        self.key_unlock_value.clear();
                                        self.set_error(format_error(&error));
                                    }
                                }
                            }
                            Err(message) => {
                                self.key_unlock_value.clear();
                                self.set_error(message);
                            }
                        }
                    }
                });
            });
        if close {
            self.show_key_unlock = false;
            self.key_unlock_value.clear();
            self.pending_key_vault = None;
        }
    }

    fn external_key_import_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        egui::Window::new("Abrir Caja con Clave portable")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("Selecciona la carpeta física de una Caja Fuerte cifrada y proporciona su Vault Key.");
                ui.label(RichText::new("La Caja quedará dentro de la carpeta privada del usuario activo. Si la carpeta está fuera, se copiará su contenido cifrado y el original no se modifica.").small().color(Color32::from_rgb(158, 149, 168)));
                ui.add_space(10.0);
                ui.label("Nombre local");
                ui.add(egui::TextEdit::singleline(&mut self.external_vault_name).desired_width(440.0).hint_text("Ej.: Personal"));
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    if ui.button("Seleccionar carpeta…").clicked()
                        && let Some(path) = FileDialog::new()
                            .set_title("Seleccionar carpeta de la Caja Fuerte")
                            .set_directory(
                                self.session
                                    .as_ref()
                                    .and_then(|session| session.profile_root().map(PathBuf::from))
                                    .unwrap_or_else(|| PathBuf::from(".")),
                            )
                            .pick_folder()
                    {
                        self.external_vault_path = Some(path);
                    }
                    let text = self.external_vault_path.as_ref().map(|p| p.display().to_string()).unwrap_or_else(|| "Ninguna carpeta seleccionada".to_owned());
                    ui.label(RichText::new(text).small().color(Color32::from_rgb(158, 149, 168)));
                });
                ui.add_space(8.0);
                ui.label("Vault Key");
                let response = ui.add(
                    egui::TextEdit::singleline(&mut *self.external_key_value)
                        .password(true)
                        .desired_width(440.0)
                        .char_limit(64)
                        .font(TextStyle::Monospace)
                        .hint_text("64 caracteres hexadecimales"),
                );
                ui.add_space(10.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    if ui.button(RichText::new("Abrir e incorporar").strong()).clicked()
                        || (response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                    {
                        let parsed = parse_portable_key(self.external_key_value.as_str());
                        match (parsed, self.external_vault_path.clone()) {
                            (Ok(key), Some(path)) => {
                                let name = self.external_vault_name.trim().to_owned();
                                if name.is_empty() {
                                    self.set_error("Escribe un nombre local para la Caja Fuerte.");
                                } else {
                                    let keystore_path = self
                                        .session
                                        .as_ref()
                                        .map(|session| session.storage_path().to_path_buf());
                                    let was_keystore_released = match keystore_path.as_deref() {
                                        Some(keystore) => match self.guard_release_path(keystore) {
                                            Ok(value) => value,
                                            Err(error) => {
                                                self.set_error(format!("OPAC Guard no autorizo la incorporacion de la Caja Fuerte: {error}"));
                                                return;
                                            }
                                        },
                                        None => false,
                                    };
                                    let result = self
                                        .session
                                        .as_mut()
                                        .ok_or(SessionError::Vault(VaultError::NotFound))
                                        .and_then(|session| {
                                            if session
                                                .profile_root()
                                                .and_then(|root| {
                                                    fs::canonicalize(root).ok().zip(fs::canonicalize(&path).ok())
                                                })
                                                .is_some_and(|(root, source)| path_is_same_or_descendant(&source, &root))
                                            {
                                                session.import_vault_with_key(&name, &path, key)
                                            } else {
                                                session.import_external_vault_with_key(&name, &path, key)
                                            }
                                        });
                                    let keystore_reprotect = keystore_path
                                        .as_deref()
                                        .map(|keystore| self.guard_reprotect(keystore, was_keystore_released))
                                        .unwrap_or(Ok(()));
                                    match result {
                                        Ok(id) => {
                                            self.external_key_value.clear();
                                            self.external_vault_path = None;
                                            self.external_vault_name.clear();
                                            self.show_external_key_import = false;
                                            self.select_vault(id);
                                            if let Err(reprotect_error) = keystore_reprotect {
                                                self.set_error(format!("Clave importada · Caja Fuerte incorporada, pero OPAC Guard no pudo reproteger el Key Store: {reprotect_error}"));
                                            } else {
                                                self.set_ok("Clave importada · Caja Fuerte incorporada.".into());
                                            }
                                        }
                                        Err(error) => {
                                            if let Err(reprotect_error) = keystore_reprotect {
                                                self.set_error(format!("{} Además, OPAC Guard no pudo confirmar la reprotección del Key Store: {reprotect_error}", format_error(&error)));
                                            } else {
                                                self.set_error(format_error(&error));
                                            }
                                        }
                                    }
                                }
                            }
                            (Err(message), _) => self.set_error(message),
                            (_, None) => self.set_error("Selecciona primero la carpeta física de la Caja Fuerte."),
                        }
                    }
                });
            });
        if close {
            self.show_external_key_import = false;
            self.external_key_value.clear();
            self.external_vault_name.clear();
            self.external_vault_path = None;
        }
    }

    fn begin_add_pin(&mut self) {
        let Some(id) = self.selected_vault_id else {
            return;
        };
        self.begin_add_pin_for(id);
    }

    fn begin_add_pin_for(&mut self, id: Uuid) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error("Espera a que termine la operacion actual antes de cambiar la proteccion de la Caja Fuerte.");
            return;
        }
        let Some(session) = self.session.as_ref() else {
            return;
        };
        let Some(info) = session.list_vaults().into_iter().find(|info| info.id == id) else {
            self.set_error("No se encontro la Caja Fuerte.");
            return;
        };
        if info.has_pin {
            self.set_error("Esta Caja Fuerte ya tiene un PIN configurado.");
            return;
        }
        self.pending_pin_add_vault = Some(id);
        self.new_pin_value.clear();
        self.new_pin_confirm.clear();
        self.show_add_pin = true;
    }

    fn add_pin_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        egui::Window::new("Añadir PIN a la Caja Fuerte")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("Introduce un PIN de al menos 8 caracteres; si es solo numérico, usa al menos 10.");
                ui.label(
                    RichText::new("Se permiten letras y números; un PIN de solo dígitos no se acepta por seguridad.")
                        .small()
                        .color(Color32::from_rgb(158, 149, 168)),
                );
                ui.add_space(12.0);
                let input = ui.add(
                    egui::TextEdit::singleline(&mut *self.new_pin_value)
                        .password(true)
                        .char_limit(128)
                        .desired_width(300.0)
                        .hint_text("mín. 8; numérico mín. 10"),
                );
                ui.add_space(8.0);
                let confirm = ui.add(
                    egui::TextEdit::singleline(&mut *self.new_pin_confirm)
                        .password(true)
                        .char_limit(128)
                        .desired_width(300.0)
                        .hint_text("Repite el PIN"),
                );
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    let submit = ui
                        .button(RichText::new("Añadir PIN").strong())
                        .clicked()
                        || (confirm.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)))
                        || (input.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)));
                    if !submit {
                        return;
                    }

                    let pin = self.new_pin_value.as_str();
                    let confirmation = self.new_pin_confirm.as_str();
                    let exact_length = pin.chars().count() == 8;
                    let valid_charset = pin.bytes().all(|byte| byte.is_ascii_alphanumeric());
                    let has_letter = pin.bytes().any(|byte| byte.is_ascii_alphabetic());
                    if !exact_length || !valid_charset || !has_letter {
                        self.set_error("El PIN debe tener exactamente 8 caracteres alfanumericos e incluir al menos una letra.");
                        return;
                    }
                    if pin != confirmation {
                        self.set_error("Los PIN no coinciden.");
                        return;
                    }

                    let keystore_path = self
                        .session
                        .as_ref()
                        .map(|session| session.storage_path().to_path_buf());
                    let was_keystore_released = match keystore_path.as_deref() {
                        Some(path) => match self.guard_release_path(path) {
                            Ok(value) => value,
                            Err(error) => {
                                self.set_error(format!(
                                    "OPAC Guard no autorizo la actualizacion del Key Store: {error}"
                                ));
                                return;
                            }
                        },
                        None => false,
                    };

                    let result = match (self.pending_pin_add_vault, self.session.as_mut()) {
                        (Some(id), Some(session)) => session.add_pin(id, pin.as_bytes()),
                        _ => Err(SessionError::Vault(VaultError::NotFound)),
                    };
                    let keystore_reprotect = keystore_path
                        .as_deref()
                        .map(|path| self.guard_reprotect(path, was_keystore_released))
                        .unwrap_or(Ok(()));

                    match result {
                        Ok(()) => {
                            let vault_id = self.pending_pin_add_vault;
                            self.new_pin_value.clear();
                            self.new_pin_confirm.clear();
                            self.pending_pin_add_vault = None;
                            self.show_add_pin = false;
                            if vault_id == self.selected_vault_id {
                                self.lock_current_vault_view();
                            }
                            if let Err(reprotect_error) = keystore_reprotect {
                                self.set_error(format!("PIN añadido y Caja Fuerte bloqueada, pero OPAC Guard no pudo reproteger el Key Store: {reprotect_error}"));
                            } else {
                                self.set_ok("PIN añadido. La Caja Fuerte ha quedado bloqueada.".into());
                            }
                            close = true;
                        }
                        Err(error) => {
                            if let Err(reprotect_error) = keystore_reprotect {
                                self.set_error(format!("{} Además, OPAC Guard no pudo confirmar la reprotección del Key Store: {reprotect_error}", format_error(&error)));
                            } else {
                                self.set_error(format_error(&error));
                            }
                        }
                    }
                });
            });
        if close {
            self.show_add_pin = false;
            self.pending_pin_add_vault = None;
            self.new_pin_value.clear();
            self.new_pin_confirm.clear();
        }
    }

    fn clear_preview_state(&mut self) {
        // Drop the image texture and decoded CPU buffers together with the
        // textual preview. The vault source file is never modified by this.
        #[cfg(target_os = "windows")]
        self.stop_video_preview();
        self.preview_text = None;
        self.preview_image = None;
        self.preview_image_texture = None;
        self.preview_image_size = None;
        self.preview_pdf_page_count = None;
        self.preview_pdf_pages.clear();
        #[cfg(target_os = "windows")]
        {
            self.video_texture = None;
            self.video_size = None;
            self.video_position = Duration::ZERO;
            self.video_duration = None;
            self.video_seek_override = None;
            self.video_finished = false;
            self.video_error = None;
        }
        self.preview_kind = PreviewKind::None;
    }

    fn clear_temp_exports(&mut self) {
        let mut remaining = Vec::with_capacity(self.temp_exports.len());
        for path in self.temp_exports.drain(..) {
            if fs::remove_file(&path).is_err() && fs::symlink_metadata(&path).is_ok() {
                remaining.push(path);
            }
        }
        self.temp_exports = remaining;
    }

    fn retry_temp_export_cleanup(&mut self) {
        if self.temp_exports.is_empty() {
            return;
        }
        self.clear_temp_exports();
    }

    fn lock_current_vault_view(&mut self) {
        if !self.save_pending_edit() {
            return;
        }
        self.clear_secret_clipboard_if_owned();
        self.stop_audio_preview();
        self.clear_preload_cache();
        self.clear_temp_exports();
        self.vault = None;
        self.vault_pin_authenticated = false;
        self.selected_file = None;
        self.files.clear();
        self.folders.clear();
        self.current_folder = None;
        self.folder_drop_rects.clear();
        self.drop_target_folder = None;
        self.clear_preview_state();
        self.editing_text = false;
        self.edit_original_text = None;
        self.markdown_cache = CommonMarkCache::default();
        self.show_vault_key = false;
        self.show_key_unlock = false;
        self.key_unlock_value.clear();
        self.pending_key_vault = None;
        self.show_external_key_import = false;
        self.external_key_value.clear();
        self.external_vault_name.clear();
        self.external_vault_path = None;
        self.show_new_vault = false;
        self.new_vault_name.clear();
        self.new_vault_parent = None;
        self.new_vault_use_imported_key = false;
        self.new_vault_imported_key.clear();
        self.show_new_folder = false;
        self.new_folder_name.clear();
        self.new_folder_parent = None;
        self.show_new_text_file = false;
        self.new_text_file_name.clear();
        self.new_text_file_parent = None;
    }

    fn pin_dialog(&mut self, ctx: &Context) {
        let mut close = false;
        let pending_vault = self.pending_pin_vault;
        let now = Instant::now();
        if let Some(vault_id) = pending_vault
            && let Some(state) = self.pin_backoff.get_mut(&vault_id)
            && state.retry_after.is_some_and(|deadline| deadline <= now)
        {
            state.retry_after = None;
        }
        let cooldown = pending_vault.and_then(|vault_id| {
            self.pin_backoff
                .get(&vault_id)
                .and_then(|state| state.retry_after)
                .and_then(|deadline| deadline.checked_duration_since(now))
        });

        egui::Window::new("Desbloquear Caja Fuerte")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("Introduce el PIN/passcode para ver los archivos.");
                ui.add_space(10.0);
                let response = ui.add(
                    egui::TextEdit::singleline(&mut *self.pin_value)
                        .password(true)
                        .desired_width(280.0)
                        .hint_text("PIN / passcode"),
                );
                if let Some(remaining) = cooldown {
                    ui.add_space(4.0);
                    ui.label(format!(
                        "Espera {} s antes de volver a intentarlo.",
                        remaining.as_secs_f32().ceil() as u64
                    ));
                }
                ui.add_space(10.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    let request_attempt = ui
                        .add_enabled(
                            cooldown.is_none(),
                            egui::Button::new(RichText::new("Desbloquear").strong()),
                        )
                        .clicked()
                        || (response.lost_focus() && ui.input(|i| i.key_pressed(Key::Enter)));
                    if request_attempt && cooldown.is_none() {
                        let result = match (pending_vault, self.session.as_ref()) {
                            (Some(id), Some(session)) => {
                                session.open_vault(id, Some(self.pin_value.as_bytes()))
                            }
                            _ => Err(SessionError::Vault(VaultError::NotFound)),
                        };
                        match result {
                            Ok(vault) => {
                                if let Some(vault_id) = pending_vault {
                                    self.pin_backoff.remove(&vault_id);
                                }
                                self.stop_audio_preview();
                                self.clear_preload_cache();
                                self.selected_vault_id = pending_vault;
                                let access_mode = vault.info().access_mode;
                                self.vault = Some(vault);
                                self.vault_pin_authenticated = true;
                                self.current_folder = None;
                                self.folder_drop_rects.clear();
                                self.drop_target_folder = None;
                                self.selected_file = None;
                                self.clear_preview_state();
                                self.editing_text = false;
                                self.edit_original_text = None;
                                self.refresh_files();
                                self.set_ok("Caja Fuerte desbloqueada.".into());
                                if access_mode == VaultAccessMode::PreloadAll {
                                    self.start_preload_all();
                                }
                                self.pin_value.clear();
                                self.pending_pin_vault = None;
                                close = true;
                            }
                            Err(error) => {
                                if let Some(vault_id) = pending_vault {
                                    let state = self.pin_backoff.entry(vault_id).or_default();
                                    state.failed_attempts = state.failed_attempts.saturating_add(1);
                                    let exponent = state.failed_attempts.saturating_sub(1).min(5);
                                    let seconds = (PIN_BACKOFF_BASE.as_secs() << exponent)
                                        .min(PIN_BACKOFF_MAX.as_secs());
                                    state.retry_after =
                                        Some(Instant::now() + Duration::from_secs(seconds));
                                }
                                self.pin_value.clear();
                                self.set_error(format_error(&error));
                            }
                        }
                    }
                });
            });
        if close {
            self.show_pin_prompt = false;
            self.pin_value.clear();
            self.pending_pin_vault = None;
        }
    }

    fn create_vault(&mut self) -> bool {
        let name = self.new_vault_name.trim().to_string();
        if name.is_empty() {
            self.set_error("Escribe un nombre para la Caja Fuerte.");
            return false;
        }

        let imported_key = if self.new_vault_use_imported_key {
            match parse_portable_key(self.new_vault_imported_key.as_str()) {
                Ok(key) => Some(key),
                Err(message) => {
                    self.set_error(message);
                    return false;
                }
            }
        } else {
            None
        };

        // Una sesion de perfil mantiene las Cajas dentro de la raiz privada para
        // que el Guard pueda cubrirlas con la misma politica de proteccion.
        if let Some(parent) = self.new_vault_parent.as_deref()
            && let Some(profile_root) = self
                .session
                .as_ref()
                .and_then(|session| session.profile_root())
        {
            let profile_root_abs =
                fs::canonicalize(profile_root).unwrap_or_else(|_| profile_root.to_path_buf());
            let parent_abs = fs::canonicalize(parent).unwrap_or_else(|_| parent.to_path_buf());
            if !path_is_same_or_descendant(&parent_abs, &profile_root_abs) {
                self.set_error("La ubicación elegida debe estar dentro del almacenamiento privado del usuario activo.");
                return false;
            }
        }

        let keystore_path = self
            .session
            .as_ref()
            .map(|session| session.storage_path().to_path_buf());

        // Crear una Caja Fuerte nueva no solo modifica el Key Store: tambien
        // necesita crear temporalmente la carpeta fisica dentro del arbol
        // protegido. Si OPAC Guard esta activo, liberamos el padre de creacion
        // durante esa operacion y lo reprotegemos inmediatamente despues.
        // Para la ubicacion predeterminada usamos la raiz del perfil porque
        // `vaults/` puede aun no existir.
        let creation_guard_path = if let Some(parent) = self.new_vault_parent.clone() {
            Some(parent)
        } else {
            self.session
                .as_ref()
                .and_then(|session| session.profile_root().map(PathBuf::from))
        };

        let was_creation_path_released = match creation_guard_path.as_deref() {
            Some(path) => match self.guard_release_path(path) {
                Ok(value) => value,
                Err(error) => {
                    self.set_error(format!("OPAC Guard no autorizó la creación de la Caja Fuerte en la ubicación elegida: {error}"));
                    return false;
                }
            },
            None => false,
        };

        let was_keystore_released = match keystore_path.as_deref() {
            Some(path) => match self.guard_release_path(path) {
                Ok(value) => value,
                Err(error) => {
                    let _ = creation_guard_path
                        .as_deref()
                        .map(|path| self.guard_reprotect(path, was_creation_path_released));
                    self.set_error(format!(
                        "OPAC Guard no autorizó la actualización del Key Store: {error}"
                    ));
                    return false;
                }
            },
            None => false,
        };

        let result = {
            let Some(session) = self.session.as_mut() else {
                let _ = keystore_path
                    .as_deref()
                    .map(|path| self.guard_reprotect(path, was_keystore_released));
                let _ = creation_guard_path
                    .as_deref()
                    .map(|path| self.guard_reprotect(path, was_creation_path_released));
                return false;
            };
            match (self.new_vault_parent.clone(), imported_key) {
                (Some(parent), Some(key)) => {
                    session.create_vault_in_parent(&name, &parent, Some(key))
                }
                (Some(parent), None) => session.create_vault_in_parent(&name, &parent, None),
                (None, Some(key)) => session.create_vault_default_with_key(&name, key),
                (None, None) => session.create_vault_default(&name),
            }
        };

        let keystore_reprotect = keystore_path
            .as_deref()
            .map(|path| self.guard_reprotect(path, was_keystore_released))
            .unwrap_or(Ok(()));
        let creation_reprotect = creation_guard_path
            .as_deref()
            .map(|path| self.guard_reprotect(path, was_creation_path_released))
            .unwrap_or(Ok(()));

        match result {
            Ok(id) => {
                self.select_vault(id);
                self.new_vault_imported_key.clear();
                match (keystore_reprotect, creation_reprotect) {
                    (Ok(()), Ok(())) => {
                        self.status = Some(format!("Caja Fuerte «{}» creada.", name));
                        self.status_error = false;
                    }
                    (Err(keystore_error), Ok(())) => self.set_error(format!("Caja Fuerte «{}» creada, pero OPAC Guard no pudo reproteger el Key Store: {keystore_error}", name)),
                    (Ok(()), Err(creation_error)) => self.set_error(format!("Caja Fuerte «{}» creada, pero OPAC Guard no pudo reproteger la ubicación de la Caja: {creation_error}", name)),
                    (Err(keystore_error), Err(creation_error)) => self.set_error(format!("Caja Fuerte «{}» creada, pero OPAC Guard no pudo confirmar la reprotección del Key Store ({keystore_error}) ni de la ubicación de la Caja ({creation_error}).", name)),
                }
                true
            }
            Err(error) => {
                match (keystore_reprotect, creation_reprotect) {
                    (Ok(()), Ok(())) => self.set_error(format_error(&error)),
                    (Err(keystore_error), Ok(())) => self.set_error(format!("{} Además, OPAC Guard no pudo confirmar la reprotección del Key Store: {keystore_error}", format_error(&error))),
                    (Ok(()), Err(creation_error)) => self.set_error(format!("{} Además, OPAC Guard no pudo confirmar la reprotección de la ubicación de la Caja: {creation_error}", format_error(&error))),
                    (Err(keystore_error), Err(creation_error)) => self.set_error(format!("{} Además, OPAC Guard no pudo confirmar la reprotección del Key Store ({keystore_error}) ni de la ubicación de la Caja ({creation_error}).", format_error(&error))),
                }
                false
            }
        }
    }

    fn select_vault(&mut self, id: Uuid) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "Espera a que termine la operacion actual antes de cambiar de Caja Fuerte.",
            );
            return;
        }
        if self.selected_vault_id != Some(id) && !self.save_pending_edit() {
            return;
        }
        self.clear_temp_exports();
        let result = self
            .session
            .as_ref()
            .ok_or(SessionError::Vault(VaultError::NotFound))
            .and_then(|session| session.open_vault(id, None));

        match result {
            Ok(vault) => {
                self.stop_audio_preview();
                self.clear_preload_cache();
                self.selected_vault_id = Some(id);
                let access_mode = vault.info().access_mode;
                let has_pin = vault.info().has_pin;
                self.vault = Some(vault);
                self.vault_pin_authenticated = !has_pin;
                self.current_folder = None;
                self.folder_drop_rects.clear();
                self.drop_target_folder = None;
                self.selected_file = None;
                self.clear_preview_state();
                self.editing_text = false;
                self.edit_original_text = None;
                self.refresh_files();
                self.set_ok("Caja Fuerte abierta.".into());
                if access_mode == VaultAccessMode::PreloadAll {
                    self.start_preload_all();
                }
            }
            Err(SessionError::Vault(VaultError::PinRequired)) => {
                self.stop_audio_preview();
                self.clear_preload_cache();
                self.vault = None;
                self.vault_pin_authenticated = false;
                self.selected_vault_id = Some(id);
                self.current_folder = None;
                self.folder_drop_rects.clear();
                self.drop_target_folder = None;
                self.selected_file = None;
                self.clear_preview_state();
                self.editing_text = false;
                self.edit_original_text = None;
                self.pending_pin_vault = Some(id);
                self.pin_value.clear();
                self.show_pin_prompt = false;
                self.set_ok(
                    "Caja Fuerte bloqueada. Introduce el PIN para ver los archivos.".into(),
                );
            }
            Err(error) => self.set_error(format_error(&error)),
        }
    }

    fn refresh_files(&mut self) {
        let Some(vault) = self.vault.as_ref() else {
            self.files.clear();
            self.folders.clear();
            return;
        };

        let root = vault.location().to_path_buf();
        let paths_result = vault.list_files();
        let folders_result = vault.list_folders();

        let (files, file_error) = match paths_result {
            Ok(paths) => {
                let mut files = Vec::with_capacity(paths.len());
                let mut errors = Vec::new();
                for path in paths {
                    match vault.read_file_metadata(&path) {
                        Ok(metadata) => files.push(FileEntry {
                            disk_path: path,
                            metadata,
                        }),
                        Err(error) => errors.push(format_error(&error)),
                    }
                }
                files.sort_by_key(|entry| entry.metadata.original_name.to_lowercase());
                (files, errors.into_iter().next())
            }
            Err(error) => (Vec::new(), Some(format_error(&error))),
        };

        let folders = match folders_result {
            Ok(folders) => folders
                .into_iter()
                .map(|(disk_path, metadata)| FolderEntry {
                    disk_path,
                    metadata,
                })
                .collect::<Vec<_>>(),
            Err(error) => {
                self.set_error(format!(
                    "No se pudieron leer las carpetas: {}",
                    format_error(&error)
                ));
                Vec::new()
            }
        };

        self.files = files;
        self.folders = folders;
        if let Some(error) = file_error {
            self.set_error(format!("No se pudo leer un archivo: {error}"));
        }

        if let Some(current) = self.current_folder.clone()
            && current != root
            && !self
                .folders
                .iter()
                .any(|folder| folder.disk_path == current)
        {
            self.current_folder = None;
        }
        self.folder_drop_rects.clear();
        self.drop_target_folder = None;
    }

    fn handle_drops(&mut self, ctx: &Context) {
        let (hovered, dropped, hover_pos) = ctx.input(|input| {
            (
                !input.raw.hovered_files.is_empty(),
                input
                    .raw
                    .dropped_files
                    .iter()
                    .map(|file| file.path().to_path_buf())
                    .collect::<Vec<_>>(),
                input.pointer.hover_pos(),
            )
        });

        self.drop_active = hovered;
        if hovered {
            if let Some(pointer) = hover_pos {
                self.drop_target_folder = self
                    .folder_drop_rects
                    .iter()
                    .rev()
                    .find(|(_, rect)| rect.contains(pointer))
                    .map(|(path, _)| path.clone());
            }
        } else if dropped.is_empty() {
            self.drop_target_folder = None;
        }

        if !dropped.is_empty() {
            ctx.request_repaint();
        }
        if dropped.is_empty() {
            return;
        }

        let target_folder = self.drop_target_folder.clone();
        self.start_import_files(dropped, target_folder);
    }

    fn import_files_manually(&mut self) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "La Caja Fuerte esta ocupada preparando un archivo. Espera a que termine.",
            );
            return;
        }
        if self.manual_import_dialog.is_some() {
            return;
        }

        // Crear el futuro del dialogo en el hilo de la GUI y esperar el resultado
        // en segundo plano. Esto evita llamar a pick_files() sincronico desde
        // un hilo ajeno al event loop de la aplicacion.
        let dialog_future = AsyncFileDialog::new()
            .set_title("Importar archivos a la Caja Fuerte")
            .pick_files();
        let (sender, receiver) = mpsc::channel();
        let handle = thread::Builder::new()
            .name("opac-file-dialog-await".to_owned())
            .spawn(move || {
                let files = block_on(dialog_future).map(|handles| {
                    handles
                        .into_iter()
                        .map(|handle| handle.path().to_path_buf())
                        .collect()
                });
                let _ = sender.send(files);
            });

        match handle {
            Ok(_) => {
                self.manual_import_dialog = Some(receiver);
                self.set_ok(
                    "Selecciona uno o varios archivos en el Explorador de archivos…".into(),
                );
            }
            Err(error) => {
                self.set_error(format!(
                    "No se pudo abrir el Explorador de archivos: {error}"
                ));
            }
        }
    }

    fn poll_manual_import_dialog(&mut self) {
        let Some(receiver) = self.manual_import_dialog.as_ref() else {
            return;
        };

        match receiver.try_recv() {
            Ok(Some(files)) => {
                self.manual_import_dialog = None;
                if !files.is_empty() {
                    self.start_import_files(files, self.current_folder.clone());
                }
            }
            Ok(None) => {
                self.manual_import_dialog = None;
            }
            Err(mpsc::TryRecvError::Empty) => {}
            Err(mpsc::TryRecvError::Disconnected) => {
                self.manual_import_dialog = None;
                self.set_error("El Explorador de archivos se cerro de forma inesperada.");
            }
        }
    }

    fn start_import_files(&mut self, files: Vec<PathBuf>, requested_target: Option<PathBuf>) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "La Caja Fuerte esta ocupada preparando un archivo. Espera a que termine.",
            );
            return;
        }

        if !self.save_pending_edit() {
            return;
        }

        let Some(vault) = self.vault.as_ref() else {
            if self.selected_vault_is_locked() {
                self.set_error("Desbloquea la Caja Fuerte con su PIN antes de añadir archivos.");
            } else {
                self.set_error("Selecciona o crea una Caja Fuerte antes de añadir archivos.");
            }
            return;
        };

        let vault_folder = vault.location().to_path_buf();
        let target_folder = requested_target
            .filter(|path| path_is_same_or_descendant(path, &vault_folder))
            .unwrap_or_else(|| vault_folder.clone());
        if let Err(error) =
            opac_window_core::modules::vault_fs::validate_vault_path(&vault_folder, &target_folder)
        {
            self.set_error(format!("Destino de carpeta no valido: {error}"));
            self.drop_target_folder = None;
            return;
        }

        let prepared = match prepare_import_jobs(vault, &target_folder, files) {
            Ok(prepared) => prepared,
            Err(error) => {
                self.set_error(format!("No se pudo preparar la importacion: {error}"));
                self.drop_target_folder = None;
                return;
            }
        };
        let jobs = prioritize_import_jobs(prepared.jobs);
        let total = jobs.len();
        let imported_folder_count = prepared.folder_count;
        if total == 0 {
            self.refresh_files();
            self.drop_active = false;
            self.drop_target_folder = None;
            self.selected_file = None;
            self.clear_preview_state();
            self.set_ok(if imported_folder_count == 1 {
                "Carpeta importada correctamente.".into()
            } else {
                format!("{imported_folder_count} carpetas importadas correctamente.")
            });
            return;
        }

        let target_name = self
            .folder_name_for_path(&target_folder)
            .unwrap_or_else(|| "raiz".to_owned());
        let vault_key = Arc::new(Zeroizing::new(*vault.key_bytes()));
        let jobs = jobs.into_iter().collect::<VecDeque<_>>();
        let total_bytes = jobs
            .iter()
            .filter_map(|job| fs::symlink_metadata(&job.source).ok())
            .filter(|metadata| metadata.file_type().is_file())
            .map(|metadata| metadata.len())
            .fold(0u64, u64::saturating_add);
        let single_file_chunk_workers = if total == 1 {
            jobs.front()
                .and_then(|job| fs::metadata(&job.source).ok())
                .map(|metadata| import_chunk_worker_count(metadata.len()))
                .unwrap_or(1)
        } else {
            1
        };
        let queue = Arc::new(Mutex::new(jobs));
        let (sender, receiver) = mpsc::channel();
        let file_worker_count = if total == 1 {
            1
        } else {
            import_worker_count(total)
        };

        let worker_vault_folder = vault_folder.clone();
        let handle = match thread::Builder::new()
            .name("opac-encrypt-coordinator".to_owned())
            .spawn(move || {
                let mut workers = Vec::with_capacity(file_worker_count);
                for index in 0..file_worker_count {
                    let worker_queue = Arc::clone(&queue);
                    let worker_sender = sender.clone();
                    let child_vault_folder = worker_vault_folder.clone();
                    let worker_vault_key = Arc::clone(&vault_key);
                    let worker = thread::Builder::new()
                        .name(format!("opac-encrypt-{index}"))
                        .spawn(move || {
                            run_import_worker(
                                worker_queue,
                                worker_sender,
                                child_vault_folder,
                                worker_vault_key,
                                single_file_chunk_workers,
                            );
                        });
                    match worker {
                        Ok(handle) => workers.push(handle),
                        Err(_) => {
                            // Si no podemos crear otro hilo, el coordinador drena la
                            // cola de forma síncrona. No se pierde ningún trabajo.
                            run_import_worker(
                                Arc::clone(&queue),
                                sender.clone(),
                                worker_vault_folder.clone(),
                                Arc::clone(&vault_key),
                                single_file_chunk_workers,
                            );
                            break;
                        }
                    }
                }

                for worker in workers {
                    let _ = worker.join();
                }
            }) {
            Ok(handle) => handle,
            Err(error) => {
                self.set_error(format!("No se pudo iniciar el cifrado: {error}"));
                return;
            }
        };

        if target_folder != vault_folder {
            self.expanded_folders.insert(target_folder.clone());
        }
        self.import_task = Some(ImportTask {
            total,
            completed: 0,
            total_bytes,
            completed_bytes: 0,
            current: None,
            current_bytes_completed: 0,
            current_bytes_total: 0,
            current_chunks_completed: 0,
            current_chunks_total: 0,
            per_source_bytes: HashMap::new(),
            target_folder,
            active_workers: 0,
            results: Vec::with_capacity(total),
            receiver,
            handle: Some(handle),
        });
        self.drop_active = false;
        self.drop_target_folder = None;
        self.selected_file = None;
        self.clear_preview_state();
        self.editing_text = false;
        self.edit_original_text = None;
        let start_status = if total == 1 && single_file_chunk_workers > 1 {
            format!(
                "Cifrado iniciado en «{target_name}»: 1 archivo grande; chunks cifrados en paralelo con hasta {single_file_chunk_workers} workers…"
            )
        } else {
            format!(
                "Cifrado iniciado en «{target_name}»: {} archivo{}; hasta {} cifrados en paralelo…",
                total,
                if total == 1 { "" } else { "s" },
                file_worker_count
            )
        };
        self.set_ok(start_status);
    }

    fn poll_import_task(&mut self) {
        let mut task = match self.import_task.take() {
            Some(task) => task,
            None => return,
        };

        while let Ok(event) = task.receiver.try_recv() {
            match event {
                ImportEvent::Started {
                    source_path,
                    name,
                    total_chunks,
                    total_bytes,
                    worker_units,
                } => {
                    task.active_workers += worker_units;
                    task.current = Some(name);
                    task.current_bytes_completed = 0;
                    task.current_bytes_total = total_bytes;
                    task.current_chunks_completed = 0;
                    task.current_chunks_total = total_chunks;
                    task.per_source_bytes.entry(source_path).or_insert(0);
                }
                ImportEvent::ChunkProgress {
                    source_path,
                    name,
                    completed,
                    total,
                    bytes_completed,
                } => {
                    let previous = task
                        .per_source_bytes
                        .insert(source_path, bytes_completed)
                        .unwrap_or(0);
                    task.completed_bytes = task
                        .completed_bytes
                        .saturating_add(bytes_completed.saturating_sub(previous));
                    task.current = Some(name);
                    task.current_bytes_completed = bytes_completed;
                    task.current_chunks_completed = completed;
                    task.current_chunks_total = total;
                }
                ImportEvent::Finished {
                    source_path,
                    source_name,
                    total_bytes,
                    worker_units,
                    result,
                } => {
                    task.completed += 1;
                    task.active_workers = task.active_workers.saturating_sub(worker_units);
                    let previous = task.per_source_bytes.remove(&source_path).unwrap_or(0);
                    if result.is_ok() && previous < total_bytes {
                        task.completed_bytes =
                            task.completed_bytes.saturating_add(total_bytes - previous);
                    }
                    if task.current.as_deref() == Some(source_name.as_str()) {
                        task.current = None;
                        task.current_bytes_completed = 0;
                        task.current_bytes_total = 0;
                        task.current_chunks_completed = 0;
                        task.current_chunks_total = 0;
                    }
                    task.results.push((source_name, result));
                }
            }
        }

        if task.completed < task.total {
            self.status = Some(if let Some(current) = &task.current {
                let total_percent = task
                    .completed_bytes
                    .min(task.total_bytes)
                    .saturating_mul(100)
                    .checked_div(task.total_bytes)
                    .unwrap_or(100);
                if task.current_chunks_total > 1 {
                    format!(
                        "Cifrando en paralelo: {} activos · total {}% · {}/{} archivos · {} · chunks {}/{}",
                        task.active_workers,
                        total_percent,
                        task.completed,
                        task.total,
                        current,
                        task.current_chunks_completed,
                        task.current_chunks_total
                    )
                } else {
                    format!(
                        "Cifrando en paralelo: {} activos · total {}% · {}/{} archivos · {}",
                        task.active_workers, total_percent, task.completed, task.total, current
                    )
                }
            } else {
                format!(
                    "Cifrando en paralelo: {} activos · {}/{} archivos terminados",
                    task.active_workers, task.completed, task.total
                )
            });
            self.status_error = false;
            self.import_task = Some(task);
            return;
        }

        let mut imported = 0usize;
        let mut errors = Vec::new();
        for (name, result) in task.results {
            match result {
                Ok(_) => imported += 1,
                Err(error) => errors.push(format!("{}: {}", name, error)),
            }
        }

        if let Some(handle) = task.handle.take() {
            let _ = handle.join();
        }

        if imported > 0 {
            self.refresh_files();
            if self
                .vault
                .as_ref()
                .is_some_and(|vault| vault.info().access_mode == VaultAccessMode::PreloadAll)
            {
                self.stop_audio_preview();
                self.start_preload_all();
            }
        }
        if let Some(error) = errors.first() {
            self.set_error(if errors.len() == 1 {
                format!("No se pudo cifrar: {error}")
            } else {
                format!(
                    "{} archivos no se pudieron cifrar. Primero: {}",
                    errors.len(),
                    error
                )
            });
        } else if imported > 0 {
            let target_name = self
                .folder_name_for_path(&task.target_folder)
                .unwrap_or_else(|| "raíz".to_owned());
            self.set_ok(if imported == 1 {
                format!("Archivo cifrado y añadido en «{target_name}».")
            } else {
                format!(
                    "{} archivos cifrados y añadidos en «{target_name}».",
                    imported
                )
            });
        } else {
            self.set_error("No se pudo completar el cifrado.");
        }
    }

    fn begin_text_edit(&mut self) {
        if self.editing_text
            || !matches!(self.preview_kind, PreviewKind::Text | PreviewKind::Markdown)
        {
            return;
        }
        let Some(text) = self.preview_text.as_ref() else {
            return;
        };
        self.edit_original_text = Some(text.clone());
        self.editing_text = true;
        self.set_ok("Modo edición activo. Guarda los cambios para volver a cifrarlos.".into());
    }

    fn cancel_text_edit(&mut self) {
        if let Some(original) = self.edit_original_text.take() {
            self.preview_text = Some(original);
        }
        self.editing_text = false;
        self.markdown_cache = CommonMarkCache::default();
        self.set_ok("Cambios descartados.".into());
    }

    fn save_text_edit(&mut self) -> bool {
        if !self.editing_text {
            return true;
        }
        let Some(path) = self.selected_file.clone() else {
            return false;
        };
        let Some(original) = self.edit_original_text.as_ref() else {
            self.editing_text = false;
            return true;
        };
        let Some(text) = self.preview_text.as_ref() else {
            self.set_error("No hay contenido de texto que guardar.");
            return false;
        };

        if text.as_str() == original.as_str() {
            self.edit_original_text = None;
            self.editing_text = false;
            self.markdown_cache = CommonMarkCache::default();
            self.set_ok("Sin cambios que guardar.".into());
            return true;
        }

        if text.len() > PREVIEW_MAX_BYTES as usize {
            self.set_error("El texto editado supera el límite de edición de 512 KiB.");
            return false;
        }

        let access_mode = self.vault.as_ref().map(|vault| vault.info().access_mode);
        let was_released = match self.guard_release_path(&path) {
            Ok(value) => value,
            Err(error) => {
                self.set_error(format!(
                    "OPAC Guard no autorizó el archivo para escritura: {error}"
                ));
                return false;
            }
        };
        let result = match self.vault.as_ref() {
            Some(vault) => vault.replace_file_content(&path, text.as_bytes()),
            None => {
                let _ = self.guard_reprotect(&path, was_released);
                self.set_error("La Caja Fuerte no está desbloqueada.");
                return false;
            }
        };
        let reprotect_result = self.guard_reprotect(&path, was_released);

        match result {
            Ok(metadata) => {
                // En PreloadAll la copia temporal ya existe en claro por
                // diseño. La actualizamos para no dejarla desfasada tras el
                // guardado, sin necesidad de volver a descifrar toda la Caja.
                if access_mode == Some(VaultAccessMode::PreloadAll)
                    && let Some(cached) = self.preloaded_files.get(&path).cloned()
                {
                    let cache_result = (|| -> io::Result<()> {
                        let mut file = OpenOptions::new()
                            .write(true)
                            .truncate(true)
                            .open(&cached)?;
                        use std::io::Write;
                        file.write_all(text.as_bytes())?;
                        file.sync_all()?;
                        Ok(())
                    })();
                    if cache_result.is_err() {
                        self.remove_temp_file_or_defer(cached);
                        self.preloaded_files.remove(&path);
                    }
                }

                self.edit_original_text = None;
                self.editing_text = false;
                self.markdown_cache = CommonMarkCache::default();
                self.refresh_files();
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!(
                        "Cambios guardados y cifrados: {} ({}), pero OPAC Guard no pudo confirmar la reprotección de la ruta: {reprotect_error}",
                        metadata.original_name,
                        format_bytes(metadata.original_size),
                    ));
                } else {
                    self.set_ok(format!(
                        "Cambios guardados y cifrados: {} ({})",
                        metadata.original_name,
                        format_bytes(metadata.original_size),
                    ));
                }
                true
            }
            Err(error) => {
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!("No se pudieron guardar los cambios: {}. Además, OPAC Guard no pudo confirmar la reprotección: {reprotect_error}", format_error(&error)));
                } else {
                    self.set_error(format!(
                        "No se pudieron guardar los cambios: {}",
                        format_error(&error)
                    ));
                }
                false
            }
        }
    }

    fn video_preview_busy(&self) -> bool {
        #[cfg(target_os = "windows")]
        {
            self.video_task.is_some() && self.video_texture.is_none() && self.video_error.is_none()
        }
        #[cfg(not(target_os = "windows"))]
        {
            false
        }
    }

    fn save_pending_edit(&mut self) -> bool {
        if self.editing_text {
            self.save_text_edit()
        } else {
            true
        }
    }

    fn select_file_for_preview(&mut self, path: PathBuf) {
        if self.audio_task.is_some() || self.video_preview_busy() {
            self.set_error("Espera a que termine o cancela la preparación de la vista previa.");
            return;
        }
        if self.selected_file.as_ref() == Some(&path) {
            return;
        }
        if !self.save_pending_edit() {
            return;
        }
        self.stop_audio_preview();
        self.selected_file = Some(path);
        self.clear_preview_state();
        self.editing_text = false;
        self.edit_original_text = None;
        self.audio_error = None;
        self.markdown_cache = CommonMarkCache::default();
        self.prepare_preview_selected();
    }

    fn prepare_preview_selected(&mut self) {
        let Some(path) = self.selected_file.clone() else {
            return;
        };
        let Some(entry) = self.files.iter().find(|entry| entry.disk_path == path) else {
            return;
        };
        let name = entry.metadata.original_name.clone();
        let ext = Path::new(&name)
            .extension()
            .and_then(|extension| extension.to_str())
            .unwrap_or_default()
            .to_ascii_lowercase();

        if looks_like_audio(&name) {
            self.preview_kind = PreviewKind::Audio;
            self.prepare_audio_preview(path);
            return;
        }

        if looks_like_video(&name) {
            #[cfg(target_os = "windows")]
            {
                self.preview_kind = PreviewKind::Video;
                self.prepare_video_preview(path, entry.metadata.original_size);
            }
            #[cfg(not(target_os = "windows"))]
            {
                self.preview_kind = PreviewKind::Unsupported;
            }
            return;
        }

        if looks_like_image(&name) {
            self.preview_kind = PreviewKind::Image;
            self.prepare_image_preview(path, entry.metadata.original_size);
            return;
        }

        if looks_like_pdf(&name) {
            self.preview_kind = PreviewKind::Pdf;
            self.prepare_pdf_preview(path, entry.metadata.original_size);
            return;
        }

        if ext == "md" || ext == "markdown" {
            self.preview_kind = PreviewKind::Markdown;
        } else if looks_like_text(&name) {
            self.preview_kind = PreviewKind::Text;
        } else {
            self.preview_kind = PreviewKind::Unsupported;
            return;
        }

        if entry.metadata.original_size > PREVIEW_MAX_BYTES {
            self.preview_text = None;
            return;
        }

        let result = if let Some(cached) = self.preloaded_files.get(&path) {
            match opac_window_core::modules::files::read_plain_file_bounded(
                cached,
                PREVIEW_MAX_BYTES,
            ) {
                Ok((_metadata, bytes)) => Ok(Zeroizing::new(bytes)),
                Err(error) if error.kind() == io::ErrorKind::InvalidData => {
                    Err(SessionError::PreviewTooLarge)
                }
                Err(error) => Err(SessionError::from(error)),
            }
        } else {
            let Some(vault) = self.vault.as_ref() else {
                return;
            };
            vault
                .read_small_file(&path, PREVIEW_MAX_BYTES as usize)
                .map(|(_, bytes)| bytes)
        };

        match result {
            Ok(bytes) => match std::str::from_utf8(bytes.as_slice()) {
                Ok(text) => self.preview_text = Some(Zeroizing::new(text.to_owned())),
                Err(_) => self.preview_text = None,
            },
            Err(error) => self.set_error(format_error(&error)),
        }
    }

    fn prepare_pdf_preview(&mut self, source_path: PathBuf, original_size: u64) {
        self.preview_text = None;
        self.preview_pdf_page_count = None;

        if original_size > PDF_PREVIEW_MAX_BYTES {
            self.set_error(format!(
                "El PDF supera el limite de vista previa de {}.",
                format_bytes(PDF_PREVIEW_MAX_BYTES)
            ));
            return;
        }

        // Los PDF de la vista integrada nunca usan la caché plaintext de
        // `PreloadAll`: se descifran directamente desde el `.opac` a memoria.
        // Esto evita que cambiar de archivo, bloquear o cerrar dependa de
        // borrar una copia PDF en disco.
        let Some(vault) = self.vault.as_ref() else {
            return;
        };
        let bytes = match vault.read_small_file(&source_path, PDF_PREVIEW_MAX_BYTES as usize) {
            Ok((_, bytes)) => bytes,
            Err(error) => {
                self.set_error(format_error(&error));
                return;
            }
        };

        match render_pdf_preview(&bytes) {
            Ok((page_count, pages)) => {
                let rendered_count = pages.len();
                self.preview_pdf_page_count = Some(page_count);
                self.preview_pdf_pages = pages;
                self.set_ok(format!(
                    "PDF descifrado y {rendered_count} {} renderizadas solo en memoria para la vista previa.",
                    if rendered_count == 1 { "página" } else { "páginas" }
                ));
            }
            Err(error) => {
                self.set_error(format!("No se pudo previsualizar el PDF: {error}"));
            }
        }
    }

    fn prepare_image_preview(&mut self, source_path: PathBuf, original_size: u64) {
        self.preview_image = None;
        self.preview_image_texture = None;
        self.preview_image_size = None;

        if original_size > IMAGE_PREVIEW_MAX_BYTES {
            self.set_error(format!(
                "La imagen supera el limite de vista previa de {}.",
                format_bytes(IMAGE_PREVIEW_MAX_BYTES)
            ));
            return;
        }

        // Las imágenes de la vista integrada nunca usan la caché plaintext de
        // `PreloadAll`: se descifran directamente desde el `.opac` a memoria.
        let Some(vault) = self.vault.as_ref() else {
            return;
        };
        let bytes = match vault.read_small_file(&source_path, IMAGE_PREVIEW_MAX_BYTES as usize) {
            Ok((_, bytes)) => bytes,
            Err(error) => {
                self.set_error(format_error(&error));
                return;
            }
        };

        match decode_preview_image(&bytes) {
            Ok((rgba, size)) => {
                let rgba = Zeroizing::new(rgba);
                let color_image = egui::ColorImage::from_rgba_unmultiplied(size, &rgba);
                self.preview_image_size = Some(size);
                self.preview_image = Some(color_image);
                self.set_ok(
                    "Imagen descifrada y preparada solo en memoria para la vista previa.".into(),
                );
            }
            Err(error) => {
                self.set_error(format!("No se pudo previsualizar la imagen: {error}"));
            }
        }
    }

    #[cfg(target_os = "windows")]
    fn prepare_video_preview(&mut self, source_path: PathBuf, original_size: u64) {
        self.stop_video_preview();
        self.video_texture = None;
        self.video_size = None;
        self.video_position = Duration::ZERO;
        self.video_duration = None;
        self.video_seek_override = None;
        self.video_finished = false;
        self.video_error = None;

        if original_size > VIDEO_PREVIEW_MAX_BYTES {
            self.video_error = Some(format!(
                "El vídeo supera el límite de vista previa de {}.",
                format_bytes(VIDEO_PREVIEW_MAX_BYTES)
            ));
            return;
        }

        if let Some(cached) = self.preloaded_files.get(&source_path).cloned() {
            match fs::symlink_metadata(&cached) {
                Ok(meta) if meta.is_file() && !is_reparse_or_symlink_gui(&meta) => {
                    self.start_video_preview_from_plaintext(source_path, cached);
                    return;
                }
                Ok(_) | Err(_) => {
                    self.video_error =
                        Some("La copia precargada del vídeo ya no está disponible.".into());
                    return;
                }
            }
        }

        let Some(vault) = self.vault.as_ref() else {
            self.video_error = Some("La Caja Fuerte no está desbloqueada.".into());
            return;
        };
        let key = Zeroizing::new(*vault.key_bytes());
        let temp_root = match self.ensure_session_temp_dir() {
            Ok(path) => path,
            Err(error) => {
                self.video_error =
                    Some(format!("No se pudo crear el área temporal segura: {error}"));
                return;
            }
        };
        let extension = safe_temp_extension(
            self.files
                .iter()
                .find(|entry| entry.disk_path == source_path)
                .map(|entry| entry.metadata.original_name.as_str())
                .unwrap_or("video.mp4"),
            "video",
        );
        let preview_path =
            temp_root.join(format!("video-{}.{}", Uuid::new_v4().simple(), extension));
        let task = match video_preview::spawn_video_preview(
            source_path.clone(),
            preview_path.clone(),
            key,
        ) {
            Ok(task) => task,
            Err(error) => {
                self.video_error = Some(error);
                return;
            }
        };
        self.video_preview_path = Some(preview_path);
        self.video_preview_owned = true;
        self.video_task = Some(task);
        self.set_ok("Preparando vídeo…".into());
    }

    #[cfg(target_os = "windows")]
    fn start_video_preview_from_plaintext(&mut self, source_path: PathBuf, preview_path: PathBuf) {
        let task = match video_preview::spawn_video_preview_from_plaintext(
            source_path,
            preview_path.clone(),
        ) {
            Ok(task) => task,
            Err(error) => {
                self.video_error = Some(error);
                return;
            }
        };
        self.video_preview_path = Some(preview_path);
        self.video_preview_owned = false;
        self.video_task = Some(task);
        self.set_ok("Preparando vídeo…".into());
    }

    #[cfg(target_os = "windows")]
    fn start_video_audio_from_path(&mut self, path: &Path) -> Result<(), String> {
        self.stop_video_audio();
        let file = open_video_audio_file(path)?;
        let decoder = Decoder::try_from(file)
            .map_err(|error| format!("La pista de audio del vídeo no es compatible: {error}"))?;
        let output = DeviceSinkBuilder::open_default_sink().map_err(|error| {
            format!("No se pudo abrir el dispositivo de audio para el vídeo: {error}")
        })?;
        let player = Player::connect_new(output.mixer());
        player.append(decoder);
        player.set_volume(self.audio_volume);
        player.pause();
        self.video_audio_output = Some(output);
        self.video_audio_player = Some(player);
        self.video_audio_start_pending = true;
        self.video_audio_error = None;
        Ok(())
    }

    #[cfg(target_os = "windows")]
    fn update_video_audio_clock(&mut self) {
        let task_playing = self
            .video_task
            .as_ref()
            .is_some_and(|task| task.playing.load(Ordering::Acquire));
        let (active, position) = if task_playing && !self.video_audio_start_pending {
            match self.video_audio_player.as_ref() {
                Some(player) if !player.empty() => {
                    (true, self.video_audio_base + player.get_pos())
                }
                _ => (false, Duration::ZERO),
            }
        } else {
            (false, Duration::ZERO)
        };

        if let Some(task) = self.video_task.as_ref() {
            task.audio_clock_nanos.store(
                position.as_nanos().min(u64::MAX as u128) as u64,
                Ordering::Release,
            );
            task.audio_clock_active.store(active, Ordering::Release);
            task.audio_clock_pending
                .store(self.video_audio_start_pending, Ordering::Release);
        }

        if active && self.video_seek_override.is_none() {
            self.video_position = position;
        }
    }

    #[cfg(target_os = "windows")]
    fn stop_video_audio(&mut self) {
        self.cancel_video_audio_seek_task();
        self.video_audio_base = Duration::ZERO;
        if let Some(task) = self.video_task.as_ref() {
            task.audio_clock_active.store(false, Ordering::Release);
            task.audio_clock_nanos.store(0, Ordering::Release);
            task.audio_clock_pending.store(false, Ordering::Release);
        }
        self.video_audio_player = None;
        self.video_audio_output = None;
        self.video_audio_start_pending = false;
        self.video_audio_error = None;
    }

    #[cfg(target_os = "windows")]
    fn set_video_playback(&mut self, playing: bool) {
        // Mientras se reposiciona el audio, el Player actual es obsoleto:
        // solo se recuerda la intención y se aplica al terminar.
        if let Some(pending) = self.video_audio_seek_task.as_mut() {
            pending.was_playing = playing;
            return;
        }
        if playing {
            if let Some(player) = self.video_audio_player.as_ref() {
                player.play();
            }
            if self.video_audio_start_pending {
                self.video_audio_start_pending = false;
            }
            if let Some(task) = self.video_task.as_ref() {
                task.audio_clock_pending.store(false, Ordering::Release);
                task.playing.store(true, Ordering::Release);
            }
        } else {
            if let Some(task) = self.video_task.as_ref() {
                task.playing.store(false, Ordering::Release);
                task.audio_clock_pending.store(false, Ordering::Release);
            }
            if let Some(player) = self.video_audio_player.as_ref() {
                player.pause();
            }
        }
        self.update_video_audio_clock();
    }

    #[cfg(target_os = "windows")]
    fn restart_video_playback(&mut self) {
        let Some(path) = self.video_preview_path.clone() else {
            self.stop_video_audio();
            if let Some(task) = self.video_task.as_ref()
                && task.request_restart().is_ok()
            {
                task.playing.store(true, Ordering::Release);
            }
            self.video_finished = false;
            self.video_position = Duration::ZERO;
            self.video_seek_override = None;
            return;
        };

        if let Err(error) = self.start_video_audio_from_path(&path) {
            self.video_audio_error = Some(error);
        }
        if let Some(task) = self.video_task.as_ref()
            && task.request_restart().is_ok()
        {
            task.playing.store(true, Ordering::Release);
            task.audio_clock_nanos.store(0, Ordering::Release);
            task.audio_clock_active.store(false, Ordering::Release);
            task.audio_clock_pending
                .store(self.video_audio_player.is_some(), Ordering::Release);
            self.video_audio_start_pending = self.video_audio_player.is_some();
        }
        self.update_video_audio_clock();
        self.video_finished = false;
        self.video_position = Duration::ZERO;
        self.video_seek_override = None;
    }

    #[cfg(target_os = "windows")]
    fn seek_video_playback(&mut self, requested: Duration, was_playing: bool) {
        let was_playing = self.cancel_video_audio_seek_task().unwrap_or(false) || was_playing;
        self.set_video_playback(false);

        // No se usa `Player::try_seek`: el seek del demuxer sobre el MP4
        // completo dejaba el audio en una posición distinta de la pedida,
        // mientras `get_pos()` informaba la pedida. Se crea un Player nuevo
        // que descarta el audio anterior a `requested` (preciso por
        // construcción) y se suma su posición base al reloj.
        if self.video_audio_player.is_some() {
            if self.begin_video_audio_seek(requested, was_playing) {
                self.video_position = requested;
                return;
            }
            self.stop_video_audio();
            self.video_audio_error = Some(
                "No se pudo reposicionar el audio del vídeo; se continúa con el reloj local."
                    .into(),
            );
        }
        self.finish_video_seek(requested, was_playing);
    }

    /// Lanza en un hilo la construcción del Player posicionado en `requested`.
    #[cfg(target_os = "windows")]
    fn begin_video_audio_seek(&mut self, requested: Duration, was_playing: bool) -> bool {
        let (Some(path), Some(output)) = (
            self.video_preview_path.clone(),
            self.video_audio_output.as_ref(),
        ) else {
            return false;
        };
        let mixer = output.mixer().clone();
        let volume = self.audio_volume;
        let (sender, receiver) = mpsc::channel();
        let spawn = thread::Builder::new()
            .name("opac-video-audio-seek".into())
            .spawn(move || {
                let result = (|| -> Result<Player, String> {
                    let file = open_video_audio_file(&path)?;
                    let decoder = Decoder::try_from(file).map_err(|error| {
                        format!("La pista de audio del vídeo no es compatible: {error}")
                    })?;
                    let player = Player::connect_new(&mixer);
                    player.set_volume(volume);
                    player.pause();
                    player.append(decoder.skip_duration(requested));
                    Ok(player)
                })();
                let _ = sender.send(result);
            });
        match spawn {
            Ok(handle) => {
                self.video_audio_seek_task = Some(VideoAudioSeekTask {
                    requested,
                    was_playing,
                    receiver,
                    handle: Some(handle),
                });
                true
            }
            Err(_) => false,
        }
    }

    /// Cancela un reposicionamiento de audio en curso y devuelve si el usuario
    /// quería reproducir al terminar.
    #[cfg(target_os = "windows")]
    fn cancel_video_audio_seek_task(&mut self) -> Option<bool> {
        let VideoAudioSeekTask {
            was_playing,
            receiver,
            handle,
            ..
        } = self.video_audio_seek_task.take()?;
        drop(receiver);
        if let Some(handle) = handle {
            let _ = handle.join();
        }
        Some(was_playing)
    }

    #[cfg(target_os = "windows")]
    fn poll_video_audio_seek_task(&mut self) {
        let Some(mut task) = self.video_audio_seek_task.take() else {
            return;
        };
        let result = match task.receiver.try_recv() {
            Ok(result) => result,
            Err(mpsc::TryRecvError::Empty) => {
                self.video_audio_seek_task = Some(task);
                return;
            }
            Err(mpsc::TryRecvError::Disconnected) => {
                Err("El reposicionamiento del audio terminó de forma inesperada.".into())
            }
        };
        if let Some(handle) = task.handle.take() {
            let _ = handle.join();
        }
        let requested = task.requested;
        let was_playing = task.was_playing;
        match result {
            Ok(player) => {
                self.video_audio_player = Some(player);
                self.video_audio_base = requested;
            }
            Err(error) => {
                self.stop_video_audio();
                self.video_audio_error = Some(error);
            }
        }
        self.finish_video_seek(requested, was_playing);
    }

    #[cfg(target_os = "windows")]
    fn finish_video_seek(&mut self, requested: Duration, was_playing: bool) {
        self.update_video_audio_clock();

        let seek_requested = if let Some(task) = self.video_task.as_ref() {
            task.request_seek(requested).is_ok()
        } else {
            true
        };

        if !seek_requested {
            self.set_error("No se pudo enviar la orden de búsqueda al decodificador de vídeo.");
            return;
        }

        self.video_position = requested;
        self.video_audio_start_pending = was_playing && self.video_audio_player.is_some();
        if was_playing {
            // Keep the audio paused while the worker seeks and rebuilds the
            // one-second video lead. The scheduler is explicitly held while
            // the audio clock is pending, so video cannot run ahead during the seek.
            if let Some(player) = self.video_audio_player.as_ref() {
                player.pause();
            }
            if let Some(task) = self.video_task.as_ref() {
                task.audio_clock_nanos.store(0, Ordering::Release);
                task.audio_clock_active.store(false, Ordering::Release);
                task.audio_clock_pending
                    .store(self.video_audio_start_pending, Ordering::Release);
                task.playing.store(true, Ordering::Release);
            }
        } else if let Some(task) = self.video_task.as_ref() {
            task.audio_clock_pending.store(false, Ordering::Release);
        }
    }

    #[cfg(target_os = "windows")]
    fn poll_video_task(&mut self, ctx: &Context) {
        let Some(mut task) = self.video_task.take() else {
            return;
        };

        let task_playing = task.playing.load(Ordering::Acquire);
        let audio_clock_pending = self.video_audio_start_pending;
        task.audio_clock_pending
            .store(audio_clock_pending, Ordering::Release);
        if task_playing
            && audio_clock_pending
            && self.video_audio_player.as_ref().is_none_or(Player::empty)
        {
            self.video_audio_start_pending = false;
            task.audio_clock_pending.store(false, Ordering::Release);
            if self.video_audio_player.is_some() {
                self.video_audio_error =
                    Some("La pista de audio terminó antes de reanudar el vídeo; se continúa con el reloj local.".into());
            }
        }
        let audio_clock_pending = self.video_audio_start_pending;
        task.audio_clock_pending
            .store(audio_clock_pending, Ordering::Release);
        let (audio_clock_active, audio_clock_position) = if task_playing && !audio_clock_pending {
            match self.video_audio_player.as_ref() {
                Some(player) if !player.empty() => {
                    (true, self.video_audio_base + player.get_pos())
                }
                _ => (false, Duration::ZERO),
            }
        } else {
            (false, Duration::ZERO)
        };
        task.audio_clock_nanos.store(
            audio_clock_position.as_nanos().min(u64::MAX as u128) as u64,
            Ordering::Release,
        );
        task.audio_clock_active
            .store(audio_clock_active, Ordering::Release);
        if audio_clock_active && self.video_seek_override.is_none() {
            self.video_position = audio_clock_position;
        }

        let mut worker_finished = false;
        let mut latest_frame = None::<(Zeroizing<Vec<u8>>, [usize; 2], Duration)>;
        while let Ok(event) = task.receiver.try_recv() {
            match event {
                video_preview::VideoPreviewEvent::Ready {
                    source_path,
                    preview_path,
                    owns_temp,
                    size,
                    duration,
                } if self.selected_file.as_ref() == Some(&source_path)
                    && self.preview_kind == PreviewKind::Video =>
                {
                    self.video_preview_path = Some(preview_path.clone());
                    self.video_preview_owned = owns_temp;
                    self.video_size = Some(size);
                    self.video_duration = duration;
                    self.video_position = Duration::ZERO;
                    self.video_seek_override = None;
                    self.video_finished = false;
                    match self.start_video_audio_from_path(&preview_path) {
                        Ok(()) => {
                            // La reproducción queda detenida al preparar la vista previa.
                            // El worker entrega un primer fotograma estático y el usuario
                            // decide cuándo comenzar con ▶.
                            task.audio_clock_nanos.store(0, Ordering::Release);
                            task.audio_clock_active.store(false, Ordering::Release);
                            task.playing.store(false, Ordering::Release);
                            self.set_ok("Vídeo preparado. Pulsa ▶ para reproducir.".into());
                        }
                        Err(error) => {
                            self.video_audio_error = Some(error);
                            task.playing.store(false, Ordering::Release);
                            self.set_ok(
                                "Vídeo preparado. Pulsa ▶ para reproducir (sin audio compatible)."
                                    .into(),
                            );
                        }
                    }
                }
                video_preview::VideoPreviewEvent::Ready {
                    preview_path,
                    owns_temp,
                    ..
                } => {
                    if owns_temp {
                        self.remove_temp_file_or_defer(preview_path);
                    }
                }
                video_preview::VideoPreviewEvent::Frame {
                    source_path,
                    rgba,
                    size,
                    position,
                    generation,
                } if self.selected_file.as_ref() == Some(&source_path)
                    && self.preview_kind == PreviewKind::Video
                    && generation == task.control_generation.load(Ordering::Acquire) =>
                {
                    // Si llegan varios fotogramas mientras la GUI estaba ocupada,
                    // conserva solo el más reciente. Subir 2–3 texturas 1080p/4K
                    // por tick de egui puede reducir la vista previa a ~1 fps.
                    latest_frame = Some((rgba, size, position));
                }
                video_preview::VideoPreviewEvent::Frame { .. } => {}
                video_preview::VideoPreviewEvent::Ended {
                    source_path,
                    generation,
                } if self.selected_file.as_ref() == Some(&source_path)
                    && self.preview_kind == PreviewKind::Video
                    && generation == task.control_generation.load(Ordering::Acquire) =>
                {
                    self.video_finished = true;
                    if let Some(duration) = self.video_duration {
                        self.video_position = duration;
                    }
                    self.video_seek_override = None;
                    if let Some(player) = self.video_audio_player.as_ref() {
                        player.pause();
                    }
                    self.set_ok("Vídeo finalizado.".into());
                }
                video_preview::VideoPreviewEvent::Ended { .. } => {}
                video_preview::VideoPreviewEvent::Failed {
                    source_path,
                    preview_path,
                    message,
                } if self.selected_file.as_ref() == Some(&source_path)
                    && self.preview_kind == PreviewKind::Video =>
                {
                    if self.video_preview_owned {
                        self.remove_temp_file_or_defer(preview_path.clone());
                    }
                    self.video_preview_path = None;
                    self.video_preview_owned = false;
                    self.stop_video_audio();
                    self.video_error = Some(message);
                    worker_finished = true;
                }
                video_preview::VideoPreviewEvent::Failed { preview_path, .. } => {
                    if self.video_preview_owned {
                        self.remove_temp_file_or_defer(preview_path);
                    }
                    worker_finished = true;
                }
            }
        }

        if !worker_finished && let Some((rgba, size, position)) = latest_frame {
            if self.video_audio_start_pending
                && task.playing.load(Ordering::Acquire)
                && self
                    .video_audio_player
                    .as_ref()
                    .is_some_and(|player| !player.empty())
            {
                if let Some(player) = self.video_audio_player.as_ref() {
                    player.play();
                }
                self.video_audio_start_pending = false;
                task.audio_clock_pending.store(false, Ordering::Release);
                let audio_position = self
                    .video_audio_player
                    .as_ref()
                    .map(|player| self.video_audio_base + player.get_pos())
                    .unwrap_or(Duration::ZERO);
                task.audio_clock_nanos.store(
                    audio_position.as_nanos().min(u64::MAX as u128) as u64,
                    Ordering::Release,
                );
                task.audio_clock_active.store(true, Ordering::Release);
                self.set_ok("Vídeo y audio sincronizados. Reproduciendo…".into());
            }

            let image = egui::ColorImage::from_rgba_unmultiplied(size, &rgba);
            if let Some(texture) = self.video_texture.as_mut() {
                texture.set(image, egui::TextureOptions::LINEAR);
            } else {
                let texture_name = format!("opac-preview-video-{}", Uuid::new_v4());
                self.video_texture =
                    Some(ctx.load_texture(texture_name, image, egui::TextureOptions::LINEAR));
            }
            self.video_size = Some(size);
            if !task.audio_clock_active.load(Ordering::Acquire) {
                self.video_position = position;
            }
            self.video_error = None;
        }

        if worker_finished || task.handle.as_ref().is_some_and(JoinHandle::is_finished) {
            if let Some(handle) = task.handle.take() {
                let _ = handle.join();
            }
            if self.video_preview_owned {
                if let Some(path) = self.video_preview_path.take() {
                    self.remove_temp_file_or_defer(path);
                }
                self.video_preview_owned = false;
            }
            self.stop_video_audio();
            self.video_task = None;
            return;
        }

        self.video_task = Some(task);
    }

    #[cfg(target_os = "windows")]
    fn video_preview_panel(&mut self, ui: &mut egui::Ui) {
        if let Some(error) = self.video_error.as_deref() {
            ui.add_space(12.0);
            ui.label(RichText::new("No se pudo reproducir este vídeo.").strong());
            ui.small(error);
            ui.add_space(8.0);
            if ui
                .button("Abrir con la aplicación predeterminada (copia temporal)")
                .clicked()
            {
                self.open_selected_externally();
            }
            return;
        }

        if let Some([width, height]) = self.video_size {
            let shown_position = self
                .video_seek_override
                .unwrap_or(self.video_position)
                .min(self.video_duration.unwrap_or(Duration::MAX));
            let duration_label = self.video_duration.map(format_video_time);
            let label = match duration_label {
                Some(total) => format!(
                    "{} × {} px · {} / {}",
                    width,
                    height,
                    format_video_time(shown_position),
                    total
                ),
                None => format!(
                    "{} × {} px · {}",
                    width,
                    height,
                    format_video_time(shown_position)
                ),
            };
            ui.label(
                RichText::new(label)
                    .small()
                    .color(Color32::from_rgb(150, 140, 160)),
            );
            ui.add_space(6.0);
        }

        let Some(texture) = self.video_texture.clone() else {
            ui.add_space(12.0);
            ui.spinner();
            ui.label("Preparando vídeo para la vista previa…");
            ui.small(
                "El vídeo se descifra en una copia temporal y se decodifica localmente con Media Foundation.",
            );
            if self.video_task.is_some() && ui.button("Cancelar preparación").clicked() {
                self.stop_video_preview();
                self.video_error = Some("Preparación del vídeo cancelada.".into());
            }
            return;
        };

        let playing = self
            .video_task
            .as_ref()
            .is_some_and(|task| task.playing.load(Ordering::Relaxed));
        let mut toggle_play = None::<bool>;
        let mut restart = false;
        ui.horizontal(|ui| {
            let play_label = if playing { "⏸" } else { "▶" };
            if ui.button(RichText::new(play_label).size(18.0)).clicked() {
                toggle_play = Some(!playing);
            }
            if ui.button("↻").clicked() {
                restart = true;
            }
            if self.video_finished {
                ui.small("Finalizado");
            }
        });

        if restart || (self.video_finished && toggle_play == Some(true)) {
            self.restart_video_playback();
            self.set_ok("Reiniciando vídeo…".into());
        } else if let Some(should_play) = toggle_play {
            self.set_video_playback(should_play);
            if should_play {
                self.set_ok("Reproduciendo vídeo y audio…".into());
            } else {
                self.set_ok("Vídeo y audio en pausa.".into());
            }
        }

        if let Some(error) = self.video_audio_error.as_deref() {
            ui.small(format!("Audio: {error}"));
        } else if self
            .video_task
            .as_ref()
            .is_some_and(|task| task.audio_clock_active.load(Ordering::Acquire))
        {
            ui.small("Audio integrado · el audio es el reloj maestro y el vídeo se corrige automáticamente para evitar deriva.");
        } else if self.video_audio_start_pending {
            ui.small("Audio integrado preparado; pulsa ▶ para comenzar.");
        } else if self
            .video_task
            .as_ref()
            .is_some_and(|task| !task.playing.load(Ordering::Acquire))
            && self.video_audio_player.is_some()
        {
            ui.small("Audio integrado en pausa; pulsa ▶ para continuar.");
        } else if self.video_audio_player.is_some() {
            ui.small("Audio integrado detenido; el vídeo continúa con su reloj local.");
        }

        let mut volume = self.audio_volume;
        if ui
            .add(egui::Slider::new(&mut volume, 0.0..=1.0).text("Volumen"))
            .changed()
        {
            self.audio_volume = volume;
            if let Some(player) = self.video_audio_player.as_ref() {
                player.set_volume(volume);
            }
        }

        if let Some(duration) = self
            .video_duration
            .filter(|duration| *duration > Duration::ZERO)
        {
            let max_secs = duration.as_secs_f64().max(0.001);
            let base_position = self
                .video_seek_override
                .unwrap_or(self.video_position)
                .min(duration);
            let mut seek_secs = base_position.as_secs_f64().clamp(0.0, max_secs);
            let response = ui.add(
                egui::Slider::new(&mut seek_secs, 0.0..=max_secs)
                    .show_value(false)
                    .text("Posición"),
            );
            if response.dragged() {
                self.video_seek_override = Some(Duration::from_secs_f64(seek_secs));
            }
            if response.drag_stopped() {
                let requested = Duration::from_secs_f64(seek_secs).min(duration);
                let was_playing = playing;
                self.video_position = requested;
                self.video_seek_override = None;
                self.video_finished = false;
                self.seek_video_playback(requested, was_playing);
            }
        }

        ui.add_space(8.0);
        ui.separator();
        ui.add_space(6.0);
        if ui
            .button("Abrir en el reproductor predeterminado")
            .clicked()
        {
            self.open_selected_externally();
        }
        ui.small(
            "Se abrirá una copia temporal descifrada dentro del área privada de la sesión; el archivo cifrado de la Caja no se expone.",
        );
        ui.add_space(6.0);

        egui::ScrollArea::both()
            .auto_shrink([false, false])
            .show(ui, |ui| {
                ui.add(
                    egui::Image::from_texture(&texture)
                        .shrink_to_fit()
                        .alt_text("Vista previa de vídeo"),
                );
            });
    }

    #[cfg(target_os = "windows")]
    fn poll_cancelled_video_cleanup_tasks(&mut self) {
        let tasks = std::mem::take(&mut self.cancelled_video_cleanup);
        let mut remaining = Vec::with_capacity(tasks.len());
        for task in tasks {
            if task.handle.is_finished() {
                let CancelledVideoCleanupTask {
                    preview_path,
                    handle,
                } = task;
                let _ = handle.join();
                if let Some(path) = preview_path {
                    self.remove_temp_file_or_defer(path);
                }
            } else {
                remaining.push(task);
            }
        }
        self.cancelled_video_cleanup = remaining;
    }

    #[cfg(target_os = "windows")]
    fn join_cancelled_video_cleanup_tasks(&mut self) {
        let tasks = std::mem::take(&mut self.cancelled_video_cleanup);
        for task in tasks {
            let CancelledVideoCleanupTask {
                preview_path,
                handle,
            } = task;
            let _ = handle.join();
            if let Some(path) = preview_path {
                self.remove_temp_file_or_defer(path);
            }
        }
    }

    #[cfg(target_os = "windows")]
    fn stop_video_preview_and_join(&mut self) {
        self.stop_video_audio();
        if let Some(mut task) = self.video_task.take() {
            task.cancel.store(true, Ordering::Relaxed);
            let receiver = task.receiver;
            drop(receiver);
            if let Some(handle) = task.handle.take() {
                let _ = handle.join();
            }
        }
        self.join_cancelled_video_cleanup_tasks();
        if self.video_preview_owned {
            if let Some(path) = self.video_preview_path.take() {
                self.remove_temp_file_or_defer(path);
            }
            self.video_preview_owned = false;
        } else {
            self.video_preview_path = None;
        }
        self.video_texture = None;
        self.video_size = None;
        self.video_position = Duration::ZERO;
        self.video_duration = None;
        self.video_seek_override = None;
        self.video_finished = false;
        self.video_error = None;
    }

    #[cfg(target_os = "windows")]
    fn stop_video_preview(&mut self) {
        self.stop_video_audio();
        if let Some(mut task) = self.video_task.take() {
            task.cancel.store(true, Ordering::Release);
            let receiver = task.receiver;
            drop(receiver);
            if let Some(handle) = task.handle.take() {
                let owns_temp = self.video_preview_owned;
                let preview_path = self.video_preview_path.clone();
                if handle.is_finished() {
                    let _ = handle.join();
                    if owns_temp && let Some(path) = preview_path {
                        self.remove_temp_file_or_defer(path);
                    }
                } else {
                    // No podemos bloquear la GUI mientras termina una preparación cancelada.
                    // Conservamos el JoinHandle; si OPAC era dueño del temporal, también
                    // conservamos su ruta para eliminarlo solo después de que el worker termine.
                    self.cancelled_video_cleanup
                        .push(CancelledVideoCleanupTask {
                            preview_path: if owns_temp { preview_path } else { None },
                            handle,
                        });
                }
            }
        }
        self.video_preview_path = None;
        self.video_preview_owned = false;
        self.video_texture = None;
        self.video_size = None;
        self.video_position = Duration::ZERO;
        self.video_duration = None;
        self.video_seek_override = None;
        self.video_finished = false;
        self.video_error = None;
    }

    fn prepare_audio_preview(&mut self, source_path: PathBuf) {
        if let Some(cached) = self.preloaded_files.get(&source_path).cloned() {
            self.audio_preview_path = Some(cached.clone());
            self.audio_preview_owned = false;
            if let Err(error) = self.start_audio_player_from_path(&cached) {
                self.audio_preview_path = None;
                self.audio_error = Some(error);
            } else {
                self.set_ok("Audio preparado. Pulsa reproducir para escucharlo.".into());
            }
            return;
        }

        let Some(entry) = self
            .files
            .iter()
            .find(|entry| entry.disk_path == source_path)
        else {
            return;
        };
        if entry.metadata.original_size > AUDIO_PREVIEW_MAX_BYTES {
            self.audio_error =
                Some("El archivo de audio supera el límite de vista previa de 1 GiB.".into());
            return;
        }

        if self.vault.is_none() {
            self.audio_error = Some("La Caja Fuerte no está desbloqueada.".into());
            return;
        }

        if self.audio_task.is_some() {
            return;
        }

        let key = match self.vault.as_ref() {
            Some(vault) => Zeroizing::new(*vault.key_bytes()),
            None => {
                self.audio_error = Some("La Caja Fuerte no está desbloqueada.".into());
                return;
            }
        };
        let extension = safe_temp_extension(&entry.metadata.original_name, "audio");
        let temp_root = match self.ensure_session_temp_dir() {
            Ok(path) => path,
            Err(error) => {
                self.audio_error =
                    Some(format!("No se pudo crear el area temporal segura: {error}"));
                return;
            }
        };
        let preview_path =
            temp_root.join(format!("audio-{}.{}", Uuid::new_v4().simple(), extension));
        let cancel = std::sync::Arc::new(AtomicBool::new(false));
        let cancel_worker = cancel.clone();
        let source_for_worker = source_path.clone();
        let preview_for_worker = preview_path.clone();
        let (sender, receiver) = mpsc::channel();

        let handle = match thread::Builder::new()
            .name("opac-audio-preview".to_owned())
            .spawn(move || {
                let result = opac_window_core::modules::vault_fs::decrypt_file_from_vault(
                    &source_for_worker,
                    &key,
                    &preview_for_worker,
                );

                if cancel_worker.load(Ordering::Relaxed) {
                    // The GUI thread owns deferred cleanup and will retry after the
                    // worker is joined. Keeping the path in AudioPreviewTask also
                    // covers the cancelled-before-event case.
                    return;
                }

                match result {
                    Ok(_) => {
                        let _ = sender.send(AudioPreviewEvent::Ready {
                            source_path: source_for_worker,
                            preview_path: preview_for_worker,
                            owns_temp: true,
                        });
                    }
                    Err(error) => {
                        let _ = sender.send(AudioPreviewEvent::Failed {
                            source_path: source_for_worker,
                            preview_path: preview_for_worker,
                            message: error.to_string(),
                        });
                    }
                }
            }) {
            Ok(handle) => handle,
            Err(error) => {
                self.audio_error = Some(format!(
                    "No se pudo iniciar la preparación del audio: {error}"
                ));
                return;
            }
        };

        self.audio_task = Some(AudioPreviewTask {
            cancel,
            receiver,
            preview_path,
            handle: Some(handle),
        });
        self.set_ok("Preparando audio…".into());
    }

    fn poll_audio_task(&mut self) {
        let Some(mut task) = self.audio_task.take() else {
            return;
        };

        let mut event = None;
        while let Ok(next) = task.receiver.try_recv() {
            event = Some(next);
        }

        if let Some(event) = event {
            if let Some(handle) = task.handle.take() {
                let _ = handle.join();
            }
            match event {
                AudioPreviewEvent::Ready {
                    source_path,
                    preview_path,
                    owns_temp,
                } if self.selected_file.as_ref() == Some(&source_path)
                    && self.preview_kind == PreviewKind::Audio =>
                {
                    self.audio_preview_path = Some(preview_path.clone());
                    self.audio_preview_owned = owns_temp;
                    if let Err(error) = self.start_audio_player_from_path(&preview_path) {
                        if owns_temp {
                            self.remove_temp_file_or_defer(preview_path.clone());
                        }
                        self.audio_preview_path = None;
                        self.audio_preview_owned = false;
                        self.audio_error = Some(error);
                    } else {
                        self.set_ok("Audio preparado. Pulsa reproducir para escucharlo.".into());
                    }
                }
                AudioPreviewEvent::Ready {
                    preview_path,
                    owns_temp,
                    ..
                } => {
                    if owns_temp {
                        self.remove_temp_file_or_defer(preview_path);
                    }
                }
                AudioPreviewEvent::Failed {
                    source_path,
                    preview_path,
                    message,
                } if self.selected_file.as_ref() == Some(&source_path)
                    && self.preview_kind == PreviewKind::Audio =>
                {
                    self.remove_temp_file_or_defer(preview_path);
                    self.audio_error = Some(message);
                }
                AudioPreviewEvent::Failed { preview_path, .. } => {
                    self.remove_temp_file_or_defer(preview_path);
                }
            }
            return;
        }

        if task.handle.as_ref().is_some_and(JoinHandle::is_finished) {
            if let Some(handle) = task.handle.take() {
                let _ = handle.join();
            }
            // The worker may finish without publishing an event (notably when
            // cancellation wins the race). Its temporary path still belongs
            // to this task and must be cleaned up now that the worker is joined.
            self.remove_temp_file_or_defer(task.preview_path);
            return;
        }

        self.audio_task = Some(task);
    }

    fn start_audio_player_from_path(&mut self, path: &Path) -> Result<(), String> {
        self.audio_error = None;
        let file =
            fs::File::open(path).map_err(|error| format!("No se pudo abrir el audio: {error}"))?;
        let decoder = Decoder::try_from(file)
            .map_err(|error| format!("Formato de audio no compatible: {error}"))?;
        let duration = decoder.total_duration();

        if self.audio_output.is_none() {
            let output = DeviceSinkBuilder::open_default_sink()
                .map_err(|error| format!("No se pudo abrir el dispositivo de audio: {error}"))?;
            self.audio_output = Some(output);
        }

        self.audio_player = None;
        let output = self
            .audio_output
            .as_ref()
            .ok_or_else(|| "No hay salida de audio disponible.".to_string())?;
        let player = Player::connect_new(output.mixer());
        player.append(decoder);
        player.set_volume(self.audio_volume);
        player.pause();
        self.audio_duration = duration;
        self.audio_player = Some(player);
        Ok(())
    }

    fn stop_audio_preview(&mut self) {
        if let Some(mut task) = self.audio_task.take() {
            task.cancel.store(true, Ordering::Relaxed);
            if let Some(handle) = task.handle.take() {
                let _ = handle.join();
            }
            self.remove_temp_file_or_defer(task.preview_path);
        }
        self.audio_player = None;
        self.audio_output = None;
        self.audio_duration = None;
        if self.audio_preview_owned {
            if let Some(path) = self.audio_preview_path.take() {
                self.remove_temp_file_or_defer(path);
            }
        } else {
            self.audio_preview_path = None;
        }
        self.audio_preview_owned = false;
        self.audio_error = None;
    }

    fn export_file(&mut self, source_path: &Path) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error("Espera a que termine la operacion actual antes de exportar.");
            return;
        }

        let Some(original_name) = self
            .files
            .iter()
            .find(|entry| entry.disk_path == source_path)
            .map(|entry| entry.metadata.original_name.clone())
        else {
            self.set_error("No se encontro el archivo seleccionado en la Caja Fuerte.");
            return;
        };
        if self.selected_file.as_deref() == Some(source_path) && !self.save_pending_edit() {
            return;
        }

        let Some(destination) = FileDialog::new()
            .set_title("Exportar archivo")
            .set_file_name(original_name.as_str())
            .save_file()
        else {
            return;
        };

        if destination.as_path() == source_path {
            self.set_error(
                "El destino de exportacion no puede ser el archivo cifrado de la Caja Fuerte.",
            );
            return;
        }

        let Some(vault) = self.vault.as_ref() else {
            self.set_error("La Caja Fuerte no esta desbloqueada.");
            return;
        };

        match vault.decrypt_file(source_path, &destination) {
            Ok(metadata) => {
                self.set_ok(format!(
                    "Exportado: {} ({}) — la copia cifrada permanece en la Caja Fuerte.",
                    destination.display(),
                    format_bytes(metadata.original_size)
                ));
            }
            Err(error) => {
                self.set_error(format!(
                    "No se pudo exportar el archivo: {}",
                    format_error(&error)
                ));
            }
        }
    }

    fn request_delete_file(&mut self, source_path: &Path) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "Espera a que termine la operacion actual antes de eliminar un archivo.",
            );
            return;
        }

        let Some(entry) = self
            .files
            .iter()
            .find(|entry| entry.disk_path == source_path)
        else {
            self.set_error("No se encontro el archivo seleccionado en la Caja Fuerte.");
            return;
        };

        self.pending_delete_file = Some(entry.disk_path.clone());
        self.show_delete_confirm = true;
    }

    fn delete_confirm_dialog(&mut self, ctx: &Context) {
        let Some(source_path) = self.pending_delete_file.clone() else {
            self.show_delete_confirm = false;
            return;
        };
        let name = self
            .files
            .iter()
            .find(|entry| entry.disk_path == source_path)
            .map(|entry| entry.metadata.original_name.clone())
            .unwrap_or_else(|| source_path.display().to_string());

        let mut close = false;
        let mut confirm = false;
        egui::Window::new("Eliminar archivo")
            .collapsible(false)
            .resizable(false)
            .anchor(Align2::CENTER_CENTER, [0.0, 0.0])
            .show(ctx, |ui| {
                ui.label("Esta accion eliminara el archivo cifrado de la Caja Fuerte.");
                ui.add_space(6.0);
                ui.label(RichText::new(name.as_str()).strong());
                ui.add_space(8.0);
                ui.label("Esta accion no exporta ni descifra el archivo.");
                ui.add_space(14.0);
                ui.horizontal(|ui| {
                    if ui.button("Cancelar").clicked() {
                        close = true;
                    }
                    if ui.button("Eliminar").clicked() {
                        confirm = true;
                        close = true;
                    }
                });
            });

        if confirm {
            self.delete_file(&source_path);
        }
        if close {
            self.show_delete_confirm = false;
            self.pending_delete_file = None;
        }
    }

    fn delete_file(&mut self, source_path: &Path) {
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error(
                "Espera a que termine la operacion actual antes de eliminar un archivo.",
            );
            return;
        }

        self.stop_audio_preview();
        let was_released = match self.guard_release_path(source_path) {
            Ok(value) => value,
            Err(error) => {
                self.set_error(format!(
                    "OPAC Guard no autorizó el borrado del archivo: {error}"
                ));
                return;
            }
        };
        // El borrado del .opac es la operacion principal y debe completarse
        // independientemente de que exista una copia descifrada en PreloadAll.
        // La copia temporal se limpia despues y, si Windows la mantiene abierta,
        // remove_temp_file_or_defer() la deja en cola para reintentos automaticos.
        let result = match self.vault.as_ref() {
            Some(vault) => vault.delete_file(source_path),
            None => {
                let _ = self.guard_reprotect(source_path, was_released);
                self.set_error("La Caja Fuerte no esta desbloqueada.");
                return;
            }
        };
        let reprotect_result = self.guard_reprotect(source_path, was_released);

        match result {
            Ok(()) => {
                // Nunca se debe hacer depender el borrado del ciphertext de la
                // eliminacion inmediata del preload descifrado.
                if let Some(cached) = self.preloaded_files.remove(source_path) {
                    self.remove_temp_file_or_defer(cached);
                }
                if self.selected_file.as_deref() == Some(source_path) {
                    self.selected_file = None;
                    self.clear_preview_state();
                    self.editing_text = false;
                    self.edit_original_text = None;
                    self.markdown_cache = CommonMarkCache::default();
                }
                self.refresh_files();

                if let Err(error) = reprotect_result {
                    self.set_error(format!(
                        "Archivo eliminado de la Caja Fuerte, pero OPAC Guard no pudo confirmar la reproteccion: {error}"
                    ));
                } else {
                    self.set_ok("Archivo eliminado de la Caja Fuerte.".into());
                }
            }
            Err(error) => {
                if let Err(reprotect_error) = reprotect_result {
                    self.set_error(format!(
                        "No se pudo eliminar el archivo: {}. Ademas, OPAC Guard no pudo confirmar la reproteccion: {reprotect_error}",
                        format_error(&error)
                    ));
                } else {
                    self.set_error(format!(
                        "No se pudo eliminar el archivo: {}",
                        format_error(&error)
                    ));
                }
            }
        }
    }

    fn open_selected_externally(&mut self) {
        if self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.external_open_task.is_some()
        {
            self.set_error("Espera a que termine la preparacion actual.");
            return;
        }
        let Some(path) = self.selected_file.clone() else {
            return;
        };
        let Some(original_name) = self
            .files
            .iter()
            .find(|entry| entry.disk_path == path)
            .map(|entry| entry.metadata.original_name.clone())
        else {
            return;
        };
        if !self.save_pending_edit() {
            return;
        }

        let ext = safe_temp_extension(&original_name, "tmp");
        let temp_root = match self.ensure_session_temp_dir() {
            Ok(path) => path,
            Err(error) => {
                self.set_error(format!("No se pudo crear el area temporal segura: {error}"));
                return;
            }
        };
        let temp = temp_root.join(format!("open-{}.{}", Uuid::new_v4().simple(), ext));
        let Some(vault) = self.vault.as_ref() else {
            return;
        };
        if let Err(error) = vault.check_vault_file(&path) {
            self.set_error(format_error(&error));
            return;
        }
        let key = Zeroizing::new(*vault.key_bytes());
        let cached = self.preloaded_files.get(&path).cloned();
        let worker_temp = temp.clone();
        let (sender, receiver) = mpsc::channel();
        let spawn = thread::Builder::new()
            .name("opac-open-external".into())
            .spawn(move || {
                let result = match cached {
                    Some(cached) => copy_file_securely(&cached, &worker_temp)
                        .map_err(|error| format!("No se pudo copiar el archivo: {error}")),
                    None => opac_window_core::modules::vault_fs::decrypt_file_from_vault(
                        &path,
                        &key,
                        &worker_temp,
                    )
                    .map(|_| ())
                    .map_err(|error| error.to_string()),
                };
                let _ = sender.send(result);
            });
        match spawn {
            Ok(handle) => {
                self.external_open_task = Some(ExternalOpenTask {
                    temp,
                    receiver,
                    handle: Some(handle),
                });
                self.set_ok("Preparando copia temporal…".into());
            }
            Err(error) => {
                self.set_error(format!("No se pudo iniciar la preparación: {error}"));
            }
        }
    }

    /// Recoge el resultado del descifrado en segundo plano y lanza la app
    /// predeterminada desde el hilo de la GUI (donde COM/OLE ya está
    /// inicializado por winit), de modo que ShellExecuteW se comporta igual
    /// que antes.
    fn poll_external_open_task(&mut self) {
        let Some(mut task) = self.external_open_task.take() else {
            return;
        };
        let result = match task.receiver.try_recv() {
            Ok(result) => result,
            Err(mpsc::TryRecvError::Empty) => {
                self.external_open_task = Some(task);
                return;
            }
            Err(mpsc::TryRecvError::Disconnected) => {
                Err("La preparación de la copia temporal terminó de forma inesperada.".into())
            }
        };
        if let Some(handle) = task.handle.take() {
            let _ = handle.join();
        }
        let temp = task.temp;
        match result {
            Ok(()) => match open_with_default_app(&temp) {
                Ok(()) => {
                    self.temp_exports.push(temp);
                    self.set_ok("Archivo abierto desde una copia temporal descifrada.".into());
                }
                Err(error) => {
                    self.remove_temp_file_or_defer(temp);
                    self.set_error(format!("No se pudo abrir el archivo: {error}"));
                }
            },
            Err(message) => {
                self.remove_temp_file_or_defer(temp);
                self.set_error(message);
            }
        }
    }

    /// Espera al hilo pendiente y borra su copia temporal (bloqueo/cambio de usuario).
    fn cancel_external_open_task(&mut self) {
        if let Some(mut task) = self.external_open_task.take() {
            if let Some(handle) = task.handle.take() {
                let _ = handle.join();
            }
            self.remove_temp_file_or_defer(task.temp);
        }
    }

    fn lock_all_due_to_idle(&mut self) {
        let saved_pending_edit = self.save_pending_edit();
        let pending_profile = self.active_profile_id;
        self.auto_lock_pending = false;
        self.clear_active_runtime();
        self.last_activity = Instant::now();
        self.pending_profile_id = pending_profile;
        self.unlock_password_focus_pending = pending_profile.is_some();
        self.screen = if pending_profile.is_some() {
            Screen::Unlock
        } else {
            Screen::ProfileSelect
        };
        let message = if saved_pending_edit {
            "Sesión bloqueada automáticamente por inactividad."
        } else {
            "Sesión bloqueada automáticamente por inactividad; los cambios no guardados se descartaron por seguridad."
        };
        self.set_ok(message.into());
    }

    fn lock_all(&mut self) {
        if self.guard_operation.is_some() {
            self.set_error(
                "Espera a que termine la operación de OPAC Guard antes de bloquear la aplicación.",
            );
            return;
        }
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error("Espera a que termine la operacion antes de bloquear la aplicacion.");
            return;
        }
        let pending_profile = self.active_profile_id;
        if !self.save_pending_edit() {
            return;
        }
        self.clear_active_runtime();
        self.last_activity = Instant::now();
        self.auto_lock_pending = false;
        self.pending_profile_id = pending_profile;
        self.unlock_password_focus_pending = pending_profile.is_some();
        self.screen = if pending_profile.is_some() {
            Screen::Unlock
        } else {
            Screen::ProfileSelect
        };
        self.set_ok("Sesión bloqueada.".into());
    }

    fn switch_user(&mut self) {
        if self.guard_operation.is_some() {
            self.set_error(
                "Espera a que termine la operación de OPAC Guard antes de cambiar de usuario.",
            );
            return;
        }
        if self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
        {
            self.set_error("Espera a que termine la operación actual antes de cambiar de usuario.");
            return;
        }
        if !self.save_pending_edit() {
            return;
        }
        self.clear_active_runtime();
        self.last_activity = Instant::now();
        self.auto_lock_pending = false;
        self.pending_profile_id = None;
        self.unlock_password_focus_pending = false;
        self.screen = Screen::ProfileSelect;
        self.set_ok("Sesión cerrada. Selecciona un usuario para continuar.".into());
    }

    fn clear_active_runtime(&mut self) {
        self.show_settings = false;
        self.show_guard_disable_prompt = false;
        self.guard_disable_password.clear();
        self.clear_secret_clipboard_if_owned();
        self.cancel_external_open_task();
        self.clear_temp_exports();
        self.stop_audio_preview();
        #[cfg(target_os = "windows")]
        {
            self.stop_video_preview();
            self.join_cancelled_video_cleanup_tasks();
        }
        self.clear_preload_cache();
        self.clear_session_temp_dir();
        self.vault = None;
        self.vault_pin_authenticated = false;
        self.session = None;
        self.selected_vault_id = None;
        self.selected_file = None;
        self.files.clear();
        self.folders.clear();
        self.current_folder = None;
        self.folder_drop_rects.clear();
        self.drop_target_folder = None;
        self.clear_preview_state();
        self.editing_text = false;
        self.edit_original_text = None;
        self.show_vault_key = false;
        self.show_new_vault = false;
        self.new_vault_name.clear();
        self.new_vault_parent = None;
        self.new_vault_use_imported_key = false;
        self.new_vault_imported_key.clear();
        self.show_new_folder = false;
        self.new_folder_name.clear();
        self.new_folder_parent = None;
        self.show_new_text_file = false;
        self.new_text_file_name.clear();
        self.new_text_file_parent = None;
        self.show_key_unlock = false;
        self.key_unlock_value.clear();
        self.pending_key_vault = None;
        self.show_external_key_import = false;
        self.external_key_value.clear();
        self.external_vault_name.clear();
        self.external_vault_path = None;
        self.show_pin_prompt = false;
        self.pending_pin_vault = None;
        self.pin_value.clear();
        self.pin_backoff.clear();
        self.clear_secret_clipboard_if_owned();
        self.show_add_pin = false;
        self.pending_pin_add_vault = None;
        self.new_pin_value.clear();
        self.new_pin_confirm.clear();
        self.show_delete_confirm = false;
        self.pending_delete_file = None;
        self.show_delete_vault_confirm = false;
        self.pending_delete_vault = None;
        self.show_folder_delete_confirm = false;
        self.pending_delete_folder = None;
        self.show_folder_export_confirm = false;
        self.pending_export_folder = None;
        self.show_rename = false;
        self.pending_rename_path = None;
        self.rename_name.clear();
        self.active_profile_id = None;
        self.active_profile_name = None;
        self.master_password.clear();
        // Tell the Guard to re-arm only after the authenticated runtime state
        // has been released, so its handles do not race with OPAC's own closes.
        self.guard_rearm_all();
        self.shutdown_guard_client();
        self.guard_service_status = guard::GuardServiceStatus::Missing;
    }

    fn access_mode_selector(&mut self, ui: &mut egui::Ui) {
        let Some(current_mode) = self.vault.as_ref().map(|vault| vault.info().access_mode) else {
            return;
        };
        let mut mode = current_mode;
        let enabled = self.import_task.is_none()
            && self.preload_task.is_none()
            && self.audio_task.is_none()
            && !self.video_preview_busy();
        ui.horizontal(|ui| {
            ui.label(RichText::new("Acceso:").small().color(Color32::from_rgb(150, 140, 160)));
            ui.add_enabled_ui(enabled, |ui| {
                egui::ComboBox::from_id_salt("vault-access-mode")
                    .selected_text(match mode {
                        VaultAccessMode::OnDemand => "Descifrar al usar",
                        VaultAccessMode::PreloadAll => "Descifrar al abrir",
                    })
                    .show_ui(ui, |ui| {
                        ui.selectable_value(
                            &mut mode,
                            VaultAccessMode::OnDemand,
                            "Descifrar al usar",
                        )
                        .on_hover_text("Solo se crea una copia temporal cuando utilizas un archivo.");
                        ui.selectable_value(
                            &mut mode,
                            VaultAccessMode::PreloadAll,
                            "Descifrar al abrir",
                        )
                        .on_hover_text("Prepara los archivos compatibles en una carpeta temporal; las imágenes y PDF se descifran solo al previsualizarlos en memoria.");
                    });
            });
        });
        if mode != current_mode {
            self.stop_audio_preview();
            self.change_access_mode(mode);
        }
    }

    fn change_access_mode(&mut self, mode: VaultAccessMode) {
        if !self.save_pending_edit() {
            return;
        }
        let Some(id) = self.selected_vault_id else {
            return;
        };
        let keystore_path = self
            .session
            .as_ref()
            .map(|session| session.storage_path().to_path_buf());
        let was_keystore_released = match keystore_path.as_deref() {
            Some(path) => match self.guard_release_path(path) {
                Ok(value) => value,
                Err(error) => {
                    self.set_error(format!(
                        "OPAC Guard no autorizó el cambio del modo de acceso: {error}"
                    ));
                    return;
                }
            },
            None => false,
        };
        let result = self
            .session
            .as_mut()
            .ok_or(SessionError::Vault(VaultError::NotFound))
            .and_then(|session| session.set_vault_access_mode(id, mode));
        let keystore_reprotect = keystore_path
            .as_deref()
            .map(|path| self.guard_reprotect(path, was_keystore_released))
            .unwrap_or(Ok(()));
        if let Err(error) = result {
            if let Err(reprotect_error) = keystore_reprotect.as_ref() {
                self.set_error(format!("{} Además, OPAC Guard no pudo confirmar la reprotección del Key Store: {reprotect_error}", format_error(&error)));
            } else {
                self.set_error(format_error(&error));
            }
            return;
        }
        if let Some(vault) = self.vault.as_mut() {
            vault.set_access_mode(mode);
        }
        match mode {
            VaultAccessMode::OnDemand => {
                self.clear_preload_cache();
                if let Err(reprotect_error) = keystore_reprotect.as_ref() {
                    self.set_error(format!("Modo cambiado a demanda, pero OPAC Guard no pudo reproteger el Key Store: {reprotect_error}"));
                } else {
                    self.set_ok("Modo cambiado: los archivos se descifran al usarlos.".into());
                }
            }
            VaultAccessMode::PreloadAll => {
                if let Err(reprotect_error) = keystore_reprotect.as_ref() {
                    self.set_error(format!("Modo cambiado a precarga, pero OPAC Guard no pudo reproteger el Key Store: {reprotect_error}"));
                } else {
                    self.set_ok("Modo cambiado: preparando todos los archivos…".into());
                }
                self.start_preload_all();
            }
        }
    }

    fn start_preload_all(&mut self) {
        if self.preload_task.is_some() {
            return;
        }
        let vault_key = {
            let Some(vault) = self.vault.as_ref() else {
                return;
            };
            Zeroizing::new(*vault.key_bytes())
        };
        // Nunca materializamos imágenes ni PDF en plaintext sobre disco.
        // Sus vistas integradas se descifran directamente a memoria mediante
        // `read_small_file`. El resto conserva el comportamiento de
        // `PreloadAll`, que usa temporales cuando hace falta un archivo real.
        let files = self
            .files
            .iter()
            .filter(|entry| !uses_memory_only_preview(&entry.metadata.original_name))
            .map(|entry| {
                let ext = safe_temp_extension(&entry.metadata.original_name, "");
                (entry.disk_path.clone(), ext)
            })
            .collect::<Vec<_>>();
        if files.is_empty() {
            self.clear_preload_cache();
            self.set_ok(
                "Caja Fuerte abierta. Las imágenes y PDF se previsualizan solo en memoria.".into(),
            );
            return;
        }
        self.clear_preload_cache();
        let cache_dir = match self.create_preload_cache_dir() {
            Ok(path) => path,
            Err(error) => {
                self.set_error(format!(
                    "No se pudo crear el area temporal de descifrado: {}",
                    error
                ));
                return;
            }
        };
        let cache_dir_for_worker = cache_dir.clone();
        let total = files.len();
        let (sender, receiver) = mpsc::channel();
        let handle = match thread::Builder::new()
            .name("opac-preload".to_owned())
            .spawn(move || {
                for (source, extension) in files {
                    let display_name = source
                        .file_name()
                        .map(|name| name.to_string_lossy().to_string())
                        .unwrap_or_else(|| source.display().to_string());
                    let _ = sender.send(PreloadEvent::Started { name: display_name });
                    let destination = if extension.is_empty() {
                        cache_dir_for_worker.join(Uuid::new_v4().simple().to_string())
                    } else {
                        cache_dir_for_worker.join(format!(
                            "{}.{}",
                            Uuid::new_v4().simple(),
                            extension
                        ))
                    };
                    let result = opac_window_core::modules::vault_fs::decrypt_file_from_vault(
                        &source,
                        &vault_key,
                        &destination,
                    )
                    .map(|_| ())
                    .map_err(|error| error.to_string());
                    // The GUI performs the final cleanup/defer step when it
                    // receives Finished, so a transient Windows file-lock is
                    // not silently forgotten.
                    let _ = sender.send(PreloadEvent::Finished {
                        source_path: source,
                        cache_path: destination,
                        result,
                    });
                }
            }) {
            Ok(handle) => handle,
            Err(error) => {
                let _ = fs::remove_dir_all(&cache_dir);
                self.set_error(format!("No se pudo iniciar la preparacion: {}", error));
                return;
            }
        };
        self.preload_cache_dir = Some(cache_dir.clone());
        self.preloaded_files.clear();
        self.preload_task = Some(PreloadTask {
            total,
            completed: 0,
            current: None,
            cache_dir,
            receiver,
            handle: Some(handle),
        });
    }

    fn poll_preload_task(&mut self) {
        let mut task = match self.preload_task.take() {
            Some(task) => task,
            None => return,
        };
        let mut errors = 0usize;
        while let Ok(event) = task.receiver.try_recv() {
            match event {
                PreloadEvent::Started { name } => task.current = Some(name),
                PreloadEvent::Finished {
                    source_path,
                    cache_path,
                    result,
                } => {
                    task.completed += 1;
                    task.current = None;
                    if result.is_ok() {
                        self.preloaded_files.insert(source_path, cache_path);
                    } else {
                        self.remove_temp_file_or_defer(cache_path);
                        errors += 1;
                    }
                }
            }
        }
        if task.completed < task.total {
            if let Some(current) = &task.current {
                self.status = Some(format!(
                    "Preparando {} de {}: {}",
                    task.completed + 1,
                    task.total,
                    current
                ));
                self.status_error = false;
            }
            self.preload_task = Some(task);
            return;
        }
        if let Some(handle) = task.handle.take() {
            let _ = handle.join();
        }
        if errors == 0 {
            self.set_ok(format!(
                "{} archivos preparados para acceso directo; imágenes y PDF permanecen solo en memoria al previsualizarlos.",
                task.total
            ));
        } else {
            self.set_error(format!("No se pudieron preparar {} archivos.", errors));
        }
    }

    fn ensure_session_temp_dir(&mut self) -> io::Result<PathBuf> {
        if let Some(path) = self.session_temp_dir.clone() {
            match fs::symlink_metadata(&path) {
                Ok(metadata) if metadata.is_dir() && !is_reparse_or_symlink_gui(&metadata) => {
                    return Ok(path);
                }
                Ok(_) => {
                    self.session_temp_dir = None;
                }
                Err(error) if error.kind() == io::ErrorKind::NotFound => {
                    self.session_temp_dir = None;
                }
                Err(error) => return Err(error),
            }
        }

        let base_root =
            opac_window_core::modules::vault_fs::default_vaults_root().ok_or_else(|| {
                io::Error::new(
                    io::ErrorKind::NotFound,
                    "no se pudo determinar el almacenamiento local",
                )
            })?;
        fs::create_dir_all(&base_root)?;
        ensure_private_directory_gui(&base_root)?;
        let root = base_root.join("session-temp");
        fs::create_dir_all(&root)?;
        ensure_private_directory_gui(&root)?;
        let _ = cleanup_orphaned_session_temp_dirs();

        for _ in 0..32 {
            let candidate = root.join(format!(
                "{}{}",
                SESSION_TEMP_DIR_PREFIX,
                Uuid::new_v4().simple()
            ));
            match fs::create_dir(&candidate) {
                Ok(()) => {
                    ensure_private_directory_gui(&candidate)?;
                    write_session_marker(&candidate)?;
                    self.session_temp_dir = Some(candidate.clone());
                    return Ok(candidate);
                }
                Err(error) if error.kind() == io::ErrorKind::AlreadyExists => continue,
                Err(error) => return Err(error),
            }
        }

        Err(io::Error::new(
            io::ErrorKind::AlreadyExists,
            "no se pudo reservar una carpeta temporal de sesion unica",
        ))
    }

    fn create_preload_cache_dir(&mut self) -> io::Result<PathBuf> {
        let session_dir = self.ensure_session_temp_dir()?;
        for _ in 0..32 {
            let candidate = session_dir.join(format!("preload-{}", Uuid::new_v4().simple()));
            match fs::create_dir(&candidate) {
                Ok(()) => {
                    ensure_private_directory_gui(&candidate)?;
                    return Ok(candidate);
                }
                Err(error) if error.kind() == io::ErrorKind::AlreadyExists => continue,
                Err(error) => return Err(error),
            }
        }

        Err(io::Error::new(
            io::ErrorKind::AlreadyExists,
            "no se pudo reservar una carpeta de precarga unica",
        ))
    }

    fn expire_secret_clipboard(&mut self) {
        let Some(deadline) = self.clipboard_clear_deadline else {
            return;
        };
        if Instant::now() < deadline {
            return;
        }
        self.clear_secret_clipboard_if_owned();
    }

    fn clear_secret_clipboard_if_owned(&mut self) {
        let Some(secret) = self.clipboard_secret.as_ref().cloned() else {
            self.clipboard_clear_deadline = None;
            return;
        };

        let mut clipboard = match Clipboard::new() {
            Ok(clipboard) => clipboard,
            Err(_) => {
                self.clipboard_clear_deadline = Some(Instant::now() + Duration::from_secs(1));
                return;
            }
        };

        let current = match clipboard.get_text() {
            Ok(current) => current,
            Err(_) => {
                self.clipboard_clear_deadline = Some(Instant::now() + Duration::from_secs(1));
                return;
            }
        };

        if current != secret.as_str() {
            self.clipboard_secret = None;
            self.clipboard_clear_deadline = None;
            return;
        }

        if clipboard.set_text(String::new()).is_ok() {
            self.clipboard_secret = None;
            self.clipboard_clear_deadline = None;
        } else {
            self.clipboard_clear_deadline = Some(Instant::now() + Duration::from_secs(1));
        }
    }

    fn clear_session_temp_dir(&mut self) {
        if let Some(path) = self.session_temp_dir.take() {
            self.schedule_temp_dir_cleanup(path);
        }
    }

    fn retry_deferred_temp_file_cleanup(&mut self) {
        let mut remaining = Vec::with_capacity(self.deferred_temp_files.len());
        for path in self.deferred_temp_files.drain(..) {
            if fs::symlink_metadata(&path).is_err() {
                continue;
            }
            if fs::remove_file(&path).is_err() && fs::symlink_metadata(&path).is_ok() {
                remaining.push(path);
            }
        }
        self.deferred_temp_files = remaining;
    }

    fn remove_temp_file_or_defer(&mut self, path: PathBuf) {
        if fs::symlink_metadata(&path).is_err() {
            return;
        }
        if fs::remove_file(&path).is_err()
            && fs::symlink_metadata(&path).is_ok()
            && !self.deferred_temp_files.contains(&path)
        {
            self.deferred_temp_files.push(path);
        }
    }

    fn retry_deferred_temp_dir_cleanup(&mut self) {
        let mut remaining = Vec::with_capacity(self.deferred_temp_dirs.len());
        for path in self.deferred_temp_dirs.drain(..) {
            if fs::symlink_metadata(&path).is_err() {
                continue;
            }
            if fs::remove_dir_all(&path).is_err() && fs::symlink_metadata(&path).is_ok() {
                remaining.push(path);
            }
        }
        self.deferred_temp_dirs = remaining;
    }

    fn clear_preload_cache(&mut self) {
        if let Some(mut task) = self.preload_task.take() {
            let cache_dir = task.cache_dir.clone();
            if let Some(handle) = task.handle.take() {
                let _ = handle.join();
            }
            self.schedule_temp_dir_cleanup(cache_dir);
        }
        self.preloaded_files.clear();
        if let Some(dir) = self.preload_cache_dir.take() {
            self.schedule_temp_dir_cleanup(dir);
        }
    }

    fn schedule_temp_dir_cleanup(&mut self, path: PathBuf) {
        if fs::symlink_metadata(&path).is_err() {
            return;
        }
        if fs::remove_dir_all(&path).is_err()
            && fs::symlink_metadata(&path).is_ok()
            && !self.deferred_temp_dirs.contains(&path)
        {
            self.deferred_temp_dirs.push(path);
        }
    }

    fn reconcile_screen_capture_protection(&mut self, frame: &eframe::Frame) {
        #[cfg(target_os = "windows")]
        {
            let Some(window) = frame.winit_window() else {
                self.screen_capture_protection_applied = false;
                self.screen_capture_protected_hwnd = None;
                return;
            };

            let current_hwnd = match window.window_handle() {
                Ok(handle) => match handle.as_raw() {
                    RawWindowHandle::Win32(handle) => handle.hwnd.get(),
                    _ => {
                        self.screen_capture_protection_applied = false;
                        self.screen_capture_protected_hwnd = None;
                        return;
                    }
                },
                Err(_) => {
                    self.screen_capture_protection_applied = false;
                    self.screen_capture_protected_hwnd = None;
                    return;
                }
            };

            // El HWND puede cambiar durante el ciclo de vida nativo de la ventana.
            // En ese caso hay que reaplicar la afinidad aunque la preferencia del
            // usuario no haya cambiado; esto mantiene la protección también en
            // capturas por región o por ventana tras recreaciones de la ventana.
            let hwnd_changed = self.screen_capture_protected_hwnd != Some(current_hwnd);
            if !hwnd_changed && self.block_screen_captures == self.screen_capture_protection_applied
            {
                return;
            }

            match set_screen_capture_protection(window.as_ref(), self.block_screen_captures) {
                Ok(()) => {
                    self.screen_capture_protection_applied = self.block_screen_captures;
                    self.screen_capture_protected_hwnd = Some(current_hwnd);
                    if self.block_screen_captures {
                        self.set_ok("Protección de capturas activada para OPAC: pantalla completa, región y captura de ventana (si el capturador respeta Windows).".into());
                    } else {
                        self.set_ok("Protección de capturas de pantalla desactivada.".into());
                    }
                }
                Err(error) => {
                    if self.block_screen_captures {
                        self.block_screen_captures = false;
                        self.screen_capture_protection_applied = false;
                        self.screen_capture_protected_hwnd = None;
                        self.set_error(format!(
                            "No se pudo activar la protección de capturas de pantalla: {error}"
                        ));
                    } else {
                        // Si Windows no acepta WDA_NONE, conservamos el estado
                        // realmente aplicado y reintentamos en el siguiente frame.
                        self.set_error(format!(
                            "No se pudo desactivar todavía la protección de capturas de pantalla: {error}"
                        ));
                    }
                }
            }
        }

        #[cfg(not(target_os = "windows"))]
        {
            self.block_screen_captures = false;
            self.screen_capture_protection_applied = false;
        }
    }

    fn set_error(&mut self, message: impl Into<String>) {
        self.status = Some(message.into());
        self.status_error = true;
    }

    fn set_ok(&mut self, message: String) {
        self.status = Some(message);
        self.status_error = false;
    }
}

impl App for OpacApp {
    fn logic(&mut self, ctx: &Context, _frame: &mut eframe::Frame) {
        // Eframe 0.36 separa la lógica del pintado. Mantener aquí las tareas
        // de fondo permite que el cifrado/preparación progrese sin depender
        // de que el UI esté siendo repintado.
        configure_theme(ctx, self.dark_mode);
        self.poll_unlock_task();
        self.poll_guard_operation();
        self.expire_secret_clipboard();
        self.poll_external_open_task();
        self.retry_temp_export_cleanup();
        self.retry_deferred_temp_file_cleanup();
        self.retry_deferred_temp_dir_cleanup();
        #[cfg(target_os = "windows")]
        self.poll_cancelled_video_cleanup_tasks();

        let long_operation_active = self.unlock_task.is_some()
            || self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.guard_operation.is_some()
            || self.video_preview_busy();
        if long_operation_active {
            if self.long_operation_started_at.is_none() {
                self.long_operation_started_at = Some(Instant::now());
            }
        } else {
            self.long_operation_started_at = None;
        }

        if self.screen == Screen::Main {
            if ctx.input(|input| !input.events.is_empty()) {
                self.last_activity = Instant::now();
                self.auto_lock_pending = false;
            }
            self.poll_manual_import_dialog();
            self.poll_import_task();
            self.poll_preload_task();
            self.poll_audio_task();
            #[cfg(target_os = "windows")]
            self.poll_video_audio_seek_task();
            #[cfg(target_os = "windows")]
            self.poll_video_task(ctx);
            self.handle_drops(ctx);

            if inactivity_expired(self.last_activity, Instant::now()) {
                self.auto_lock_pending = true;
            }
            if self.auto_lock_pending
                && self.import_task.is_none()
                && self.preload_task.is_none()
                && self.audio_task.is_none()
                && !self.video_preview_busy()
                && self.guard_operation.is_none()
            {
                self.lock_all_due_to_idle();
            }
        }

        #[cfg(target_os = "windows")]
        let video_clock_polling = self.video_task.is_some();
        #[cfg(not(target_os = "windows"))]
        let video_clock_polling = false;

        ctx.request_repaint_after(std::time::Duration::from_millis(if video_clock_polling {
            16
        } else if self.clipboard_secret.is_some()
            || self.pin_backoff.values().any(|state| {
                state
                    .retry_after
                    .is_some_and(|deadline| deadline > Instant::now())
            })
            || self.import_task.is_some()
            || self.preload_task.is_some()
            || self.audio_task.is_some()
            || self.video_preview_busy()
            || self.audio_player.is_some()
            || self.guard_operation.is_some()
            || self.unlock_task.is_some()
        {
            50
        } else {
            250
        }));
    }

    fn persist_egui_memory(&self) -> bool {
        false
    }

    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        eframe::set_value(
            storage,
            SCREEN_CAPTURE_SETTING_KEY,
            &self.block_screen_captures,
        );
        eframe::set_value(
            storage,
            LEFT_DRAG_SETTING_KEY,
            &self.internal_drag_with_left_button,
        );
        eframe::set_value(storage, DARK_MODE_SETTING_KEY, &self.dark_mode);
    }

    fn ui(&mut self, ui: &mut egui::Ui, frame: &mut eframe::Frame) {
        match self.screen {
            Screen::Setup => self.setup_screen(ui),
            Screen::ProfileSelect => self.profile_select_screen(ui),
            Screen::Unlock => self.unlock_screen(ui),
            Screen::Main => {
                self.main_screen(ui);
                if self.show_settings {
                    self.settings_window(ui.ctx());
                }
            }
        }
        self.reconcile_screen_capture_protection(frame);
    }
}

impl Drop for OpacApp {
    fn drop(&mut self) {
        self.clear_secret_clipboard_if_owned();
        let _ = self.save_pending_edit();
        if let Some(mut task) = self.unlock_task.take()
            && let Some(handle) = task.handle.take()
        {
            let _ = handle.join();
        }
        if let Some(mut task) = self.import_task.take()
            && let Some(handle) = task.handle.take()
        {
            let _ = handle.join();
        }
        if let Some(mut task) = self.preload_task.take()
            && let Some(handle) = task.handle.take()
        {
            let _ = handle.join();
        }
        if let Some(task) = &self.audio_task {
            task.cancel.store(true, Ordering::Relaxed);
        }
        if let Some(mut task) = self.audio_task.take()
            && let Some(handle) = task.handle.take()
        {
            let _ = handle.join();
        }
        self.stop_audio_preview();
        #[cfg(target_os = "windows")]
        self.stop_video_preview_and_join();
        self.clear_preload_cache();
        self.clear_preview_state();
        // Explicitly release the vault/session before asking the Guard to re-arm.
        // Otherwise the Guard could race with OPAC while those objects still own
        // filesystem handles needed to finalize pending writes.
        self.vault = None;
        self.session = None;
        self.guard_rearm_all();
        self.shutdown_guard_client();
        for path in self.temp_exports.drain(..) {
            let _ = fs::remove_file(path);
        }
        self.clear_session_temp_dir();
        self.retry_deferred_temp_file_cleanup();
        self.retry_deferred_temp_dir_cleanup();
    }
}

fn long_operation_spinner_visible(started_at: Instant, now: Instant) -> bool {
    now.duration_since(started_at) >= Duration::from_secs(1)
}

fn inactivity_expired(last_activity: Instant, now: Instant) -> bool {
    now >= last_activity + AUTO_LOCK_IDLE
}

fn path_is_same_or_descendant(path: &Path, root: &Path) -> bool {
    path == root || path.strip_prefix(root).is_ok()
}

fn remap_moved_path(path: &Path, source: &Path, destination: &Path) -> PathBuf {
    if path == source {
        return destination.to_path_buf();
    }
    path.strip_prefix(source)
        .map(|relative| destination.join(relative))
        .unwrap_or_else(|_| path.to_path_buf())
}

#[cfg(target_os = "windows")]
fn set_screen_capture_protection<H: HasWindowHandle + ?Sized>(
    source: &H,
    block: bool,
) -> Result<(), String> {
    let window_handle = source.window_handle().map_err(|error| {
        format!("no se pudo obtener el identificador nativo de la ventana: {error}")
    })?;

    let hwnd = match window_handle.as_raw() {
        RawWindowHandle::Win32(handle) => handle.hwnd.get() as *mut core::ffi::c_void,
        _ => return Err("la ventana no expone un HWND de Windows".to_owned()),
    };

    let affinity = if block {
        WDA_EXCLUDEFROMCAPTURE
    } else {
        WDA_NONE
    };
    let result = unsafe { SetWindowDisplayAffinity(hwnd, affinity) };
    if result == 0 {
        let code = unsafe { GetLastError() };
        return Err(format!(
            "SetWindowDisplayAffinity devolvió FALSE (GetLastError={code})"
        ));
    }

    Ok(())
}

fn theme_neutral(dark_mode: bool, dark: (u8, u8, u8), light: (u8, u8, u8)) -> Color32 {
    let (r, g, b) = if dark_mode { dark } else { light };
    Color32::from_rgb(r, g, b)
}

fn theme_rgba_neutral(
    dark_mode: bool,
    dark: (u8, u8, u8),
    light: (u8, u8, u8),
    alpha: u8,
) -> Color32 {
    let (r, g, b) = if dark_mode { dark } else { light };
    Color32::from_rgba_premultiplied(r, g, b, alpha)
}

fn configure_theme(ctx: &Context, dark_mode: bool) {
    let mut visuals = if dark_mode {
        egui::Visuals::dark()
    } else {
        egui::Visuals::light()
    };
    if dark_mode {
        visuals.panel_fill = Color32::from_rgb(17, 15, 21);
        visuals.window_fill = Color32::from_rgb(23, 20, 29);
        visuals.extreme_bg_color = Color32::from_rgb(11, 10, 14);
        visuals.faint_bg_color = Color32::from_rgb(22, 19, 27);
        visuals.override_text_color = Some(Color32::from_rgb(236, 231, 241));
        visuals.weak_text_color = Some(Color32::from_rgb(158, 149, 168));
        visuals.selection.bg_fill = Color32::from_rgb(84, 46, 115);
        visuals.selection.stroke.color = Color32::from_rgb(207, 176, 231);
        visuals.widgets.active.bg_fill = Color32::from_rgb(75, 42, 103);
        visuals.widgets.hovered.bg_fill = Color32::from_rgb(48, 37, 57);
        visuals.widgets.inactive.bg_fill = Color32::from_rgb(28, 24, 34);
        visuals.widgets.inactive.weak_bg_fill = Color32::from_rgb(28, 24, 34);
    } else {
        visuals.panel_fill = Color32::from_rgb(245, 243, 248);
        visuals.window_fill = Color32::from_rgb(252, 250, 254);
        visuals.extreme_bg_color = Color32::WHITE;
        visuals.faint_bg_color = Color32::from_rgb(239, 236, 244);
        visuals.override_text_color = Some(Color32::from_rgb(45, 40, 50));
        visuals.weak_text_color = Some(Color32::from_rgb(105, 96, 110));
        visuals.selection.bg_fill = Color32::from_rgb(218, 198, 232);
        visuals.selection.stroke.color = Color32::from_rgb(99, 62, 121);
        visuals.widgets.active.bg_fill = Color32::from_rgb(199, 172, 217);
        visuals.widgets.hovered.bg_fill = Color32::from_rgb(232, 224, 237);
        visuals.widgets.inactive.bg_fill = Color32::from_rgb(246, 243, 248);
        visuals.widgets.inactive.weak_bg_fill = Color32::from_rgb(246, 243, 248);
    }

    ctx.set_visuals(visuals);
}

fn copy_file_securely(source: &Path, destination: &Path) -> io::Result<()> {
    let source_metadata = fs::symlink_metadata(source)?;
    if is_reparse_or_symlink_gui(&source_metadata) || !source_metadata.is_file() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "la fuente temporal no es un archivo regular seguro",
        ));
    }

    let mut input_options = OpenOptions::new();
    input_options.read(true);
    #[cfg(windows)]
    input_options.custom_flags(0x0020_0000); // FILE_FLAG_OPEN_REPARSE_POINT
    let mut input = input_options.open(source)?;
    let opened_metadata = input.metadata()?;
    if is_reparse_or_symlink_gui(&opened_metadata) || !opened_metadata.is_file() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "la fuente temporal dejo de ser un archivo regular seguro",
        ));
    }
    let mut output_options = OpenOptions::new();
    output_options.write(true).create_new(true);
    #[cfg(unix)]
    std::os::unix::fs::OpenOptionsExt::mode(&mut output_options, 0o600);
    let mut output = output_options.open(destination)?;
    if let Err(error) = io::copy(&mut input, &mut output) {
        let _ = fs::remove_file(destination);
        return Err(error);
    }
    if let Err(error) = output.sync_all() {
        let _ = fs::remove_file(destination);
        return Err(error);
    }
    Ok(())
}

fn is_reparse_or_symlink_gui(metadata: &fs::Metadata) -> bool {
    if metadata.file_type().is_symlink() {
        return true;
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0400;
        metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0
    }
    #[cfg(not(windows))]
    {
        false
    }
}

fn ensure_private_directory_gui(path: &Path) -> io::Result<()> {
    opac_window_core::modules::vault_fs::set_private_directory_permissions(path)
}

fn write_session_marker(path: &Path) -> io::Result<()> {
    let marker = path.join(SESSION_TEMP_MARKER);
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    std::os::unix::fs::OpenOptionsExt::mode(&mut options, 0o600);
    let mut file = options.open(marker)?;
    writeln!(file, "pid={}", std::process::id())?;
    writeln!(file, "created_unix={}", unix_now_gui())?;
    file.sync_all()
}

fn unix_now_gui() -> u64 {
    SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

fn parse_session_pid(marker: &Path) -> Option<u32> {
    let metadata = fs::symlink_metadata(marker).ok()?;
    if is_reparse_or_symlink_gui(&metadata) || !metadata.is_file() || metadata.len() > 128 {
        return None;
    }
    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(windows)]
    options.custom_flags(0x0020_0000);
    let file = options.open(marker).ok()?;
    let opened = file.metadata().ok()?;
    if is_reparse_or_symlink_gui(&opened) || !opened.is_file() || opened.len() > 128 {
        return None;
    }
    let mut text = String::new();
    file.take(129).read_to_string(&mut text).ok()?;
    if text.len() > 128 {
        return None;
    }
    text.lines()
        .find_map(|line| line.strip_prefix("pid="))
        .and_then(|value| value.trim().parse::<u32>().ok())
}

#[cfg(target_os = "windows")]
fn process_is_alive_gui(pid: u32) -> bool {
    if pid == 0 {
        return false;
    }
    unsafe {
        let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
        if handle.is_null() {
            // Fail closed for cleanup: if Windows no permite consultar el proceso,
            // no arriesgamos borrar un directorio posiblemente vivo.
            return true;
        }
        let mut exit_code = 0u32;
        let ok = GetExitCodeProcess(handle, &mut exit_code);
        windows_sys::Win32::Foundation::CloseHandle(handle);
        ok != 0 && exit_code == 259
    }
}

#[cfg(not(target_os = "windows"))]
fn process_is_alive_gui(_pid: u32) -> bool {
    true
}

fn cleanup_orphaned_session_temp_dirs() -> io::Result<()> {
    let Some(root) = opac_window_core::modules::vault_fs::default_vaults_root() else {
        return Ok(());
    };
    let root = root.join("session-temp");
    let root_meta = match fs::symlink_metadata(&root) {
        Ok(meta) => meta,
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(()),
        Err(error) => return Err(error),
    };
    if is_reparse_or_symlink_gui(&root_meta) || !root_meta.is_dir() {
        return Err(io::Error::new(
            io::ErrorKind::PermissionDenied,
            "almacenamiento temporal de sesion no seguro",
        ));
    }

    let now = SystemTime::now();
    for entry in fs::read_dir(&root)? {
        let entry = entry?;
        let path = entry.path();
        match path.file_name().and_then(|n| n.to_str()) {
            Some(name) if name.starts_with(SESSION_TEMP_DIR_PREFIX) => {}
            _ => continue,
        }
        let meta = match fs::symlink_metadata(&path) {
            Ok(meta) => meta,
            Err(_) => continue,
        };
        if is_reparse_or_symlink_gui(&meta) || !meta.is_dir() {
            continue;
        }
        let marker = path.join(SESSION_TEMP_MARKER);
        let marker_meta = match fs::symlink_metadata(&marker) {
            Ok(meta) => meta,
            Err(_) => continue,
        };
        if is_reparse_or_symlink_gui(&marker_meta) || !marker_meta.is_file() {
            continue;
        }
        let age = now
            .duration_since(marker_meta.modified().unwrap_or(now))
            .unwrap_or_default();
        if age < SESSION_TEMP_ORPHAN_AGE {
            continue;
        }
        let Some(pid) = parse_session_pid(&marker) else {
            continue;
        };
        if process_is_alive_gui(pid) {
            continue;
        }
        let _ = fs::remove_dir_all(&path);
    }
    Ok(())
}

fn same_or_descendant_path(candidate: &Path, root: &Path) -> bool {
    let candidate_abs = fs::canonicalize(candidate).unwrap_or_else(|_| candidate.to_path_buf());
    let root_abs = fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
    candidate_abs == root_abs || candidate_abs.strip_prefix(&root_abs).is_ok()
}

fn parse_portable_key(input: &str) -> Result<[u8; 32], String> {
    let text = input.trim();
    if text.len() != 64 {
        return Err("La Vault Key debe tener exactamente 64 caracteres hexadecimales.".into());
    }
    let bytes = text.as_bytes();
    if bytes.iter().any(|byte| !byte.is_ascii_hexdigit()) {
        return Err("La Vault Key solo puede contener caracteres hexadecimales (0-9, A-F).".into());
    }
    let mut key = [0u8; 32];
    let (chunks, remainder) = bytes.as_chunks::<2>();
    if !remainder.is_empty() {
        return Err("Vault Key invalida".to_owned());
    }
    for (index, chunk) in chunks.iter().enumerate() {
        let high = (chunk[0] as char)
            .to_digit(16)
            .ok_or_else(|| "Vault Key invalida".to_owned())?;
        let low = (chunk[1] as char)
            .to_digit(16)
            .ok_or_else(|| "Vault Key invalida".to_owned())?;
        key[index] = ((high << 4) | low) as u8;
    }
    Ok(key)
}

fn format_profile_error(error: &ProfileError) -> String {
    format!("No se pudo gestionar el usuario: {error}")
}

#[cfg(target_os = "windows")]
fn open_video_audio_file(path: &Path) -> Result<fs::File, String> {
    let metadata = fs::symlink_metadata(path)
        .map_err(|error| format!("No se pudo validar la pista de audio del vídeo: {error}"))?;
    if !metadata.is_file() || is_reparse_or_symlink_gui(&metadata) {
        return Err("La pista de audio del vídeo no es un archivo regular seguro.".into());
    }
    let mut options = OpenOptions::new();
    options.read(true);
    options.custom_flags(0x0020_0000); // FILE_FLAG_OPEN_REPARSE_POINT
    let file = options
        .open(path)
        .map_err(|error| format!("No se pudo abrir la pista de audio del vídeo: {error}"))?;
    let opened_metadata = file.metadata().map_err(|error| {
        format!("No se pudo verificar la pista de audio del vídeo después de abrirla: {error}")
    })?;
    if !opened_metadata.is_file() || is_reparse_or_symlink_gui(&opened_metadata) {
        return Err("La pista de audio del vídeo dejó de ser un archivo regular seguro.".into());
    }
    Ok(file)
}

fn format_error(error: &SessionError) -> String {
    match error {
        SessionError::Vault(VaultError::Crypto(
            opac_window_core::modules::crypto::CryptoError::AuthenticationFailed,
        )) => "La contraseña no coincide con este usuario o el Key Store está dañado.".to_owned(),
        SessionError::Persistence(opac_window_core::PersistenceError::NoRecoverableStore) => {
            "No se encontró el Key Store de este usuario.".to_owned()
        }
        SessionError::VaultOutsideProfile => {
            "El Key Store encontrado pertenece a otro perfil o no coincide con este usuario."
                .to_owned()
        }
        _ => error.to_string(),
    }
}

fn hex_bytes(bytes: &[u8; 32]) -> String {
    let mut out = String::with_capacity(64);
    for byte in bytes {
        out.push_str(&format!("{byte:02x}"));
    }
    out
}

fn safe_temp_extension(name: &str, fallback: &str) -> String {
    let extension = Path::new(name)
        .extension()
        .and_then(|value| value.to_str())
        .unwrap_or_default();
    if !extension.is_empty()
        && extension.len() <= 16
        && extension.bytes().all(|byte| byte.is_ascii_alphanumeric())
    {
        extension.to_ascii_lowercase()
    } else {
        fallback.to_string()
    }
}

fn file_icon(name: &str) -> &'static str {
    let ext = Path::new(name)
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or_default()
        .to_ascii_lowercase();
    match ext.as_str() {
        "png" | "jpg" | "jpeg" | "gif" | "webp" => "🖼",
        "pdf" => "📕",
        "zip" | "7z" | "rar" | "tar" | "gz" => "📦",
        "doc" | "docx" | "odt" => "📘",
        "xls" | "xlsx" | "ods" => "📊",
        "mp3" | "wav" | "flac" | "ogg" | "m4a" | "aac" => "🎵",
        "mp4" | "mkv" | "mov" | "avi" | "webm" | "m4v" | "wmv" | "ts" | "m2ts" | "mts" | "3gp" => {
            "🎬"
        }
        _ => "📄",
    }
}

fn looks_like_video(name: &str) -> bool {
    matches!(
        Path::new(name)
            .extension()
            .and_then(|extension| extension.to_str())
            .unwrap_or_default()
            .to_ascii_lowercase()
            .as_str(),
        "mp4" | "mkv" | "mov" | "avi" | "webm" | "m4v" | "wmv" | "ts" | "m2ts" | "mts" | "3gp"
    )
}

fn looks_like_image(name: &str) -> bool {
    matches!(
        Path::new(name)
            .extension()
            .and_then(|extension| extension.to_str())
            .unwrap_or_default()
            .to_ascii_lowercase()
            .as_str(),
        "png" | "jpg" | "jpeg" | "gif" | "webp"
    )
}

fn decode_preview_image(bytes: &[u8]) -> Result<(Vec<u8>, [usize; 2]), String> {
    if bytes.len() > IMAGE_PREVIEW_MAX_BYTES as usize {
        return Err("la imagen supera el limite de 32 MiB".into());
    }

    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let reader = ImageReader::new(Cursor::new(bytes))
            .with_guessed_format()
            .map_err(|error| format!("formato no identificable: {error}"))?;

        let (width, height) = reader
            .into_dimensions()
            .map_err(|error| format!("dimensiones invalidas: {error}"))?;

        if width == 0 || height == 0 {
            return Err("la imagen tiene dimensiones invalidas".into());
        }
        if width > IMAGE_PREVIEW_MAX_DIMENSION || height > IMAGE_PREVIEW_MAX_DIMENSION {
            return Err(format!(
                "las dimensiones superan el limite de {} px por eje",
                IMAGE_PREVIEW_MAX_DIMENSION
            ));
        }
        let pixels = u64::from(width) * u64::from(height);
        if pixels > IMAGE_PREVIEW_MAX_PIXELS {
            return Err(format!(
                "la imagen supera el limite de {} millones de pixeles",
                IMAGE_PREVIEW_MAX_PIXELS / 1_000_000
            ));
        }

        let mut reader = ImageReader::new(Cursor::new(bytes))
            .with_guessed_format()
            .map_err(|error| format!("formato no identificable: {error}"))?;
        let mut limits = image::Limits::default();
        limits.max_image_width = Some(IMAGE_PREVIEW_MAX_DIMENSION);
        limits.max_image_height = Some(IMAGE_PREVIEW_MAX_DIMENSION);
        limits.max_alloc = Some(IMAGE_PREVIEW_MAX_ALLOC);
        reader.limits(limits);

        let decoded = reader
            .decode()
            .map_err(|error| format!("decodificacion rechazada: {error}"))?;
        let rgba = decoded.to_rgba8().into_raw();
        Ok((rgba, [width as usize, height as usize]))
    }));

    match result {
        Ok(result) => result,
        Err(_) => Err("el decodificador de imagen rechazo la entrada".into()),
    }
}

fn looks_like_pdf(name: &str) -> bool {
    Path::new(name)
        .extension()
        .and_then(|extension| extension.to_str())
        .is_some_and(|extension| extension.eq_ignore_ascii_case("pdf"))
}

fn uses_memory_only_preview(name: &str) -> bool {
    looks_like_image(name) || looks_like_pdf(name)
}

fn render_pdf_preview(bytes: &[u8]) -> Result<(usize, Vec<PdfPreviewPage>), String> {
    if bytes.len() > PDF_PREVIEW_MAX_BYTES as usize {
        return Err(format!(
            "el PDF supera el limite de {}",
            format_bytes(PDF_PREVIEW_MAX_BYTES)
        ));
    }

    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let document = PdfDocument::load(bytes.to_vec())
            .map_err(|error| format!("formato PDF invalido o no compatible: {error}"))?;

        let page_count = document.page_count();
        if page_count == 0 {
            return Err("el PDF no contiene paginas".to_string());
        }

        let render_count = page_count.min(PDF_PREVIEW_RENDER_PAGES);
        let mut pages = Vec::with_capacity(render_count);

        for index in 0..render_count {
            let page = document
                .page(index)
                .map_err(|error| format!("no se pudo abrir la pagina {}: {error}", index + 1))?;
            let (width, height) = page.size();

            if !width.is_finite() || !height.is_finite() || width <= 0.0 || height <= 0.0 {
                return Err(format!(
                    "la pagina {} tiene dimensiones invalidas",
                    index + 1
                ));
            }

            let scale = pdf_render_scale(width, height)?;
            let pixmap = render_pdf_page(&document, &page, scale).map_err(|error| {
                format!("no se pudo renderizar la pagina {}: {error}", index + 1)
            })?;

            let pixel_width = pixmap.width as usize;
            let pixel_height = pixmap.height as usize;
            let pixel_count = pixel_width
                .checked_mul(pixel_height)
                .ok_or_else(|| format!("la pagina {} produce demasiados pixeles", index + 1))?;
            if pixel_count as f64 > PDF_RENDER_MAX_PIXELS {
                return Err(format!(
                    "la pagina {} supera el limite seguro de pixeles de la vista previa",
                    index + 1
                ));
            }
            let expected_len = pixel_count.checked_mul(4).ok_or_else(|| {
                format!(
                    "la pagina {} produce un buffer de imagen demasiado grande",
                    index + 1
                )
            })?;
            let rgba = &pixmap.data;

            if rgba.len() != expected_len {
                return Err(format!(
                    "la pagina {} produjo un buffer RGBA inesperado",
                    index + 1
                ));
            }

            pages.push(PdfPreviewPage {
                size: [pixel_width, pixel_height],
                rgba: Some(Zeroizing::new(rgba.to_vec())),
                texture: None,
            });
        }

        Ok((page_count, pages))
    }));

    match result {
        Ok(result) => result,
        Err(_) => Err("el renderizador PDF rechazo la entrada".into()),
    }
}

fn pdf_render_scale(width: f32, height: f32) -> Result<f32, String> {
    let page_pixels_at_unit_scale = f64::from(width) * f64::from(height);
    if !page_pixels_at_unit_scale.is_finite() || page_pixels_at_unit_scale <= 0.0 {
        return Err("dimensiones PDF no validas".into());
    }

    let dimension_scale = PDF_RENDER_MAX_DIMENSION / width.max(height);
    let pixel_scale = (PDF_RENDER_MAX_PIXELS / page_pixels_at_unit_scale).sqrt() as f32;
    let scale = 1.25_f32.min(dimension_scale).min(pixel_scale);

    if !scale.is_finite() || scale <= 0.0 {
        return Err("no se pudo calcular una escala segura de renderizado".into());
    }

    Ok(scale)
}

fn looks_like_audio(name: &str) -> bool {
    matches!(
        Path::new(name)
            .extension()
            .and_then(|extension| extension.to_str())
            .unwrap_or_default()
            .to_ascii_lowercase()
            .as_str(),
        "mp3" | "wav" | "flac" | "ogg" | "m4a" | "aac"
    )
}

fn looks_like_text(name: &str) -> bool {
    let Some(extension) = Path::new(name).extension().and_then(|e| e.to_str()) else {
        return false;
    };
    extension.eq_ignore_ascii_case("txt")
        || extension.eq_ignore_ascii_case("md")
        || extension.eq_ignore_ascii_case("markdown")
        || extension.eq_ignore_ascii_case("csv")
        || extension.eq_ignore_ascii_case("json")
        || extension.eq_ignore_ascii_case("toml")
        || extension.eq_ignore_ascii_case("xml")
        || extension.eq_ignore_ascii_case("yaml")
        || extension.eq_ignore_ascii_case("yml")
        || extension.eq_ignore_ascii_case("log")
        || extension.eq_ignore_ascii_case("ini")
        || extension.eq_ignore_ascii_case("rs")
        || extension.eq_ignore_ascii_case("ron")
}

fn is_editable_text(name: &str) -> bool {
    let Some(extension) = Path::new(name).extension().and_then(|e| e.to_str()) else {
        return false;
    };
    extension.eq_ignore_ascii_case("txt")
        || extension.eq_ignore_ascii_case("md")
        || extension.eq_ignore_ascii_case("markdown")
}

fn format_audio_time(duration: Duration) -> String {
    let total_seconds = duration.as_secs();
    let hours = total_seconds / 3600;
    let minutes = (total_seconds % 3600) / 60;
    let seconds = total_seconds % 60;
    if hours > 0 {
        format!("{hours:02}:{minutes:02}:{seconds:02}")
    } else {
        format!("{minutes:02}:{seconds:02}")
    }
}

fn format_video_time(duration: Duration) -> String {
    let total_seconds = duration.as_secs();
    let hours = total_seconds / 3600;
    let minutes = (total_seconds % 3600) / 60;
    let seconds = total_seconds % 60;
    if hours > 0 {
        format!("{hours:02}:{minutes:02}:{seconds:02}")
    } else {
        format!("{minutes:02}:{seconds:02}")
    }
}

fn format_bytes(bytes: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KB", "MB", "GB", "TB"];
    let mut value = bytes as f64;
    let mut index = 0usize;
    while value >= 1024.0 && index + 1 < UNITS.len() {
        value /= 1024.0;
        index += 1;
    }
    if index == 0 {
        format!("{} {}", bytes, UNITS[index])
    } else {
        format!("{value:.1} {}", UNITS[index])
    }
}

#[derive(Debug)]
struct ImportJob {
    source: PathBuf,
    target_folder: PathBuf,
    display_name: String,
}

const IMPORT_MAX_WORKERS: usize = 8;

fn import_worker_count(total_files: usize) -> usize {
    if total_files == 0 {
        return 0;
    }
    std::thread::available_parallelism()
        .map(|count| count.get())
        .unwrap_or(2)
        .clamp(1, IMPORT_MAX_WORKERS)
        .min(total_files)
}

fn import_chunk_worker_count(source_bytes: u64) -> usize {
    if source_bytes <= opac_window_core::modules::opac_format::DEFAULT_CHUNKING_THRESHOLD {
        return 1;
    }
    let total_chunks = opac_window_core::modules::opac_format::chunk_count_for_size(source_bytes);
    if total_chunks <= 1 {
        return 1;
    }
    std::thread::available_parallelism()
        .map(|count| count.get())
        .unwrap_or(2)
        .clamp(2, IMPORT_MAX_WORKERS)
        .min(opac_window_core::modules::opac_format::MAX_PARALLEL_CHUNK_WORKERS)
        .min(total_chunks as usize)
}

fn import_progress_bytes(source_bytes: u64, completed: u64, total_chunks: u64) -> u64 {
    if completed == 0 || source_bytes == 0 {
        return 0;
    }
    if total_chunks <= 1 {
        return source_bytes;
    }
    completed
        .saturating_mul(opac_window_core::modules::opac_format::DEFAULT_CHUNK_SIZE as u64)
        .min(source_bytes)
}

fn run_import_worker(
    queue: Arc<Mutex<VecDeque<ImportJob>>>,
    sender: mpsc::Sender<ImportEvent>,
    vault_folder: PathBuf,
    vault_key: Arc<Zeroizing<[u8; 32]>>,
    requested_chunk_workers: usize,
) {
    loop {
        let job = match queue.lock() {
            Ok(mut queue) => queue.pop_front(),
            Err(poisoned) => poisoned.into_inner().pop_front(),
        };
        let Some(job) = job else {
            break;
        };

        let display_name = job.display_name.clone();
        let total_chunks = std::fs::metadata(&job.source)
            .map(|metadata| {
                opac_window_core::modules::opac_format::chunk_count_for_size(metadata.len())
            })
            .unwrap_or(1);
        let source_bytes = std::fs::metadata(&job.source)
            .map(|metadata| metadata.len())
            .unwrap_or(0);
        let worker_units = if source_bytes
            > opac_window_core::modules::opac_format::DEFAULT_CHUNKING_THRESHOLD
            && total_chunks > 1
        {
            requested_chunk_workers
                .clamp(
                    1,
                    opac_window_core::modules::opac_format::MAX_PARALLEL_CHUNK_WORKERS,
                )
                .min(total_chunks as usize)
                .max(1)
        } else {
            1
        };
        let _ = sender.send(ImportEvent::Started {
            source_path: job.source.clone(),
            name: display_name.clone(),
            total_chunks,
            total_bytes: source_bytes,
            worker_units,
        });

        let progress_sender = sender.clone();
        let progress_name = display_name.clone();
        let source_path_for_progress = job.source.clone();
        let key_ref: &[u8; 32] = &vault_key;
        let result =
            opac_window_core::modules::vault_fs::encrypt_file_into_vault_folder_with_progress_and_parallelism(
                &vault_folder,
                &job.target_folder,
                key_ref,
                &job.source,
                worker_units,
                move |completed, total| {
                    let bytes_completed = import_progress_bytes(source_bytes, completed, total);
                    let _ = progress_sender.send(ImportEvent::ChunkProgress {
                        source_path: source_path_for_progress.clone(),
                        name: progress_name.clone(),
                        completed,
                        total,
                        bytes_completed,
                    });
                },
            )
            .map_err(|error| error.to_string());

        let _ = sender.send(ImportEvent::Finished {
            source_path: job.source,
            source_name: display_name,
            total_bytes: source_bytes,
            worker_units,
            result,
        });
    }
}

#[derive(Debug)]
struct PreparedImportJobs {
    jobs: Vec<ImportJob>,
    folder_count: usize,
}

#[derive(Debug)]
struct ExternalTreePlan {
    folders: Vec<PathBuf>,
    files: Vec<(PathBuf, PathBuf)>,
}

#[cfg(test)]
fn prioritize_import_sources(files: Vec<PathBuf>) -> Vec<PathBuf> {
    let mut sized = files
        .into_iter()
        .enumerate()
        .map(|(index, path)| {
            let size = fs::symlink_metadata(&path)
                .ok()
                .filter(|metadata| metadata.file_type().is_file())
                .map(|metadata| metadata.len())
                .unwrap_or(u64::MAX);
            (size, index, path)
        })
        .collect::<Vec<_>>();
    sized.sort_by(|left, right| left.0.cmp(&right.0).then_with(|| left.1.cmp(&right.1)));
    sized.into_iter().map(|(_, _, path)| path).collect()
}

fn prioritize_import_jobs(mut jobs: Vec<ImportJob>) -> Vec<ImportJob> {
    jobs.sort_by(|left, right| {
        let left_size = fs::symlink_metadata(&left.source)
            .ok()
            .filter(|metadata| metadata.file_type().is_file())
            .map(|metadata| metadata.len())
            .unwrap_or(u64::MAX);
        let right_size = fs::symlink_metadata(&right.source)
            .ok()
            .filter(|metadata| metadata.file_type().is_file())
            .map(|metadata| metadata.len())
            .unwrap_or(u64::MAX);
        left_size
            .cmp(&right_size)
            .then_with(|| left.source.cmp(&right.source))
    });
    jobs
}

fn prepare_import_jobs(
    vault: &VaultSession,
    target_folder: &Path,
    paths: Vec<PathBuf>,
) -> Result<PreparedImportJobs, String> {
    let mut jobs = Vec::new();
    let mut folder_count = 0usize;
    let mut planned_directories: BTreeMap<PathBuf, PathBuf> = BTreeMap::new();
    let vault_folder = vault.location().to_path_buf();

    let mut roots = paths;
    roots.sort_by(|left, right| {
        let left_kind = fs::symlink_metadata(left)
            .map(|metadata| metadata.file_type().is_dir())
            .unwrap_or(false);
        let right_kind = fs::symlink_metadata(right)
            .map(|metadata| metadata.file_type().is_dir())
            .unwrap_or(false);
        right_kind.cmp(&left_kind).then_with(|| left.cmp(right))
    });

    let mut checked_roots = Vec::new();
    for source in &roots {
        if checked_roots
            .iter()
            .any(|root: &PathBuf| path_is_same_or_descendant(source, root))
        {
            return Err(format!(
                "se rechazo una importacion redundante dentro de otra carpeta: {}",
                source.display()
            ));
        }
        checked_roots.push(source.clone());
    }

    for source in roots {
        if path_is_same_or_descendant(&source, &vault_folder) {
            return Err(format!(
                "no se puede importar una ruta que ya esta dentro de la Caja Fuerte: {}",
                source.display()
            ));
        }
        let metadata = fs::symlink_metadata(&source)
            .map_err(|error| format!("{}: {error}", source.display()))?;
        if is_unsafe_import_entry(&metadata) {
            return Err(format!(
                "se rechazo una entrada enlazada o especial: {}",
                source.display()
            ));
        }
        if metadata.file_type().is_file() {
            ensure_import_source_is_file(&source)?;
            let display_name = source
                .file_name()
                .map(|value| value.to_string_lossy().into_owned())
                .unwrap_or_else(|| source.display().to_string());
            jobs.push(ImportJob {
                source,
                target_folder: target_folder.to_path_buf(),
                display_name,
            });
            continue;
        }
        if !metadata.file_type().is_dir() {
            return Err(format!("entrada no compatible: {}", source.display()));
        }

        let plan = scan_external_tree(&source)?;
        let root_name = source
            .file_name()
            .ok_or_else(|| format!("no se pudo obtener el nombre de {}", source.display()))
            .and_then(|name| {
                name.to_str()
                    .map(str::to_owned)
                    .ok_or_else(|| format!("nombre de carpeta no valido: {}", source.display()))
            })?;
        let imported_root = vault
            .create_folder(target_folder, &root_name)
            .map_err(|error| format!("no se pudo crear «{root_name}»: {error}"))?;
        folder_count += 1;
        planned_directories.insert(PathBuf::new(), imported_root.clone());

        let mut folders = plan.folders;
        folders.sort_by_key(|path| path.components().count());
        for relative in folders {
            let parent_relative = relative.parent().unwrap_or_else(|| Path::new(""));
            let parent_target = planned_directories
                .get(parent_relative)
                .cloned()
                .ok_or_else(|| {
                    format!(
                        "estructura interna no encontrada para {}",
                        relative.display()
                    )
                })?;
            let name = relative
                .file_name()
                .and_then(|value| value.to_str())
                .ok_or_else(|| format!("nombre de subcarpeta no valido: {}", relative.display()))?;
            let created = vault
                .create_folder(&parent_target, name)
                .map_err(|error| format!("no se pudo crear «{name}»: {error}"))?;
            planned_directories.insert(relative, created);
            folder_count += 1;
        }

        for (relative, source_file) in plan.files {
            let parent_relative = relative.parent().unwrap_or_else(|| Path::new(""));
            let target = planned_directories
                .get(parent_relative)
                .cloned()
                .ok_or_else(|| {
                    format!("destino interno no encontrado para {}", relative.display())
                })?;
            let display_name = relative.to_string_lossy().replace('\\', "/");
            jobs.push(ImportJob {
                source: source_file,
                target_folder: target,
                display_name,
            });
        }

        planned_directories.clear();
    }

    Ok(PreparedImportJobs { jobs, folder_count })
}

fn scan_external_tree(root: &Path) -> Result<ExternalTreePlan, String> {
    let mut folders = Vec::new();
    let mut files = Vec::new();
    let mut stack = vec![root.to_path_buf()];

    while let Some(current) = stack.pop() {
        for entry in fs::read_dir(&current)
            .map_err(|error| format!("no se pudo leer {}: {error}", current.display()))?
        {
            let entry = entry.map_err(|error| {
                format!(
                    "no se pudo leer una entrada de {}: {error}",
                    current.display()
                )
            })?;
            let path = entry.path();
            let metadata = fs::symlink_metadata(&path)
                .map_err(|error| format!("{}: {error}", path.display()))?;
            if is_unsafe_import_entry(&metadata) {
                return Err(format!(
                    "se rechazo una entrada enlazada o especial: {}",
                    path.display()
                ));
            }
            let relative = path
                .strip_prefix(root)
                .map_err(|_| format!("ruta externa invalida: {}", path.display()))?
                .to_path_buf();
            if metadata.file_type().is_dir() {
                folders.push(relative);
                stack.push(path);
            } else if metadata.file_type().is_file() {
                files.push((relative, path));
            } else {
                return Err(format!(
                    "entrada especial no compatible: {}",
                    path.display()
                ));
            }
        }
    }

    folders.sort();
    files.sort_by(|left, right| left.0.cmp(&right.0));
    Ok(ExternalTreePlan { folders, files })
}

fn ensure_import_source_is_file(path: &Path) -> Result<(), String> {
    let metadata =
        fs::symlink_metadata(path).map_err(|error| format!("{}: {error}", path.display()))?;
    if is_unsafe_import_entry(&metadata) || !metadata.file_type().is_file() {
        return Err(format!("entrada no compatible: {}", path.display()));
    }
    Ok(())
}

fn is_unsafe_import_entry(metadata: &fs::Metadata) -> bool {
    if metadata.file_type().is_symlink() {
        return true;
    }
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::fs::MetadataExt;
        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0400;
        metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0
    }
    #[cfg(not(target_os = "windows"))]
    {
        false
    }
}

#[cfg(target_os = "windows")]
fn open_with_default_app(path: &Path) -> io::Result<()> {
    use std::iter::once;
    use std::os::windows::ffi::OsStrExt;

    let file = path
        .as_os_str()
        .encode_wide()
        .chain(once(0))
        .collect::<Vec<_>>();
    let operation = "open".encode_utf16().chain(once(0)).collect::<Vec<_>>();

    let result = unsafe {
        ShellExecuteW(
            std::ptr::null_mut(),
            operation.as_ptr(),
            file.as_ptr(),
            std::ptr::null(),
            std::ptr::null(),
            SW_SHOWNORMAL,
        )
    };

    if (result as isize) <= 32 {
        let last_error = unsafe { GetLastError() };
        if last_error != 0 {
            return Err(io::Error::from_raw_os_error(last_error as i32));
        }
        return Err(io::Error::other(format!(
            "Windows ShellExecuteW rechazo la apertura (codigo {result:?})"
        )));
    }

    Ok(())
}

#[cfg(target_os = "macos")]
fn open_with_default_app(path: &Path) -> io::Result<()> {
    Command::new("open").arg(path).spawn()?;
    Ok(())
}

#[cfg(all(unix, not(target_os = "macos")))]
fn open_with_default_app(path: &Path) -> io::Result<()> {
    Command::new("xdg-open").arg(path).spawn()?;
    Ok(())
}

#[cfg(not(any(target_os = "windows", target_os = "macos", unix)))]
fn open_with_default_app(_path: &Path) -> io::Result<()> {
    Err(io::Error::new(
        io::ErrorKind::Unsupported,
        "plataforma no compatible",
    ))
}

#[cfg(test)]
mod preview_tests {
    #[test]
    fn long_operation_spinner_waits_for_one_second() {
        let started = Instant::now();
        assert!(!long_operation_spinner_visible(started, started));
        assert!(!long_operation_spinner_visible(
            started,
            started + Duration::from_millis(999),
        ));
        assert!(long_operation_spinner_visible(
            started,
            started + Duration::from_secs(1),
        ));
    }

    use super::*;

    #[test]
    fn portable_key_parser_accepts_exact_32_byte_hex_and_rejects_invalid_lengths() {
        let input = "00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff";
        let parsed = parse_portable_key(input).unwrap();
        assert_eq!(parsed.len(), 32);
        assert_eq!(parsed[0], 0x00);
        assert_eq!(parsed[31], 0xff);
        assert!(parse_portable_key("00").is_err());
        assert!(parse_portable_key(&"zz".repeat(32)).is_err());
        assert!(parse_portable_key(&format!(" {} ", input)).is_ok());
    }

    #[test]
    fn markdown_files_are_detected_for_preview() {
        assert!(!looks_like_audio("readme.md"));
        assert!(matches!(
            Path::new("readme.md")
                .extension()
                .and_then(|value| value.to_str()),
            Some("md")
        ));
        assert!(matches!(
            Path::new("document.markdown")
                .extension()
                .and_then(|value| value.to_str()),
            Some("markdown")
        ));
    }

    #[test]
    fn editable_text_extensions_include_txt_and_markdown() {
        for name in [
            "notas.txt",
            "README.md",
            "README.markdown",
            "NOTAS.TXT",
            "README.MD",
        ] {
            assert!(is_editable_text(name), "{name} should be editable");
        }
        for name in ["photo.png", "document.pdf", "archive.zip"] {
            assert!(!is_editable_text(name), "{name} should not be editable");
        }
    }

    #[test]
    fn text_editor_supports_txt_and_markdown_previews() {
        for name in ["secret.txt", "README.md", "README.markdown"] {
            assert!(looks_like_text(name));
            assert!(is_editable_text(name));
        }
    }

    #[test]
    fn supported_pdf_extensions_are_detected() {
        for name in ["document.pdf", "DOCUMENT.PDF"] {
            assert!(looks_like_pdf(name), "{name} should be recognized as PDF");
        }
        for name in ["notes.txt", "photo.png", "archive.zip"] {
            assert!(
                !looks_like_pdf(name),
                "{name} should not be recognized as PDF"
            );
        }
    }

    #[test]
    fn integrated_image_and_pdf_previews_are_memory_only() {
        for name in ["photo.png", "photo.jpg", "document.pdf", "DOCUMENT.PDF"] {
            assert!(
                uses_memory_only_preview(name),
                "{name} should bypass plaintext preload"
            );
        }
        for name in ["notes.txt", "song.mp3", "archive.zip"] {
            assert!(
                !uses_memory_only_preview(name),
                "{name} should keep normal preload behavior"
            );
        }
    }

    #[test]
    fn invalid_pdf_bytes_are_rejected_without_panicking() {
        let result = render_pdf_preview(b"not a pdf");
        assert!(result.is_err());
    }

    #[test]
    fn oversized_pdf_preview_is_rejected_before_parsing() {
        let bytes = vec![0u8; PDF_PREVIEW_MAX_BYTES as usize + 1];
        let result = render_pdf_preview(&bytes);
        assert!(result.is_err());
    }

    #[test]
    fn pdf_render_scale_stays_within_preview_limits() {
        let scale = pdf_render_scale(612.0, 792.0).unwrap();
        assert!(scale > 0.0 && scale <= 1.25);

        let huge = pdf_render_scale(20_000.0, 20_000.0).unwrap();
        let rendered_pixels = 20_000.0_f64 * 20_000.0_f64 * f64::from(huge) * f64::from(huge);
        assert!(rendered_pixels <= PDF_RENDER_MAX_PIXELS * 1.01);
    }

    #[test]
    fn supported_image_extensions_are_detected() {
        for name in [
            "photo.png",
            "photo.jpg",
            "photo.jpeg",
            "animation.gif",
            "picture.webp",
            "PHOTO.PNG",
        ] {
            assert!(
                looks_like_image(name),
                "{name} should be recognized as image"
            );
        }
        for name in ["movie.mp4", "document.pdf", "notes.txt"] {
            assert!(
                !looks_like_image(name),
                "{name} should not be recognized as image"
            );
        }
    }

    #[test]
    fn invalid_image_bytes_are_rejected_without_panicking() {
        let result = decode_preview_image(&[0x00, 0x01, 0x02, 0x03]);
        assert!(result.is_err());
    }

    #[test]
    fn tiny_png_decodes_for_preview() {
        let png: &[u8] = &[
            137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1, 0, 0, 0, 1,
            8, 6, 0, 0, 0, 31, 21, 196, 137, 0, 0, 0, 13, 73, 68, 65, 84, 120, 156, 99, 248, 207,
            192, 240, 31, 0, 5, 0, 1, 255, 137, 153, 61, 29, 0, 0, 0, 0, 73, 69, 78, 68, 174, 66,
            96, 130,
        ];
        let result = decode_preview_image(png).expect("tiny png should decode");
        assert_eq!(result.1, [1, 1]);
        assert_eq!(result.0.len(), 4);
    }

    #[test]
    fn external_folder_scan_preserves_nested_structure_and_files() {
        let temp = std::env::temp_dir().join(format!("opac-folder-import-scan-{}", Uuid::new_v4()));
        let root = temp.join("Proyecto");
        let nested = root.join("Privado").join("Fotos");
        fs::create_dir_all(&nested).unwrap();
        fs::write(root.join("readme.md"), b"hello").unwrap();
        fs::write(root.join("Privado").join("notas.txt"), b"secret").unwrap();
        fs::write(nested.join("foto.bin"), vec![7u8; 17]).unwrap();

        let plan = scan_external_tree(&root).expect("external folder should scan");
        let folder_names = plan
            .folders
            .iter()
            .map(|path| path.to_string_lossy().replace('\\', "/"))
            .collect::<Vec<_>>();
        let file_names = plan
            .files
            .iter()
            .map(|(path, _)| path.to_string_lossy().replace('\\', "/"))
            .collect::<Vec<_>>();

        assert_eq!(folder_names, vec!["Privado", "Privado/Fotos"]);
        let file_names = file_names
            .into_iter()
            .collect::<std::collections::BTreeSet<_>>();
        let expected_file_names = ["Privado/notas.txt", "Privado/Fotos/foto.bin", "readme.md"]
            .into_iter()
            .map(str::to_owned)
            .collect::<std::collections::BTreeSet<_>>();
        assert_eq!(file_names, expected_file_names);

        let _ = fs::remove_dir_all(temp);
    }

    #[test]
    fn external_folder_import_creates_native_managed_tree_and_encryption_jobs() {
        let temp =
            std::env::temp_dir().join(format!("opac-folder-import-native-{}", Uuid::new_v4()));
        let profile_root = temp.join("profile");
        let keystore_path = profile_root.join("keystore.opks");
        let source = temp.join("Proyecto");
        fs::create_dir_all(source.join("Privado").join("Fotos")).unwrap();
        fs::write(source.join("readme.md"), b"root").unwrap();
        fs::write(source.join("Privado").join("notas.md"), b"nested").unwrap();
        fs::write(
            source.join("Privado").join("Fotos").join("foto.bin"),
            vec![9u8; 1025],
        )
        .unwrap();

        let mut session = KeyStoreSession::create_scoped_named(
            &keystore_path,
            &profile_root,
            "Tester",
            b"correct horse battery staple",
        )
        .unwrap();
        let vault_path = profile_root.join("vaults").join("vault");
        let vault_id = session.create_vault("Caja", &vault_path).unwrap();
        let vault = session.open_vault(vault_id, None).unwrap();
        let prepared = prepare_import_jobs(&vault, vault.location(), vec![source.clone()]).unwrap();

        assert_eq!(prepared.folder_count, 3);
        assert_eq!(prepared.jobs.len(), 3);

        let folders = vault.list_folders().unwrap();
        let names = folders
            .iter()
            .map(|(_, metadata)| metadata.original_name.clone())
            .collect::<std::collections::HashSet<_>>();
        assert_eq!(names.len(), 3);
        assert!(names.contains("Proyecto"));
        assert!(names.contains("Privado"));
        assert!(names.contains("Fotos"));
        for job in &prepared.jobs {
            assert!(job.target_folder.starts_with(vault.location()));
            assert!(!job.source.starts_with(vault.location()));
        }

        let mut encrypted = Vec::new();
        for job in prepared.jobs {
            let encrypted_path =
                opac_window_core::modules::vault_fs::encrypt_file_into_vault_folder(
                    vault.location(),
                    &job.target_folder,
                    vault.key_bytes(),
                    &job.source,
                )
                .unwrap();
            let decrypted_path = temp.join(format!("decrypted-{}", Uuid::new_v4().simple()));
            opac_window_core::modules::vault_fs::decrypt_file_from_vault(
                &encrypted_path,
                vault.key_bytes(),
                &decrypted_path,
            )
            .unwrap();
            let source_bytes = fs::read(&job.source).unwrap();
            let decrypted_bytes = fs::read(&decrypted_path).unwrap();
            assert_eq!(decrypted_bytes, source_bytes);
            let _ = fs::remove_file(&decrypted_path);
            encrypted.push(encrypted_path);
        }
        assert_eq!(encrypted.len(), 3);

        let _ = fs::remove_dir_all(temp);
    }

    #[test]
    fn external_folder_scan_rejects_symlink_or_reparse_entries() {
        let temp =
            std::env::temp_dir().join(format!("opac-folder-import-unsafe-{}", Uuid::new_v4()));
        let root = temp.join("Proyecto");
        fs::create_dir_all(&root).unwrap();
        fs::write(root.join("real.txt"), b"ok").unwrap();

        #[cfg(unix)]
        std::os::unix::fs::symlink(&root.join("real.txt"), root.join("enlace.txt")).unwrap();

        #[cfg(unix)]
        assert!(scan_external_tree(&root).is_err());

        #[cfg(not(unix))]
        assert!(scan_external_tree(&root).is_ok());

        let _ = fs::remove_dir_all(temp);
    }

    #[test]
    fn import_queue_prioritizes_smaller_regular_files_and_keeps_equal_size_order() {
        let temp = std::env::temp_dir().join(format!("opac-import-priority-{}", Uuid::new_v4()));
        fs::create_dir_all(&temp).unwrap();
        let small = temp.join("small.bin");
        let medium = temp.join("medium.bin");
        let large = temp.join("large.bin");
        fs::write(&small, vec![0u8; 8]).unwrap();
        fs::write(&medium, vec![1u8; 64]).unwrap();
        fs::write(&large, vec![2u8; 4096]).unwrap();

        let ordered = prioritize_import_sources(vec![large.clone(), small.clone(), medium.clone()]);
        assert_eq!(ordered, vec![small.clone(), medium.clone(), large.clone()]);

        let same_a = temp.join("same-a.bin");
        let same_b = temp.join("same-b.bin");
        fs::write(&same_a, vec![3u8; 128]).unwrap();
        fs::write(&same_b, vec![4u8; 128]).unwrap();
        let ordered_equal = prioritize_import_sources(vec![same_a.clone(), same_b.clone()]);
        assert_eq!(ordered_equal, vec![same_a.clone(), same_b.clone()]);

        let _ = fs::remove_dir_all(&temp);
    }

    #[test]
    fn import_total_progress_uses_bytes_so_large_files_do_not_look_stuck() {
        let total_bytes = 100u64 * 1024 * 1024;
        let completed_bytes = 25u64 * 1024 * 1024;
        let progress = completed_bytes as f32 / total_bytes as f32;
        assert!((progress - 0.25).abs() < f32::EPSILON);
        assert!(completed_bytes > 0);
    }

    #[test]
    fn import_chunk_progress_bytes_matches_real_chunk_boundaries() {
        let source_bytes = 9u64 * 1024 * 1024 + 123;
        let total_chunks =
            opac_window_core::modules::opac_format::chunk_count_for_size(source_bytes);
        assert_eq!(total_chunks, 3);
        assert_eq!(
            import_progress_bytes(source_bytes, 1, total_chunks),
            opac_window_core::modules::opac_format::DEFAULT_CHUNK_SIZE as u64
        );
        assert_eq!(
            import_progress_bytes(source_bytes, 2, total_chunks),
            (opac_window_core::modules::opac_format::DEFAULT_CHUNK_SIZE as u64) * 2
        );
        assert_eq!(
            import_progress_bytes(source_bytes, 3, total_chunks),
            source_bytes
        );
    }

    #[test]
    fn import_progress_for_small_files_reaches_total_on_first_chunk() {
        let source_bytes = 123_456u64;
        assert_eq!(import_progress_bytes(source_bytes, 0, 1), 0);
        assert_eq!(import_progress_bytes(source_bytes, 1, 1), source_bytes);
    }

    #[test]
    fn import_worker_count_is_bounded_and_uses_available_parallelism() {
        assert_eq!(import_worker_count(0), 0);
        assert!(import_worker_count(1) == 1);
        assert!((1..=IMPORT_MAX_WORKERS).contains(&import_worker_count(IMPORT_MAX_WORKERS + 4)));
    }

    #[test]
    fn large_single_file_uses_chunk_workers_but_small_files_stay_single_worker() {
        let small = opac_window_core::modules::opac_format::DEFAULT_CHUNKING_THRESHOLD;
        assert_eq!(import_chunk_worker_count(small), 1);
        assert!((2..=IMPORT_MAX_WORKERS).contains(&import_chunk_worker_count(small + 1)));
        let large = 128u64 * 1024 * 1024;
        assert!((2..=IMPORT_MAX_WORKERS).contains(&import_chunk_worker_count(large)));
    }

    #[test]
    fn concurrent_import_scheduler_dispatches_small_jobs_first() {
        let temp = std::env::temp_dir().join(format!(
            "opac-import-concurrent-priority-{}",
            Uuid::new_v4()
        ));
        fs::create_dir_all(&temp).unwrap();

        let sizes = [4096usize, 8, 1024, 16, 65_536, 32];
        let mut paths = Vec::new();
        for (index, size) in sizes.iter().copied().enumerate() {
            let path = temp.join(format!("file-{index}.bin"));
            fs::write(&path, vec![index as u8; size]).unwrap();
            paths.push(path);
        }

        let ordered = prioritize_import_sources(paths.clone());
        let ordered_sizes: Vec<u64> = ordered
            .iter()
            .map(|path| fs::metadata(path).unwrap().len())
            .collect();
        assert!(
            ordered_sizes
                .windows(2)
                .all(|window| window[0] <= window[1])
        );

        let workers = import_worker_count(ordered.len());
        assert!(workers > 0);
        assert!(workers <= IMPORT_MAX_WORKERS);

        let _ = fs::remove_dir_all(temp);
    }

    #[test]
    fn supported_audio_extensions_are_detected() {
        for name in [
            "song.mp3",
            "speech.wav",
            "album.flac",
            "recording.ogg",
            "track.m4a",
            "voice.aac",
        ] {
            assert!(
                looks_like_audio(name),
                "{name} should be recognized as audio"
            );
        }
    }

    #[test]
    fn supported_video_extensions_are_detected() {
        for name in [
            "movie.mp4",
            "movie.mkv",
            "movie.mov",
            "movie.avi",
            "movie.webm",
            "movie.m4v",
            "movie.wmv",
            "movie.ts",
            "movie.m2ts",
            "movie.mts",
            "movie.3gp",
        ] {
            assert!(
                looks_like_video(name),
                "{name} should be recognized as video"
            );
        }
    }

    #[test]
    fn video_previews_do_not_claim_memory_only_decoding() {
        assert!(looks_like_video("movie.mp4"));
        assert!(!uses_memory_only_preview("movie.mp4"));
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn video_audio_decoder_accepts_wav_container() {
        let sample_rate = 8_000u32;
        let samples = 160u32;
        let data_len = samples * 2;
        let riff_len = 36 + data_len;
        let mut wav = Vec::with_capacity((riff_len + 8) as usize);
        wav.extend_from_slice(b"RIFF");
        wav.extend_from_slice(&riff_len.to_le_bytes());
        wav.extend_from_slice(b"WAVE");
        wav.extend_from_slice(b"fmt ");
        wav.extend_from_slice(&16u32.to_le_bytes());
        wav.extend_from_slice(&1u16.to_le_bytes());
        wav.extend_from_slice(&1u16.to_le_bytes());
        wav.extend_from_slice(&sample_rate.to_le_bytes());
        wav.extend_from_slice(&(sample_rate * 2).to_le_bytes());
        wav.extend_from_slice(&2u16.to_le_bytes());
        wav.extend_from_slice(&16u16.to_le_bytes());
        wav.extend_from_slice(b"data");
        wav.extend_from_slice(&data_len.to_le_bytes());
        wav.extend(std::iter::repeat_n(0u8, data_len as usize));

        let decoder = Decoder::try_from(Cursor::new(wav)).expect("WAV audio should decode");
        let duration = decoder
            .total_duration()
            .expect("WAV should expose duration");
        assert_eq!(duration, Duration::from_millis(20));
    }

    #[test]
    fn path_boundary_checks_do_not_treat_name_prefixes_as_descendants() {
        let root = PathBuf::from(r"C:\Vault\foo");
        assert!(path_is_same_or_descendant(&root, &root));
        assert!(path_is_same_or_descendant(
            &PathBuf::from(r"C:\Vault\foo\bar"),
            &root
        ));
        assert!(!path_is_same_or_descendant(
            &PathBuf::from(r"C:\Vault\foobar\bar"),
            &root
        ));
        assert!(!path_is_same_or_descendant(
            &PathBuf::from(r"C:\Vault\food"),
            &root
        ));
    }

    #[test]
    fn path_remap_only_rewrites_real_descendants() {
        let source = PathBuf::from(r"C:\Vault\foo");
        let destination = PathBuf::from(r"C:\Vault\bar");
        let child = PathBuf::from(r"C:\Vault\foo\note.txt");
        let sibling_prefix = PathBuf::from(r"C:\Vault\foobar\note.txt");
        assert_eq!(
            remap_moved_path(&child, &source, &destination),
            PathBuf::from(r"C:\Vault\bar\note.txt")
        );
        assert_eq!(
            remap_moved_path(&sibling_prefix, &source, &destination),
            sibling_prefix
        );
    }

    #[test]
    fn inactivity_timeout_expires_only_after_configured_interval() {
        let start = Instant::now();
        assert!(!inactivity_expired(
            start,
            start + AUTO_LOCK_IDLE - Duration::from_secs(1)
        ));
        assert!(inactivity_expired(start, start + AUTO_LOCK_IDLE));
    }

    #[test]
    fn unsupported_media_is_not_classified_as_audio() {
        for name in ["movie.mkv", "image.png", "document.pdf", "archive.zip"] {
            assert!(
                !looks_like_audio(name),
                "{name} should not be recognized as audio"
            );
        }
    }
}
