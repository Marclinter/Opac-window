#![cfg(target_os = "windows")]

use std::collections::VecDeque;
use std::fs;
use std::mem::size_of;
use std::path::Path;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc::{self, Receiver, Sender, SyncSender, TrySendError};
use std::sync::{Arc, Condvar, Mutex};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

use windows::Win32::Media::MediaFoundation::{
    IMF2DBuffer, IMF2DBuffer2, IMFMediaEvent, IMFSample, IMFSourceReader, IMFSourceReaderCallback,
    IMFSourceReaderCallback_Impl, MF_MT_DEFAULT_STRIDE, MF_MT_FRAME_SIZE, MF_MT_MAJOR_TYPE,
    MF_MT_SUBTYPE, MF_PD_DURATION, MF_SOURCE_READER_ASYNC_CALLBACK,
    MF_SOURCE_READER_ENABLE_ADVANCED_VIDEO_PROCESSING, MF_SOURCE_READER_FIRST_VIDEO_STREAM,
    MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED, MF_SOURCE_READERF_ENDOFSTREAM,
    MF_SOURCE_READERF_ERROR, MF_SOURCE_READERF_NATIVEMEDIATYPECHANGED, MF_VERSION,
    MF2DBuffer_LockFlags_Read, MFCreateAttributes, MFCreateMediaType, MFCreateSourceReaderFromURL,
    MFMediaType_Video, MFSTARTUP_FULL, MFShutdown, MFStartup, MFVideoFormat_RGB32,
};
use windows::Win32::System::Com::StructuredStorage::PROPVARIANT;
use windows::Win32::System::Com::{COINIT_MULTITHREADED, CoInitializeEx, CoUninitialize};
use windows::core::{GUID, HRESULT, Interface, PCWSTR, Ref};
use windows_core::Result as WindowsCoreResult;
use windows_sys::Win32::System::ProcessStatus::{
    K32GetProcessMemoryInfo, PROCESS_MEMORY_COUNTERS_EX,
};
use windows_sys::Win32::System::Threading::GetCurrentProcess;
use zeroize::Zeroizing;

const MAX_FRAME_PIXELS: u64 = 16 * 1024 * 1024;
const MAX_FRAME_DIMENSION: u32 = 8192;
const FRAME_BYTES_PER_PIXEL: usize = 4;
const FRAME_QUEUE_CAPACITY: usize = 6;
const MAX_PREVIEW_WIDTH: u32 = 960;
const MAX_PREVIEW_HEIGHT: u32 = 540;
// The integrated preview is intentionally capped at 960x540 (540p); the
// encrypted source file keeps its original resolution and the external-player
// path is unchanged.
const VIDEO_MAX_FPS: usize = 60;
const VIDEO_READY_BUFFER: Duration = Duration::from_secs(1);
const VIDEO_TARGET_BUFFER: Duration = Duration::from_secs(3);
const VIDEO_RAW_SAMPLE_QUEUE_CAPACITY: usize = 4;
const VIDEO_RAM_SAFETY_LIMIT_BYTES: usize = 1024 * 1024 * 1024;
// Keep room for Media Foundation, egui, rodio and the rest of the process. This
// is a safety envelope, not a normal playback allocation target.
const VIDEO_RAM_HEADROOM_BYTES: usize = 128 * 1024 * 1024;
const VIDEO_FRAME_PAYLOAD_BUDGET_BYTES: usize =
    VIDEO_RAM_SAFETY_LIMIT_BYTES - VIDEO_RAM_HEADROOM_BYTES;
// Small, separate staging/event queues and the current GUI texture are accounted
// for when deriving the hard frame-slot ceiling.
const VIDEO_EXTERNAL_FRAME_SLOTS: usize =
    FRAME_QUEUE_CAPACITY * 2 + VIDEO_RAW_SAMPLE_QUEUE_CAPACITY + 2;
const CONTROL_POLL_SLICE: Duration = Duration::from_millis(20);
const AUDIO_SYNC_TOLERANCE: Duration = Duration::from_millis(25);
const AUDIO_SYNC_DROP_THRESHOLD: Duration = Duration::from_millis(75);
const AUDIO_SYNC_HARD_RESYNC_THRESHOLD: Duration = Duration::from_millis(300);

// MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS is not exposed as a constant by the
// selected windows-rs Media Foundation bindings, so keep the SDK GUID locally.
const MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS: GUID = GUID::from_values(
    0xa634a91c,
    0x822b,
    0x41b9,
    [0xa4, 0x94, 0x4d, 0xe4, 0x64, 0x36, 0x12, 0xb0],
);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum VideoControlCommand {
    Restart,
    Seek(Duration),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum VideoSyncAction {
    Wait,
    Render,
    Drop,
    Resync(Duration),
}

#[derive(Debug, Default)]
struct VideoControlState {
    generation: u64,
    command: Option<VideoControlCommand>,
}

#[derive(Debug)]
pub struct VideoPreviewTask {
    pub cancel: Arc<AtomicBool>,
    pub playing: Arc<AtomicBool>,
    control: Arc<Mutex<VideoControlState>>,
    pub audio_clock_nanos: Arc<AtomicU64>,
    pub audio_clock_active: Arc<AtomicBool>,
    pub audio_clock_pending: Arc<AtomicBool>,
    pub control_generation: Arc<AtomicU64>,
    pub receiver: Receiver<VideoPreviewEvent>,
    pub handle: Option<JoinHandle<()>>,
}

impl VideoPreviewTask {
    pub fn request_seek(&self, target: Duration) -> Result<u64, String> {
        publish_video_control(
            &self.control,
            &self.control_generation,
            VideoControlCommand::Seek(target),
        )
    }

    pub fn request_restart(&self) -> Result<u64, String> {
        publish_video_control(
            &self.control,
            &self.control_generation,
            VideoControlCommand::Restart,
        )
    }
}

#[derive(Debug)]
pub enum VideoPreviewEvent {
    Ready {
        source_path: std::path::PathBuf,
        preview_path: std::path::PathBuf,
        owns_temp: bool,
        size: [usize; 2],
        duration: Option<Duration>,
    },
    Frame {
        source_path: std::path::PathBuf,
        rgba: Zeroizing<Vec<u8>>,
        size: [usize; 2],
        position: Duration,
        generation: u64,
    },
    Ended {
        source_path: std::path::PathBuf,
        generation: u64,
    },
    Failed {
        source_path: std::path::PathBuf,
        preview_path: std::path::PathBuf,
        message: String,
    },
}

struct VideoPreviewWorker {
    source_path: std::path::PathBuf,
    preview_path: std::path::PathBuf,
    key: Option<Zeroizing<[u8; 32]>>,
    decrypt_source: bool,
    cancel: Arc<AtomicBool>,
    playing: Arc<AtomicBool>,
    control: Arc<Mutex<VideoControlState>>,
    audio_clock_nanos: Arc<AtomicU64>,
    audio_clock_active: Arc<AtomicBool>,
    audio_clock_pending: Arc<AtomicBool>,
    control_generation: Arc<AtomicU64>,
    sender: SyncSender<VideoPreviewEvent>,
}

pub fn spawn_video_preview(
    source_path: std::path::PathBuf,
    preview_path: std::path::PathBuf,
    key: Zeroizing<[u8; 32]>,
) -> Result<VideoPreviewTask, String> {
    spawn_video_preview_inner(source_path, preview_path, Some(key), true)
}

pub fn spawn_video_preview_from_plaintext(
    source_path: std::path::PathBuf,
    preview_path: std::path::PathBuf,
) -> Result<VideoPreviewTask, String> {
    spawn_video_preview_inner(source_path, preview_path, None, false)
}

fn spawn_video_preview_inner(
    source_path: std::path::PathBuf,
    preview_path: std::path::PathBuf,
    key: Option<Zeroizing<[u8; 32]>>,
    decrypt_source: bool,
) -> Result<VideoPreviewTask, String> {
    let cancel = Arc::new(AtomicBool::new(false));
    let playing = Arc::new(AtomicBool::new(false));
    let control = Arc::new(Mutex::new(VideoControlState::default()));
    let audio_clock_nanos = Arc::new(AtomicU64::new(0));
    let audio_clock_active = Arc::new(AtomicBool::new(false));
    let audio_clock_pending = Arc::new(AtomicBool::new(false));
    let control_generation = Arc::new(AtomicU64::new(0));
    let cancel_worker = Arc::clone(&cancel);
    let playing_worker = Arc::clone(&playing);
    let control_worker = Arc::clone(&control);
    let audio_clock_worker = Arc::clone(&audio_clock_nanos);
    let audio_clock_active_worker = Arc::clone(&audio_clock_active);
    let audio_clock_pending_worker = Arc::clone(&audio_clock_pending);
    let control_generation_worker = Arc::clone(&control_generation);
    let source_for_worker = source_path.clone();
    let preview_for_worker = preview_path.clone();
    let (sender, receiver) = mpsc::sync_channel(FRAME_QUEUE_CAPACITY);

    let handle = thread::Builder::new()
        .name("opac-video-preview".to_owned())
        .spawn(move || {
            let worker = VideoPreviewWorker {
                source_path: source_for_worker.clone(),
                preview_path: preview_for_worker.clone(),
                key,
                decrypt_source,
                cancel: cancel_worker,
                playing: playing_worker,
                control: control_worker,
                audio_clock_nanos: audio_clock_worker,
                audio_clock_active: audio_clock_active_worker,
                audio_clock_pending: audio_clock_pending_worker,
                control_generation: control_generation_worker,
                sender: sender.clone(),
            };
            let error_sender = worker.sender.clone();
            if let Err(error) = run_video_preview(worker) {
                let _ = error_sender.send(VideoPreviewEvent::Failed {
                    source_path: source_for_worker,
                    preview_path: preview_for_worker,
                    message: error,
                });
            }
        })
        .map_err(|error| format!("no se pudo iniciar el hilo de vista previa de vídeo: {error}"))?;

    Ok(VideoPreviewTask {
        cancel,
        playing,
        control,
        audio_clock_nanos,
        audio_clock_active,
        audio_clock_pending,
        control_generation,
        receiver,
        handle: Some(handle),
    })
}

fn publish_video_control(
    control: &Mutex<VideoControlState>,
    generation: &AtomicU64,
    command: VideoControlCommand,
) -> Result<u64, String> {
    let mut state = control
        .lock()
        .map_err(|_| "no se pudo actualizar el control del vídeo".to_string())?;
    state.generation = state.generation.saturating_add(1);
    state.command = Some(command);
    generation.store(state.generation, Ordering::Release);
    Ok(state.generation)
}

fn take_video_control(
    control: &Mutex<VideoControlState>,
) -> Result<Option<(u64, VideoControlCommand)>, String> {
    let mut state = control
        .lock()
        .map_err(|_| "no se pudo leer el control del vídeo".to_string())?;
    Ok(state
        .command
        .take()
        .map(|command| (state.generation, command)))
}

fn run_video_preview(worker: VideoPreviewWorker) -> Result<(), String> {
    if worker.decrypt_source {
        let Some(key) = worker.key.as_ref() else {
            return Err("falta la clave de la Caja Fuerte para preparar el vídeo".into());
        };
        decrypt_preview_file(&worker.source_path, &worker.preview_path, key)?;
    }
    if worker.cancel.load(Ordering::Relaxed) {
        return Ok(());
    }
    validate_preview_source_file(&worker.preview_path)?;

    worker.playing.store(false, Ordering::Relaxed);

    let (status_sender, status_receiver) = mpsc::channel::<VideoDecoderStatus>();
    let current_context = Arc::new(Mutex::new(None::<Arc<VideoGenerationBuffers>>));
    let ready_event_sent = Arc::new(AtomicBool::new(false));
    let (reader_signal_sender, reader_signal_receiver) = mpsc::channel::<ReaderSignal>();

    let decoder_worker = VideoDecoderWorker {
        preview_path: worker.preview_path.clone(),
        cancel: Arc::clone(&worker.cancel),
        control: Arc::clone(&worker.control),
        control_generation: Arc::clone(&worker.control_generation),
        current_context: Arc::clone(&current_context),
        playing: Arc::clone(&worker.playing),
        status_sender: status_sender.clone(),
        reader_signal_sender,
        reader_signal_receiver,
        ready_event_sent: Arc::clone(&ready_event_sent),
    };

    let decoder_error_sender = status_sender.clone();
    let decoder_handle = thread::Builder::new()
        .name("opac-video-decoder".to_owned())
        .spawn(move || {
            if let Err(error) = run_video_decoder(decoder_worker) {
                let _ = decoder_error_sender.send(VideoDecoderStatus::Failed(error));
            }
        })
        .map_err(|error| format!("no se pudo iniciar el coordinador de vídeo: {error}"))?;

    let processor_context = Arc::clone(&current_context);
    let processor_cancel = Arc::clone(&worker.cancel);
    let processor_status = status_sender.clone();
    let processor_ready = Arc::clone(&ready_event_sent);
    let processor_handle = match thread::Builder::new()
        .name("opac-video-frame-processor".to_owned())
        .spawn(move || {
            run_video_frame_processor(
                processor_context,
                processor_cancel,
                processor_status,
                processor_ready,
            );
        }) {
        Ok(handle) => handle,
        Err(error) => {
            worker.cancel.store(true, Ordering::Release);
            let _ = decoder_handle.join();
            return Err(format!(
                "no se pudo iniciar el procesador de fotogramas de vídeo: {error}"
            ));
        }
    };

    let playback_result = run_video_playback_loop(&worker, current_context, status_receiver);

    worker.cancel.store(true, Ordering::Release);
    let _ = decoder_handle.join();
    let _ = processor_handle.join();
    playback_result
}

struct VideoDecoderWorker {
    preview_path: std::path::PathBuf,
    playing: Arc<AtomicBool>,
    cancel: Arc<AtomicBool>,
    control: Arc<Mutex<VideoControlState>>,
    control_generation: Arc<AtomicU64>,
    current_context: Arc<Mutex<Option<Arc<VideoGenerationBuffers>>>>,
    status_sender: Sender<VideoDecoderStatus>,
    reader_signal_sender: Sender<ReaderSignal>,
    reader_signal_receiver: Receiver<ReaderSignal>,
    ready_event_sent: Arc<AtomicBool>,
}

#[derive(Debug)]
enum VideoDecoderStatus {
    Ready {
        generation: u64,
        size: [usize; 2],
        duration: Option<Duration>,
    },
    BufferReady {
        generation: u64,
    },
    EndOfStream {
        generation: u64,
    },
    Failed(String),
}

#[derive(Debug)]
enum ReaderReadOutcome {
    Accepted,
    NoSample,
    MediaTypeChanged,
    EndOfStream,
}

#[derive(Debug)]
enum ReaderSignal {
    ReadCompleted {
        generation: u64,
        outcome: ReaderReadOutcome,
    },
    FlushCompleted {
        generation: u64,
    },
    Failed {
        generation: u64,
        message: String,
    },
}

#[derive(Debug)]
struct RawVideoFrame {
    bgra: Zeroizing<Vec<u8>>,
    size: [usize; 2],
    position: Duration,
    generation: u64,
    force_display: bool,
}

#[derive(Debug)]
struct VideoGenerationState {
    raw_frames: VecDeque<RawVideoFrame>,
    decoded_frames: VecDeque<DecodedVideoFrame>,
    processing_frames: usize,
    max_queue_frames: usize,
    size: [usize; 2],
    default_stride: i32,
    duration: Option<Duration>,
    requested_size: [usize; 2],
    discard_before: Option<Duration>,
    last_accepted_position: Option<Duration>,
    fallback_frame_before_target: Option<RawVideoFrame>,
    ready_sent: bool,
    end_of_stream: bool,
    failure_sent: bool,
    saw_any_frame: bool,
}

#[derive(Debug)]
struct VideoGenerationBuffers {
    generation: u64,
    active: AtomicBool,
    state: Mutex<VideoGenerationState>,
    wake: Condvar,
}

fn video_frame_interval() -> Duration {
    Duration::from_nanos(1_000_000_000u64 / VIDEO_MAX_FPS as u64)
}

fn video_process_memory_allows(additional_bytes: usize) -> Result<bool, String> {
    let process = unsafe { GetCurrentProcess() };
    let cb = u32::try_from(size_of::<PROCESS_MEMORY_COUNTERS_EX>())
        .map_err(|_| "el tamaño de los contadores de memoria no cabe en Windows".to_string())?;
    let mut counters = PROCESS_MEMORY_COUNTERS_EX {
        cb,
        ..Default::default()
    };
    let ok = unsafe {
        K32GetProcessMemoryInfo(
            process,
            (&mut counters as *mut PROCESS_MEMORY_COUNTERS_EX).cast(),
            counters.cb,
        )
    };
    if ok == 0 {
        // Memory telemetry is a safety backstop only; failure to query it must not
        // make ordinary local playback fail. The dynamic frame-payload ceiling
        // remains enforced independently.
        return Ok(true);
    }
    Ok(counters.PrivateUsage.saturating_add(additional_bytes) <= VIDEO_RAM_SAFETY_LIMIT_BYTES)
}

fn ensure_video_process_memory_budget(additional_bytes: usize) -> Result<(), String> {
    if video_process_memory_allows(additional_bytes)? {
        return Ok(());
    }
    Err(format!(
        "la vista previa de vídeo alcanzaría el límite de seguridad de memoria del proceso ({} MiB)",
        VIDEO_RAM_SAFETY_LIMIT_BYTES / (1024 * 1024)
    ))
}

fn frame_payload_bytes(size: [usize; 2]) -> Result<usize, String> {
    size[0]
        .checked_mul(size[1])
        .and_then(|pixels| pixels.checked_mul(FRAME_BYTES_PER_PIXEL))
        .ok_or_else(|| "el tamaño del fotograma desborda la plataforma".to_string())
}

fn max_decode_queue_frames(size: [usize; 2]) -> Result<usize, String> {
    let frame_bytes = frame_payload_bytes(size)?;
    if frame_bytes == 0 {
        return Err("el fotograma no puede tener un tamaño nulo".into());
    }
    let external_bytes = frame_bytes
        .checked_mul(VIDEO_EXTERNAL_FRAME_SLOTS)
        .ok_or_else(|| "el presupuesto de memoria de vídeo desborda la plataforma".to_string())?;
    let available = VIDEO_FRAME_PAYLOAD_BUDGET_BYTES.saturating_sub(external_bytes);
    let frames = available / frame_bytes;
    if frames == 0 {
        return Err("el límite de memoria de seguridad no permite reservar ni un fotograma".into());
    }
    Ok(frames)
}

fn buffered_duration_locked(state: &VideoGenerationState) -> Duration {
    let mut first = None;
    let mut last = None;
    let mut consider = |position: Duration| {
        first = Some(first.map_or(position, |value: Duration| value.min(position)));
        last = Some(last.map_or(position, |value: Duration| value.max(position)));
    };
    if let Some(frame) = state.raw_frames.front() {
        consider(frame.position);
    }
    if let Some(frame) = state.raw_frames.back() {
        consider(frame.position);
    }
    if let Some(frame) = state.decoded_frames.front() {
        consider(frame.position);
    }
    if let Some(frame) = state.decoded_frames.back() {
        consider(frame.position);
    }
    if let Some(frame) = state.fallback_frame_before_target.as_ref() {
        consider(frame.position);
    }
    match (first, last) {
        (Some(first), Some(last)) => last.saturating_sub(first),
        _ => Duration::ZERO,
    }
}

impl VideoGenerationBuffers {
    fn new(
        generation: u64,
        size: [usize; 2],
        default_stride: i32,
        duration: Option<Duration>,
        requested_size: [usize; 2],
    ) -> Arc<Self> {
        Arc::new(Self {
            generation,
            active: AtomicBool::new(true),
            state: Mutex::new(VideoGenerationState {
                raw_frames: VecDeque::with_capacity(VIDEO_RAW_SAMPLE_QUEUE_CAPACITY),
                decoded_frames: VecDeque::new(),
                processing_frames: 0,
                max_queue_frames: 1,
                size,
                default_stride,
                duration,
                requested_size,
                discard_before: None,
                last_accepted_position: None,
                fallback_frame_before_target: None,
                ready_sent: false,
                end_of_stream: false,
                failure_sent: false,
                saw_any_frame: false,
            }),
            wake: Condvar::new(),
        })
    }

    fn set_layout(&self, size: [usize; 2], default_stride: i32) -> Result<(), String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado interno del vídeo".to_string())?;
        let max_queue_frames = max_decode_queue_frames(size)?;
        state.size = size;
        state.default_stride = default_stride;
        state.max_queue_frames = max_queue_frames;
        Ok(())
    }

    fn set_discard_before(&self, target: Option<Duration>) -> Result<(), String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado de seek del vídeo".to_string())?;
        state.discard_before = target;
        state.last_accepted_position = None;
        state.fallback_frame_before_target = None;
        Ok(())
    }

    fn should_copy_sample(&self, position: Duration) -> Result<bool, String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado de cadencia del vídeo".to_string())?;
        if !self.active.load(Ordering::Acquire) {
            return Ok(false);
        }
        let interval = video_frame_interval();
        if let Some(target) = state.discard_before {
            if position < target {
                // During the keyframe-to-target walk we keep the last frame before
                // the requested position available as the EOS fallback, but still
                // enforce the normal presentation-rate admission limit.
                if state
                    .last_accepted_position
                    .is_some_and(|last| position.saturating_sub(last) < interval)
                {
                    return Ok(false);
                }
                state.last_accepted_position = Some(position);
                return Ok(true);
            }
            // The first sample at/after the target must always be admitted so a
            // seek can make visible progress even when it lands on the cadence
            // boundary of the preceding fallback sample. Subsequent samples use
            // the normal interval check.
            state.discard_before = None;
            state.fallback_frame_before_target = None;
            state.last_accepted_position = Some(position);
            return Ok(true);
        }
        if state
            .last_accepted_position
            .is_some_and(|last| position.saturating_sub(last) < interval)
        {
            return Ok(false);
        }
        state.last_accepted_position = Some(position);
        Ok(true)
    }

    fn layout(&self) -> Result<([usize; 2], i32), String> {
        let state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el layout interno del vídeo".to_string())?;
        Ok((state.size, state.default_stride))
    }

    fn duration(&self) -> Result<Option<Duration>, String> {
        let state = self
            .state
            .lock()
            .map_err(|_| "se corrompió la duración interna del vídeo".to_string())?;
        Ok(state.duration)
    }

    fn requested_size(&self) -> Result<[usize; 2], String> {
        let state = self
            .state
            .lock()
            .map_err(|_| "se corrompió la resolución objetivo del vídeo".to_string())?;
        Ok(state.requested_size)
    }

    fn set_requested_size(&self, size: [usize; 2]) -> Result<(), String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió la resolución objetivo del vídeo".to_string())?;
        state.requested_size = size;
        Ok(())
    }

    fn queue_depth_locked(state: &VideoGenerationState) -> usize {
        state
            .raw_frames
            .len()
            .saturating_add(state.decoded_frames.len())
            .saturating_add(state.processing_frames)
            .saturating_add(usize::from(state.fallback_frame_before_target.is_some()))
    }

    #[cfg(test)]
    fn has_capacity(&self) -> Result<bool, String> {
        let state = self
            .state
            .lock()
            .map_err(|_| "se corrompió la cola interna del vídeo".to_string())?;
        Ok(Self::queue_depth_locked(&state) < state.max_queue_frames)
    }

    fn push_raw_frame(&self, frame: RawVideoFrame) -> Result<(), String> {
        if !self.active.load(Ordering::Acquire) {
            return Ok(());
        }
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió la cola de fotogramas del vídeo".to_string())?;
        if !self.active.load(Ordering::Acquire) {
            return Ok(());
        }

        let mut frame = frame;
        state.saw_any_frame = true;
        if let Some(target) = state.discard_before {
            if frame.position < target {
                state.fallback_frame_before_target = Some(frame);
                return Ok(());
            }
            state.discard_before = None;
            state.fallback_frame_before_target = None;
        }

        if Self::queue_depth_locked(&state) >= state.max_queue_frames {
            return Err(
                "la cola de vídeo alcanzó su límite de memoria antes de aceptar el fotograma"
                    .into(),
            );
        }
        frame.force_display = false;
        state.raw_frames.push_back(frame);
        self.wake.notify_one();
        Ok(())
    }

    fn pop_raw_frame(&self) -> Result<Option<RawVideoFrame>, String> {
        if !self.active.load(Ordering::Acquire) {
            return Ok(None);
        }
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió la cola de decodificación del vídeo".to_string())?;
        if !self.active.load(Ordering::Acquire) {
            return Ok(None);
        }
        let Some(frame) = state.raw_frames.pop_front() else {
            return Ok(None);
        };
        state.processing_frames = state.processing_frames.saturating_add(1);
        Ok(Some(frame))
    }

    fn finish_processing(&self, raw: RawVideoFrame) -> Result<(), String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió la cola procesada del vídeo".to_string())?;
        state.processing_frames = state.processing_frames.saturating_sub(1);
        if !self.active.load(Ordering::Acquire) {
            return Ok(());
        }
        if Self::queue_depth_locked(&state) >= state.max_queue_frames {
            return Err(
                "la cola procesada del vídeo superó inesperadamente su límite de memoria".into(),
            );
        }
        state.decoded_frames.push_back(DecodedVideoFrame {
            rgba: raw.bgra,
            size: raw.size,
            position: raw.position,
            generation: raw.generation,
            force_display: raw.force_display,
        });
        self.wake.notify_one();
        Ok(())
    }

    fn pop_decoded_frame(&self) -> Result<Option<DecodedVideoFrame>, String> {
        if !self.active.load(Ordering::Acquire) {
            return Ok(None);
        }
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió la cola de reproducción del vídeo".to_string())?;
        if !self.active.load(Ordering::Acquire) {
            return Ok(None);
        }
        Ok(state.decoded_frames.pop_front())
    }

    fn mark_end_of_stream(&self) -> Result<(), String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado de fin del vídeo".to_string())?;
        state.end_of_stream = true;
        Ok(())
    }

    fn promote_fallback_at_end(&self) -> Result<(), String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado de seek final del vídeo".to_string())?;
        state.discard_before = None;
        let Some(mut frame) = state.fallback_frame_before_target.take() else {
            return Ok(());
        };
        if Self::queue_depth_locked(&state) >= state.max_queue_frames {
            state.fallback_frame_before_target = Some(frame);
            return Ok(());
        }
        frame.force_display = true;
        state.raw_frames.push_back(frame);
        self.wake.notify_one();
        Ok(())
    }

    fn deactivate_and_clear(&self) -> Result<(), String> {
        self.active.store(false, Ordering::Release);
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado interno al cerrar el vídeo".to_string())?;
        state.raw_frames.clear();
        state.decoded_frames.clear();
        state.fallback_frame_before_target = None;
        state.discard_before = None;
        state.last_accepted_position = None;
        state.end_of_stream = false;
        self.wake.notify_all();
        Ok(())
    }

    fn wait_for_work(&self, cancel: &AtomicBool) -> Result<(), String> {
        if cancel.load(Ordering::Acquire) || !self.active.load(Ordering::Acquire) {
            return Ok(());
        }
        let state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado al esperar trabajo de vídeo".to_string())?;
        if cancel.load(Ordering::Acquire)
            || !self.active.load(Ordering::Acquire)
            || !state.raw_frames.is_empty()
        {
            return Ok(());
        }
        let _ = self
            .wake
            .wait_timeout(state, Duration::from_millis(10))
            .map_err(|_| "se corrompió el estado al esperar trabajo de vídeo".to_string())?;
        Ok(())
    }

    #[cfg(test)]
    fn snapshot_playback_state(&self) -> Result<(bool, usize, bool), String> {
        let state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado de reproducción del vídeo".to_string())?;
        Ok((
            state.end_of_stream,
            state.decoded_frames.len(),
            Self::queue_depth_locked(&state) == 0,
        ))
    }

    fn ready_status(
        &self,
        ready_event_sent: &AtomicBool,
    ) -> Result<Option<VideoDecoderStatus>, String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado de precarga del vídeo".to_string())?;
        if state.ready_sent {
            return Ok(None);
        }
        let enough_buffered_time = buffered_duration_locked(&state) >= VIDEO_READY_BUFFER;
        let short_video_ready = state.end_of_stream
            && state.raw_frames.is_empty()
            && state.processing_frames == 0
            && !state.decoded_frames.is_empty();
        if !(enough_buffered_time || short_video_ready) {
            return Ok(None);
        }
        state.ready_sent = true;
        let size = state.size;
        let duration = state.duration;
        let status = if !ready_event_sent.swap(true, Ordering::AcqRel) {
            VideoDecoderStatus::Ready {
                generation: self.generation,
                size,
                duration,
            }
        } else {
            VideoDecoderStatus::BufferReady {
                generation: self.generation,
            }
        };
        Ok(Some(status))
    }

    fn needs_more_decoding(&self, playing: bool) -> Result<bool, String> {
        let state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado de precarga del vídeo".to_string())?;
        if !self.active.load(Ordering::Acquire)
            || state.end_of_stream
            || state.raw_frames.len() >= VIDEO_RAW_SAMPLE_QUEUE_CAPACITY
            || Self::queue_depth_locked(&state) >= state.max_queue_frames
        {
            return Ok(false);
        }
        let next_frame_bytes = frame_payload_bytes(state.size)?;
        if !video_process_memory_allows(next_frame_bytes)? {
            return Ok(false);
        }
        if !state.ready_sent {
            return Ok(true);
        }
        Ok(playing && buffered_duration_locked(&state) < VIDEO_TARGET_BUFFER)
    }

    fn empty_eos_failure(&self) -> Result<Option<String>, String> {
        let mut state = self
            .state
            .lock()
            .map_err(|_| "se corrompió el estado de fin del vídeo".to_string())?;
        if state.failure_sent
            || !state.end_of_stream
            || !state.raw_frames.is_empty()
            || !state.decoded_frames.is_empty()
            || state.processing_frames != 0
            || state.fallback_frame_before_target.is_some()
            || state.saw_any_frame
        {
            return Ok(None);
        }
        state.failure_sent = true;
        Ok(Some(
            "Media Foundation no devolvió ningún fotograma de vídeo".into(),
        ))
    }
}

#[derive(Debug)]
struct AsyncReaderSession {
    reader: IMFSourceReader,
    context: Arc<VideoGenerationBuffers>,
    _callback: IMFSourceReaderCallback,
    callback_in_flight: Arc<AtomicUsize>,
}

#[windows_core::implement(IMFSourceReaderCallback)]
struct AsyncSourceReaderCallback {
    context: Arc<VideoGenerationBuffers>,
    signal_sender: Sender<ReaderSignal>,
    callback_in_flight: Arc<AtomicUsize>,
}

struct CallbackActivityGuard {
    counter: Arc<AtomicUsize>,
}

impl CallbackActivityGuard {
    fn enter(counter: &Arc<AtomicUsize>) -> Self {
        counter.fetch_add(1, Ordering::AcqRel);
        Self {
            counter: Arc::clone(counter),
        }
    }
}

impl Drop for CallbackActivityGuard {
    fn drop(&mut self) {
        self.counter.fetch_sub(1, Ordering::Release);
    }
}

impl IMFSourceReaderCallback_Impl for AsyncSourceReaderCallback_Impl {
    fn OnReadSample(
        &self,
        hrstatus: HRESULT,
        _dwstreamindex: u32,
        dwstreamflags: u32,
        lltimestamp: i64,
        psample: Ref<'_, IMFSample>,
    ) -> WindowsCoreResult<()> {
        if !self.context.active.load(Ordering::Acquire) {
            return Ok(());
        }
        let _activity_guard = CallbackActivityGuard::enter(&self.callback_in_flight);
        if hrstatus.0 < 0 {
            let _ = self.signal_sender.send(ReaderSignal::Failed {
                generation: self.context.generation,
                message: format!("Media Foundation devolvió un error de lectura: {hrstatus:?}"),
            });
            return Ok(());
        }
        if dwstreamflags & MF_SOURCE_READERF_ERROR.0 as u32 != 0 {
            let _ = self.signal_sender.send(ReaderSignal::Failed {
                generation: self.context.generation,
                message: "Media Foundation indicó un error irrecuperable en la lectura del vídeo"
                    .into(),
            });
            return Ok(());
        }
        if dwstreamflags
            & (MF_SOURCE_READERF_CURRENTMEDIATYPECHANGED.0 as u32
                | MF_SOURCE_READERF_NATIVEMEDIATYPECHANGED.0 as u32)
            != 0
        {
            let _ = self.signal_sender.send(ReaderSignal::ReadCompleted {
                generation: self.context.generation,
                outcome: ReaderReadOutcome::MediaTypeChanged,
            });
            return Ok(());
        }
        if dwstreamflags & MF_SOURCE_READERF_ENDOFSTREAM.0 as u32 != 0 {
            let _ = self.signal_sender.send(ReaderSignal::ReadCompleted {
                generation: self.context.generation,
                outcome: ReaderReadOutcome::EndOfStream,
            });
            return Ok(());
        }
        // `ReadSample` accepts MF_SOURCE_READER_FIRST_VIDEO_STREAM as a selector,
        // but OnReadSample reports the actual zero-based stream index that delivered
        // the sample. Those are different values (the selector is 0xFFFFFFFC), so
        // comparing dwStreamIndex with the selector would reject every normal video
        // sample and drain the file until EOS without displaying a frame.
        // This callback is registered for a ReadSample request targeting the first
        // video stream, so a normal sample reaching this point is the requested video
        // sample.

        let position = timestamp_to_duration(lltimestamp);
        let should_copy = match self.context.should_copy_sample(position) {
            Ok(value) => value,
            Err(error) => {
                let _ = self.signal_sender.send(ReaderSignal::Failed {
                    generation: self.context.generation,
                    message: error,
                });
                return Ok(());
            }
        };
        if !should_copy {
            let _ = self.signal_sender.send(ReaderSignal::ReadCompleted {
                generation: self.context.generation,
                outcome: ReaderReadOutcome::Accepted,
            });
            return Ok(());
        }

        let Some(sample) = psample.as_ref() else {
            let _ = self.signal_sender.send(ReaderSignal::ReadCompleted {
                generation: self.context.generation,
                outcome: ReaderReadOutcome::NoSample,
            });
            return Ok(());
        };

        let (size, default_stride) = match self.context.layout() {
            Ok(layout) => layout,
            Err(error) => {
                let _ = self.signal_sender.send(ReaderSignal::Failed {
                    generation: self.context.generation,
                    message: error,
                });
                return Ok(());
            }
        };
        let expected = match frame_payload_bytes(size) {
            Ok(bytes) => bytes,
            Err(error) => {
                let _ = self.signal_sender.send(ReaderSignal::Failed {
                    generation: self.context.generation,
                    message: error,
                });
                return Ok(());
            }
        };
        match video_process_memory_allows(expected) {
            Ok(true) => {}
            Ok(false) => {
                let _ = self.signal_sender.send(ReaderSignal::ReadCompleted {
                    generation: self.context.generation,
                    outcome: ReaderReadOutcome::Accepted,
                });
                return Ok(());
            }
            Err(error) => {
                let _ = self.signal_sender.send(ReaderSignal::Failed {
                    generation: self.context.generation,
                    message: error,
                });
                return Ok(());
            }
        }
        let bgra = match copy_sample_to_packed_bgra(sample, size, default_stride) {
            Ok(bgra) => bgra,
            Err(error) => {
                let _ = self.signal_sender.send(ReaderSignal::Failed {
                    generation: self.context.generation,
                    message: error,
                });
                return Ok(());
            }
        };
        if !self.context.active.load(Ordering::Acquire) {
            return Ok(());
        }
        let frame = RawVideoFrame {
            bgra,
            size,
            position,
            generation: self.context.generation,
            force_display: false,
        };
        if let Err(error) = self.context.push_raw_frame(frame) {
            let _ = self.signal_sender.send(ReaderSignal::Failed {
                generation: self.context.generation,
                message: error,
            });
            return Ok(());
        }
        let _ = self.signal_sender.send(ReaderSignal::ReadCompleted {
            generation: self.context.generation,
            outcome: ReaderReadOutcome::Accepted,
        });
        Ok(())
    }

    fn OnFlush(&self, _dwstreamindex: u32) -> WindowsCoreResult<()> {
        let _ = self.signal_sender.send(ReaderSignal::FlushCompleted {
            generation: self.context.generation,
        });
        Ok(())
    }

    fn OnEvent(
        &self,
        _dwstreamindex: u32,
        _pevent: windows::core::Ref<'_, IMFMediaEvent>,
    ) -> windows::core::Result<()> {
        Ok(())
    }
}

fn timestamp_to_duration(timestamp: i64) -> Duration {
    if timestamp <= 0 {
        Duration::ZERO
    } else {
        Duration::from_nanos((timestamp as u64).saturating_mul(100))
    }
}

fn validate_preview_source_file(path: &Path) -> Result<(), String> {
    let metadata = fs::symlink_metadata(path)
        .map_err(|error| format!("no se pudo validar el vídeo de vista previa: {error}"))?;
    if !metadata.is_file() {
        return Err("el origen temporal de la vista previa no es un archivo normal".into());
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0400;
        if metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0 {
            return Err(
                "el origen temporal de la vista previa no puede ser un punto de reanálisis".into(),
            );
        }
    }
    Ok(())
}

fn decrypt_preview_file(
    source_path: &Path,
    preview_path: &Path,
    key: &Zeroizing<[u8; 32]>,
) -> Result<(), String> {
    opac_window_core::modules::vault_fs::decrypt_file_from_vault(source_path, key, preview_path)
        .map(|_| ())
        .map_err(|error| format!("no se pudo descifrar el vídeo para la vista previa: {error}"))
}

fn run_video_decoder(worker: VideoDecoderWorker) -> Result<(), String> {
    let com_hr = unsafe { CoInitializeEx(None, COINIT_MULTITHREADED) };
    if com_hr.0 < 0 {
        return Err(format!(
            "no se pudo inicializar COM para vídeo (HRESULT 0x{:08X})",
            com_hr.0 as u32,
        ));
    }

    let mf_started = unsafe { MFStartup(MF_VERSION, MFSTARTUP_FULL) };
    if let Err(error) = mf_started {
        unsafe { CoUninitialize() };
        return Err(format!("no se pudo iniciar Media Foundation: {error}"));
    }

    let result = run_video_decoder_loop(&worker);

    unsafe {
        let _ = MFShutdown();
        CoUninitialize();
    }
    result
}

fn run_video_decoder_loop(worker: &VideoDecoderWorker) -> Result<(), String> {
    let mut session = create_async_reader_session(
        &worker.preview_path,
        worker.control_generation.load(Ordering::Acquire),
        Arc::clone(&worker.ready_event_sent),
        worker.reader_signal_sender.clone(),
    )?;
    publish_current_context(&worker.current_context, session.context.clone())?;
    request_async_sample(&session.reader)?;
    let mut read_pending = true;

    loop {
        if worker.cancel.load(Ordering::Acquire) {
            shutdown_reader_session(session, &worker.reader_signal_receiver, &worker.cancel)?;
            clear_current_context(&worker.current_context)?;
            return Ok(());
        }

        if let Some((requested_generation, command)) = take_video_control(&worker.control)? {
            shutdown_reader_session(session, &worker.reader_signal_receiver, &worker.cancel)?;
            if worker.cancel.load(Ordering::Acquire) {
                clear_current_context(&worker.current_context)?;
                return Ok(());
            }
            let new_session = create_async_reader_session(
                &worker.preview_path,
                requested_generation,
                Arc::clone(&worker.ready_event_sent),
                worker.reader_signal_sender.clone(),
            )?;
            match command {
                VideoControlCommand::Restart => {
                    new_session.context.set_discard_before(None)?;
                }
                VideoControlCommand::Seek(target) => {
                    let clamped = new_session
                        .context
                        .duration()?
                        .map(|duration| target.min(duration))
                        .unwrap_or(target);
                    new_session.context.set_discard_before(Some(clamped))?;
                    set_reader_position(&new_session.reader, clamped)?;
                }
            }
            publish_current_context(&worker.current_context, new_session.context.clone())?;
            request_async_sample(&new_session.reader)?;
            session = new_session;
            read_pending = true;
            continue;
        }

        if !read_pending
            && session
                .context
                .needs_more_decoding(worker.playing.load(Ordering::Acquire))?
        {
            request_async_sample(&session.reader)?;
            read_pending = true;
        }

        match worker
            .reader_signal_receiver
            .recv_timeout(CONTROL_POLL_SLICE)
        {
            Ok(ReaderSignal::ReadCompleted {
                generation,
                outcome,
            }) if generation == session.context.generation => {
                read_pending = false;
                match outcome {
                    ReaderReadOutcome::Accepted | ReaderReadOutcome::NoSample => {}
                    ReaderReadOutcome::MediaTypeChanged => {
                        wait_for_reader_callback_quiescence(
                            &session.callback_in_flight,
                            &worker.cancel,
                        )?;
                        ensure_preview_output_type(
                            &session.reader,
                            session.context.requested_size()?,
                        )?;
                        let (size, stride) = read_video_layout(&session.reader)?;
                        let requested = session.context.requested_size()?;
                        if size[0] > requested[0] || size[1] > requested[1] {
                            return Err("Media Foundation cambió la salida a una resolución superior a la solicitada".into());
                        }
                        session.context.set_layout(size, stride)?;
                    }
                    ReaderReadOutcome::EndOfStream => {
                        session.context.mark_end_of_stream()?;
                        session.context.promote_fallback_at_end()?;
                        if let Some(error) = session.context.empty_eos_failure()? {
                            return Err(error);
                        }
                        let _ = worker
                            .status_sender
                            .send(VideoDecoderStatus::EndOfStream { generation });
                    }
                }
            }
            Ok(ReaderSignal::FlushCompleted { .. }) => {}
            Ok(ReaderSignal::Failed {
                generation,
                message,
            }) if generation == session.context.generation => {
                return Err(message);
            }
            Ok(_) => {}
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                return Err(
                    "el canal interno del decodificador de vídeo terminó inesperadamente".into(),
                );
            }
        }
    }
}

fn publish_current_context(
    current_context: &Mutex<Option<Arc<VideoGenerationBuffers>>>,
    context: Arc<VideoGenerationBuffers>,
) -> Result<(), String> {
    let mut slot = current_context
        .lock()
        .map_err(|_| "se corrompió el contexto compartido del vídeo".to_string())?;
    if let Some(old) = slot.replace(context) {
        let _ = old.deactivate_and_clear();
    }
    Ok(())
}

fn clear_current_context(
    current_context: &Mutex<Option<Arc<VideoGenerationBuffers>>>,
) -> Result<(), String> {
    let mut slot = current_context
        .lock()
        .map_err(|_| "se corrompió el contexto compartido al cerrar el vídeo".to_string())?;
    if let Some(old) = slot.take() {
        let _ = old.deactivate_and_clear();
    }
    Ok(())
}

fn create_async_reader_session(
    preview_path: &Path,
    generation: u64,
    _ready_event_sent: Arc<AtomicBool>,
    signal_sender: Sender<ReaderSignal>,
) -> Result<AsyncReaderSession, String> {
    use std::os::windows::ffi::OsStrExt;

    let wide = preview_path
        .as_os_str()
        .encode_wide()
        .chain(std::iter::once(0))
        .collect::<Vec<_>>();

    let mut attributes = None;
    unsafe {
        MFCreateAttributes(&mut attributes, 3)
            .map_err(|error| format!("no se pudieron crear los atributos multimedia: {error}"))?;
    }
    let attributes = attributes
        .ok_or_else(|| "Media Foundation no devolvió los atributos multimedia".to_string())?;

    let provisional_context = VideoGenerationBuffers::new(
        generation,
        [2, 2],
        FRAME_BYTES_PER_PIXEL as i32 * 2,
        None,
        [2, 2],
    );
    let callback_in_flight = Arc::new(AtomicUsize::new(0));
    let callback_object = AsyncSourceReaderCallback {
        context: Arc::clone(&provisional_context),
        signal_sender,
        callback_in_flight: Arc::clone(&callback_in_flight),
    };
    let callback: IMFSourceReaderCallback = callback_object.into();

    unsafe {
        attributes
            .SetUINT32(&MF_SOURCE_READER_ENABLE_ADVANCED_VIDEO_PROCESSING, 1)
            .map_err(|error| {
                format!("no se pudo habilitar el procesamiento avanzado de vídeo: {error}")
            })?;
        attributes
            .SetUINT32(&MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS, 1)
            .map_err(|error| {
                format!("no se pudieron habilitar las transformaciones hardware de Media Foundation: {error}")
            })?;
        attributes
            .SetUnknown(&MF_SOURCE_READER_ASYNC_CALLBACK, &callback)
            .map_err(|error| {
                format!("no se pudo configurar el callback asíncrono de Media Foundation: {error}")
            })?;
    }

    let reader = unsafe {
        MFCreateSourceReaderFromURL(PCWSTR(wide.as_ptr()), &attributes)
            .map_err(|error| format!("Media Foundation no admite este vídeo: {error}"))?
    };

    let native_media_type = unsafe {
        reader
            .GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM.0 as u32)
            .map_err(|error| format!("no se pudo consultar el tamaño nativo del vídeo: {error}"))?
    };
    let native_packed = unsafe {
        native_media_type
            .GetUINT64(&MF_MT_FRAME_SIZE)
            .map_err(|error| {
                format!("el vídeo no expone unas dimensiones nativas válidas: {error}")
            })?
    };
    let native_width = (native_packed >> 32) as u32;
    let native_height = (native_packed & 0xffff_ffff) as u32;
    if native_width == 0 || native_height == 0 {
        return Err("el vídeo tiene unas dimensiones nativas inválidas".into());
    }
    if native_width > MAX_FRAME_DIMENSION || native_height > MAX_FRAME_DIMENSION {
        return Err(format!(
            "las dimensiones nativas superan el límite de {MAX_FRAME_DIMENSION} px por eje"
        ));
    }
    if u64::from(native_width) * u64::from(native_height) > MAX_FRAME_PIXELS {
        return Err(format!(
            "el fotograma nativo supera el límite de {} millones de píxeles",
            MAX_FRAME_PIXELS / 1_000_000
        ));
    }
    let (preview_width, preview_height) = scaled_preview_dimensions(
        native_width,
        native_height,
        MAX_PREVIEW_WIDTH,
        MAX_PREVIEW_HEIGHT,
    )?;
    provisional_context.set_requested_size([preview_width as usize, preview_height as usize])?;

    let media_type = unsafe {
        MFCreateMediaType()
            .map_err(|error| format!("no se pudo crear el tipo de salida de vídeo: {error}"))?
    };
    unsafe {
        media_type
            .SetGUID(&MF_MT_MAJOR_TYPE, &MFMediaType_Video)
            .map_err(|error| format!("no se pudo seleccionar el tipo de vídeo: {error}"))?;
        media_type
            .SetGUID(&MF_MT_SUBTYPE, &MFVideoFormat_RGB32)
            .map_err(|error| format!("no se pudo solicitar salida RGB32: {error}"))?;
        let preview_packed = (u64::from(preview_width) << 32) | u64::from(preview_height);
        media_type
            .SetUINT64(&MF_MT_FRAME_SIZE, preview_packed)
            .map_err(|error| {
                format!("no se pudo limitar la resolución de vista previa: {error}")
            })?;
        reader
            .SetCurrentMediaType(
                MF_SOURCE_READER_FIRST_VIDEO_STREAM.0 as u32,
                None,
                &media_type,
            )
            .map_err(|error| format!("Windows no pudo convertir el vídeo a RGB32: {error}"))?;
    }

    let (size, stride) = read_video_layout(&reader)?;
    let requested = provisional_context.requested_size()?;
    if size[0] > requested[0] || size[1] > requested[1] {
        return Err(
            "Media Foundation devolvió una resolución de salida superior a la solicitada".into(),
        );
    }
    let duration = read_video_duration(&reader);
    provisional_context.set_layout(size, stride)?;
    {
        let mut state = provisional_context
            .state
            .lock()
            .map_err(|_| "se corrompió el estado al preparar la vista previa".to_string())?;
        state.duration = duration;
    }

    Ok(AsyncReaderSession {
        reader,
        context: provisional_context,
        _callback: callback,
        callback_in_flight,
    })
}

fn request_async_sample(reader: &IMFSourceReader) -> Result<(), String> {
    unsafe {
        reader
            .ReadSample(
                MF_SOURCE_READER_FIRST_VIDEO_STREAM.0 as u32,
                0,
                None,
                None,
                None,
                None,
            )
            .map_err(|error| {
                format!("Media Foundation no pudo solicitar el siguiente fotograma: {error}")
            })?;
    }
    Ok(())
}

fn set_reader_position(reader: &IMFSourceReader, target: Duration) -> Result<(), String> {
    let hns = i64::try_from(target.as_nanos() / 100).map_err(|_| {
        "la posición solicitada está fuera del rango soportado por Media Foundation".to_string()
    })?;
    let position = PROPVARIANT::from(hns);
    let guid_time_format = GUID::zeroed();
    unsafe {
        reader
            .SetCurrentPosition(&guid_time_format, &position)
            .map_err(|error| {
                format!("Media Foundation no pudo cambiar la posición del vídeo: {error}")
            })?;
    }
    Ok(())
}

fn shutdown_reader_session(
    session: AsyncReaderSession,
    signal_receiver: &Receiver<ReaderSignal>,
    cancel: &AtomicBool,
) -> Result<(), String> {
    let generation = session.context.generation;
    session.context.deactivate_and_clear()?;

    let flush_result = unsafe {
        session
            .reader
            .Flush(MF_SOURCE_READER_FIRST_VIDEO_STREAM.0 as u32)
    };
    let flush_error = flush_result
        .err()
        .map(|error| format!("Media Foundation no pudo cancelar la lectura del vídeo: {error}"));

    let deadline = Instant::now() + Duration::from_secs(2);
    let mut flush_completed = false;
    while Instant::now() < deadline {
        match signal_receiver.recv_timeout(Duration::from_millis(20)) {
            Ok(ReaderSignal::FlushCompleted {
                generation: completed_generation,
            }) if completed_generation == generation => {
                flush_completed = true;
                break;
            }
            Ok(_) => {}
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(mpsc::RecvTimeoutError::Disconnected) => break,
        }
    }

    // `session` is owned by this function, so dropping it here releases the
    // local Media Foundation reader/callback references immediately. The old
    // implementation received `&mut AsyncReaderSession` and `drop(session)`
    // only dropped the reference, leaving the reader alive until the caller
    // reassigned it. That made every seek/restart pay the full callback
    // shutdown grace period in many cases.
    drop(session);

    if let Some(error) = flush_error {
        if cancel.load(Ordering::Acquire) {
            return Ok(());
        }
        return Err(error);
    }
    if !flush_completed && !cancel.load(Ordering::Acquire) {
        return Err(
            "Media Foundation no confirmó a tiempo el cierre de la lectura anterior".into(),
        );
    }
    Ok(())
}

fn run_video_frame_processor(
    current_context: Arc<Mutex<Option<Arc<VideoGenerationBuffers>>>>,
    cancel: Arc<AtomicBool>,
    status_sender: Sender<VideoDecoderStatus>,
    ready_event_sent: Arc<AtomicBool>,
) {
    while !cancel.load(Ordering::Acquire) {
        let context = current_context
            .lock()
            .ok()
            .and_then(|slot| slot.as_ref().cloned());
        let Some(context) = context else {
            thread::sleep(CONTROL_POLL_SLICE);
            continue;
        };
        if !context.active.load(Ordering::Acquire) {
            thread::sleep(CONTROL_POLL_SLICE);
            continue;
        }

        match context.pop_raw_frame() {
            Ok(Some(mut raw)) => {
                convert_packed_bgra_to_rgba_in_place(&mut raw.bgra);
                if let Err(error) = context.finish_processing(raw) {
                    let _ = status_sender.send(VideoDecoderStatus::Failed(error));
                    context.active.store(false, Ordering::Release);
                    continue;
                }
                if let Ok(Some(status)) = context.ready_status(&ready_event_sent) {
                    let _ = status_sender.send(status);
                }
            }
            Ok(None) => {
                if let Ok(Some(error)) = context.empty_eos_failure() {
                    let _ = status_sender.send(VideoDecoderStatus::Failed(error));
                    context.active.store(false, Ordering::Release);
                    continue;
                }
                let _ = context.wait_for_work(&cancel);
            }
            Err(error) => {
                let _ = status_sender.send(VideoDecoderStatus::Failed(error));
                context.active.store(false, Ordering::Release);
            }
        }
    }
}

fn run_video_playback_loop(
    worker: &VideoPreviewWorker,
    current_context: Arc<Mutex<Option<Arc<VideoGenerationBuffers>>>>,
    status_receiver: Receiver<VideoDecoderStatus>,
) -> Result<(), String> {
    let owns_temp = worker.decrypt_source;
    let (size, duration, ready_generation) = loop {
        if worker.cancel.load(Ordering::Acquire) {
            return Ok(());
        }
        let expected_generation = worker.control_generation.load(Ordering::Acquire);
        match status_receiver.recv_timeout(CONTROL_POLL_SLICE) {
            Ok(VideoDecoderStatus::Ready {
                generation,
                size,
                duration,
            }) if generation == expected_generation => {
                break (size, duration, generation);
            }
            Ok(VideoDecoderStatus::BufferReady { generation })
                if generation == expected_generation => {}
            Ok(VideoDecoderStatus::EndOfStream { .. }) => {}
            Ok(VideoDecoderStatus::Failed(error)) => return Err(error),
            Ok(_) => {}
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                return Err("el coordinador de vídeo terminó inesperadamente".into());
            }
        }
    };

    send_blocking_cancelable(
        &worker.sender,
        VideoPreviewEvent::Ready {
            source_path: worker.source_path.clone(),
            preview_path: worker.preview_path.clone(),
            owns_temp,
            size,
            duration,
        },
        &worker.cancel,
    )?;

    let mut buffered_frames = VecDeque::<DecodedVideoFrame>::with_capacity(FRAME_QUEUE_CAPACITY);
    let mut observed_generation = ready_generation;
    let mut end_of_stream = false;
    let mut initial_frame_pending = true;
    let mut awaiting_buffer_ready = false;
    let mut playback_anchor = None::<Instant>;
    let mut last_presented_position = None::<Duration>;

    loop {
        if worker.cancel.load(Ordering::Acquire) {
            return Ok(());
        }

        let current_generation = worker.control_generation.load(Ordering::Acquire);
        if current_generation != observed_generation {
            observed_generation = current_generation;
            buffered_frames.clear();
            end_of_stream = false;
            playback_anchor = None;
            awaiting_buffer_ready = true;
            initial_frame_pending = true;
            last_presented_position = None;
        }

        if let Some(context) = current_video_context(&current_context)?
            && context.generation == current_generation
        {
            while buffered_frames.len() < FRAME_QUEUE_CAPACITY {
                let Some(frame) = context.pop_decoded_frame()? else {
                    break;
                };
                if frame.generation == current_generation {
                    buffered_frames.push_back(frame);
                }
            }
        }

        while let Ok(status) = status_receiver.try_recv() {
            match status {
                VideoDecoderStatus::Ready {
                    generation,
                    size: _,
                    duration: _,
                } if generation == current_generation => {
                    awaiting_buffer_ready = false;
                }
                VideoDecoderStatus::BufferReady { generation }
                    if generation == current_generation =>
                {
                    awaiting_buffer_ready = false;
                }
                VideoDecoderStatus::EndOfStream { generation }
                    if generation == current_generation =>
                {
                    end_of_stream = true;
                }
                VideoDecoderStatus::Failed(error) => return Err(error),
                _ => {}
            }
        }

        if initial_frame_pending
            && !awaiting_buffer_ready
            && let Some(frame) = buffered_frames.pop_front()
            && frame.generation == current_generation
        {
            initial_frame_pending = false;
            let position = frame.position;
            match try_send_video_frame(worker, frame) {
                Ok(()) => {
                    last_presented_position = Some(position);
                }
                Err(SendVideoFrameError::Full(frame)) => {
                    buffered_frames.push_front(frame);
                    initial_frame_pending = true;
                    thread::sleep(CONTROL_POLL_SLICE);
                }
                Err(SendVideoFrameError::Disconnected) => return Ok(()),
            }
        }

        let playing = worker.playing.load(Ordering::Acquire);
        if !playing {
            playback_anchor = None;
            thread::sleep(CONTROL_POLL_SLICE);
            continue;
        }

        if buffered_frames.is_empty() {
            if end_of_stream {
                worker.playing.store(false, Ordering::Release);
                send_blocking_cancelable(
                    &worker.sender,
                    VideoPreviewEvent::Ended {
                        source_path: worker.source_path.clone(),
                        generation: current_generation,
                    },
                    &worker.cancel,
                )?;
                end_of_stream = false;
                initial_frame_pending = true;
            } else {
                thread::sleep(CONTROL_POLL_SLICE.min(Duration::from_millis(4)));
            }
            continue;
        }

        let audio_active = worker.audio_clock_active.load(Ordering::Acquire);
        let audio_pending = worker.audio_clock_pending.load(Ordering::Acquire);
        if audio_pending && !audio_active {
            playback_anchor = None;
            thread::sleep(CONTROL_POLL_SLICE.min(Duration::from_millis(8)));
            continue;
        }
        if audio_active {
            let audio_position = load_audio_clock(&worker.audio_clock_nanos).unwrap_or_else(|| {
                buffered_frames
                    .front()
                    .map(|frame| frame.position)
                    .unwrap_or(Duration::ZERO)
            });
            let current_generation = worker.control_generation.load(Ordering::Acquire);
            if let Some(front) = buffered_frames.front()
                && front.generation != current_generation
            {
                observed_generation = current_generation;
                buffered_frames.clear();
                initial_frame_pending = true;
                awaiting_buffer_ready = true;
                playback_anchor = None;
                continue;
            }

            let Some(front) = buffered_frames.front() else {
                continue;
            };
            match if front.force_display {
                VideoSyncAction::Render
            } else {
                decide_video_sync(front.position, audio_position)
            } {
                VideoSyncAction::Render => {
                    let frame = buffered_frames.pop_front().expect("front frame exists");
                    if frame.force_display
                        || last_presented_position
                            .map(|last| {
                                frame.position.saturating_sub(last) >= video_frame_interval()
                            })
                            .unwrap_or(true)
                    {
                        let position = frame.position;
                        match try_send_video_frame(worker, frame) {
                            Ok(()) => {
                                last_presented_position = Some(position);
                            }
                            Err(SendVideoFrameError::Full(frame)) => {
                                buffered_frames.push_front(frame);
                                thread::sleep(CONTROL_POLL_SLICE);
                            }
                            Err(SendVideoFrameError::Disconnected) => return Ok(()),
                        }
                    }
                }
                VideoSyncAction::Wait => {
                    sleep_until_audio_position(
                        front.position,
                        &AudioWaitContext {
                            clock_nanos: &worker.audio_clock_nanos,
                            audio_clock_active: &worker.audio_clock_active,
                            cancel: &worker.cancel,
                            playing: &worker.playing,
                            control_generation: &worker.control_generation,
                            expected_generation: current_generation,
                        },
                    );
                }
                VideoSyncAction::Drop => {
                    buffered_frames.pop_front();
                }
                VideoSyncAction::Resync(target) => {
                    buffered_frames.clear();
                    let generation = publish_video_control(
                        &worker.control,
                        &worker.control_generation,
                        VideoControlCommand::Seek(target),
                    )?;
                    observed_generation = generation;
                    end_of_stream = false;
                    initial_frame_pending = true;
                    awaiting_buffer_ready = true;
                    playback_anchor = None;
                    last_presented_position = None;
                }
            }
            continue;
        }

        let position = buffered_frames
            .front()
            .map(|frame| frame.position)
            .unwrap_or(Duration::ZERO);
        let target = if let Some(anchor) = playback_anchor {
            anchor + position
        } else {
            let anchor = Instant::now()
                .checked_sub(position)
                .unwrap_or_else(Instant::now);
            playback_anchor = Some(anchor);
            anchor + position
        };
        sleep_until_or_control(
            target,
            &worker.cancel,
            &worker.playing,
            &worker.control_generation,
            current_generation,
        );

        if worker.cancel.load(Ordering::Acquire) || !worker.playing.load(Ordering::Acquire) {
            playback_anchor = None;
            continue;
        }

        let current_generation = worker.control_generation.load(Ordering::Acquire);
        let Some(frame) = buffered_frames.pop_front() else {
            continue;
        };
        if frame.generation != current_generation {
            continue;
        }
        let should_present = frame.force_display
            || last_presented_position
                .map(|last| frame.position.saturating_sub(last) >= video_frame_interval())
                .unwrap_or(true);
        if !should_present {
            continue;
        }
        let position = frame.position;
        match try_send_video_frame(worker, frame) {
            Ok(()) => {
                last_presented_position = Some(position);
            }
            Err(SendVideoFrameError::Full(frame)) => {
                buffered_frames.push_front(frame);
                thread::sleep(CONTROL_POLL_SLICE);
            }
            Err(SendVideoFrameError::Disconnected) => return Ok(()),
        }
    }
}

fn current_video_context(
    current_context: &Mutex<Option<Arc<VideoGenerationBuffers>>>,
) -> Result<Option<Arc<VideoGenerationBuffers>>, String> {
    let slot = current_context
        .lock()
        .map_err(|_| "se corrompió el contexto compartido del vídeo".to_string())?;
    Ok(slot.as_ref().cloned())
}

enum SendVideoFrameError {
    Full(DecodedVideoFrame),
    Disconnected,
}

fn try_send_video_frame(
    worker: &VideoPreviewWorker,
    frame: DecodedVideoFrame,
) -> Result<(), SendVideoFrameError> {
    let force_display = frame.force_display;
    match worker.sender.try_send(VideoPreviewEvent::Frame {
        source_path: worker.source_path.clone(),
        rgba: frame.rgba,
        size: frame.size,
        position: frame.position,
        generation: frame.generation,
    }) {
        Ok(()) => Ok(()),
        Err(TrySendError::Full(event)) => {
            let VideoPreviewEvent::Frame {
                rgba,
                size,
                position,
                generation,
                ..
            } = event
            else {
                return Err(SendVideoFrameError::Disconnected);
            };
            Err(SendVideoFrameError::Full(DecodedVideoFrame {
                rgba,
                size,
                position,
                generation,
                force_display,
            }))
        }
        Err(TrySendError::Disconnected(_)) => Err(SendVideoFrameError::Disconnected),
    }
}

#[derive(Debug)]
struct DecodedVideoFrame {
    rgba: Zeroizing<Vec<u8>>,
    size: [usize; 2],
    position: Duration,
    generation: u64,
    force_display: bool,
}

fn convert_packed_bgra_to_rgba_in_place(buffer: &mut [u8]) {
    let (pixels, _remainder) = buffer.as_chunks_mut::<4>();
    for pixel in pixels {
        pixel.swap(0, 2);
        pixel[3] = 255;
    }
}

#[cfg(test)]
#[test]
fn in_place_bgra_to_rgba_conversion_swaps_channels_without_a_second_buffer() {
    let mut pixels = Zeroizing::new(vec![1, 2, 3, 4, 10, 20, 30, 40]);
    convert_packed_bgra_to_rgba_in_place(&mut pixels);
    assert_eq!(&*pixels, &[3, 2, 1, 255, 30, 20, 10, 255]);
}

fn load_audio_clock(clock_nanos: &AtomicU64) -> Option<Duration> {
    let nanos = clock_nanos.load(Ordering::Acquire);
    if nanos == 0 {
        Some(Duration::ZERO)
    } else {
        Some(Duration::from_nanos(nanos))
    }
}

fn decide_video_sync(video_position: Duration, audio_position: Duration) -> VideoSyncAction {
    if video_position > audio_position {
        if video_position.saturating_sub(audio_position) > AUDIO_SYNC_TOLERANCE {
            VideoSyncAction::Wait
        } else {
            VideoSyncAction::Render
        }
    } else {
        let lag = audio_position.saturating_sub(video_position);
        if lag >= AUDIO_SYNC_HARD_RESYNC_THRESHOLD {
            VideoSyncAction::Resync(audio_position)
        } else if lag > AUDIO_SYNC_DROP_THRESHOLD {
            VideoSyncAction::Drop
        } else {
            VideoSyncAction::Render
        }
    }
}

struct AudioWaitContext<'a> {
    clock_nanos: &'a AtomicU64,
    audio_clock_active: &'a AtomicBool,
    cancel: &'a AtomicBool,
    playing: &'a AtomicBool,
    control_generation: &'a AtomicU64,
    expected_generation: u64,
}

fn sleep_until_audio_position(target: Duration, context: &AudioWaitContext<'_>) {
    loop {
        if audio_wait_should_abort(
            context.cancel,
            context.playing,
            context.audio_clock_active,
            context.control_generation,
            context.expected_generation,
        ) {
            return;
        }
        let audio_position = Duration::from_nanos(context.clock_nanos.load(Ordering::Acquire));
        if audio_position.saturating_add(AUDIO_SYNC_TOLERANCE) >= target {
            return;
        }
        thread::sleep(CONTROL_POLL_SLICE.min(Duration::from_millis(8)));
    }
}

fn audio_wait_should_abort(
    cancel: &AtomicBool,
    playing: &AtomicBool,
    audio_clock_active: &AtomicBool,
    control_generation: &AtomicU64,
    expected_generation: u64,
) -> bool {
    cancel.load(Ordering::Acquire)
        || !playing.load(Ordering::Acquire)
        || !audio_clock_active.load(Ordering::Acquire)
        || control_generation.load(Ordering::Acquire) != expected_generation
}

fn scaled_preview_dimensions(
    width: u32,
    height: u32,
    max_width: u32,
    max_height: u32,
) -> Result<(u32, u32), String> {
    if width == 0 || height == 0 || max_width == 0 || max_height == 0 {
        return Err("no se pueden calcular unas dimensiones de vista previa nulas".into());
    }

    let width_limited = u64::from(width).min(u64::from(max_width));
    let height_limited = u64::from(height).min(u64::from(max_height));
    let needs_scaling = width > max_width || height > max_height;
    if !needs_scaling {
        return Ok((width, height));
    }

    let by_width_num = u64::from(max_width);
    let by_height_num = u64::from(max_height);
    let width_ratio_den = u64::from(width);
    let height_ratio_den = u64::from(height);

    let use_width = by_width_num.saturating_mul(height_ratio_den)
        <= by_height_num.saturating_mul(width_ratio_den);
    let (mut out_width, mut out_height) = if use_width {
        let out_height = u64::from(height)
            .saturating_mul(by_width_num)
            .checked_div(width_ratio_den)
            .unwrap_or(height_limited);
        (width_limited, out_height.min(u64::from(max_height)))
    } else {
        let out_width = u64::from(width)
            .saturating_mul(by_height_num)
            .checked_div(height_ratio_den)
            .unwrap_or(width_limited);
        (out_width.min(u64::from(max_width)), height_limited)
    };

    out_width = out_width.max(2);
    out_height = out_height.max(2);
    // RGB32 is happiest with even dimensions across common decoder paths.
    out_width &= !1;
    out_height &= !1;
    if out_width == 0 || out_height == 0 {
        return Err("la resolución calculada de vista previa es inválida".into());
    }
    Ok((out_width as u32, out_height as u32))
}

fn wait_for_reader_callback_quiescence(
    callback_in_flight: &AtomicUsize,
    cancel: &AtomicBool,
) -> Result<(), String> {
    let deadline = Instant::now() + Duration::from_secs(2);
    while callback_in_flight.load(Ordering::Acquire) != 0 {
        if cancel.load(Ordering::Acquire) {
            return Ok(());
        }
        if Instant::now() >= deadline {
            return Err(
                "Media Foundation no terminó a tiempo la devolución de la muestra anterior".into(),
            );
        }
        thread::yield_now();
    }
    Ok(())
}

fn ensure_preview_output_type(
    reader: &windows::Win32::Media::MediaFoundation::IMFSourceReader,
    size: [usize; 2],
) -> Result<(), String> {
    let width = u32::try_from(size[0])
        .map_err(|_| "la anchura de vista previa no cabe en Media Foundation".to_string())?;
    let height = u32::try_from(size[1])
        .map_err(|_| "la altura de vista previa no cabe en Media Foundation".to_string())?;

    let current = unsafe {
        reader
            .GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM.0 as u32)
            .map_err(|error| format!("no se pudo consultar la salida actual de vídeo: {error}"))?
    };
    let current_subtype = unsafe {
        current
            .GetGUID(&MF_MT_SUBTYPE)
            .map_err(|error| format!("no se pudo consultar el subtipo actual de vídeo: {error}"))?
    };

    if current_subtype != MFVideoFormat_RGB32 {
        let media_type = unsafe {
            MFCreateMediaType()
                .map_err(|error| format!("no se pudo crear el tipo de salida de vídeo: {error}"))?
        };
        unsafe {
            media_type
                .SetGUID(&MF_MT_MAJOR_TYPE, &MFMediaType_Video)
                .map_err(|error| format!("no se pudo seleccionar el tipo de vídeo: {error}"))?;
            media_type
                .SetGUID(&MF_MT_SUBTYPE, &MFVideoFormat_RGB32)
                .map_err(|error| format!("no se pudo seleccionar RGB32: {error}"))?;
            let packed = (u64::from(width) << 32) | u64::from(height);
            media_type
                .SetUINT64(&MF_MT_FRAME_SIZE, packed)
                .map_err(|error| {
                    format!("no se pudo establecer la resolución de vista previa: {error}")
                })?;
            reader
                .SetCurrentMediaType(
                    MF_SOURCE_READER_FIRST_VIDEO_STREAM.0 as u32,
                    None,
                    &media_type,
                )
                .map_err(|error| {
                    format!("no se pudo restaurar la salida RGB32 del vídeo: {error}")
                })?;
        }
    }

    Ok(())
}

fn read_video_duration(
    reader: &windows::Win32::Media::MediaFoundation::IMFSourceReader,
) -> Option<Duration> {
    let value = unsafe {
        reader
            .GetPresentationAttribute(0xffff_ffff, &MF_PD_DURATION)
            .ok()?
    };
    let ticks = i64::try_from(&value).ok()?;
    if ticks <= 0 {
        return None;
    }
    Some(Duration::from_nanos((ticks as u64).saturating_mul(100)))
}

fn read_video_layout(
    reader: &windows::Win32::Media::MediaFoundation::IMFSourceReader,
) -> Result<([usize; 2], i32), String> {
    let media_type = unsafe {
        reader
            .GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM.0 as u32)
            .map_err(|error| format!("no se pudo obtener el tamaño del vídeo: {error}"))?
    };
    let packed = unsafe {
        media_type
            .GetUINT64(&MF_MT_FRAME_SIZE)
            .map_err(|error| format!("el vídeo no expone unas dimensiones válidas: {error}"))?
    };
    let width = (packed >> 32) as u32;
    let height = (packed & 0xffff_ffff) as u32;

    if width == 0 || height == 0 {
        return Err("el vídeo tiene dimensiones inválidas".into());
    }
    if width > MAX_FRAME_DIMENSION || height > MAX_FRAME_DIMENSION {
        return Err(format!(
            "las dimensiones del vídeo superan el límite de {MAX_FRAME_DIMENSION} px por eje"
        ));
    }
    if u64::from(width) * u64::from(height) > MAX_FRAME_PIXELS {
        return Err(format!(
            "el fotograma supera el límite de {} millones de píxeles",
            MAX_FRAME_PIXELS / 1_000_000
        ));
    }

    let row_bytes = u64::from(width)
        .checked_mul(FRAME_BYTES_PER_PIXEL as u64)
        .ok_or_else(|| "el ancho del fotograma desborda el límite interno".to_string())?;
    let fallback_stride = i32::try_from(row_bytes)
        .map_err(|_| "el stride del fotograma no cabe en el formato esperado".to_string())?;
    let default_stride = unsafe {
        media_type
            .GetUINT32(&MF_MT_DEFAULT_STRIDE)
            .map(|value| value as i32)
            .unwrap_or(fallback_stride)
    };
    let stride = if default_stride == 0 {
        fallback_stride
    } else {
        default_stride
    };

    let abs_stride = i64::from(stride).unsigned_abs();
    if abs_stride < row_bytes || abs_stride == 0 {
        return Err(format!(
            "Media Foundation devolvió un stride inválido ({stride} bytes por fila)"
        ));
    }
    let total_stride_bytes = abs_stride.checked_mul(u64::from(height)).ok_or_else(|| {
        "el tamaño del búfer del fotograma desborda el límite interno".to_string()
    })?;
    let max_expected = u64::from(width)
        .checked_mul(u64::from(height))
        .and_then(|pixels| pixels.checked_mul(FRAME_BYTES_PER_PIXEL as u64))
        .ok_or_else(|| "el tamaño del fotograma desborda el límite interno".to_string())?;
    if total_stride_bytes > max_expected.saturating_add(64 * 1024 * 1024) {
        return Err("el stride del fotograma es desproporcionadamente grande".into());
    }

    Ok(([width as usize, height as usize], stride))
}

fn copy_sample_to_packed_bgra(
    sample: &IMFSample,
    size: [usize; 2],
    default_stride: i32,
) -> Result<Zeroizing<Vec<u8>>, String> {
    let row_bytes = size[0]
        .checked_mul(FRAME_BYTES_PER_PIXEL)
        .ok_or_else(|| "el ancho del fotograma desborda la plataforma".to_string())?;
    let expected = row_bytes
        .checked_mul(size[1])
        .ok_or_else(|| "el tamaño del fotograma desborda la plataforma".to_string())?;
    ensure_video_process_memory_budget(expected)?;
    let buffer_count = unsafe {
        sample.GetBufferCount().map_err(|error| {
            format!("no se pudo consultar el número de búferes de vídeo: {error}")
        })?
    };
    if buffer_count == 0 {
        return Err("Media Foundation devolvió una muestra de vídeo sin búferes".into());
    }
    let buffer = unsafe {
        if buffer_count == 1 {
            sample
                .GetBufferByIndex(0)
                .map_err(|error| format!("no se pudo obtener el búfer de vídeo: {error}"))?
        } else {
            sample.ConvertToContiguousBuffer().map_err(|error| {
                format!("no se pudo combinar la muestra multimedia de vídeo: {error}")
            })?
        }
    };

    if let Ok(buffer_2d) = buffer.cast::<IMF2DBuffer>() {
        copy_2d_buffer_to_packed_bgra(&buffer_2d, size, row_bytes, expected)
    } else {
        copy_linear_buffer_to_packed_bgra(&buffer, size, row_bytes, expected, default_stride)
    }
}

fn copy_2d_buffer_to_packed_bgra(
    buffer_2d: &IMF2DBuffer,
    size: [usize; 2],
    row_bytes: usize,
    expected: usize,
) -> Result<Zeroizing<Vec<u8>>, String> {
    if let Ok(buffer_2d2) = buffer_2d.cast::<IMF2DBuffer2>() {
        return copy_2d_buffer2_to_packed_bgra(&buffer_2d2, size, row_bytes, expected);
    }

    let contiguous_length = unsafe { buffer_2d.GetContiguousLength() }.map_err(|error| {
        format!("no se pudo consultar la longitud del búfer 2D de vídeo: {error}")
    })?;
    let contiguous_length = usize::try_from(contiguous_length)
        .map_err(|_| "la longitud contigua del vídeo no cabe en la plataforma".to_string())?;
    if contiguous_length < expected {
        return Err(format!(
            "el búfer 2D es demasiado pequeño para el fotograma contiguo ({} bytes; se requieren al menos {})",
            contiguous_length, expected
        ));
    }
    let max_staging = expected.saturating_add(64 * 1024 * 1024);
    if contiguous_length > max_staging {
        return Err(format!(
            "el búfer 2D contiguo es desproporcionadamente grande ({} bytes; máximo permitido {})",
            contiguous_length, max_staging
        ));
    }

    ensure_video_process_memory_budget(contiguous_length)?;
    let mut packed = Zeroizing::new(vec![0u8; contiguous_length]);
    unsafe {
        buffer_2d.ContiguousCopyTo(&mut packed).map_err(|error| {
            format!("no se pudo copiar el búfer 2D a formato contiguo: {error}")
        })?;
    }
    packed.truncate(expected);
    Ok(packed)
}

fn copy_2d_buffer2_to_packed_bgra(
    buffer_2d: &IMF2DBuffer2,
    size: [usize; 2],
    row_bytes: usize,
    expected: usize,
) -> Result<Zeroizing<Vec<u8>>, String> {
    let mut data = std::ptr::null_mut();
    let mut pitch = 0i32;
    let mut buffer_start = std::ptr::null_mut();
    let mut buffer_length = 0u32;

    unsafe {
        buffer_2d
            .Lock2DSize(
                MF2DBuffer_LockFlags_Read,
                &mut data,
                &mut pitch,
                &mut buffer_start,
                &mut buffer_length,
            )
            .map_err(|error| format!("no se pudo bloquear el búfer 2D de vídeo: {error}"))?;
    }

    let result = (|| {
        if data.is_null() || buffer_start.is_null() {
            return Err("Media Foundation devolvió un puntero 2D nulo".into());
        }

        let pitch_abs = i64::from(pitch).unsigned_abs();
        let height = size[1];
        if pitch_abs < row_bytes as u64 || pitch_abs == 0 {
            return Err(format!(
                "el stride real del vídeo es demasiado pequeño ({pitch} bytes)"
            ));
        }

        let buffer_start_addr = buffer_start as usize;
        let buffer_end_addr = buffer_start_addr
            .checked_add(usize::try_from(buffer_length).unwrap_or(usize::MAX))
            .ok_or_else(|| "los límites del búfer 2D desbordan la plataforma".to_string())?;
        validate_2d_region_bounds(
            data as usize,
            buffer_start_addr,
            buffer_end_addr,
            pitch,
            height,
            row_bytes,
        )?;

        let mut packed = Zeroizing::new(vec![0u8; expected]);
        let base = data as *const u8;
        let stride = isize::try_from(pitch).map_err(|_| {
            "el stride del vídeo no cabe en un desplazamiento de la plataforma".to_string()
        })?;
        for row in 0..height {
            let row_offset = stride
                .checked_mul(isize::try_from(row).map_err(|_| {
                    "el índice de fila del vídeo no cabe en la plataforma".to_string()
                })?)
                .ok_or_else(|| {
                    "el desplazamiento del búfer 2D desborda la plataforma".to_string()
                })?;
            let row_ptr = unsafe { base.offset(row_offset) };
            let row_slice = unsafe { std::slice::from_raw_parts(row_ptr, row_bytes) };
            packed[row * row_bytes..(row + 1) * row_bytes].copy_from_slice(row_slice);
        }
        Ok(packed)
    })();

    unsafe {
        let _ = buffer_2d.Unlock2D();
    }
    result
}

fn validate_2d_region_bounds(
    scanline0: usize,
    buffer_start: usize,
    buffer_end: usize,
    pitch: i32,
    height: usize,
    row_bytes: usize,
) -> Result<(), String> {
    if buffer_start >= buffer_end {
        return Err("Media Foundation devolvió un rango de búfer 2D vacío".into());
    }
    if height == 0 {
        return Err("el vídeo tiene una altura nula".into());
    }

    let stride = isize::try_from(pitch).map_err(|_| {
        "el stride del vídeo no cabe en un desplazamiento de la plataforma".to_string()
    })?;
    let last_row = isize::try_from(height - 1)
        .map_err(|_| "el índice de fila del vídeo no cabe en la plataforma".to_string())?;
    let last_offset = stride
        .checked_mul(last_row)
        .ok_or_else(|| "el desplazamiento del búfer 2D desborda la plataforma".to_string())?;

    let last_row_addr = if last_offset >= 0 {
        scanline0
            .checked_add(last_offset as usize)
            .ok_or_else(|| "la dirección del búfer 2D desborda la plataforma".to_string())?
    } else {
        scanline0
            .checked_sub(last_offset.unsigned_abs())
            .ok_or_else(|| "la dirección del búfer 2D desborda la plataforma".to_string())?
    };

    let first_row_end = scanline0
        .checked_add(row_bytes)
        .ok_or_else(|| "el final del primer renglón 2D desborda la plataforma".to_string())?;
    let last_row_end = last_row_addr
        .checked_add(row_bytes)
        .ok_or_else(|| "el final del último renglón 2D desborda la plataforma".to_string())?;
    let lowest = scanline0.min(last_row_addr);
    let highest_end = first_row_end.max(last_row_end);

    if lowest < buffer_start || highest_end > buffer_end {
        return Err(format!(
            "el búfer 2D es demasiado pequeño para su stride ({} bytes accesibles; se requiere un rango de al menos {} bytes)",
            buffer_end.saturating_sub(buffer_start),
            highest_end.saturating_sub(lowest)
        ));
    }
    Ok(())
}

fn copy_linear_buffer_to_packed_bgra(
    buffer: &windows::Win32::Media::MediaFoundation::IMFMediaBuffer,
    size: [usize; 2],
    row_bytes: usize,
    expected: usize,
    default_stride: i32,
) -> Result<Zeroizing<Vec<u8>>, String> {
    let mut data = std::ptr::null_mut();
    let mut max_length = 0u32;
    let mut current_length = 0u32;
    unsafe {
        buffer
            .Lock(&mut data, Some(&mut max_length), Some(&mut current_length))
            .map_err(|error| format!("no se pudo bloquear el búfer de vídeo: {error}"))?;
    }

    let result = if data.is_null() {
        Err("Media Foundation devolvió un búfer de vídeo nulo".into())
    } else {
        let pitch_abs = i64::from(default_stride).unsigned_abs();
        let required_span = pitch_abs
            .checked_mul(size[1].saturating_sub(1) as u64)
            .and_then(|value| value.checked_add(row_bytes as u64));
        if pitch_abs < row_bytes as u64 {
            Err(format!(
                "el stride por defecto del vídeo es demasiado pequeño ({default_stride} bytes)"
            ))
        } else if required_span.is_none_or(|span| span > u64::from(current_length)) {
            Err(format!(
                "el búfer lineal del vídeo es demasiado pequeño ({} bytes; se requieren al menos {})",
                current_length,
                required_span.unwrap_or(u64::MAX)
            ))
        } else {
            let mut packed = Zeroizing::new(vec![0u8; expected]);
            let source_base = if default_stride < 0 {
                let base_offset = pitch_abs
                    .checked_mul(size[1].saturating_sub(1) as u64)
                    .and_then(|offset| usize::try_from(offset).ok())
                    .ok_or_else(|| {
                        "el desplazamiento inicial del búfer lineal desborda la plataforma"
                            .to_string()
                    })?;
                unsafe { (data as *const u8).add(base_offset) }
            } else {
                data as *const u8
            };
            let stride = isize::try_from(default_stride).map_err(|_| {
                "el stride del vídeo no cabe en un desplazamiento de la plataforma".to_string()
            })?;
            for row in 0..size[1] {
                let row_offset = stride
                    .checked_mul(isize::try_from(row).map_err(|_| {
                        "el índice de fila del vídeo no cabe en la plataforma".to_string()
                    })?)
                    .ok_or_else(|| {
                        "el desplazamiento de fila del búfer lineal desborda la plataforma"
                            .to_string()
                    })?;
                let row_ptr = unsafe { source_base.offset(row_offset) };
                let row_slice = unsafe { std::slice::from_raw_parts(row_ptr, row_bytes) };
                packed[row * row_bytes..(row + 1) * row_bytes].copy_from_slice(row_slice);
            }
            Ok(packed)
        }
    };

    unsafe {
        let _ = buffer.Unlock();
    }
    result
}

#[cfg(test)]
fn convert_bgra_row_to_rgba(source: &[u8], destination: &mut [u8]) {
    debug_assert_eq!(source.len(), destination.len());
    for (source_px, dest_px) in source.as_chunks::<FRAME_BYTES_PER_PIXEL>().0.iter().zip(
        destination
            .as_chunks_mut::<FRAME_BYTES_PER_PIXEL>()
            .0
            .iter_mut(),
    ) {
        dest_px[0] = source_px[2];
        dest_px[1] = source_px[1];
        dest_px[2] = source_px[0];
        dest_px[3] = 255;
    }
}

fn sleep_until_or_control(
    target: Instant,
    cancel: &AtomicBool,
    playing: &AtomicBool,
    control_generation: &AtomicU64,
    expected_generation: u64,
) {
    loop {
        if cancel.load(Ordering::Relaxed)
            || !playing.load(Ordering::Relaxed)
            || control_generation.load(Ordering::Acquire) != expected_generation
        {
            return;
        }
        let now = Instant::now();
        if now >= target {
            return;
        }
        let remaining = target.saturating_duration_since(now);
        thread::sleep(remaining.min(CONTROL_POLL_SLICE));
    }
}

fn send_blocking_cancelable(
    sender: &SyncSender<VideoPreviewEvent>,
    event: VideoPreviewEvent,
    cancel: &AtomicBool,
) -> Result<(), String> {
    let mut pending = event;
    loop {
        if cancel.load(Ordering::Relaxed) {
            return Ok(());
        }
        match sender.try_send(pending) {
            Ok(()) => return Ok(()),
            Err(TrySendError::Full(event)) => {
                pending = event;
                thread::sleep(CONTROL_POLL_SLICE);
            }
            Err(TrySendError::Disconnected(_)) => return Ok(()),
        }
    }
}

#[cfg(test)]
mod sync_tests {
    use super::*;

    #[test]
    fn audio_master_holds_video_that_runs_ahead() {
        assert_eq!(
            decide_video_sync(Duration::from_millis(500), Duration::from_millis(440)),
            VideoSyncAction::Wait
        );
    }

    #[test]
    fn audio_master_accepts_small_video_lead() {
        assert_eq!(
            decide_video_sync(Duration::from_millis(500), Duration::from_millis(480)),
            VideoSyncAction::Render
        );
    }

    #[test]
    fn audio_master_drops_stale_video_frames_before_visible_drift() {
        assert_eq!(
            decide_video_sync(Duration::from_millis(500), Duration::from_millis(590)),
            VideoSyncAction::Drop
        );
    }

    #[test]
    fn audio_master_hard_resyncs_after_large_drift() {
        assert_eq!(
            decide_video_sync(Duration::from_millis(500), Duration::from_millis(850)),
            VideoSyncAction::Resync(Duration::from_millis(850))
        );
    }

    #[test]
    fn control_generation_changes_invalidate_old_video_frames() {
        let generation = AtomicU64::new(0);
        assert_eq!(generation.load(Ordering::Acquire), 0);
        generation.fetch_add(1, Ordering::AcqRel);
        assert_ne!(0, generation.load(Ordering::Acquire));
    }

    #[test]
    fn presentation_interval_is_capped_at_target_fps_without_forcing_media_foundation() {
        let interval = video_frame_interval();
        assert_eq!(VIDEO_MAX_FPS, 60);
        assert!(Duration::from_millis(17) >= interval);
        assert!(Duration::from_millis(16) < interval);
    }

    #[test]
    fn generation_buffer_wakes_processor_when_a_raw_frame_arrives() {
        let context =
            VideoGenerationBuffers::new(1, [4, 4], 16, Some(Duration::from_secs(1)), [4, 4]);
        let cancel = AtomicBool::new(false);
        context
            .push_raw_frame(RawVideoFrame {
                bgra: Zeroizing::new(vec![0; 4 * 4 * FRAME_BYTES_PER_PIXEL]),
                size: [4, 4],
                position: Duration::ZERO,
                generation: 1,
                force_display: false,
            })
            .expect("raw frame should enter the bounded queue");
        context
            .wait_for_work(&cancel)
            .expect("wake wait should succeed");
        assert_eq!(
            context
                .snapshot_playback_state()
                .expect("snapshot should succeed")
                .1,
            0
        );
        assert!(context.pop_raw_frame().expect("raw frame pop").is_some());
    }

    #[test]
    fn preview_resolution_is_bounded_without_upscaling() {
        assert_eq!(
            scaled_preview_dimensions(1280, 720, MAX_PREVIEW_WIDTH, MAX_PREVIEW_HEIGHT).unwrap(),
            (960, 540)
        );
        assert_eq!(
            scaled_preview_dimensions(1920, 1080, MAX_PREVIEW_WIDTH, MAX_PREVIEW_HEIGHT).unwrap(),
            (960, 540)
        );
        assert_eq!(
            scaled_preview_dimensions(320, 240, MAX_PREVIEW_WIDTH, MAX_PREVIEW_HEIGHT).unwrap(),
            (320, 240)
        );
        assert_eq!(
            scaled_preview_dimensions(1080, 1920, MAX_PREVIEW_WIDTH, MAX_PREVIEW_HEIGHT).unwrap(),
            (302, 540)
        );
    }

    #[test]
    fn seek_target_is_clamped_to_known_duration() {
        let duration = Duration::from_secs(10);
        let requested = Duration::from_secs(25);
        assert_eq!(requested.min(duration), duration);
    }

    #[test]
    fn preview_pipeline_uses_one_second_ready_and_three_second_target() {
        assert_eq!(VIDEO_MAX_FPS, 60);
        assert_eq!(VIDEO_READY_BUFFER, Duration::from_secs(1));
        assert_eq!(VIDEO_TARGET_BUFFER, Duration::from_secs(3));
        assert_eq!(FRAME_QUEUE_CAPACITY, 6);
        assert_eq!(VIDEO_RAW_SAMPLE_QUEUE_CAPACITY, 4);
        assert_eq!(VIDEO_RAM_SAFETY_LIMIT_BYTES, 1024 * 1024 * 1024);
        const { assert!(VIDEO_FRAME_PAYLOAD_BUDGET_BYTES < VIDEO_RAM_SAFETY_LIMIT_BYTES) };
    }

    #[test]
    fn preview_frame_queue_capacity_is_dynamic_and_below_one_gibibyte() {
        let frame_bytes = frame_payload_bytes([960, 540]).expect("frame payload size");
        let capacity = max_decode_queue_frames([960, 540]).expect("dynamic queue capacity");
        assert!(capacity > 180);
        let accounted = capacity
            .saturating_add(VIDEO_EXTERNAL_FRAME_SLOTS)
            .saturating_mul(frame_bytes);
        assert!(accounted <= VIDEO_FRAME_PAYLOAD_BUDGET_BYTES);
    }

    #[test]
    fn process_memory_budget_is_a_backstop_not_a_normal_buffer_target() {
        assert_eq!(VIDEO_RAM_SAFETY_LIMIT_BYTES, 1024 * 1024 * 1024);
        assert!(VIDEO_TARGET_BUFFER < Duration::from_secs(10));
        const { assert!(VIDEO_FRAME_PAYLOAD_BUDGET_BYTES < VIDEO_RAM_SAFETY_LIMIT_BYTES) };
    }

    #[test]
    fn preview_common_rgb32_memory_stays_below_total_video_safety_envelope() {
        let frame_bytes = frame_payload_bytes([960, 540]).expect("frame payload size");
        let decode_queue =
            max_decode_queue_frames([960, 540]).expect("dynamic queue capacity") * frame_bytes;
        let external = VIDEO_EXTERNAL_FRAME_SLOTS * frame_bytes;
        assert!(decode_queue + external <= VIDEO_FRAME_PAYLOAD_BUDGET_BYTES);
        const { assert!(VIDEO_FRAME_PAYLOAD_BUDGET_BYTES <= VIDEO_RAM_SAFETY_LIMIT_BYTES) };
    }

    #[test]
    fn audio_wait_aborts_when_audio_clock_stops() {
        let cancel = AtomicBool::new(false);
        let playing = AtomicBool::new(true);
        let audio_clock_active = AtomicBool::new(false);
        let generation = AtomicU64::new(7);

        assert!(audio_wait_should_abort(
            &cancel,
            &playing,
            &audio_clock_active,
            &generation,
            7,
        ));
    }

    #[test]
    fn audio_wait_aborts_when_control_generation_changes() {
        let cancel = AtomicBool::new(false);
        let playing = AtomicBool::new(true);
        let audio_clock_active = AtomicBool::new(true);
        let generation = AtomicU64::new(8);

        assert!(audio_wait_should_abort(
            &cancel,
            &playing,
            &audio_clock_active,
            &generation,
            7,
        ));
    }

    #[test]
    fn converts_bgra_rows_with_positive_padding_pitch() {
        let source = [
            1, 2, 3, 255, 4, 5, 6, 255, 90, 91, 92, 93, 7, 8, 9, 255, 10, 11, 12, 255, 94, 95, 96,
            97,
        ];
        let mut rgba = vec![0u8; 16];
        for row in 0..2 {
            let start = row * 12;
            let src_row = &source[start..start + 8];
            convert_bgra_row_to_rgba(src_row, &mut rgba[row * 8..(row + 1) * 8]);
        }
        assert_eq!(
            rgba,
            vec![3, 2, 1, 255, 6, 5, 4, 255, 9, 8, 7, 255, 12, 11, 10, 255]
        );
    }

    #[test]
    fn media_foundation_negative_pitch_rows_are_addressed_from_the_top_row() {
        let row_bytes = 8usize;
        let pitch = -12i32;
        let height = 2usize;
        let buffer = [
            // Physical row 0, visible bottom row for a negative-pitch layout.
            1, 2, 3, 255, 4, 5, 6, 255, 90, 91, 92, 93,
            // Physical row 1, visible top row for a negative-pitch layout.
            7, 8, 9, 255, 10, 11, 12, 255, 94, 95, 96, 97,
        ];
        let source_base = unsafe {
            buffer
                .as_ptr()
                .add((pitch.unsigned_abs() as usize) * (height - 1))
        };
        let mut rgba = vec![0u8; row_bytes * height];
        for row in 0..height {
            let row_ptr = unsafe { source_base.offset(pitch as isize * row as isize) };
            let row_slice = unsafe { std::slice::from_raw_parts(row_ptr, row_bytes) };
            convert_bgra_row_to_rgba(row_slice, &mut rgba[row * row_bytes..(row + 1) * row_bytes]);
        }
        assert_eq!(
            rgba,
            vec![9, 8, 7, 255, 12, 11, 10, 255, 3, 2, 1, 255, 6, 5, 4, 255,]
        );
    }

    #[test]
    fn validates_padded_positive_pitch_2d_region_without_using_contiguous_length() {
        let start = 0x1000usize;
        let scanline0 = start;
        let pitch = 2048i32;
        let height = 4usize;
        let row_bytes = 1920usize;
        let accessible = pitch as usize * height;

        assert!(
            validate_2d_region_bounds(
                scanline0,
                start,
                start + accessible,
                pitch,
                height,
                row_bytes,
            )
            .is_ok()
        );
    }

    #[test]
    fn validates_negative_pitch_2d_region_from_top_row() {
        let start = 0x2000usize;
        let pitch = -12i32;
        let height = 2usize;
        let row_bytes = 8usize;
        let scanline0 = start + 12;

        assert!(
            validate_2d_region_bounds(scanline0, start, start + 24, pitch, height, row_bytes,)
                .is_ok()
        );
    }

    #[test]
    fn rejects_2d_region_that_runs_outside_reported_buffer_bounds() {
        let start = 0x3000usize;
        assert!(validate_2d_region_bounds(start, start, start + 15, 8, 2, 8,).is_err());
    }

    #[test]
    fn audio_wait_continues_when_controls_and_clock_are_valid() {
        let cancel = AtomicBool::new(false);
        let playing = AtomicBool::new(true);
        let audio_clock_active = AtomicBool::new(true);
        let generation = AtomicU64::new(9);

        assert!(!audio_wait_should_abort(
            &cancel,
            &playing,
            &audio_clock_active,
            &generation,
            9,
        ));
    }

    const SIM_FPS: usize = VIDEO_MAX_FPS;
    const SIM_BUFFER_FRAMES: usize = SIM_FPS * 3;

    #[derive(Debug)]
    struct PlaybackSimulation {
        frame_interval: Duration,
        duration: Duration,
        generation: u64,
        playing: bool,
        audio_position: Duration,
        audio_clock_active: bool,
        buffered: VecDeque<Duration>,
        rendered: Vec<Duration>,
        target_frames: usize,
    }

    impl PlaybackSimulation {
        fn new(duration: Duration) -> Self {
            Self {
                frame_interval: video_frame_interval(),
                duration,
                generation: 0,
                playing: false,
                audio_position: Duration::ZERO,
                audio_clock_active: false,
                buffered: VecDeque::new(),
                rendered: Vec::new(),
                target_frames: SIM_FPS,
            }
        }

        fn prepare_from(&mut self, start: Duration, target_frames: usize) {
            self.buffered.clear();
            self.target_frames = target_frames;
            let mut position = start.min(self.duration);
            while self.buffered.len() < target_frames && position <= self.duration {
                self.buffered.push_back(position);
                if position == self.duration {
                    break;
                }
                position = position.saturating_add(self.frame_interval);
            }
        }

        fn start(&mut self) {
            let Some(&first) = self.buffered.front() else {
                panic!("simulation cannot start without a buffered frame");
            };
            let available_frames = if first >= self.duration {
                1
            } else {
                let available_after_first = self.duration.saturating_sub(first);
                let frames_after_first = available_after_first
                    .as_nanos()
                    .div_ceil(self.frame_interval.as_nanos())
                    .min((self.target_frames.saturating_sub(1)) as u128);
                usize::try_from(frames_after_first + 1).unwrap_or(self.target_frames)
            };
            assert!(
                self.buffered.len() >= self.target_frames.min(available_frames),
                "simulation started below the buffer guarantee: first={first:?}, buffered={}, target={}, available={available_frames}",
                self.buffered.len(),
                self.target_frames
            );
            self.playing = true;
            self.audio_clock_active = true;
        }

        fn tick(&mut self, audio_position: Duration) {
            self.audio_position = audio_position.min(self.duration);
            if !self.playing || !self.audio_clock_active {
                return;
            }
            while let Some(&front) = self.buffered.front() {
                match decide_video_sync(front, self.audio_position) {
                    VideoSyncAction::Render => {
                        self.rendered
                            .push(self.buffered.pop_front().expect("frame exists"));
                    }
                    VideoSyncAction::Drop => {
                        self.buffered.pop_front();
                    }
                    VideoSyncAction::Wait => break,
                    VideoSyncAction::Resync(target) => {
                        self.generation = self.generation.saturating_add(1);
                        self.prepare_from(target, SIM_BUFFER_FRAMES);
                        break;
                    }
                }
            }
            self.refill();
        }

        fn refill(&mut self) {
            let Some(mut position) = self.buffered.back().copied() else {
                return;
            };
            while self.buffered.len() < self.target_frames && position < self.duration {
                position = position.saturating_add(self.frame_interval);
                if position > self.duration {
                    break;
                }
                self.buffered.push_back(position);
            }
        }

        fn seek_from_progress_bar(&mut self, requested: Duration, resume: bool) {
            self.playing = false;
            self.audio_clock_active = false;
            self.audio_position = requested.min(self.duration);
            self.generation = self.generation.saturating_add(1);
            self.prepare_from(self.audio_position, SIM_BUFFER_FRAMES);
            if resume {
                self.start();
            }
        }
    }

    #[test]
    fn playback_simulation_primes_one_second_before_start() {
        let mut sim = PlaybackSimulation::new(Duration::from_secs(20));
        sim.prepare_from(Duration::ZERO, SIM_FPS);
        assert_eq!(sim.buffered.len(), SIM_FPS);
        assert_eq!(sim.buffered.front().copied(), Some(Duration::ZERO));
        assert_eq!(
            sim.buffered.get(SIM_FPS - 1).copied(),
            Some(Duration::from_nanos(
                (SIM_FPS as u64 - 1) * sim.frame_interval.as_nanos() as u64
            ))
        );
        sim.start();
        assert!(sim.playing);
        assert!(sim.audio_clock_active);
    }

    #[test]
    fn playback_simulation_keeps_a_three_second_buffer_target() {
        let mut sim = PlaybackSimulation::new(Duration::from_secs(20));
        sim.prepare_from(Duration::ZERO, SIM_BUFFER_FRAMES);
        sim.start();

        for second in 0..5 {
            let audio = Duration::from_secs(second);
            sim.tick(audio);
            assert!(sim.buffered.len() >= SIM_BUFFER_FRAMES - 1);
            assert!(
                sim.buffered
                    .front()
                    .is_some_and(|position| *position >= audio)
            );
        }
    }

    #[test]
    fn playback_simulation_large_audio_lead_triggers_hard_resync_instead_of_fake_history() {
        let mut sim = PlaybackSimulation::new(Duration::from_secs(20));
        sim.prepare_from(Duration::ZERO, SIM_BUFFER_FRAMES);
        sim.start();
        let generation_before = sim.generation;

        sim.tick(Duration::from_secs(2));

        assert!(sim.generation > generation_before);
        assert!(
            sim.buffered
                .front()
                .is_some_and(|position| *position >= Duration::from_secs(2))
        );
        assert!(sim.rendered.is_empty());
    }

    #[test]
    fn playback_simulation_forward_seek_invalidates_old_frames_and_restarts_clock() {
        let mut sim = PlaybackSimulation::new(Duration::from_secs(20));
        sim.prepare_from(Duration::ZERO, SIM_BUFFER_FRAMES);
        sim.start();
        sim.tick(Duration::from_millis(100));
        let old_generation = sim.generation;
        let old_last_rendered = *sim.rendered.last().expect("simulation rendered a frame");

        sim.seek_from_progress_bar(Duration::from_secs(12), true);

        assert_eq!(sim.generation, old_generation + 1);
        assert!(sim.playing);
        assert!(sim.audio_clock_active);
        assert_eq!(sim.audio_position, Duration::from_secs(12));
        assert!(
            sim.buffered
                .front()
                .is_some_and(|position| *position >= Duration::from_secs(12))
        );
        assert!(sim.buffered.len() >= SIM_FPS);
        assert!(old_last_rendered < Duration::from_secs(12));
    }

    #[test]
    fn playback_simulation_backward_seek_rebuilds_from_new_progress_position() {
        let mut sim = PlaybackSimulation::new(Duration::from_secs(20));
        sim.prepare_from(Duration::from_secs(5), SIM_BUFFER_FRAMES);
        sim.start();
        sim.tick(Duration::from_secs(7));
        let generation_before = sim.generation;

        sim.seek_from_progress_bar(Duration::from_secs(3), true);

        assert_eq!(sim.generation, generation_before + 1);
        assert!(
            sim.buffered
                .front()
                .is_some_and(|position| *position >= Duration::from_secs(3))
        );
        assert!(
            sim.buffered
                .back()
                .is_some_and(|position| *position > Duration::from_secs(3))
        );
        assert_eq!(sim.audio_position, Duration::from_secs(3));
    }

    #[test]
    fn playback_simulation_repeated_progress_bar_seeks_keep_only_latest_target() {
        let mut sim = PlaybackSimulation::new(Duration::from_secs(60));
        sim.prepare_from(Duration::ZERO, SIM_BUFFER_FRAMES);
        sim.start();

        sim.seek_from_progress_bar(Duration::from_secs(10), false);
        sim.seek_from_progress_bar(Duration::from_secs(25), false);
        sim.seek_from_progress_bar(Duration::from_secs(41), true);

        assert_eq!(sim.audio_position, Duration::from_secs(41));
        assert!(
            sim.buffered
                .front()
                .is_some_and(|position| *position >= Duration::from_secs(41))
        );
        assert!(
            sim.buffered
                .iter()
                .all(|position| *position >= Duration::from_secs(41))
        );
        assert!(sim.playing);
        assert!(sim.audio_clock_active);
    }

    #[test]
    fn control_plane_keeps_latest_generation_and_command_together() {
        let control = Mutex::new(VideoControlState::default());
        let generation = AtomicU64::new(0);

        let first = publish_video_control(
            &control,
            &generation,
            VideoControlCommand::Seek(Duration::from_secs(10)),
        )
        .expect("first control command");
        let second = publish_video_control(
            &control,
            &generation,
            VideoControlCommand::Seek(Duration::from_secs(41)),
        )
        .expect("second control command");

        assert_eq!(first + 1, second);
        assert_eq!(generation.load(Ordering::Acquire), second);
        assert_eq!(
            take_video_control(&control)
                .expect("control state")
                .expect("command"),
            (second, VideoControlCommand::Seek(Duration::from_secs(41)))
        );
    }

    #[test]
    fn seek_end_can_force_the_last_decoded_frame_to_be_displayed() {
        let frame = DecodedVideoFrame {
            rgba: Zeroizing::new(Vec::new()),
            size: [0, 0],
            position: Duration::from_secs(9),
            generation: 2,
            force_display: true,
        };

        assert!(frame.force_display);
        assert_eq!(frame.generation, 2);
        assert_eq!(frame.position, Duration::from_secs(9));
    }

    #[test]
    fn seek_end_promotes_last_pre_target_frame_so_preview_does_not_stall() {
        let context =
            VideoGenerationBuffers::new(3, [4, 4], 16, Some(Duration::from_secs(10)), [4, 4]);
        context
            .set_discard_before(Some(Duration::from_secs(9)))
            .expect("seek target should be stored");
        context
            .push_raw_frame(RawVideoFrame {
                bgra: Zeroizing::new(vec![0; 4 * 4 * FRAME_BYTES_PER_PIXEL]),
                size: [4, 4],
                position: Duration::from_secs(8),
                generation: 3,
                force_display: false,
            })
            .expect("pre-target frame should be retained as fallback");
        context
            .mark_end_of_stream()
            .expect("EOS should be recorded");
        context
            .promote_fallback_at_end()
            .expect("fallback should be promoted at EOS");

        let raw = context
            .pop_raw_frame()
            .expect("raw pop should succeed")
            .expect("fallback frame should be available");
        assert!(raw.force_display);
        assert_eq!(raw.position, Duration::from_secs(8));
    }

    #[test]
    fn generation_change_drains_stale_frames_without_dropping_new_generation() {
        let old_generation = 1_u64;
        let new_generation = 2_u64;
        let receiver_values = VecDeque::from([old_generation, old_generation, new_generation]);
        let kept: Vec<u64> = receiver_values
            .into_iter()
            .filter(|generation| *generation == new_generation)
            .collect();

        assert_eq!(kept, vec![new_generation]);
    }

    #[test]
    fn playback_simulation_progress_bar_clamps_beyond_end_of_video() {
        let mut sim = PlaybackSimulation::new(Duration::from_secs(10));
        sim.seek_from_progress_bar(Duration::from_secs(99), true);

        assert_eq!(sim.audio_position, Duration::from_secs(10));
        assert!(
            sim.buffered
                .front()
                .is_some_and(|position| *position == Duration::from_secs(10))
        );
        assert_eq!(sim.buffered.len(), 1);
        assert!(sim.playing);
        assert!(sim.audio_clock_active);
    }

    #[test]
    fn playback_simulation_progress_seek_never_reuses_frames_from_old_generation() {
        let old_generation = 4_u64;
        let new_generation = old_generation + 1;
        let mut frames = VecDeque::from([
            DecodedVideoFrame {
                rgba: Zeroizing::new(Vec::new()),
                size: [0, 0],
                position: Duration::from_secs(8),
                generation: old_generation,
                force_display: false,
            },
            DecodedVideoFrame {
                rgba: Zeroizing::new(Vec::new()),
                size: [0, 0],
                position: Duration::from_secs(12),
                generation: new_generation,
                force_display: false,
            },
        ]);

        while frames
            .front()
            .is_some_and(|frame| frame.generation != new_generation)
        {
            frames.pop_front();
        }

        let frame = frames.front().expect("new generation frame remains");
        assert_eq!(frame.generation, new_generation);
        assert_eq!(frame.position, Duration::from_secs(12));
    }

    #[test]
    fn async_pipeline_capacity_counts_raw_decoded_and_processing_frames() {
        let context = VideoGenerationBuffers::new(
            1,
            [960, 540],
            960 * 4,
            Some(Duration::from_secs(10)),
            [960, 540],
        );
        assert!(context.has_capacity().expect("capacity check"));
        let mut state = context.state.lock().expect("state lock");
        let capacity = state.max_queue_frames;
        state.processing_frames = capacity.saturating_sub(1);
        state.raw_frames.push_back(RawVideoFrame {
            bgra: Zeroizing::new(Vec::new()),
            size: [960, 540],
            position: Duration::ZERO,
            generation: 1,
            force_display: false,
        });
        assert!(VideoGenerationBuffers::queue_depth_locked(&state) >= capacity);
        drop(state);
        assert!(!context.has_capacity().expect("capacity check"));
    }

    #[test]
    fn async_generation_context_starts_empty_and_active() {
        let context = VideoGenerationBuffers::new(7, [960, 540], 960 * 4, None, [960, 540]);
        assert!(context.active.load(Ordering::Acquire));
        context
            .set_layout([960, 540], 960 * 4)
            .expect("layout should calculate a dynamic queue capacity");
        let state = context.state.lock().expect("state lock");
        assert!(state.raw_frames.is_empty());
        assert!(state.decoded_frames.is_empty());
        assert_eq!(state.processing_frames, 0);
        assert!(!state.end_of_stream);
    }

    #[test]
    fn async_ready_threshold_is_one_second_at_sixty_fps() {
        assert_eq!(VIDEO_MAX_FPS, 60);
        assert_eq!(VIDEO_READY_BUFFER, Duration::from_secs(1));
        assert_eq!(VIDEO_TARGET_BUFFER, Duration::from_secs(3));
        assert_eq!(VIDEO_RAW_SAMPLE_QUEUE_CAPACITY, 4);
    }

    #[test]
    fn sample_admission_caps_preview_cadence_at_sixty_fps() {
        let context = VideoGenerationBuffers::new(1, [960, 540], 960 * 4, None, [960, 540]);
        assert!(
            context
                .should_copy_sample(Duration::ZERO)
                .expect("first sample should be accepted")
        );
        assert!(
            !context
                .should_copy_sample(Duration::from_millis(16))
                .expect("early sample should be dropped")
        );
        assert!(
            context
                .should_copy_sample(Duration::from_millis(17))
                .expect("next presentation sample should be accepted")
        );
        assert!(
            !context
                .should_copy_sample(Duration::from_millis(33))
                .expect("early follow-up sample should be dropped")
        );
    }

    #[test]
    fn seek_admission_accepts_first_frame_after_target_even_with_same_cadence() {
        let context = VideoGenerationBuffers::new(2, [960, 540], 960 * 4, None, [960, 540]);
        context
            .set_discard_before(Some(Duration::from_secs(10)))
            .expect("seek target should be stored");
        assert!(
            context
                .should_copy_sample(Duration::from_secs(9))
                .expect("pre-target frame remains eligible as fallback")
        );
        assert!(
            context
                .should_copy_sample(Duration::from_millis(10_005))
                .expect("first post-target frame should be accepted")
        );
        assert!(
            !context
                .should_copy_sample(Duration::from_millis(10_020))
                .expect("too-close post-target frame should be dropped")
        );
    }

    #[test]
    fn seek_fallback_sampling_is_rate_limited_before_target() {
        let context = VideoGenerationBuffers::new(6, [960, 540], 960 * 4, None, [960, 540]);
        context
            .set_discard_before(Some(Duration::from_secs(10)))
            .expect("seek target should be stored");

        assert!(
            context
                .should_copy_sample(Duration::from_secs(9))
                .expect("first pre-target sample should be eligible")
        );
        assert!(
            !context
                .should_copy_sample(Duration::from_millis(9_005))
                .expect("a too-close pre-target sample should be skipped")
        );
        assert!(
            context
                .should_copy_sample(Duration::from_millis(9_017))
                .expect("a sufficiently separated pre-target sample should be eligible")
        );
    }

    #[test]
    fn media_foundation_smoke_produces_a_real_video_frame() {
        let root = std::env::temp_dir().join(format!(
            "opac-video-smoke-{}",
            uuid::Uuid::new_v4().simple()
        ));
        fs::create_dir_all(&root).expect("smoke directory should be created");
        let path = root.join("smoke.mp4");
        fs::write(&path, include_bytes!("../tests/data/opac_video_smoke.mp4"))
            .expect("smoke video should be written");

        let mut task = spawn_video_preview_from_plaintext(path.clone(), path.clone())
            .expect("Media Foundation preview task should start");
        let deadline = Instant::now() + Duration::from_secs(8);
        let mut ready = false;
        let mut frame = false;
        while Instant::now() < deadline && !(ready && frame) {
            match task.receiver.recv_timeout(Duration::from_millis(100)) {
                Ok(VideoPreviewEvent::Ready { size, .. }) => {
                    assert_eq!(size, [160, 90]);
                    ready = true;
                }
                Ok(VideoPreviewEvent::Frame { size, rgba, .. }) => {
                    assert_eq!(size, [160, 90]);
                    assert_eq!(rgba.len(), 160 * 90 * FRAME_BYTES_PER_PIXEL);
                    frame = true;
                }
                Ok(VideoPreviewEvent::Failed { message, .. }) => {
                    panic!("Media Foundation smoke preview failed: {message}");
                }
                Ok(VideoPreviewEvent::Ended { .. }) => {}
                Err(mpsc::RecvTimeoutError::Timeout) => {}
                Err(mpsc::RecvTimeoutError::Disconnected) => {
                    panic!("Media Foundation smoke preview channel disconnected");
                }
            }
        }

        task.cancel.store(true, Ordering::Release);
        if let Some(handle) = task.handle.take() {
            handle
                .join()
                .expect("Media Foundation smoke preview worker should stop");
        }
        let _ = fs::remove_file(&path);
        let _ = fs::remove_dir(&root);

        assert!(
            ready,
            "Media Foundation did not report the preview ready state"
        );
        assert!(frame, "Media Foundation did not deliver any video frame");
    }

    #[test]
    fn audio_pending_flag_holds_scheduler_until_audio_clock_is_ready() {
        let pending = AtomicBool::new(true);
        let active = AtomicBool::new(false);
        assert!(pending.load(Ordering::Acquire) && !active.load(Ordering::Acquire));
        active.store(true, Ordering::Release);
        pending.store(false, Ordering::Release);
        assert!(!pending.load(Ordering::Acquire));
        assert!(active.load(Ordering::Acquire));
    }

    #[test]
    fn eos_after_playback_does_not_become_a_false_empty_video_failure() {
        let context =
            VideoGenerationBuffers::new(4, [4, 4], 16, Some(Duration::from_secs(5)), [4, 4]);
        context
            .push_raw_frame(RawVideoFrame {
                bgra: Zeroizing::new(vec![0; 4 * 4 * FRAME_BYTES_PER_PIXEL]),
                size: [4, 4],
                position: Duration::ZERO,
                generation: 4,
                force_display: false,
            })
            .expect("a decoded frame should be accepted");
        context
            .mark_end_of_stream()
            .expect("EOS should be recorded");
        let _ = context.pop_raw_frame().expect("raw frame pop");
        assert!(
            context
                .empty_eos_failure()
                .expect("EOS state should be readable")
                .is_none()
        );
    }

    #[test]
    fn empty_eos_failure_still_reports_a_video_with_no_decoded_frames() {
        let context =
            VideoGenerationBuffers::new(5, [4, 4], 16, Some(Duration::from_secs(5)), [4, 4]);
        context
            .mark_end_of_stream()
            .expect("EOS should be recorded");
        assert_eq!(
            context
                .empty_eos_failure()
                .expect("EOS state should be readable")
                .as_deref(),
            Some("Media Foundation no devolvió ningún fotograma de vídeo")
        );
    }
}
