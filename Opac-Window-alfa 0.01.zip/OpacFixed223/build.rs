use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

fn guard_exe_path(target_dir: &Path, target: &str, windows_target: bool) -> PathBuf {
    target_dir
        .join(target)
        .join("release")
        .join(if windows_target {
            "opac_guard.exe"
        } else {
            "opac_guard"
        })
}

fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-changed=guard/src/lib.rs");
    println!("cargo:rerun-if-changed=guard/Cargo.toml");
    println!("cargo:rerun-if-changed=guard/src/main.rs");
    println!("cargo:rerun-if-changed=Cargo.lock");
    println!("cargo:rerun-if-changed=assets/opac_window.ico");

    if env::var("PROFILE").as_deref() == Ok("release") && !Path::new("Cargo.lock").is_file() {
        panic!(
            "release security check: Cargo.lock is required; run `cargo generate-lockfile` once and commit it before building a release"
        );
    }

    if env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("windows")
        && env::var("CARGO_CFG_TARGET_ENV").as_deref() == Ok("msvc")
    {
        let target_features = env::var("CARGO_CFG_TARGET_FEATURE").unwrap_or_default();
        if !target_features
            .split(',')
            .any(|feature| feature.trim() == "crt-static")
        {
            panic!(
                "Windows/MSVC builds of Opac Window require the static MSVC CRT; target feature `crt-static` is missing"
            );
        }
    }

    if env::var_os("CARGO_CFG_WINDOWS").is_some() {
        let mut resource = winresource::WindowsResource::new();
        resource
            .set_icon("assets/opac_window.ico")
            .set("FileDescription", "Opac Window")
            .set("ProductName", "Opac Window")
            .set("InternalName", "opac_window")
            .set("OriginalFilename", "opac_window.exe")
            .set("ProductVersion", "0.1.0-beta")
            .set("FileVersion", "0.1.0.0")
            .compile()
            .expect("failed to embed Opac Window Windows resources");
    }

    let out_dir = PathBuf::from(env::var_os("OUT_DIR").expect("OUT_DIR must be set"));
    let payload_path = out_dir.join("opac_guard_payload.bin");

    if env::var_os("CARGO_CFG_WINDOWS").is_none() {
        fs::write(&payload_path, []).expect("failed to create non-Windows Guard payload");
        return;
    }

    let cargo = env::var_os("CARGO").unwrap_or_else(|| "cargo".into());
    let target = env::var("TARGET").expect("TARGET must be set");
    let child_target_dir = out_dir.join("opac_guard_build");
    let status = Command::new(cargo)
        .arg("build")
        .arg("--locked")
        .arg("--package")
        .arg("opac_guard")
        .arg("--release")
        .arg("--target")
        .arg(&target)
        .arg("--target-dir")
        .arg(&child_target_dir)
        .status()
        .expect("failed to invoke Cargo for embedded OPAC Guard");

    if !status.success() {
        panic!("embedded OPAC Guard build failed with status {status}");
    }

    let windows_target = env::var_os("CARGO_CFG_WINDOWS").is_some();
    let guard_exe = guard_exe_path(&child_target_dir, &target, windows_target);
    if !guard_exe.is_file() {
        panic!(
            "Cargo built OPAC Guard but expected artifact was not found: {}",
            guard_exe.display()
        );
    }
    let bytes = fs::read(&guard_exe).expect("failed to read built OPAC Guard executable");
    if bytes.len() < 2 || &bytes[..2] != b"MZ" {
        panic!("embedded OPAC Guard payload is not a valid Windows executable");
    }
    fs::write(&payload_path, bytes).expect("failed to write embedded OPAC Guard payload");
}
