# Fixed110 — Desactivacion de Guard sin bloqueo de GUI

## Correccion principal
- `GuardClient::shutdown()` ya no envia un comando de cierre y hace `join()` sobre su hilo IPC.
- El `Sender` se libera directamente y el hilo del cliente se deja terminar de forma autonoma al detectar el cierre del canal.
- Cuando el cliente se desconecta, `handle_client()` en el servicio limpia las excepciones y vuelve a armar la proteccion completa antes de regresar.

## Efecto en la interfaz
- La desactivacion de OPAC Guard no puede quedar bloqueada por una lectura/escritura del named pipe.
- El mismo comportamiento mejora bloqueo, cambio de usuario y cierre de la aplicacion, ya que esos caminos tambien liberan el cliente Guard.

## Seguridad
- Se mantiene la autenticacion Ed25519, el SID de Windows y la validacion del profile_id.
- No se desactiva la proteccion del servicio por cerrar el cliente: la desconexion provoca el rearme de las excepciones.

## Resultados de UAC/SCM
- El resultado de la operacion elevada ya no se escribe en `%TEMP%` (directorio controlado por el usuario).
- Se utiliza un directorio administrativo bajo ProgramData protegido con ACL; la GUI solo recibe permiso de recorrido/lectura.
- La ruta enviada al helper se valida para que quede estrictamente dentro del directorio de resultados protegido.
- Un resultado `PENDING` no se interpreta como un error final; en ese caso la GUI usa el codigo de salida del helper.
