# Fixed73 — simulacion y tests del OPAC Guard

Fixed73 añade cobertura de tests de comportamiento para OPAC Guard sin iniciar el servicio real ni modificar el filesystem del usuario.

Se cubren mediante simulación/lógica pura:

- orden de recuperación de configuración (`roots.bin`, `.new`, `.bak`);
- condición fail-closed: todos los roots deben quedar cubiertos por workers;
- contrato de apertura de handles: no se comparte escritura ni borrado;
- presencia de los flags necesarios para tratar reparse points y directorios de forma explícita;
- exclusión por límites de componentes de ruta (evita que `abc` coincida con `abcd`);
- autenticación IPC Ed25519 y detección de cambio de perfil/nonce;
- firma de configuración y detección de cambio de ruta;
- rechazo de payloads de roots demasiado grandes;
- comportamiento existente de payloads con bytes sobrantes.

Los tests no sustituyen las pruebas de integración sobre Windows: no demuestran por sí solos que NTFS bloquee una operación concreta, que el Service Control Manager arranque el servicio o que un named pipe real respete sus ACL. Esas pruebas quedan para una fase posterior de integración.
