# Fixed84 — OPAC Guard: protección continua con liberación por operación

- El perfil permanece protegido mientras está abierto: se elimina el antiguo desbloqueo global de la raíz.
- Lecturas, previews y descifrado a memoria no desprotegen el ciphertext; `FILE_SHARE_READ` permite esas lecturas.
- Las mutaciones que necesitan tocar el filesystem cifrado solicitan al Guard una excepción tipada y concreta: archivo, directorio o subárbol.
- La GUI espera confirmación del Guard antes de ejecutar la mutación y solicita reprotección inmediatamente después.
- El servicio valida la ruta, el tipo, el perfil, los reparse points y el límite de excepciones antes de aceptar la liberación.
- Cada liberación/reprotección está firmada con Ed25519 y vinculada al desafío fresco de la sesión IPC, perfil, comando, secuencia y payload.
- Si se rompe el IPC, el Guard elimina las excepciones y rearma toda la protección.
- El rearme sustituye completamente el conjunto de workers anterior antes de abrir nuevos handles, evitando que los propios handles del Guard bloqueen la operación siguiente.
- La enumeración falla en modo fail-closed ante errores de lectura de entradas o reparse points dentro del perfil protegido.
