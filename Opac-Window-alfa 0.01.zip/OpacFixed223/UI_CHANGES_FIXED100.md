# Fixed100

## Corrección de compilación de elevación de OPAC Guard

- Se corrigió la integración de `ShellExecuteW` utilizada para solicitar UAC.
- `windows-sys 0.61.2` no expone el símbolo en el árbol que estaba siendo resuelto por el proyecto del usuario; Fixed100 evita esa discrepancia mediante una declaración FFI privada y explícita contra `shell32.dll`.
- Se conserva el verbo `runas`, el mismo ejecutable y el mismo empaquetado de argumentos.
- No se modifica la lógica criptográfica, de IPC ni de instalación del Guard.
