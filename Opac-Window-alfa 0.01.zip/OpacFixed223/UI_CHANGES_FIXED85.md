# UI / integration changes — Fixed85

Fixed85 mantiene el Guard en modo protegido por defecto y simplifica la interfaz de excepciones temporales.

## Integración de uso temporal

- `GuardClient` expone una sola operación: `set_path_in_use(path)`.
- Si la ruta es un archivo OPAC protegido, solo se libera ese archivo.
- Si la ruta es un directorio, se libera ese subárbol únicamente mientras OPAC ejecuta una operación que lo necesita.
- La ruta raíz del perfil nunca puede liberarse.
- Al terminar, OPAC llama a `set_path_protected(path)` y espera confirmación.
- La desconexión del IPC, `LOCK` o `QUIT` limpia las excepciones y rearma toda la protección.

## Bloqueo de movimientos

Los handles protegidos se siguen abriendo con `FILE_SHARE_READ` solamente: no se comparte escritura ni borrado. Por ello, Explorer y otros procesos normales no pueden modificar, borrar, renombrar o mover los artefactos protegidos mientras el Guard los mantenga abiertos.

## Simplificación

Se eliminan del protocolo público los comandos separados para archivo, directorio y árbol. El servicio determina internamente si la ruta solicitada es un archivo o un directorio. La autenticación Ed25519, el nonce de sesión y la secuencia monotónica se mantienen porque son la barrera que impide que otro proceso solicite una desprotección arbitraria.
