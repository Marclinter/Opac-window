# Cambios UI / OPAC Guard — Fixed68

## OPAC Guard: alcance por usuario de la aplicación

- La activación de OPAC Guard se vincula al `profile_id` del usuario autenticado de Opac Window.
- Cada perfil obtiene una instancia independiente del servicio: `OpacGuard-<profile-id>`.
- La configuración persistente de raíces se separa por perfil.
- El botón de Ajustes consulta únicamente el estado del Guard del perfil activo.
- La raíz protegida queda restringida exactamente a `OpacWindow\profiles\<profile-id>`.
- La GUI ya no registra la raíz global de Opac Window para el Guard.
- Al cambiar de usuario dentro de Opac Window, el cliente IPC del perfil anterior se cierra después de rearmar su protección.
- Las órdenes IPC de desbloqueo validan que la raíz recibida coincida con la raíz instalada para ese `profile_id`; no existe una operación IPC para añadir raíces arbitrarias.
- El SID de Windows se conserva solo para seguridad del canal IPC y no define qué usuario de Opac Window está protegido.
- No se añade todavía el instalador definitivo; `opac_guard.exe` sigue compilándose como binario separado dentro del mismo proyecto Cargo.
