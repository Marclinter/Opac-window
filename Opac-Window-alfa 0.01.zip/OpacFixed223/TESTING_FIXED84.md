# Fixed85 — OPAC Guard: rearme seguro y excepciones acotadas

Fixed85 mantiene el modelo de protección continua introducido en Fixed83 y corrige un punto importante de funcionamiento: al cambiar las excepciones autorizadas, el servicio detiene primero sus workers anteriores y solo después reconstruye el conjunto de handles. Así se evita que el propio Guard bloquee la operación de reconfiguración con sus handles FILE_SHARE_READ.

Las liberaciones siguen siendo por operación, no por desbloqueo global del perfil. La GUI solicita una liberación solo para mutaciones que realmente la necesitan; lectura y previsualización no requieren desproteger el ciphertext.

La autorización de cada liberación queda ligada a: perfil OPAC, desafío criptográfico fresco de la sesión IPC, tipo de comando, secuencia monotónica, ruta exacta y firma Ed25519. El servicio valida además que la ruta exista, no sea reparse point, pertenezca al perfil configurado, sea del tipo solicitado y nunca sea la raíz completa. Se limita el número de excepciones simultáneas.

La enumeración del árbol es fail-closed ante errores de lectura de entradas o aparición de reparse points dentro del perfil protegido.

## Comandos

```powershell
cargo test -p opac_guard --all-targets
cargo test --workspace --all-targets
cargo clippy --workspace --all-targets --all-features -- -D warnings
```

## Prueba manual Windows

1. Activar Guard para un perfil.
2. Comprobar que los `.opac`, `keystore.opks` y `.opac-folder` no permiten escritura/borrado/renombrado desde otro proceso mientras no haya una operación autorizada.
3. Guardar, mover, renombrar o borrar desde OPAC y comprobar que solo la ruta necesaria queda temporalmente liberada y que el servicio confirma después su reprotección.
4. Interrumpir la aplicación o romper el canal IPC y verificar que desaparecen todas las excepciones y el Guard vuelve a proteger la raíz.
5. Intentar usar un proceso con el mismo SID pero sin la clave Ed25519 del perfil: el pipe debe ser accesible solo en primera instancia por ACL y la autenticación criptográfica debe rechazarlo.
