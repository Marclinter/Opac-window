# Fixed80 — correcciones de integración del Guard

Partiendo de Fixed79:

- `PIPE_ACCESS_DUPLEX` se importa desde `Win32::Storage::FileSystem`, compatible con `windows-sys 0.61.2`.
- `guard_config_signature` se mantiene como función pública del módulo superior y ya no se reexporta incorrectamente desde `windows_guard`.
- No se modifica el protocolo ni la lógica de protección; son correcciones de compilación/integración.

Validación pendiente en Windows:

```powershell
cargo test --workspace --all-targets
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo build --workspace --release
```
