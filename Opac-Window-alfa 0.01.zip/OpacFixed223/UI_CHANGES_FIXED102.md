# Fixed102 — Diagnóstico y activación robusta de OPAC Guard

- La interfaz de Ajustes muestra inline los errores de OPAC Guard; ya no dependen de la barra de estado inferior cubierta por la ventana de Ajustes.
- El estado del servicio distingue `No instalado` de errores reales al consultar SCM/servicio.
- La activación elevada pasa a ejecutarse en segundo plano para mantener la GUI responsiva y mostrar `Activando…` mientras se espera UAC/SCM.
- Se añade `Comprobar estado` para forzar una consulta del servicio desde Ajustes.
- `ShellExecuteExW` usa `SEE_MASK_NOCLOSEPROCESS | SEE_MASK_NOASYNC` y la ausencia de un `hProcess` ya no se trata como éxito.
- Se muestran, cuando existen, los códigos Win32 del servicio si la instalación termina dejando el servicio detenido.
- Los archivos de resultado temporal del helper se limpian también cuando la elevación falla antes de devolver un código.
- Si el Guard figura activo pero falta la identidad criptográfica del perfil, se informa del problema en lugar de fallar silenciosamente.

Los colores morados existentes no se modifican.
- Si la creación del cliente autenticado del Guard falla tras una instalación exitosa, el mensaje de error no es sobrescrito por el mensaje de éxito.
- El bloqueo automático no interrumpe una operación de activación elevada en curso.
