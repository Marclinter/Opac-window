# Fixed81 — reestructuración de OPAC Guard

## Cambio principal

- `guard/src/lib.rs` es ahora la fuente canónica de OPAC Guard.
- `guard/src/main.rs` es un wrapper mínimo que llama a `opac_guard::main_entry`.
- `opac_window` consume el Guard como dependencia de workspace, sin duplicar el archivo de implementación.
- `build.rs` compila `opac_guard` como paquete del workspace y embebe el ejecutable esperado de la target triple.
- Se elimina la búsqueda recursiva de un `opac_guard.exe`, evitando incrustar accidentalmente un artefacto antiguo.
- El crate principal deja de declarar `windows-sys` para el Guard; esa dependencia queda encapsulada en `opac_guard`.

## Preservado

- Guard sigue siendo opcional.
- Mientras está desactivado, no se materializa `opac_guard.exe`.
- La activación sigue partiendo de la GUI y usando el payload embebido.
- La API pública usada por la GUI mantiene los mismos nombres.

## Ajuste de runtime del servicio

- El servicio ya no intenta reconstruir la ruta del perfil mediante `LOCALAPPDATA` del contexto de `LocalSystem`.
- En arranque, `roots.bin` se valida por formato y firma; la comprobacion de que la raiz coincide exactamente con el perfil se hace durante la operacion elevada de instalacion.
- Esto separa correctamente la identidad interactiva de la configuracion que el servicio debe consumir al iniciar.
