# Fixed214 — revisión del procesamiento de preview de vídeo

## Causa confirmada del fallo visible en Fixed213

La implementación de `IMFSourceReaderCallback::OnReadSample` comparaba `dwStreamIndex` con `MF_SOURCE_READER_FIRST_VIDEO_STREAM`.

Media Foundation documenta que `MF_SOURCE_READER_FIRST_VIDEO_STREAM` es un selector especial (`0xFFFFFFFC`), mientras que `OnReadSample` devuelve en `dwStreamIndex` el índice real de la secuencia que entregó la muestra (índice cero basado). Por ello una muestra de vídeo normal podía ser interpretada como `NoSample`, drenando el archivo hasta `EOS` y produciendo el mensaje de Fixed213 «Media Foundation no devolvió ningún fotograma de vídeo».

Fixed214 elimina esa comparación incorrecta y confía en que la petición `ReadSample` explícitamente dirigida a la primera secuencia de vídeo es la que activa este callback.

Fuentes: Microsoft Learn, `IMFSourceReaderCallback::OnReadSample` y `IMFSourceReader::SetCurrentMediaType`.

## Otras comprobaciones realizadas

- Se mantiene Media Foundation en modo asíncrono; no se introduce `ReadSample` síncrono.
- Se mantienen generaciones para invalidar samples de seeks anteriores.
- Se mantiene `Flush` antes de liberar una sesión anterior.
- Se mantiene la salida RGB32 limitada a la resolución de preview.
- Se mantiene la validación de dimensiones, stride y límites de memoria.
- La cola RAW queda explícitamente limitada a cuatro muestras; el decoder deja de solicitar nuevas muestras mientras esa cola está llena.
- La asignación temporal usada por `IMF2DBuffer::ContiguousCopyTo` se incluye ahora en la comprobación del presupuesto de memoria.
- Si el hilo procesador no puede arrancar, se cancela y une el decoder ya arrancado antes de devolver el error; no se deja un hilo huérfano.
- El temporal de vídeo continúa siendo privado de la sesión y el archivo cifrado original no se entrega a Media Foundation.

## Regresión de ejecución real

Se añade un pequeño MP4 H.264 de 160×90 como fixture de 2,4 KiB y una prueba Windows-only que arranca el pipeline real, espera `Ready` y exige que Media Foundation entregue al menos un frame RGBA de 160×90.

Esta prueba está pensada para detectar una regresión del tipo que Fixed213 no podía detectar con simulaciones: el código compila y la lógica de scheduler puede pasar, pero el callback real no entrega ninguna imagen.

La prueba no depende de FFmpeg en tiempo de ejecución; el MP4 está incluido como fixture. Requiere que Windows disponga del decodificador H.264/Media Foundation correspondiente.
