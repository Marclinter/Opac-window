# OPAC Window Fixed63

## Progreso visible de importación

- Se añade un panel de progreso visible en la GUI mientras existe una importación activa.
- La primera barra representa el progreso de archivos completados (`n/N`).
- Para archivos con más de un chunk se muestra una segunda barra con el progreso de chunks del archivo actual.
- El progreso sigue viniendo de los eventos reales del worker; la GUI no simula avance.
- La barra ya no depende de que la carpeta de destino esté expandida en el árbol.

## Ramas del árbol

- Se mantiene la continuidad de los conectores entre filas.
- Las ramas terminales se marcan explícitamente y terminan en la unión `└`, sin segmento vertical posterior.
- Se añade una pequeña protección visual bajo el extremo terminal para evitar que un tronco adyacente parezca continuar la rama más allá del archivo final.

### Fixed64 correction

- Fixed the egui 0.36 `Painter::rect_filled` call used by the terminal-branch visual guard: the current API requires an explicit corner radius before the fill color. No tree behavior was changed; this is a compatibility/build fix only.
