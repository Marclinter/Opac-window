# OPAC Window Fixed67

## OPAC Guard: aislamiento por usuario de Windows

- El Guard deja de ser una única instancia global `OpacGuard`.
- Cada usuario que activa la función obtiene su propia instancia del servicio, identificada por su SID (`OpacGuard-S-1-...`).
- La configuración persistente de las raíces queda separada por SID bajo `ProgramData\\OpacWindow\\guard\\<SID>\\roots.bin`.
- El canal IPC también es independiente por usuario (`\\\\.\\pipe\\OpacGuard-<SID>`), con ACL limitada al SID autorizado, SYSTEM y administradores.
- La GUI consulta el estado del servicio correspondiente al SID del usuario actual; otro usuario del mismo PC verá su Guard como no instalado hasta activarlo por separado.
- Durante la instalación se valida que las raíces configuradas pertenecen al almacenamiento local de OPAC del usuario que está activando el Guard.
- El servicio sigue ejecutándose como un componente independiente y ligero; solo protege las raíces persistidas para su SID y únicamente los artefactos gestionados (`*.opac`, `.opac-folder`, `keystore.opks`).
- No se añade todavía el instalador definitivo ni el watchdog de la GUI.
