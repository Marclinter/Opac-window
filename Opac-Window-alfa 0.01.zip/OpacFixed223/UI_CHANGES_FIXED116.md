# UI / Preview Changes — Fixed116

## Vista previa de vídeo

- Añadido soporte de previsualización integrada para vídeo en Windows mediante Microsoft Media Foundation Source Reader.
- Formatos reconocidos por extensión: MP4, MKV, MOV, AVI, WebM, M4V, WMV, TS, M2TS, MTS y 3GP.
- La selección de un vídeo abre una tarea de descifrado/decodificación en segundo plano para mantener responsiva la GUI.
- La reproducción muestra los fotogramas dentro del panel de Vista previa y permite reproducir/pausar y reiniciar.
- Se reutiliza la misma ruta temporal segura de descifrado ya existente para audio; los archivos temporales propiedad de la vista previa se limpian al cerrar/cambiar de selección y se dejan para reintento si Windows los mantiene abiertos.
- El límite de entrada de la vista previa es 512 MiB y el fotograma está limitado a 8192 px por eje y 16 millones de píxeles para evitar asignaciones descontroladas.
- El audio contenido dentro del vídeo no se reproduce en esta primera implementación; la salida de audio de OPAC sigue funcionando mediante la vista previa de audio dedicada.
- En equipos sin un códec de Media Foundation compatible con un contenedor/códec concreto, se muestra el error del sistema y se ofrece abrirlo externamente.
