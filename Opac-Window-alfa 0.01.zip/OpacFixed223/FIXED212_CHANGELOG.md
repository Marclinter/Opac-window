# OpacFixed212 — cambio por capas

Base: OpacFixed211.

Correcciones de esta capa, derivadas exclusivamente de la salida de `cargo test` sobre Fixed211:

1. `KeyStoreSession` ahora resuelve rutas con componentes intermedios inexistentes mediante la misma resolución de alcance usada por el resto de la sesión. Esto evita un falso `VaultOutsideProfile` por diferencias entre rutas canónicas Windows y rutas no existentes.
2. Se añadió una regresión que crea un Vault en `profile\vaults\vault-a` cuando `vaults` todavía no existe.
3. `VideoGenerationBuffers::should_copy_sample` aplica el límite de cadencia también durante el recorrido previo al objetivo de seek, conserva el fallback, y admite siempre el primer frame situado en/tras el objetivo.
4. La simulación de reproducción admite iniciar un seek al final del vídeo con menos de un segundo de frames disponibles.
5. La prueba de forward seek usa un paso de audio sub-resync para validar que exista histórico renderizado antes del seek.
6. La prueba de importación entre Vaults usa contraseñas de exportación que cumplen la política, evitando que la prueba falle antes de llegar a la condición que pretende verificar.

No se modificaron algoritmos criptográficos, el protocolo de Guard, ni la arquitectura Media Foundation fuera de las condiciones de simulación/cadencia indicadas.
