# TESTING_FIXED130

## Comprobaciones estaticas preparadas

- `cargo fmt --check` debe quedar limpio en la maquina Windows del proyecto.
- `cargo clippy --all-targets --all-features -- -D warnings` debe quedar limpio.
- `cargo test` debe ejecutar las regresiones de persistencia, perfiles, credenciales, temporales y formato V2.

## Regresiones nuevas

- bloqueo de segundo escritor sobre el catalogo global y Key Store;
- lectura acotada de `keystore.opks` y `profiles.oprp`;
- permisos privados de directorios gestionados;
- reescritura de metadata V2 en streaming;
- rechazo de contrasenas de exportacion V2 demasiado cortas;
- compatibilidad de exportaciones V1 legacy;
- expiracion/limpieza condicional de Vault Key del portapapeles;
- backoff temporal de PIN;
- limpieza de temporales de sesion asociados a procesos terminados.
- renombrado de un `.opac` V2 despues de leer metadata, verificando que la fuente se rebobina y el contenido se conserva.
- copia de una entrada precargada rechazada cuando la fuente deja de ser un archivo regular seguro.

## Validacion final en Windows

Esta entrega no se ha compilado dentro de este entorno porque no dispone de Cargo/Rust ni Media Foundation de Windows. La validacion final debe hacerse en la maquina Windows del proyecto.
