# Fixed74 — hardening del OPAC Guard

- La raíz configurada del Guard se valida contra la ruta física completa del `profile_id`; ya no basta con coincidir con los tres últimos componentes.
- El almacenamiento administrativo del Guard se asegura por niveles bajo `%ProgramData%\OpacWindow\guard`, manteniendo acceso explícito para SYSTEM y Administradores.
- `roots.bin` usa escritura temporal + flush/sync + backup y recuperación de candidatos válidos.
- Los cambios del árbol se vigilan con `ReadDirectoryChangesW` y una operación superpuesta por raíz; se elimina el sondeo periódico del watcher.
- Si una entrada protegible no puede volver a quedar protegida, el worker marca el servicio para detención (fail-closed).
- La eliminación de un perfil o de su almacenamiento dedicado se bloquea mientras exista el almacenamiento administrativo de OPAC Guard para ese `profile_id`, evitando Guards huérfanos.
- El servicio se registra explícitamente con `LocalSystem`; los binarios/configuración quedan fuera de rutas de usuario y bajo ACL restrictivas. El cambio definitivo a una cuenta de mínimos privilegios queda pendiente de validación de permisos de acceso al almacenamiento de perfiles.
- Se añadieron tests de política para la vigilancia superpuesta, validación estricta de raíz y ciclo de vida del perfil.

No se añade todavía el instalador final, watchdog de la GUI ni copias de seguridad de contenido.

- Tras una desactivación correcta, la identidad Ed25519 del Guard se elimina del Key Store mediante persistencia crash-safe; la siguiente activación genera una identidad nueva.
- La limpieza del Guard es estricta: solo elimina los artefactos conocidos y no utiliza `remove_dir_all`.
- Si algún artefacto no puede eliminarse, la operación devuelve error en lugar de informar de una desactivación incompleta como éxito.

- El cierre fail-closed despierta la espera del pipe para no dejar el servicio bloqueado esperando conexiones tras perder la proteccion.
- La desactivacion rota la identidad persistida del Guard solo despues de completar la retirada del servicio y sus artefactos administrativos.
