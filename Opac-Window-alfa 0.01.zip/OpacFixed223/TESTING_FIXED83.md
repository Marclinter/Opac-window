# Fixed84 — pruebas del OPAC Guard

## Suite exclusiva del Guard

```powershell
cargo test -p opac_guard --all-targets
```

Debe aparecer una ejecución para `opac_guard` (librería) y otra para `tests\guard_public_api.rs`. La cobertura unitaria incluye aislamiento por perfil, autenticación IPC, firmas de configuración, firmas de desinstalación, firmas de comandos por operación, límites de rutas, reparse points, `FILE_SHARE_READ`, recuperación autenticada y fail-closed de los workers.

## Workspace completo

```powershell
cargo test --workspace --all-targets
```

## Clippy

```powershell
cargo clippy --workspace --all-targets --all-features -- -D warnings
```

## Release y comprobación del embedding

```powershell
cargo build --release
cargo build --release --bin opac_window
```

El `build.rs` compila el crate `opac_guard`, localiza exactamente su artefacto `target\<target>\release\opac_guard.exe` y comprueba que el payload que se embebe empieza con `MZ`.

## Prueba manual Windows recomendada

1. Activar OPAC Guard desde Ajustes con UAC.
2. Confirmar que el servicio `OpacGuard-<profile-id>` queda en ejecución.
3. Desde otro proceso, intentar escribir, truncar, borrar y renombrar un `.opac`: debe fallar mientras no exista una operación legítima en curso.
4. Editar un archivo de texto desde OPAC: durante el guardado solo ese ciphertext queda temporalmente liberado y después debe volver a aceptar únicamente lectura.
5. Mover/renombrar/borrar una carpeta: debe liberarse temporalmente solo el subárbol necesario.
6. Cerrar OPAC o romper el canal IPC y comprobar que todas las excepciones desaparecen y el Guard vuelve a proteger toda la raíz.
