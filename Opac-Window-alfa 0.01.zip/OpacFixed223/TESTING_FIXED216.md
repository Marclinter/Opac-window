# Testing Fixed216

Fixed216 is a warning-only cleanup on top of Fixed215.

Recommended validation on Windows:

```powershell
cargo fmt --check
cargo check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-targets --no-fail-fast
cargo build --release --locked
```

Expected result from the reported issue: no `unused variable: dwstreamindex` warning/error.

The rename is intentional; it does not suppress a discovered code path because the callback does not need to inspect the concrete stream index after the read request has already selected the first video stream.
