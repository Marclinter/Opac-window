# UI / Video changes — Fixed182

- Video preview reserve increased from 12 to 30 frames.
- Prefetch target is now 60 frames total (30 FPS × 1 second ahead + 30-frame reserve).
- Total video preview memory budget increased to 256 MiB so the original 6-frame IPC queue and GUI texture can remain without sacrificing the 720p ceiling.
- Maximum preview resolution remains 1280×720; lower source resolutions are not upscaled.
- Memory-bound tests now validate the 60-frame configuration.
