# OPAC Window Fixed66

## OPAC Guard (Windows, experimental)

- Se añade el binario separado `opac_guard.exe` dentro del mismo proyecto Cargo.
- Desde **Ajustes → OPAC Guard** la GUI puede activar o desactivar el servicio mediante elevación UAC.
- El Guard se registra como servicio Windows `OpacGuard`, con inicio automático y acciones de recuperación por reinicio.
- La protección mantiene handles sobre `*.opac`, `.opac-folder` y `keystore.opks` sin descifrar ni leer el contenido y sin compartir escritura/borrado.
- Mientras una sesión está desbloqueada, la GUI comunica por named pipe las raíces de esa sesión para excluirlas temporalmente; al bloquear, cerrar o perderse el IPC, el Guard vuelve a proteger todas las raíces.
- El canal IPC está restringido mediante ACL, rechazo de clientes remotos y comprobación adicional del SID y del ejecutable cliente.
- El recorrido ignora puntos de reanálisis y usa notificaciones de cambio para evitar escaneos periódicos completos. Las rutas que no se pueden abrir para protección quedan en una cola de reintento ligera.
- No se añaden todavía copias de seguridad, recuperación de corrupción, watchdog de la GUI ni instalador final.
- Para desarrollo se requiere `cargo build --bins` para generar `opac_window.exe` y `opac_guard.exe` juntos.

## Regresión corregida durante la implementación

- Al bloquear/cerrar OPAC, el servicio se rearma **después** de liberar `VaultSession` y `Vault`, evitando carreras con handles propios de la GUI.
- Si la conexión IPC desaparece inesperadamente, el servicio rearma todas las raíces aunque existiera una protección parcial anterior, evitando dejar excluido indefinidamente el perfil desbloqueado.
