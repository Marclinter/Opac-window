# UI_CHANGES_FIXED109

- Fixed OPAC Guard deactivation freezing the GUI while the elevated helper and Windows Service Control Manager completed the operation.
- Guard disable authentication and service uninstall now run on a background thread.
- The GUI remains responsive and shows explicit `Desactivando…` progress.
- The local Guard IPC client is shut down before beginning uninstall and restored when authentication/uninstall fails while the service remains running.
- Installation and uninstallation operations are now explicitly distinguished so their asynchronous results cannot be interpreted as the wrong operation.
- The Settings window stays open while deactivation completes, allowing the final service status/error to be displayed.
- Repeated deactivation clicks are disabled while uninstall is in progress.
- The encrypted Key Store credential is kept inside the worker through a zeroizing value; the password field is cleared immediately after scheduling the operation.
- Password authentication for uninstall keeps raw bytes in `Zeroizing<Vec<u8>>`, matching `KeyStoreSession::open_scoped` and avoiding a type mismatch while preserving memory cleanup.
- Elevated uninstall receives a dedicated 180-second process timeout; the 60-second installation timeout is retained. The timeout is now measured with a deadline instead of a fixed polling count.
- The main GUI never waits synchronously for either UAC helper or Service Control Manager work.
- User switching and manual locking are blocked while an install/uninstall operation is in flight, preventing the asynchronous Guard result from being applied to a different profile or from losing the active session before identity cleanup.
- Removed the obsolete WAIT_TIMEOUT constant after moving the elevated helper timeout to a duration/deadline.
