# Opac Window — revisión documental Fixed207

## Base revisada

Fixed207 parte de OpacFixed206. La documentación y las guardas de regresión de Fixed204 siguen siendo la referencia de mantenimiento.

## Decisiones vigentes confirmadas

- El preview integrado usa Media Foundation en modo asíncrono.
- `IMFSample` no cruza hilos; el callback publica buffers Rust zeroizing.
- Cada seek/restart crea una generación nueva y el cierre usa `Flush` + `OnFlush` antes de liberar la sesión.
- El vídeo integrado está limitado a 60 FPS de admisión/presentación; no se fuerza un nuevo frame-rate en Media Foundation.
- El buffer de vídeo es dinámico y el límite duro de seguridad del proceso es de 1 GiB, con margen interno.
- El audio es el reloj maestro cuando está disponible.
- `VideoSyncAction` (`Wait`, `Render`, `Drop`, `Resync(Duration)`) forma parte de la lógica A/V y no debe eliminarse.
- Con `windows-rs 0.62.2`, la implementación COM de `IMFSourceReaderCallback` requiere la dependencia directa `windows-core` 0.62.2 para la macro `implement`.

## Inconsistencia histórica detectada

`VIDEO_ARCHITECTURE_REVIEW_FIXED196.md` conserva una descripción histórica que menciona un scheduler de 30 FPS, un presupuesto de 256 MiB y un buffer de 60 frames. Esa descripción queda superada por `VIDEO_ARCHITECTURE_FINAL.md` y por `REGRESSION_GUARDRAILS_FIXED204.md`, que establecen 60 FPS, buffer dinámico y un backstop de 1 GiB.

No se ha eliminado el documento histórico para conservar trazabilidad. Las nuevas modificaciones de vídeo deben seguir la especificación final y las guardas de regresión, no esos valores históricos.

## Cargo.lock

El `Cargo.toml` contiene comentarios que describen `Cargo.lock` como la fijación exacta de versiones, pero esta base no incluye `Cargo.lock`. Por eso `cargo check` puede resolver y descargar dependencias al ejecutarse en una máquina limpia. Antes de una build release con `--locked`, debe existir un `Cargo.lock` generado y validado por Cargo en el workspace.

Esto es una cuestión de reproducibilidad del build, no un fallo criptográfico.
