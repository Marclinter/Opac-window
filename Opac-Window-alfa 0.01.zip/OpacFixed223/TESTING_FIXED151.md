# Testing Fixed151

Fixed151 añade pruebas de regresión para el paralelismo de chunks y la revisión final del framing V2.

Se cubre que: 
- los resultados de workers pueden llegar 1-3-2 y se reordenan a 1-2-3 antes de escribir;
- un worker que devuelve el plaintext asociado a otro índice es rechazado antes de publicar el batch;
- una permutación real de registros cifrados en el archivo final es detectada por la revisión estructural;
- el temporal de una Caja Fuerte se revisa antes de renombrarlo al nombre físico definitivo.

La huella usada entre workers es solo una comprobación de coherencia interna y no sustituye la autenticación AEAD.

La revisión final además reautentica cada ciphertext con su nonce y AAD correspondientes, por lo que una permutación de registros o un ciphertext asociado al índice equivocado se rechaza antes de publicar el archivo. Se añade una prueba positiva de un `.opac` válido y otra donde dos payloads cifrados se intercambian manteniendo sus índices: la revisión detecta el fallo AEAD antes de publicar.
