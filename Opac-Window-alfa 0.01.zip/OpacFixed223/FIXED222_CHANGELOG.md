# Fixed222

Base: Fixed221.

## Ventana de cmd que parpadea

`icacls.exe` y `sc.exe` son programas de consola. Lanzados desde procesos con
subsistema `windows` (la GUI y el Guard) sin `CREATE_NO_WINDOW`, Windows abre una
consola nueva por cada llamada, que aparece y se cierra al instante.
`set_private_directory_permissions` ejecuta `icacls` cada vez que se asegura una
carpeta (p. ej. el área temporal de sesión al abrir/previsualizar archivos).

- `hidden_command()` aplica `CREATE_NO_WINDOW` a todas las llamadas a `icacls`/`sc`
  (1 en `vault_fs`, 7 en `opac_guard`).
- Sin cambios funcionales: mismos argumentos, mismo control de errores y códigos de salida.
