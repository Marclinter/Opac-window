# Security review — Fixed131

Fixed131 corrige cuatro hallazgos de la revisión de Fixed130:

1. La creación de una Caja Fuerte dentro de una carpeta elegida por el usuario ya no cambia las ACL/permisos de la carpeta contenedora. La protección privada se aplica únicamente a la nueva carpeta de la Caja.
2. La limpieza automática de la Vault Key del portapapeles conserva el estado cuando el portapapeles no está accesible o no puede escribirse, y reintenta hasta conseguir limpiar el secreto. Si el usuario reemplaza el contenido, OPAC deja de considerarlo propio y no sobrescribe el nuevo valor.
3. El backoff de PIN es independiente por Caja Fuerte, evitando que un intento fallido en una Caja afecte a otra.
4. La política de 12–512 caracteres para contraseñas maestras y de exportación cuenta caracteres Unicode cuando la entrada es UTF-8, manteniendo el límite anterior por bytes para entradas binarias no UTF-8.
5. La política de PIN se aplica también por número de caracteres Unicode y la GUI permite el rango completo de 8–128 caracteres; los PIN numéricos siguen exigiendo al menos 10 dígitos.

OPAC Guard no se modifica en Fixed131.
