# Cambios UI — Fixed149

- La barra principal de importación ahora representa el **progreso total por bytes**, no solo el número de archivos terminados. Un vídeo grande ya no permanece visualmente en 0% mientras se cifra.
- La segunda barra está etiquetada como **Archivo actual** y muestra bytes procesados + chunks, para distinguirla de la barra global.
- Los tamaños usan unidades adaptativas (B/KB/MB/GB/TB) en lugar de truncar todo a MB enteros.
- El progreso agregado mantiene avances independientes por archivo para que el cifrado en paralelo no retroceda ni mezcle porcentajes entre workers.
- Un archivo que termina con error no se contabiliza falsamente como si estuviera completamente procesado.
- Se añadieron regresiones para los límites de progreso en archivos pequeños y grandes.
- OPAC Guard no fue modificado.
