# SECURITY_REVIEW_FIXED135

## Dependencias y reproducibilidad

Fixed135 revierte la sobre-fijación de dependencias introducida en Fixed130. El crate principal
utiliza requisitos SemVer razonables y Cargo.lock es la fuente de verdad para las versiones exactas
de cada build. `rand` tiene como mínimo 0.10.1; `chacha20poly1305` permanece en la familia 0.11 y
`zeroize` en la familia 1.9.

La build release exige `Cargo.lock` y `build.rs` invoca el build del Guard embebido con `--locked`
para impedir una resolución distinta en esa segunda invocación de Cargo.

## Alcance

No se modifica la lógica de OPAC Guard.

## Validación

Este entorno no dispone de Cargo/Rust, por lo que no se genera un Cargo.lock inventado. En Windows
debe ejecutarse `cargo generate-lockfile` una vez, revisar el diff del lockfile y después usar
`cargo fmt --check`, `cargo check`, `cargo clippy --all-targets --all-features -- -D warnings` y
`cargo test`. Las releases deben compilarse con `cargo build --release --locked`.
