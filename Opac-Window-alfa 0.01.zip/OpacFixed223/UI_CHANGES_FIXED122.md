# Fixed122 — creación en ubicación elegida y Vault Key importada

- La creación de una Caja Fuerte desde la GUI permite elegir entre generar una Vault Key nueva o reutilizar una Vault Key portable de 64 caracteres hexadecimales.
- La variante de Vault Key importada crea una Caja nueva inicialmente vacía; la clave se reutiliza exactamente y se conserva en memoria usando `Zeroizing`.
- Se añadió `create_vault_default_with_key()` a `KeyStoreSession` para cubrir también la ubicación predeterminada con una clave importada.
- La ubicación personalizada se valida explícitamente en la GUI contra la raíz privada del perfil activo antes de tocar el Key Store, evitando el mensaje tardío de ruta fuera de perfil.
- Esto mantiene el aislamiento por perfil y permite que OPAC Guard siga cubriendo las Cajas creadas por la GUI con la misma raíz protegida.
- Se mantiene separado el flujo «Abrir caja con clave», que sirve para incorporar una Caja existente y conservar su contenido.

- Se limpian el selector de Vault Key importada y su estado tambien al abrir la ventana desde la pantalla vacia o al bloquear/cambiar de sesion.
- Se añade una prueba de persistencia para la variante predeterminada con Vault Key importada.
