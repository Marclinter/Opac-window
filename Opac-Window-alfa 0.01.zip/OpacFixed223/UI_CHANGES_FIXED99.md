# Fixed99 — activación real de OPAC Guard

- Reemplazada la elevación indirecta mediante PowerShell por la API nativa de Windows `ShellExecuteW` con el verbo `runas`.
- El ejecutable elevado recibe directamente `--install-guard`/`--uninstall-guard`, evitando un PowerShell oculto que podía impedir una elevación visible y fiable.
- La activación espera hasta 10 segundos a que el servicio llegue realmente a `Running`; si no aparece, se muestra un error concreto en lugar de dejar la interfaz en `No instalado`.
- La desactivación espera hasta 10 segundos a que el servicio desaparezca.
- Añadido el quoting de argumentos compatible con la línea de comandos de Windows.
- La GUI solo marca Guard como activo después de confirmar que el servicio está en ejecución.
- Los morados y el resto de la apariencia de Fixed86 se mantienen sin cambios.
