# Fixed86 — botón configurable para el arrastre interno

- Añadido en **Ajustes → Arrastre interno para ordenar** un selector entre **Clic izquierdo** y **Clic derecho**.
- La preferencia se guarda en la persistencia de eframe y se recupera al iniciar OPAC.
- La selección se aplica tanto a **archivos** como a **carpetas** del árbol de la Caja Fuerte.
- Por defecto se conserva **Clic derecho**, que era el comportamiento anterior.
- Cuando se selecciona clic izquierdo, el clic derecho mantiene el menú contextual; cuando se selecciona clic derecho, el clic izquierdo mantiene la selección y la apertura normal.
