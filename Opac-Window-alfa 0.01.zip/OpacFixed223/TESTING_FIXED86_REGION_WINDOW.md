# Testing Fixed86 — región y ventana

En Windows, con **No permitir capturas de pantalla de OPAC** activado:

1. `Win+Shift+S` → **Recorte rectangular** → seleccionar una zona que contenga OPAC. OPAC debe quedar excluido.
2. `Win+Shift+S` → **Recorte de ventana** → seleccionar OPAC. OPAC debe quedar excluido.
3. `Win+Shift+S` → **Recorte rectangular** → seleccionar únicamente una zona situada dentro de OPAC. El contenido protegido no debe aparecer.
4. Hacer una captura de pantalla completa que incluya OPAC. OPAC debe quedar excluido.
5. Reiniciar OPAC con la preferencia conservada y repetir las pruebas.
6. Desactivar la protección y comprobar que las capturas vuelven a incluir OPAC.

Si una modalidad concreta sigue capturando OPAC, anotar la versión de Windows, la herramienta exacta utilizada y si era captura de región, ventana o pantalla completa. La API oficial no garantiza protección frente a métodos que ignoren `SetWindowDisplayAffinity`.
