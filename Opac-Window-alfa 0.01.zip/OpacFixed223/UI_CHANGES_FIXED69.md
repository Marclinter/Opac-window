# Fixed69

Esta version parte de Fixed68 y añade una desactivacion autenticada de OPAC Guard; no incluye instalador.

## OPAC Guard: desactivacion autenticada
- `Desactivar` ya no elimina el servicio directamente.
- Se solicita de nuevo la contrasena maestra del usuario de OPAC activo.
- La GUI abre el Key Store dedicado con `KeyStoreSession::open_scoped`; una autenticacion correcta demuestra criptograficamente que se conoce la credencial del perfil que activo el Guard.
- La contrasena nunca se envia al `OpacGuard`.
- Solo despues de la reautenticacion correcta se solicita la elevacion UAC para detener/eliminar el servicio.
- Si UAC se cancela o Windows no completa la desinstalacion, la proteccion sigue activa y la sesion actual vuelve a conectar con el Guard.
- No se modifica el flujo de activacion ni la proteccion de archivos.

## Limites
Esta proteccion garantiza la desactivacion autentica a traves de la GUI de OPAC. Un administrador local con privilegios suficientes puede seguir administrando servicios de Windows fuera de OPAC; el Guard no pretende derrotar el control administrativo del sistema operativo.
