# Validación Fixed125

Pruebas solicitadas para el entorno Windows:

```powershell
cargo fmt --check
cargo check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
cargo test -p opac_guard --all-targets
cargo audit
```

Prueba manual del multimedia:

1. Abrir una Caja Fuerte y seleccionar un vídeo con una pista de audio compatible.
2. Comprobar que aparece "Audio integrado" y que se escuchan vídeo y audio.
3. Probar reproducir/pausa y comprobar que ambos se detienen y continúan juntos.
4. Probar reinicio y comprobar que ambos vuelven al principio.
5. Mover la barra de posición y comprobar que ambos saltan al mismo punto.
6. Cambiar el volumen y comprobar que afecta al audio del vídeo.
7. Probar un vídeo sin pista compatible: el vídeo debe seguir funcionando y debe aparecer el motivo del fallo de audio.
8. Bloquear/cambiar de usuario/cambiar de archivo: la pista de audio y cualquier copia temporal deben detenerse y limpiarse igual que la vista previa de vídeo.
