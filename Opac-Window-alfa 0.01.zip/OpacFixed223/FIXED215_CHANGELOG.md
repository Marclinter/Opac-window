# Fixed215 – formato únicamente

Base: OpacFixed214.

Cambios:
- Corregido el formato `rustfmt` del bloque de `spawn` en `src/video_preview.rs`.
- Corregido el formato `rustfmt` del `assert!` de la prueba smoke de Media Foundation.

No se ha modificado lógica, seguridad, sincronización A/V, criptografía, Guard ni comportamiento del pipeline.
