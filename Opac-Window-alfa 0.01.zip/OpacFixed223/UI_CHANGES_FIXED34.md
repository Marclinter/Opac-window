# Cambios de UI — fixed34

- La raíz de la Caja Fuerte es un destino real de drag-and-drop interno mediante `Ui::dnd_drop_zone` y no puede ser arrastrada como origen.
- Los archivos y carpetas pueden salir de cualquier carpeta y volver a la raíz usando clic derecho + arrastre.
- Los conectores del árbol se calculan con una geometría fija independiente del texto visible.
- El cálculo de `is_last` distingue correctamente entre carpetas y archivos hermanos, evitando líneas verticales que se prolongan o se cortan de forma incorrecta.
- El ramal de un archivo termina en el borde de la fila del archivo para mantener la alineación con las carpetas anidadas.

## Eliminación completa de Caja Fuerte

Las Cajas totalmente desbloqueadas muestran `🗑 Eliminar Caja` en la barra superior. Una Caja con PIN solo muestra ese botón después de una autenticación correcta mediante PIN; una Caja abierta exclusivamente con Vault Key portable mantiene el botón oculto. El diálogo avisa que se perderá todo el contenido y la acción es irreversible.
