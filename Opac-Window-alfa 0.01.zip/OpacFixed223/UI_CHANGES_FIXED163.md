# Fixed163 — indicador de operaciones largas

- El desbloqueo de perfiles dedicados (`KeyStoreSession::open_scoped`) se ejecuta en un hilo de trabajo para que una derivación/verificación Argon2 costosa no bloquee el hilo de la GUI.
- Si una operación de fondo supera 1 segundo, la GUI muestra un pequeño `spinner`.
- El indicador global cubre desbloqueo de usuario, importación, precarga, preparación de audio/vídeo y operaciones de OPAC Guard.
- El desbloqueo deshabilita las acciones de navegación mientras procesa la contraseña.
- La contraseña maestra se limpia del estado de la GUI antes de entregar la copia `Zeroizing` al trabajador.
- Se añadió una prueba de regresión para el umbral de 1 segundo.
