# Fixed86 — revisión y correcciones de bugs

## Correcciones aplicadas

- Se añadió al estado `OpacApp` el campo persistente para elegir clic izquierdo/derecho al arrastrar.
- El cambio de `VaultAccessMode` ya no reutiliza un `Result` movido: la reprotección del Key Store se consulta mediante referencia.
- Las operaciones protegidas (renombrar, mover, borrar, editar, añadir PIN, crear/importar cajas y cambiar el modo de acceso) ya no dejan la interfaz desincronizada si la mutación de disco funciona pero OPAC Guard falla al confirmar la reprotección.
- `CMD_REPROTECT_PATH` del Guard puede retirar una excepción incluso después de que la ruta original haya sido borrada, renombrada o movida. Para ello reconstruye de forma segura la ruta canónica a partir del ancestro existente y rechaza reparse points.
- La normalización de raíces del Guard usa límites de componentes de ruta, evitando que `C:\Opac2` se trate como descendiente de `C:\Opac`.
- El almacenamiento administrativo del Guard exige que la carpeta solicitada esté dentro de `ProgramData\OpacWindow\guard\profiles` y no permite la propia raíz `profiles`.
- Las comprobaciones de rutas de la GUI y del núcleo ya no confunden prefijos de nombres (`foo` frente a `foobar`) con relaciones padre/hijo.
- La exportación fuera de la Caja Fuerte usa una comprobación de descendencia por componentes, evitando falsos positivos por prefijos.
- Las tareas de audio y `PreloadAll` conservan sus temporales y los envían a limpieza diferida cuando Windows no permite borrarlos inmediatamente.
- La limpieza diferida consulta `symlink_metadata`, de modo que un enlace simbólico roto no queda invisible para el limpiador.
- Si la carpeta temporal de sesión desaparece o deja de ser una carpeta normal, se invalida la referencia guardada y se crea otra carpeta única.
- Durante la migración V1→V2, si el V1 no puede eliminarse después de publicar el V2, se intenta retirar la nueva copia para evitar dejar dos representaciones del mismo archivo.

## Orden de borrado

El borrado del `.opac` sigue siendo la operación principal. La limpieza de cualquier copia plaintext temporal es secundaria y nunca puede impedir que el ciphertext se elimine correctamente.

## Límites de validación

Se realizó revisión estática dirigida sobre GUI, filesystem, persistencia y Guard, además de comprobaciones de referencias, campos, rutas y balance estructural. El entorno no dispone de `cargo`, `rustc` ni `rustfmt`, y tampoco permite descargar la toolchain por red; por tanto, no se pudieron ejecutar `cargo check`, `cargo test`, Clippy ni una compilación Windows real.
