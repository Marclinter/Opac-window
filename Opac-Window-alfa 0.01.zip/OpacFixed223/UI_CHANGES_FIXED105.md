# Fixed105 — auditoría completa de la ruta de instalación de OPAC Guard

Esta versión consolida la revisión de instalación/elevación del Guard.

## Cambios

- Las rutas firmadas por OPAC Guard deben poder resolverse de forma canónica antes de generar la firma. Esto evita firmar una ruta textual en la GUI y verificar una ruta canónica diferente en el proceso elevado.
- La GUI y el proceso elevado trabajan con la misma representación canónica del perfil.
- Se añadieron validaciones por etapas para identificar en qué fase falla la instalación: rutas, perfil, almacenamiento administrativo, servicio anterior, configuración, SCM o arranque.
- La sustitución de un servicio anterior espera hasta 30 segundos para detenerse y otros 30 segundos para desaparecer del SCM, en vez de usar una ventana de 3 segundos.
- Se distinguen errores de consulta del SCM de un servicio realmente inexistente.
- Se restauraron las funciones internas de comprobación de archivos/rutas utilizadas por el almacenamiento administrativo (`path_entry_exists` y `ensure_safe_file`).
- Se añadieron regresiones para la canonicalización estricta y el almacenamiento seguro de `roots.bin`.
- Se mantiene el uso de la carpeta ProgramData de Windows obtenida mediante la API de Known Folders y System32 mediante `GetSystemDirectoryW` para evitar depender de variables de entorno administrativas.
- No se modifican los morados ni las funciones visuales de Fixed86+ fuera de esta revisión de Guard.

## Ruta de instalación revisada de extremo a extremo

1. La GUI obtiene la raíz exacta del perfil autenticado y la resuelve antes de firmar.
2. La configuración se firma con Ed25519 sobre `profile_id + public_key + raíces canónicas`.
3. El proceso elevado recibe exactamente la raíz canónica y vuelve a validarla.
4. Se resuelve `ProgramData` con la carpeta conocida de Windows; el almacenamiento administrativo queda separado del perfil del usuario.
5. Se aseguran las ACL de `ProgramData\OpacWindow\guard` y su perfil antes de publicar el binario.
6. Se detiene y elimina el servicio anterior, esperando su desaparición real del SCM.
7. Se materializa el binario en un archivo temporal, se sincroniza y se publica.
8. Se escribe `roots.bin` atómicamente, verificando la firma antes de instalarlo.
9. Se crea el servicio `OpacGuard-<profile-id>` como proceso propio con `LocalSystem` y argumentos ligados al perfil/SID.
10. Se inicia el servicio y la GUI espera hasta confirmar `Running`.
11. Una vez `Running`, la GUI establece el canal IPC autenticado por SID + Ed25519.

Cualquier error se devuelve con la fase correspondiente para no ocultar el punto de fallo.

- Fixed106: se expone `windows_guard::guard_storage_exists` al módulo padre con `pub(super)` para que la API pública del crate pueda delegar correctamente en Windows.
