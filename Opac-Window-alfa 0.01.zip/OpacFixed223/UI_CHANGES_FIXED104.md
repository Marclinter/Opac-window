# Fixed104

## OPAC Guard: firma de configuración y rutas canónicas

- Corregido un fallo en la activación de OPAC Guard donde la GUI firmaba la configuración con la ruta original mientras el instalador elevado la normalizaba/canonicalizaba antes de guardarla.
- `guard_config_message()` ahora usa la ruta canónica cuando está disponible, manteniendo la ruta original como respaldo si todavía no existe.
- La firma generada por la GUI y la verificación realizada por el instalador elevado utilizan así exactamente el mismo material firmado.
- Añadida una regresión que comprueba que la firma de configuración sea válida frente a la raíz canónica.
- No se modifican las claves, el esquema criptográfico ni los morados de la interfaz.


## Fixed105

Revisión integral de la ruta de instalación de OPAC Guard:
- la ubicación administrativa usa la carpeta conocida ProgramData de Windows, no la variable de entorno PROGRAMDATA del proceso elevado;
- las herramientas icacls/sc se resuelven desde el directorio System32 obtenido por la API de Windows, no desde SystemRoot;
- se elimina la validación contra LOCALAPPDATA del proceso elevado, evitando que una elevación con otra cuenta administrativa rechace falsamente la raíz firmada;
- se valida que la raíz firmada exista, sea un directorio normal y termine en profiles/<profile-id>;
- corregido el formato de roots.bin: se estaba serializando dos veces el contador de raíces, lo que hacía que load_config no pudiera parsear correctamente el archivo;
- la materialización del ejecutable del Guard usa escritura+flush+sync_all y ya no ignora un fallo al eliminar la copia anterior;
- se endurece la detección de puntos de reanálisis en el almacenamiento administrativo;
- el nombre del archivo de resultado de UAC incorpora un UUID aleatorio para evitar rutas predecibles;
- añadida regresión de round-trip de roots.bin para impedir que vuelva a romperse el formato.
