# Pruebas de regresión — Fixed126

## Sincronización A/V

Se añadieron pruebas unitarias para fijar el contrato del reloj maestro de audio:

1. un fotograma de vídeo adelantado debe esperar al audio;
2. un adelanto pequeño dentro de tolerancia debe poder mostrarse;
3. un fotograma claramente atrasado debe descartarse para recuperar sincronía;
4. una deriva grande debe forzar una resincronización mediante seek;
5. el mecanismo de generación de control debe avanzar cuando se emite una operación de control.

## Validación Windows recomendada

Ejecutar:

```powershell
cargo fmt --check
cargo check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
cargo test -p opac_guard --all-targets
cargo audit
```

## Prueba manual multimedia

Con un MP4/M4V con audio:

- comprobar el arranque y la sincronización de voz/imagen;
- dejarlo reproducir varios minutos y observar labios, diálogos y golpes de sonido;
- pausar y reanudar repetidamente;
- hacer varios seeks hacia delante y atrás;
- reiniciar desde el principio;
- probar un archivo cuyo audio termine antes que el vídeo;
- probar un archivo sin audio compatible y confirmar que el vídeo continúa sin quedarse bloqueado.
