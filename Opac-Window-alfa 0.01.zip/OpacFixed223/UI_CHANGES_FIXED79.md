# OPAC Window — Fixed79

## Correcciones de compilación tras integrar OPAC Guard como miembro del workspace

- `src/gui.rs` declara y utiliza correctamente el módulo `crate::guard`.
- Se eliminó el código residual en `OpacApp::new()` que referenciaba una variable `app` inexistente.
- `set_ok` recibe ahora una `String` en el flujo de desactivación de OPAC Guard.
- `guard_config_signature` queda reexportada por `src/guard.rs` para la GUI.
- `PIPE_ACCESS_DUPLEX` se importa desde `Win32::System::Pipes`, compatible con `windows-sys 0.61.2`.
- El crate standalone `opac_guard` silencia únicamente los `dead_code` derivados de las APIs compartidas que solo consume la GUI; esto evita que `cargo clippy --workspace --all-targets -- -D warnings` trate esas APIs intencionadamente compartidas como errores.

## Objetivo

Esta versión no cambia el diseño funcional de OPAC Guard. Solo corrige la integración de la GUI y del binario Guard como miembros del workspace, manteniendo el Guard embebido y materializado bajo demanda.

## Validación pendiente

Ejecutar en Windows:

```powershell
cargo test --workspace --all-targets
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo build --workspace --release
```
