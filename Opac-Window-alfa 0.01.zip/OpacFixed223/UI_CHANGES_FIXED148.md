# Fixed148 - control manual de reproducción y suavizado de la vista previa de vídeo

La vista previa de vídeo se queda pausada al terminar la preparación. El worker decodifica un único primer fotograma para mostrar una imagen fija y espera a que el usuario pulse `▶` para comenzar.

El arranque del audio integrado también queda diferido hasta la orden explícita de reproducción. Pausa, reproducción y búsqueda mantienen el reloj de audio inactivo mientras el vídeo está detenido.

También se ha cambiado el consumo de la cola de fotogramas de la GUI para conservar únicamente el último fotograma recibido en cada tick de egui. Así se evita subir varias texturas grandes (1080p/4K) consecutivas mientras la interfaz está ocupada, reduciendo trabajo y evitando que la previsualización se comporte como si fuera de ~1 fps en máquinas donde la subida de texturas era el cuello de botella.

La corrección de stride de Media Foundation de Fixed147 se conserva.

Para vídeos donde la conversión a RGB32 era un cuello de botella, el Source Reader pasa a usar procesamiento avanzado y se le permite utilizar transformaciones de Media Foundation basadas en hardware cuando el equipo ofrece una ruta compatible. El procesamiento avanzado permite que la conversión YUV→RGB32 y otras transformaciones puedan realizarse con mayor soporte de hardware; el modo limitado anterior era un camino de software no optimizado para reproducción en tiempo real.

OPAC Guard no fue modificado.
