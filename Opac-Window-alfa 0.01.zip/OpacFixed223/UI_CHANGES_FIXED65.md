# OPAC Window Fixed65

## Test de escaneo de carpetas externas

- Se corrigió `external_folder_scan_preserves_nested_structure_and_files` para no depender del orden de `PathBuf::cmp` en el sistema operativo.
- El test ahora compara el conjunto de rutas encontradas con el conjunto esperado, manteniendo como contrato la estructura y presencia de archivos, no un orden de enumeración que no forma parte de la API.
- No se modifica la lógica de `scan_external_tree`, la importación ni el cifrado.

## Estado heredado

- Fixed56: aislamiento por `profile_root` y hardening de `export_vault()`.
- Fixed57: corrección de tamaños infinitos que provocaban `NaN` en egui.
- Fixed60/61: selector nativo de archivos sin bloquear la GUI.
- Fixed62/63: conectores del árbol y panel de progreso visible.
- Fixed64: compatibilidad de `Painter::rect_filled` con egui 0.36.
