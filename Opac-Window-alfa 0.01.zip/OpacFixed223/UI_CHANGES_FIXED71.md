# Fixed71 — OPAC Guard: endurecimiento de la primera implementacion

## Cambios

- Identidad Ed25519 persistente por perfil dentro del Key Store cifrado.
- Configuracion de Guard autenticada mediante firma sobre perfil, clave publica y raiz normalizada.
- IPC del Guard con ACL local + desafio/respuesta Ed25519.
- Desactivacion elevada autorizada mediante nonce + firma de la identidad del perfil, ademas de la autenticacion previa de la contrasena en la GUI.
- Almacenamiento administrativo bajo `%ProgramData%\\OpacWindow\\guard` con ACLs restrictivas antes de publicar ejecutable y configuracion.
- Persistencia de `roots.bin` con temporal sincronizado y backups `.new`/`.bak` para tolerar interrupciones.
- Preflight fail-closed: el servicio no se marca como operativo si una raiz falla al recorrer o crear sus handles iniciales.
- Handles sobre directorios y comprobacion del propio handle para rechazar reparse points y reducir TOCTOU.
- Eliminada la dependencia de comprobar la ruta del ejecutable de la GUI contra la ruta del Guard materializado; la autorizacion se basa en SID local + identidad criptografica del perfil.

## Pendiente deliberado

- Cambio a una cuenta de servicio de privilegios minimos: requiere pruebas de ACL/acceso real a los perfiles de usuario.
- Migracion del monitor a `ReadDirectoryChangesW` para evitar reescaneos completos en arboles muy grandes.
- Proteccion de nivel minifilter no forma parte de esta fase.
- Instalador final fuera del alcance.


## Fixed72 — validación del Guard como workspace
- `guard/` pasa a ser miembro del workspace Cargo.
- `cargo test --workspace --all-targets` incluye el binario OPAC Guard.
- `cargo clippy --workspace --all-targets --all-features -- -D warnings` incluye el Guard.
- El binario sigue embebido y materializándose solo al activar OPAC Guard.
- Corregidas referencias internas para que `opac_guard` compile como crate independiente.
- Añadido test de arranque directo del Guard fuera del modo servicio.
