# Opac Window — Fixed183

## Vista previa de vídeo
- La vista previa integrada limita la salida a 960x540 (540p) máximo.
- No se amplían vídeos inferiores a ese tamaño.
- Se mantienen 30 FPS, 30 frames adelantados, 30 de reserva y la cola de 6 frames.
- El archivo original y la ruta de reproductor externo no se modifican.
