# opac_window_core

### OPAC Guard (Fixed87)

`guard/` es un miembro real del workspace y contiene la única implementación del Guard. El crate expone una
librería consumida por `opac_window` y un binario `opac_guard` usado por el servicio de Windows.

La implementación ya no se duplica mediante `#[path = "../../src/guard.rs"]`: `guard/src/lib.rs` es la fuente canónica.
`guard/src/main.rs` es únicamente un wrapper de arranque. `build.rs` compila ese binario de forma determinista y embebe
el PE en `opac_window.exe`; el ejecutable solo se materializa cuando el usuario activa OPAC Guard.

Validación completa del workspace:

```powershell
cargo test --workspace --all-targets
cargo clippy --workspace --all-targets --all-features -- -D warnings
```


Núcleo local-first de **Opac Window** para proteger archivos en Cajas Fuertes locales.
No necesita servidor ni servicio remoto para cifrar, descifrar o gestionar las claves.

## Estado actual

| Pieza | Estado |
|---|---|
| ChaCha20-Poly1305 | Implementado |
| Master Key con Argon2id | Implementado |
| Vault Key aleatoria por Caja Fuerte | Implementado |
| Protección opcional por PIN/passcode | Implementado |
| Exportación explícita por clic derecho | Implementado |
| Key Store (`.opks`) autenticado | Implementado |
| Formato `.opac` V2 por chunks | **Canónico para todas las escrituras nuevas** |
| Formato `.opac` V1 | **Solo lectura legacy** |
| Migración V1 → V2 | Implementado |
| Exportación/importación `.opackey` | Implementado |
| E/S segura en temporales | Implementado |
| Persistencia crash-safe del Key Store | Implementado |
| `KeyStoreSession` / `VaultSession` para la GUI | Implementado |
| Serialización persistente actual (Postcard) | Implementado |
| GUI nativa (egui/eframe) | Implementado: modo oscuro, Cajas Fuertes, carpetas dentro del panel de la Caja, Markdown y drag & drop |

## GUI de Opac Window

La aplicación de escritorio principal es el binario `opac_window`. La GUI utiliza un diseño oscuro y
minimalista con un acento morado y una barra lateral para las Cajas Fuertes. No existen Cajas Fuertes
predeterminadas: la instalación empieza vacía y el usuario crea cada Caja Fuerte con el nombre que
quiera desde `+ Nueva caja fuerte`. La ubicación física se genera automáticamente dentro del almacenamiento
local de Opac Window y no utiliza el nombre visible de la Caja como nombre de carpeta.

El drag & drop de archivos está habilitado en la ventana nativa. Mientras se arrastra un archivo,
la aplicación muestra una zona de destino visible. Al soltarlo, el cifrado V2 se ejecuta en un hilo
de trabajo para que la interfaz siga respondiendo y muestra el archivo actual y el progreso por
cuenta de archivos. La Caja Fuerte no se puede cambiar ni bloquear durante ese trabajo.

La barra lateral se reserva para las Cajas Fuertes. El contenido de una Caja Fuerte abierta se muestra dentro
del panel central: hay una fila **Raíz**, un botón **+** para crear **Nueva carpeta** o **Nuevo archivo de texto**,
y las carpetas se abren dentro del mismo panel con una ruta de migas. Los archivos de texto nuevos se crean como
Markdown (`.md`) y se pueden editar y previsualizar dentro de Opac Window. Las carpetas usan un marcador
`.opac-folder` cifrado para conservar su nombre visible sin convertirlo en el nombre físico del directorio.

El drag & drop del sistema operativo se conserva: soltar un archivo fuera de cualquier fila de carpeta o sobre
**Raíz** lo cifra en la raíz de la Caja; soltarlo sobre una carpeta visible lo cifra directamente dentro de esa
carpeta. La carpeta abierta no cambia esta regla: su panel sigue ofreciendo **Raíz** como destino explícito y
las carpetas visibles como destinos concretos. Para reorganizar elementos ya almacenados, un archivo o una
carpeta se puede arrastrar manteniendo el botón derecho y soltándolo sobre otra carpeta o sobre **Raíz**. El
movimiento cambia únicamente la ubicación física del `.opac`; no descifra ni vuelve a cifrar su contenido.

El flujo principal es deliberadamente corto:

```text
crear/desbloquear instalación
          |
          v
   Cajas Fuertes (barra lateral)
          |
          +---- crear nueva caja
          |
          v
      archivos .opac
          |
          +---- arrastrar archivos a la ventana
          +---- seleccionar para ver metadata
          +---- previsualizar textos pequeños
          +---- doble clic para abrir mediante una copia temporal descifrada
```

Las nuevas escrituras siguen usando V2 y la misma Vault Key por Caja Fuerte. La GUI no expone el
formato `.opac`: al usuario le muestra el nombre original almacenado en la metadata autenticada.

El modo oscuro es el predeterminado y se fija explícitamente incluso si Windows utiliza el tema claro.
Al arrastrar archivos sobre la ventana aparece una zona de destino visible y, al soltarlos, el cifrado
se ejecuta en segundo plano para que la interfaz no se congele. Mientras dura la operación se muestra
el archivo actual, el progreso de archivos `n/N` y, cuando aplica, el progreso por chunks; no se puede cambiar de Caja Fuerte ni bloquear la sesión hasta
que el trabajo termine.

La clave de una Caja Fuerte puede mostrarse explícitamente desde el botón `Clave`. Las Cajas Fuertes
protegidas por PIN muestran un diálogo al abrirse. El bloqueo elimina inmediatamente las sesiones y
la referencia a las claves del estado de la GUI. Los archivos de texto pequeños pueden previsualizarse
dentro de la aplicación; el doble clic sobre cualquier archivo lo descifra a un temporal con nombre
aleatorio y lo abre con la aplicación predeterminada del sistema.

Para ejecutar la aplicación:

```bash
cargo run
```

La GUI usa `eframe 0.36.2`, que requiere Rust 1.95 como MSRV, por lo que este proyecto requiere Rust 1.95 o superior.

## V1 frente a V2

El ZIP no contiene historial Git, por lo que no se puede reconstruir un commit exacto que
marque la transición. Sí se puede verificar el estado del diseño actual:

- V1 es el formato monolítico que cifra metadata + contenido de una vez.
- V2 es el formato canónico que contiene toda la funcionalidad de V1 y añade streaming por
  chunks, nonces derivados de prefijo + índice, metadata separada y detección autenticada
  de truncamiento, reordenación y extensión.
- El código original seleccionaba V1 para archivos pequeños y V2 para archivos grandes.
  Eso convertía V1 en un formato de escritura todavía activo.
- En esta revisión se elimina esa bifurcación de formatos: **todo archivo nuevo se escribe como V2**.
  Para conservar la eficiencia de V1 en archivos pequeños, V2 usa un único chunk hasta
  `DEFAULT_CHUNKING_THRESHOLD` (8 MiB) y activa chunks de 4 MiB por encima de ese umbral.
  V1 permanece únicamente para abrir instalaciones existentes y se puede migrar con
  `vault_fs::migrate_legacy_v1_file`.

Por tanto, V1 ya no es una segunda implementación operativa del diseño; es compatibilidad
con un formato histórico.

## Propiedades de seguridad relevantes

### Argon2id

El núcleo usa Argon2id con parámetros por defecto de **64 MiB, 3 pasadas y 4 lanes**.
Son los parámetros recomendados por RFC 9106 para el escenario de memoria limitada, mientras
que OWASP publica varias combinaciones equivalentes y exige como mínimo 19 MiB / 2 / 1.
Los archivos controlan estos parámetros, pero el núcleo los valida antes de ejecutar Argon2id y
rechaza valores extremos para impedir asignaciones arbitrarias de memoria.

### PIN en una aplicación local-first

El PIN se considera un secreto sometido a ataque offline. No se pretende que un contador de
intentos de la GUI sea una defensa criptográfica frente a una copia del disco.

La API exige al menos 8 bytes y, si el secreto es exclusivamente numérico, al menos 10 dígitos.
La protección vuelve a derivarse con Argon2id y se autentica con ChaCha20-Poly1305.

### Formato V2

Cada archivo usa el mismo contenedor V2. La política por defecto es:

- hasta 8 MiB: un único chunk de datos;
- más de 8 MiB: chunks de 4 MiB, procesados en streaming.

Cada archivo usa:

```text
cabecera pública autenticada
    + metadata cifrada/autenticada
    + chunks autenticados individualmente
```

Las nuevas escrituras V2 usan un nonce de 96 bits construido a partir de una base aleatoria por archivo y del índice del chunk; los V2 históricos con el esquema anterior siguen siendo legibles.
El índice, la marca de último chunk y la cabecera forman parte del AAD.

El lector valida además:

- tamaños antes de reservar memoria;
- índice estrictamente consecutivo;
- `is_last` con valores 0/1;
- tamaño de plaintext compatible con `chunk_size`;
- ausencia de bytes después del último chunk;
- `original_size` frente al total realmente procesado.

### Escritura atómica

`vault_fs` nunca escribe plaintext directamente al destino final. Crea un temporal con nombre
aleatorio mediante `create_new`, lo sincroniza y lo renombra solo después de completar la
operación.

La API de descifrado no sobrescribe automáticamente un archivo existente.

### Secretos en memoria

`MasterKey`, `VaultKey`, las claves derivadas de PIN y los buffers de plaintext intermedios
se limpian mediante `zeroize` cuando salen de ámbito. La representación interna del Key Store
también usa un wrapper que limpia las Vault Keys almacenadas en memoria.

Esto no convierte una máquina comprometida o un SSD en un entorno de borrado perfecto: el
módulo de visualización temporal seguirá necesitando una política específica para los archivos
plaintext que entregue a aplicaciones externas.

## Serialización y formatos persistentes

Los formatos actuales usan **Postcard 1.1.x** para serializar estructuras internas antes
de aplicar el cifrado autenticado. Postcard tiene un wire format documentado y estable desde
su versión 1.0 y usa codificación varint para enteros mayores de 8 bits.

Los archivos generados por versiones anteriores de Opac Window pueden contener datos
serializados con la antigua codificación de bincode 1.x. El núcleo actual ya no depende de
bincode: incluye un lector legacy mínimo y estrictamente acotado únicamente para esos datos
históricos. No existe un escritor bincode nuevo.

### `.opac` V2

```text
[4]  magic = OPAC
[2]  version = 2
[2]  flags
     0 = metadata legacy (bincode 1.x)
     1 = metadata actual (Postcard)
[16] file_id
[8]  nonce_prefix
[4]  chunk_size
[4]  metadata_sealed_len
[..] metadata sealed (AEAD)

repeat:
  [1]  is_last (0/1)
  [4]  chunk_index
  [4]  sealed_len
  [..] chunk sealed (AEAD)
```

Todos los `.opac` nuevos se escriben como V2 con `flags = 3` (`metadata Postcard` + nonce endurecido).
El campo `flags` forma parte de la cabecera usada como AAD. Los V2 históricos con `flags = 0`
(metadata bincode 1.x + nonce histórico) y `flags = 1` (metadata Postcard + nonce histórico)
siguen siendo legibles.

V2 conserva la misma Vault Key para todos los archivos de una Caja Fuerte. Hasta 8 MiB se
usa un único chunk de datos; por encima se usan chunks de 4 MiB.

### Migración de serialización

Las versiones anteriores usaban bincode 1.x dentro de los datos cifrados. Las versiones actuales
usan Postcard. El núcleo conserva lectores legacy para esos datos y, cuando una instalación se
guarda de nuevo o un archivo V1 se migra, el resultado pasa a utilizar la serialización actual.
No se conserva una dependencia de bincode para las nuevas operaciones.

### `.opac` V1 (legacy)

Se conserva el lector del formato monolítico anterior para compatibilidad. No se genera con
ninguna de las APIs de escritura del núcleo. La migración V1 → V2 conserva la Vault Key y
convierte el archivo al formato canónico V2.

### `keystore.opks`

Version 1 es el formato histórico: su cuerpo estaba serializado con bincode 1.x.
Version 2 es legacy de transición y usa Postcard. Version 3 es legacy de transición y añade
`VaultAccessMode` por Caja Fuerte. Version 4 es el formato actual: conserva `VaultAccessMode` y añade
la vinculación opcional del Key Store al UUID del perfil dedicado. Todas las nuevas escrituras producen V4.
El lector acepta V1/V2/V3/V4.

El salt y los parámetros Argon2id son públicos pero están autenticados como AAD. El resto,
incluidas Vault Keys, se cifra con la Master Key.

### Vault Key portable

La Vault Key mostrada explícitamente mediante el botón «Clave» es una credencial portable de 256 bits codificada como 64 caracteres hexadecimales. Puede utilizarse para abrir una Caja Fuerte en otro dispositivo sin volver a derivarla de una contraseña. La GUI permite registrar una carpeta de Caja Fuerte existente con esa clave o desbloquear una Caja registrada con ella, incluso si tiene PIN: la Vault Key es la credencial criptográfica final del contenido. El usuario debe tratarla como un secreto equivalente al acceso completo a la Caja. Copiarla al portapapeles solo ocurre tras una acción explícita.

### `.opackey`

Version 1 es legacy y se puede importar. Version 2 es el formato actual y utiliza Postcard
para el cuerpo cifrado. Las nuevas exportaciones generan siempre V2.


## Sesiones y ciclo de vida local

La capa `session` es la API de alto nivel que debe utilizar la futura GUI. `KeyStoreSession`
representa la instalacion local desbloqueada y mantiene la Master Key en memoria mientras la
sesion existe. `VaultSession` representa una Caja Fuerte concreta y conserva solamente su propia
Vault Key. `lock()` consume la sesion y permite que los wrappers `Zeroizing` limpien las claves.

El flujo previsto es:

```text
KeyStoreSession::open(...)
        |
        +-- list_vaults()
        |
        +-- open_vault(id, pin) --> VaultSession
        |                              |
        |                              +-- list_files()
        |                              +-- read_file_metadata()
        |                              +-- import_file()
        |                              +-- decrypt_file()
        |                              +-- delete_file()
        |                              +-- migrate_legacy_files()
        |                              +-- vault_key() [accion explicita de GUI]
        |                              +-- lock()
        |
        +-- create/change/import/export --> guardado automatico
        +-- change_master_password()   --> guardado automatico
        +-- lock()
```

Las mutaciones del Key Store realizadas mediante `KeyStoreSession` se persisten inmediatamente.
Si el guardado falla antes del punto de commit, la sesion intenta restaurar tambien la copia
anterior en disco y el estado anterior en memoria. La persistencia del archivo utiliza un candidato
`.new`, una copia `.bak` y un punto de commit mediante `rename`. Si una interrupcion ocurre
despues de apartar el principal y antes del commit, el siguiente arranque puede recuperar el
candidato valido; si el commit ya termino, la copia `.bak` se considera solo residuo de limpieza.
La politica esta pensada para evitar estados parciales incluso en Windows, donde no conviene
suponer que `rename` puede reemplazar siempre un archivo existente de forma portable.
En un arranque posterior se valida criptograficamente el principal y, si es necesario, se recupera
un candidato valido. En Unix tambien se sincroniza el directorio cuando la API del sistema lo permite.

La capa `session` no aplica por sí misma un temporizador de inactividad; la política de runtime vive en la GUI.
La GUI de Opac Window bloquea automáticamente la sesión tras 10 minutos sin actividad y deja el bloqueo
en espera si hay una importación, precarga o preparación de audio en curso, ejecutándolo cuando termina
esa operación. Tampoco existe todavía un bloqueo interproceso del `keystore.opks`; el diseño actual
presupone una sola instancia de Opac Window como escritora activa.

Los archivos `.opac` se manejan mediante temporales y rename en `vault_fs`, de forma que un error
de descifrado no deja un destino final parcialmente escrito. La eliminacion de un `.opac` se limita
a la carpeta de la Caja Fuerte.

## Pruebas

Los tests cubren roundtrips, claves incorrectas, manipulación de ciphertext/cabecera, PIN,
múltiples Cajas Fuertes, exportación/importación, formato V2, límites de chunks, truncamiento,
reordenación, extensión, compatibilidad de lectura V1, sesiones, carpetas anidadas y movimiento de
archivos/carpetas sin cambiar el ciphertext, eliminación segura de carpetas no vacías, guardado
automático y escenarios de recuperación del Key Store tras operaciones de persistencia incompletas.

Para validar localmente:

```bash
cargo test
cargo clippy --all-targets --all-features -- -D warnings
```

### Regresion de seguridad automatizada

Ademas de los tests unitarios por modulo, `tests/security_regression_tests.rs` fija invariantes de seguridad a nivel de API publica: secretos conocidos no aparecen en claro en Key Store/.opac/.opackey, tampering de cabeceras y AAD se rechaza, los limites de Argon2id y PIN no se relajan, entradas truncadas no provocan panicos, una Caja Fuerte no puede operar sobre rutas de otra, un chunk posterior corrupto no publica un destino parcial y un sidecar de recuperacion corrupto no sustituye a un Key Store principal valido.

Estos tests detectan regresiones del diseño, pero no constituyen una prueba formal ni garantizan ausencia de vulnerabilidades. La validacion externa sigue incluyendo `cargo clippy --all-targets --all-features -- -D warnings` y `cargo audit`.

El ZIP entregado para esta revisión no incluye el directorio `.git` ni una instalación de Rust,
por lo que la compilación final debe ejecutarse en un entorno con toolchain Rust.


## Acceso de archivos desde la GUI

Cada Caja Fuerte tiene una preferencia independiente de acceso: **Descifrar al usar** (valor por defecto) o **Descifrar al abrir**. En el primer modo, Opac Window solo crea una copia temporal descifrada cuando el usuario selecciona/previsualiza o abre un archivo. En el segundo, al abrir la Caja Fuerte la aplicación prepara en una carpeta temporal de la sesión los archivos que requieren acceso mediante fichero; las imágenes y PDF no se materializan en esa carpeta y se descifran solo al previsualizarlos.

La preferencia se guarda dentro del Key Store cifrado de Opac Window. No cambia la Vault Key ni vuelve a cifrar los archivos. Al bloquear o cerrar la aplicación, Opac Window intenta eliminar la carpeta temporal de descifrado. La opción **Descifrar al abrir** consume más disco temporal y mantiene más plaintext disponible durante la sesión; por eso **Descifrar al usar** es el valor predeterminado.


### Modo de acceso de una Caja Fuerte

La GUI ofrece una selección por Caja Fuerte:

- **Descifrar al usar** (por defecto): solo se crea un archivo temporal cuando el usuario previsualiza o abre un archivo.
- **Descifrar al abrir**: al abrir la Caja Fuerte se preparan en una carpeta temporal de la sesión los archivos que requieren un fichero; las imágenes y PDF se mantienen fuera de esa caché y se descifran directamente en memoria al previsualizarlos.

La preferencia se almacena en el Key Store cifrado. No cambia la Vault Key ni los `.opac`. Cambiar a **Descifrar al usar** elimina la caché temporal de la sesión.


## GUI nativa

El binario por defecto es `opac_window`, por lo que `cargo run` inicia directamente la interfaz. La GUI usa eframe 0.36.2 con el renderer Glow y modo oscuro.


### Previsualizacion Markdown y audio

La vista previa integrada reconoce Markdown (`.md`, `.markdown`) y lo renderiza localmente con `egui_commonmark 0.25.0`, sin las funciones `fetch` ni carga de imagenes remotas. Los audios compatibles (MP3, WAV, FLAC, Ogg/Vorbis y AAC en MP4/M4A) se descifran a una copia temporal autenticada y se reproducen con `rodio 0.22.2`. La copia temporal se mantiene solo mientras el audio esta seleccionado/reproduciendose y se elimina al cambiar de archivo, bloquear la sesion o cerrar la aplicacion.

### Exportacion explicita

Cada archivo de una Caja Fuerte dispone de la accion `Exportar…` en su menu contextual de clic derecho. Esta es la unica ruta de la GUI que exporta el archivo: se abre el dialogo nativo de guardado para elegir exactamente la ubicacion y el nombre del archivo, y despues Opac Window descifra el `.opac` a esa ruta. El `.opac` cifrado original permanece dentro de la Caja Fuerte. Mover manualmente un `.opac` con el Explorador de Windows no activa ninguna exportacion ni descifrado automatico.


### Eliminacion explicita

Cada archivo de una Caja Fuerte dispone tambien de la accion `Eliminar` en el menu contextual de clic derecho. La accion solicita confirmacion y, si se confirma, elimina unicamente el `.opac` cifrado de la Caja Fuerte mediante `VaultSession::delete_file`. No descifra, exporta ni mueve el archivo a otra ubicacion. Mover un `.opac` manualmente desde el Explorador tampoco activa esta accion.

## Edición integrada de TXT y Markdown

Los archivos de texto soportados (incluidos `.txt`, `.md` y `.markdown`) que caben en el límite de vista previa pueden editarse directamente desde la vista previa. El botón `Editar` pasa a `Guardar` y `Cancelar`. `Guardar` cifra de nuevo el contenido dentro de la Caja Fuerte sin exportar el archivo, y el cambio se conserva automáticamente al cambiar de archivo, cambiar de Caja Fuerte, bloquear la sesión o cerrar la aplicación. `Cancelar` restaura el contenido que estaba almacenado antes de entrar en edición.

La edición conserva la misma ruta opaca del `.opac`; el contenido nuevo se publica solo después de haber sido cifrado y sincronizado. Si el archivo era V1 legacy, una edición lo convierte a V2.

### Vista previa de imágenes

Los formatos PNG, JPEG, GIF y WebP se pueden previsualizar directamente dentro de la Caja Fuerte. La aplicación descifra el archivo solo en memoria para preparar la imagen y no crea una copia plaintext en disco para esta función. La vista previa está limitada a 32 MiB por archivo, 8.192 px por eje y 16 millones de píxeles. Incluso en el modo **Descifrar al abrir**, estas imágenes no se materializan en la caché temporal: se leen desde el `.opac` cifrado y se descifran solo en memoria al mostrarlas.

### Vista previa de PDF

Los archivos PDF se previsualizan como páginas renderizadas dentro de la Caja Fuerte. La aplicación descifra el PDF solo en memoria para esta función y no reutiliza la caché plaintext de **Descifrar al abrir**. Se renderizan visualmente las primeras 3 páginas mediante `pdfboss-core`/`pdfboss-render` 2.11.0, sin crear un PDF temporal en disco. La vista previa está limitada a 16 MiB por archivo, 3 páginas renderizadas y un máximo aproximado de 6 millones de píxeles por página, además de un límite de 2.400 px en su dimensión mayor. Los PDF que el renderizador no pueda interpretar mantienen la opción de abrirse con la aplicación predeterminada.

## Organización en árbol

Las carpetas se muestran integradas dentro de cada Caja Fuerte, separadas visualmente del panel de Cajas. El botón `＋` bajo el nombre de la Caja abre las acciones para crear una carpeta o un archivo Markdown. Las carpetas se expanden y contraen desde su fila, con conectores visuales para representar la jerarquía.

El arrastre de archivos desde Windows se mantiene: soltar sobre una carpeta importa el archivo dentro de ella; soltar en la raíz o fuera de cualquier carpeta lo deja en la raíz de la Caja. El movimiento interno de archivos y carpetas usa el botón configurado en **Ajustes → Arrastre interno para ordenar** (clic izquierdo o clic derecho). Por compatibilidad, el valor predeterminado sigue siendo clic derecho.

### Creacion de una Caja

Al crear una Caja Fuerte, la aplicacion permite opcionalmente importar una Vault Key
portable de 64 caracteres hexadecimales. Si no se pulsa el boton, se genera una clave
nueva como hasta ahora. Tambien se puede elegir entre la ubicacion predeterminada y
una carpeta padre seleccionada con el explorador del sistema; la carpeta fisica final
de la Caja se crea con un identificador aleatorio.

Una Caja creada con una clave portable es una Caja normal a todos los efectos. Los
archivos nuevos se cifran con esa misma clave y un `.opac` que ya haya sido cifrado con
esa clave puede autenticarse y descifrarse al colocarlo en la carpeta fisica de la Caja.



## Importacion manual multiple

El boton `+` incluye `Importar archivos…`, que abre el selector nativo de archivos de Windows.
El selector se ejecuta en un hilo dedicado, de modo que la ventana principal de Opac Window sigue
procesando repintados y eventos de entrada, incluido el arrastre de archivos o carpetas sobre la
ventana principal, mientras el Explorador permanece abierto.

Al pulsar `Abrir`, los archivos seleccionados se entregan de vuelta al hilo de la GUI mediante un
canal `mpsc` y pasan por la misma cola de cifrado que usa el drag & drop. La selección manual permite
elegir varios archivos; las carpetas completas se importan por drag & drop sobre la ventana principal.
La cola ordena los archivos por tamaño ascendente y conserva el orden original para tamaños iguales.


## Perfiles locales multiusuario

Opac Window admite varios perfiles en el mismo PC. Cada perfil dispone de un Key Store independiente y se desbloquea con su propia contraseña maestra. Los registros de Cajas Fuertes (incluidos sus nombres, ubicaciones y Vault Keys) permanecen dentro del Key Store cifrado de ese perfil.

El catálogo local de perfiles conserva únicamente identificadores opacos y el tipo de almacenamiento en sus nuevas escrituras; no contiene nombres de Cajas Fuertes, Vault Keys, contraseñas ni contenido de archivos. El nombre real del perfil se guarda dentro del Key Store cifrado y solo se muestra después de autenticar el perfil. El selector bloqueado utiliza etiquetas neutras como «Usuario 1», «Usuario 2», etc.

La opción «Cambiar usuario» limpia primero la sesión activa, previews, temporales, cachés y estado de la Caja antes de volver a la selección de perfiles. «Bloquear» vuelve directamente al desbloqueo del mismo perfil.

La compatibilidad con instalaciones antiguas se conserva mediante un perfil «Perfil principal» que apunta al `keystore.opks` histórico cuando todavía existe. Las nuevas instalaciones crean sus Key Stores en directorios por perfil con nombres aleatorios.

En un PC compartido, cada usuario debe usar una contraseña distinta y fuerte. Las contraseñas no se almacenan: se usan para derivar la Master Key. La separación se aplica a nivel de la aplicación; un administrador local de Windows, malware con permisos elevados o una sesión del sistema ya comprometida puede inspeccionar o modificar el proceso y el almacenamiento, por lo que no forma parte del modelo de amenaza que este aislamiento pueda impedir ese nivel de acceso.


### Perfiles y aislamiento local

Cada perfil dedicado de Opac Window tiene una carpeta física propia bajo `profiles/<id>/`. Su `keystore.opks` y un subdirectorio `vaults/` viven dentro de ese perfil. Una `KeyStoreSession` abierta con alcance de perfil solo puede listar, abrir, crear, importar o eliminar Cajas cuya ruta real se encuentre dentro de la raíz del perfil activo; la raíz no es una Caja movible. Las Cajas externas incorporadas mediante Vault Key se copian primero a la carpeta `vaults/` del perfil activo y el origen cifrado no se modifica. Las comprobaciones de alcance se realizan con rutas canónicas y se rechazan Cajas anidadas o rutas fuera del perfil.

### Perfiles y migracion de instalaciones antiguas

Los perfiles nuevos tienen un directorio fisico dedicado con su propio Key Store y carpeta `vaults`. Las instalaciones antiguas con un `keystore.opks` en la raiz se muestran como un perfil normal y se migran al primer desbloqueo exitoso; despues pasan a usar el mismo esquema dedicado que cualquier perfil nuevo.

### Bloqueo automatico y limpieza de runtime

Por seguridad, una sesion de usuario se bloquea automaticamente despues de 10 minutos sin actividad. Al bloquear o cambiar de usuario se liberan las sesiones de Caja, previews, PINs y claves de runtime y se detienen los workers multimedia. Los temporales de aplicaciones externas se eliminan de forma proactiva; si Windows los mantiene abiertos, Opac los reintenta eliminar sin reutilizarlos para el siguiente usuario.

### Fixed63: feedback visual de importación

Durante una importación la GUI muestra el progreso de archivos completados y, para un archivo grande dividido en varios chunks, el progreso específico del archivo actual. El indicador es independiente de que la carpeta de destino esté desplegada. En el árbol, las ramas terminales se detienen explícitamente en la unión `└`.


## OPAC Guard (Windows, experimental)

Fixed85 mantiene **OPAC Guard** como servicio opcional y separado de la interfaz de Opac Window. El ejecutable del Guard ya no se distribuye como un archivo independiente junto a la GUI: el crate `opac_guard` se compila en una caja auxiliar minima y su PE Windows se **embebe dentro de `opac_window.exe`**. Mientras la funcion esta desactivada no existe una copia fisica de `opac_guard.exe`.

Desde **Ajustes → OPAC Guard** el usuario autenticado de Opac Window puede activar la proteccion mediante UAC. La operacion elevada usa el propio `opac_window.exe`, extrae el payload del Guard solo en ese momento y lo materializa bajo `%ProgramData%\OpacWindow\guard\profiles\<profile-id>\opac_guard.exe`, despues registra y arranca el servicio correspondiente.

La frontera funcional es el **usuario de la aplicacion de Opac Window**, identificado por `profile_id`. Cada perfil que activa Guard tiene una instancia de servicio, configuracion y named pipe independientes. El SID de Windows se conserva unicamente como control del canal IPC; no decide que usuario de Opac Window recibe la proteccion.

El Guard no descifra ni lee contenido. Mantiene handles de Windows sobre `*.opac`, `.opac-folder` y `keystore.opks` con una comparticion que no permite escritura ni borrado. La raiz del perfil permanece protegida incluso mientras OPAC esta abierto y desbloqueado. Las lecturas y vistas previas no necesitan desproteger nada porque se permiten mediante `FILE_SHARE_READ`; solo las operaciones que realmente necesitan escribir, mover, renombrar o borrar solicitan una excepcion temporal y de alcance minimo.

Cada liberacion es una orden IPC autenticada y firmada con Ed25519. La firma queda ligada al `profile_id`, al desafio fresco de la sesion IPC, al tipo de operacion, a una secuencia monotona y a la ruta exacta. El servicio vuelve a validar la ruta contra la raiz autorizada, rechaza reparse points y nunca acepta liberar la raiz completa del perfil. Tras ejecutar la operacion, la GUI pide la reproteccion y espera confirmacion del Guard; si se pierde la conexion, el servicio elimina las excepciones y rearma todo el arbol. Antes de aplicar un nuevo conjunto de excepciones, el servicio detiene completamente los workers anteriores para que sus propios handles no bloqueen la reconfiguracion; si el rearme falla, el Guard se detiene en modo fail-closed. El numero de excepciones simultaneas tambien esta limitado.

El Guard tampoco expone comandos independientes de instalacion o desinstalacion. Esos cambios se realizan mediante el `opac_window.exe` elevado y, para desactivar desde la GUI, despues de autenticar de nuevo la contraseña maestra del usuario de OPAC. El servicio nunca recibe contraseñas, PINs, Vault Keys ni plaintext.

### Fixed71: identidad y endurecimiento del Guard

Fixed71 mantiene el Guard embebido y añade una identidad Ed25519 por perfil dentro del Key Store cifrado.
La clave privada nunca se transmite al servicio ni sale del proceso GUI salvo para firmar un desafio de
instalacion, sesion IPC o desactivacion. La configuracion materializada del Guard incluye la clave publica
y una firma de las rutas normalizadas; el servicio verifica esa firma antes de operar. La desactivacion
elevada necesita una prueba firmada ligada al `profile_id` y a un nonce fresco, despues de que la GUI haya
vuelto a autenticar la contrasena maestra del perfil.

La configuracion se escribe mediante un temporal sincronizado, rotacion a `.bak` y recuperacion desde
`roots.bin.new`/`.bak` si la aplicacion se interrumpe durante el reemplazo. El almacenamiento de Guard bajo
`%ProgramData%\\OpacWindow\\guard` recibe ACLs explicitas para SYSTEM y Administradores antes de publicar
el ejecutable o la configuracion, de forma que el binario del servicio no dependa de una carpeta de
desarrollo escribible por un usuario normal.

El canal named pipe combina una ACL local y un desafio/respuesta Ed25519. El SID de Windows solo se usa
como primera barrera de acceso al pipe; la identidad logica continua siendo el `profile_id` de Opac Window.
La GUI y el Guard no intercambian contrasenas, PINs, Vault Keys ni plaintext.

La proteccion de filesystem abre tambien handles sobre directorios con `FILE_FLAG_OPEN_REPARSE_POINT` y
rechaza objetos que sean reparse points en el propio handle, reduciendo la ventana TOCTOU. Si una raiz no
puede recorrer o crear sus handles iniciales, el servicio no se declara operativo.

El monitor usa `ReadDirectoryChangesW` con E/S superpuesta y reenumeracion solo tras notificaciones.

### Desarrollo del Guard

El proyecto mantiene `guard/` como una caja de compilacion minima que comparte la implementacion de `guard/src/lib.rs`. El `build.rs` compila esa caja en modo release optimizado y copia el PE resultante a un recurso generado de la GUI. Asi, el desarrollo normal utiliza un unico ejecutable `opac_window.exe`; la copia fisica del Guard aparece solo despues de activar la funcion.

```text
cargo build
cargo test --all
cargo clippy --all-targets --all-features -- -D warnings
```

### Desactivacion autenticada
La desactivacion desde la GUI requiere volver a autenticar el Key Store dedicado del perfil activo. La contraseña no se envia al servicio. Despues de la autenticacion correcta se solicita UAC para detener y eliminar el servicio y retirar su copia materializada. Si UAC se cancela o Windows no puede eliminar el servicio, la proteccion permanece activa.



### Fixed74 — OPAC Guard endurecido
Fixed74 mantiene `opac_guard.exe` embebido en `opac_window.exe` y solo lo materializa cuando el usuario de Opac Window activa OPAC Guard. La activacion usa UAC y registra un servicio Windows por `profile_id`. El servicio protege exclusivamente la raiz dedicada de ese usuario de Opac Window.

La configuracion administrativa usa `roots.bin` firmado con Ed25519, identidad criptografica persistida dentro del Key Store cifrado, escritura temporal sincronizada y candidatos de recuperacion `.new`/`.bak`. La identidad del Guard se elimina del Key Store despues de una desactivacion completa para que la siguiente activacion genere una identidad nueva.

El canal GUI-Guard usa named pipe con ACL de Windows, comprobacion del SID del proceso cliente y desafio/respuesta Ed25519 ligado al `profile_id`. El Guard no recibe contrasenas, PINs, Vault Keys ni datos en plaintext. La desactivacion requiere reautenticacion del Key Store, firma Ed25519 y elevacion UAC.

La proteccion filesystem abre archivos y directorios con `FILE_FLAG_OPEN_REPARSE_POINT`, consulta los atributos del handle y no comparte escritura ni borrado. La vigilancia usa `ReadDirectoryChangesW` con E/S superpuesta. Los fallos de escaneo, vigilancia o creacion de workers son fail-closed y solicitan la detencion del servicio.

La eliminacion de un perfil se rechaza mientras exista almacenamiento administrativo del Guard para ese `profile_id`. Primero debe desactivarse Guard y limpiarse completamente su estado administrativo.

La instalacion del servicio usa una ruta protegida bajo `%ProgramData%\OpacWindow\guard`; el ejecutable y su configuracion tienen ACL restrictivas y las herramientas administrativas se invocan mediante rutas de sistema conocidas. La cuenta del servicio permanece explicitamente en `LocalSystem` en esta etapa para conservar acceso al almacenamiento protegido; una migracion a una cuenta de minimo privilegio queda como trabajo futuro sujeto a pruebas de ACL del almacenamiento de perfiles.


## Fixed86 — protección independiente de capturas

En **Ajustes** está disponible **No permitir capturas de pantalla de OPAC**, independiente de OPAC Guard. En Windows se apoya en `SetWindowDisplayAffinity/WDA_EXCLUDEFROMCAPTURE` y la preferencia queda guardada para futuros inicios.


## Fixed102
Diagnóstico visible y activación de OPAC Guard en segundo plano, con errores de servicio diferenciados y comprobación explícita de estado.
