# Fixed114

## OPAC Guard: corrección de resolución de rutas durante la instalación

- Corregido el falso error `la ruta del Guard queda fuera del almacenamiento administrado`.
- `secure_guard_storage_tree()` ya no compara una ruta `canonicalize()` con una ruta descendiente que todavía no existe.
- Ambos lados se resuelven mediante `canonical_path_for_match()`, que canonicaliza el ancestro existente y reconstruye los componentes faltantes con la misma forma de ruta.
- Esto evita la discrepancia habitual de Windows entre rutas con prefijo `\\?\\` y rutas normales `C:\\...` durante la primera instalación.
- Añadida prueba de regresión para descendientes todavía inexistentes bajo `ProgramData\\OpacWindow\\guard\\profiles`.
- No se modifica la política ACL ni el alcance permitido: la ruta solicitada debe seguir siendo un descendiente estricto de `profiles`.
