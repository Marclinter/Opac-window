# Fixed214

- Corregido el filtrado de `dwStreamIndex` en `OnReadSample`: se usaba incorrectamente el selector `MF_SOURCE_READER_FIRST_VIDEO_STREAM` como si fuera el índice real devuelto por el callback.
- Añadida regresión de integración Windows con un MP4 H.264 real que exige la entrega de un frame por Media Foundation.
- Limitada de forma explícita la cola RAW a `VIDEO_RAW_SAMPLE_QUEUE_CAPACITY` antes de solicitar nuevas muestras.
- El staging de `IMF2DBuffer::ContiguousCopyTo` queda incluido en el presupuesto de memoria del proceso antes de reservarlo.
- Abortado y unido el hilo decoder si no puede arrancar el hilo procesador.
- Sin cambios en criptografía, Guard, API de Vault, formato Opac ni el scheduler A/V salvo la ruta necesaria para que el pipeline real reciba frames.
