# Fixed120

Correcciones de compilación del pipeline de previsualización de vídeo introducido en Fixed117.

- Compatibilidad de los índices de `IMFSourceReader` con `u32` en `windows 0.62.2`.
- Compatibilidad de los flags de `ReadSample` con `u32`.
- Uso de `&TextureHandle` en `egui::Image::from_texture` para egui 0.36.2.
- No se modifica la arquitectura de reproducción, el seek ni la lógica criptográfica.
