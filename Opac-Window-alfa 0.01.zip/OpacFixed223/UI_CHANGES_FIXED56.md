# Changes — fixed56

## Profile-scope fix

- `KeyStoreSession::list_vaults()` now validates scoped vault locations through `ensure_vault_location_in_profile_scope()`.
- This preserves registered vaults whose physical directory has not yet been materialized, while still rejecting locations outside the active profile.
- Regression coverage remains in `scoped_sessions_isolate_vault_locations_by_profile_root`.

## Export hardening

- `KeyStoreSession::export_vault()` now revalidates the selected vault location against the active profile scope before exporting its Vault Key.
- Added `scoped_export_rechecks_vault_location_scope` to verify that a vault record moved outside the active profile cannot be exported through a scoped session.

## Clippy cleanup

- Collapsed the nested `if let` in `gui.rs`.
- Removed the explicit auto-deref of `vault_key`.
- Removed the needless `return` in the Windows reparse-point check.

## Validation

- Cargo tests, Clippy, and `cargo audit` were not executed in this environment. Run them in the Windows development environment.

### Fixed after validation feedback
- Marked `scoped_session_rejects_keystore_entries_outside_active_profile` as a unit test with `#[test]` so it is executed and no longer triggers `dead_code` under `cargo clippy -- -D warnings`.
- No security behavior is changed by this adjustment; the previously added scoped `export_vault()` hardening remains in place.
