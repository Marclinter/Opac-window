# Fixed103

## Clippy

Corregido `clippy::collapsible-if` en el botón «↻ Comprobar estado» de la interfaz de OPAC Guard.

La comprobación de `clicked`, `guard_operation` y `active_profile_id` usa ahora una sola condición con `let Some(...)`, sin cambiar el comportamiento funcional.
