# Validación prevista de OpacFixed208

Ejecutar en Windows desde la raíz:

```powershell
cargo fmt --check
cargo check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-targets --no-fail-fast
cargo build --release --locked
```

Este entorno no dispone de Cargo/Rust, por lo que la validación de compilación real debe hacerse en Windows.
