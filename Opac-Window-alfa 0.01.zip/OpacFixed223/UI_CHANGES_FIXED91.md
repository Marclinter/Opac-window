# Fixed91 — Correcciones de Clippy

- Sustituido `sort_by` por `sort_by_key` en las ordenaciones por ruta normalizada.
- Sustituido `chunks_exact_mut(16)` por `as_chunks_mut::<16>()`.
- Eliminados lifetimes explícitos innecesarios en `decode_signed_command`.
- Simplificado el cierre de IPC (`CMD_QUIT`) según las sugerencias de Clippy.
- Simplificada la comprobación de `ERROR_IO_PENDING`.
- Simplificado el resultado de `wait_for_directory_change` eliminando ramas idénticas.
- Sustituido un `let...else` por `?` en la autenticación IPC.
- Eliminado el import de `WAIT_TIMEOUT` después de simplificar esa rama.

Estas modificaciones mantienen el comportamiento; son correcciones de estilo/estructura detectadas por `cargo clippy --all-targets --all-features -- -D warnings`.
