Fixed178 — Clippy cleanup for the video preview buffer

- Collapsed the nested initial-frame conditions without dropping a mismatched-generation front frame.
- Reduced `prefetch_video_frames` to seven parameters by grouping mutable buffer state.
- Replaced the manual min/max clamp with `clamp`.
- Converted constant-only assertions into const blocks so Clippy with `-D warnings` accepts them.
- No change to the A/V clock, seek, preview resolution, or 100 MiB buffer policy.
