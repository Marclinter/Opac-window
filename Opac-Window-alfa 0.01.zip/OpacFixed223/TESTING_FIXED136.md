# TESTING_FIXED136

En Windows, desde la raiz `OpacFixed126`, ejecutar en este orden:

```powershell
cargo fmt --check
cargo check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
```

Fixed136 solo corrige los errores y warnings reportados por la compilacion compartida en esta iteracion. El `Cargo.lock` debe seguir siendo el generado por Cargo en el entorno Windows de build.
