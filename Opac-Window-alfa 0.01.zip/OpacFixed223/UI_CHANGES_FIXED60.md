# OPAC Window Fixed60

## Importación manual no bloqueante

- `+ -> Importar archivos…` abre el selector nativo de Windows mediante `rfd`.
- `pick_files()` ya no se ejecuta en el hilo de la GUI. Se lanza en un hilo dedicado llamado `opac-file-dialog`.
- La selección vuelve al hilo de egui mediante un canal `mpsc`.
- Los archivos seleccionados siguen la misma cola de importación y el mismo cifrado V2 que el drag & drop.
- Mientras el selector nativo permanece abierto, la ventana principal puede seguir procesando repintados,
  eventos de entrada y drag & drop. Esto evita que un archivo arrastrado parezca “esperar” hasta cerrar
  el Explorador de Windows.
- El drag & drop de archivos y carpetas sobre la ventana principal no se modifica. Las carpetas completas
  siguen importándose por esa vía.

## Relación con Fixed56–Fixed59

- Fixed56: aislamiento por `profile_root` y hardening de `export_vault()`.
- Fixed57: eliminación de tamaños infinitos en egui para evitar `Rect` con coordenadas `NaN` al arrancar.
- Fixed59: el botón `+` vuelve a abrir directamente el selector nativo, sin una ventana de importación propia.
- Fixed60: ese selector se mantiene nativo, pero deja de bloquear el hilo de la GUI.
