# Fixed98

## Nueva Caja Fuerte desde estado vacío

- El texto `+ Nueva caja fuerte` del estado sin Caja ahora es un botón funcional.
- Al pulsarlo, abre el mismo diálogo `Nueva caja fuerte` utilizado por la vista con Cajas existentes.
- Limpia el nombre y la ubicación pendientes antes de abrirlo.
- Mantiene el tono morado existente.
