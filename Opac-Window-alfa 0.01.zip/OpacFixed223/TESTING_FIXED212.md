# Testing Fixed212

Base: OpacFixed211.

Incidencias observadas en Fixed211:
- `cargo test --workspace --all-targets --no-fail-fast`: 5 tests fallaron.
- Guard: 39 tests + 2 tests públicos pasaron en el bloque mostrado.
- Pruebas adicionales, crypto intensivas, crypto y security regression pasaron en el bloque mostrado.

Correcciones incorporadas para Fixed212:
- resolución consistente de scope para rutas con padres ausentes;
- cadencia de muestreo durante seek;
- inicio de simulación cerca del final del vídeo;
- fixture de forward seek;
- contraseña de exportación válida en la regresión de Vaults.

Validación pendiente en Windows:
```powershell
cargo fmt --check
cargo check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-targets --no-fail-fast
cargo build --release --locked
```
