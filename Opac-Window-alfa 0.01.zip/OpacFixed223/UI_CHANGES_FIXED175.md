# Opac Window — Fixed175

## Vista previa de vídeo: buffer adelantado y sincronización A/V

- La vista previa admite como máximo 1280×720, pero el tamaño real se adapta al presupuesto de memoria para mantener un buffer amplio sin superar el objetivo global de 100 MiB.
- En el formato RGB32 habitual, el límite de buffer interno deja margen para la cola de eventos y la textura actual de la GUI; para 30 fps + 12 frames de reserva, un vídeo 16:9 se reduce dinámicamente a aproximadamente 960×540.
- La salida de vídeo solicita una cadencia objetivo de 30 fps a Media Foundation.
- El evento `Ready` no se entrega hasta que se han preparado los primeros 30 frames (≈1 segundo a 30 fps); de este modo el audio no puede arrancar por delante del vídeo.
- Durante la reproducción se intenta mantener 30 frames por delante más 12 frames de reserva.
- El buffer interno ya no se vacía simplemente por estar en pausa; se conserva para evitar que un bloqueo de la GUI obligue a volver a decodificar inmediatamente.
- Seek, restart y cambios de generación invalidan el buffer anterior.
- El reloj de audio continúa siendo el maestro cuando está disponible; si el audio no es utilizable, el vídeo conserva un reloj monotónico de respaldo. Los frames que quedan retrasados se descartan y los adelantados esperan al reloj, permitiendo recuperar un bloqueo sin alterar la sincronización A/V.
