# Testing — Fixed149

Nuevos tests de regresión de progreso de importación:

- El progreso total se calcula por bytes para evitar una barra aparentemente detenida durante archivos grandes.
- La conversión de chunks a bytes alcanza exactamente el tamaño original en el último chunk y no lo supera.
- Los archivos pequeños alcanzan el 100% al terminar su único chunk.

Validación final prevista en Windows:

```powershell
cargo fmt --check
cargo check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
```
