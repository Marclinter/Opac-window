# Fixed117 — Barra de progreso y seek para vídeo

- Añadida duración del vídeo mediante Media Foundation (`MF_PD_DURATION`).
- Añadido slider de posición en la vista previa integrada.
- El slider permite adelantar y retroceder y mantiene su posición visual mientras se arrastra.
- El seek se ejecuta en el hilo de decodificación, no en la GUI.
- Se utiliza `IMFSourceReader::SetCurrentPosition` en unidades de 100 ns y se vacía el búfer con `Flush` después del salto.
- Si Media Foundation no proporciona duración, la previsualización sigue funcionando sin slider.
- Mantiene la reproducción/pausa actual después de un seek.
- No modifica la reproducción de audio del vídeo.
