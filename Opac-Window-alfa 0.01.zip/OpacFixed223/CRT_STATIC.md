# Fixed218 — static MSVC CRT

Fixed218 keeps Fixed217 as the functional baseline and changes only the Windows/MSVC
linkage policy: the Microsoft C runtime is requested statically with
`-C target-feature=+crt-static`.

## Why

The goal is that the released `opac_window.exe` does not require the VC++ runtime DLLs
(`VCRUNTIME140.dll`, `MSVCP140.dll`, or the UCRT family) just to start on a clean
Windows installation.

This does **not** remove normal Windows system dependencies such as Media Foundation,
Win32, Direct3D/OpenGL, etc. It also does not affect SmartScreen reputation or code
signing.

## Enforcement

`.cargo/config.toml` applies `crt-static` to Windows/MSVC targets. `build.rs` checks
that the target actually has the `crt-static` feature, and both the main crate and
`opac_guard` contain a compile-time guard that fails if a Windows/MSVC build is ever
attempted without that feature.

This is deliberate: setting `RUSTFLAGS` from the outside in a way that removes the
feature must fail the build rather than silently producing a dynamically linked binary.

## Verification on Windows

After a successful release build, inspect the PE imports from a Visual Studio
Developer Command Prompt:

```text
link /dump /dependents target\\release\\opac_window.exe
```

The result should not list `VCRUNTIME140.dll`, `MSVCP140.dll`, or the UCRT DLL family.

Because OPAC Guard is embedded into `opac_window.exe`, also verify the separately
built Guard artifact if desired:

```text
link /dump /dependents target\\release\\opac_guard.exe
```

A release build must still pass the project's normal validation chain:

```powershell
cargo fmt --check
cargo check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-targets --no-fail-fast
cargo build --release --locked
```
