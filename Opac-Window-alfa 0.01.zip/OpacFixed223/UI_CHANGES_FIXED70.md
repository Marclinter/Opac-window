# Fixed70 — OPAC Guard embebido

- El payload de `opac_guard.exe` se genera mediante `guard/` y `build.rs` y queda embebido dentro de `opac_window.exe`.
- El archivo físico del Guard solo se materializa cuando el usuario activa OPAC Guard.
- La activación/desactivación elevada usa el propio `opac_window.exe`; ya no depende de un `opac_guard.exe` junto a la GUI.
- La copia materializada se coloca bajo `%ProgramData%\OpacWindow\guard\profiles\<profile-id>`.
- El Guard standalone ya no acepta comandos directos de instalación/desinstalación: su único modo público es `--service`.
- `normalize_roots()` queda incluida en el módulo para eliminar raíces redundantes.
- La validación durante el arranque del servicio ya no depende de `LOCALAPPDATA` de la cuenta del servicio; comprueba que la ruta configurada termina en `OpacWindow\profiles\<profile-id>`.
- `arm_protection()` falla cerrado si no consigue crear al menos un worker.
- El perfil release del Guard usa optimización por tamaño, LTO, un solo codegen unit, símbolos eliminados y `panic = abort`.
- El instalador definitivo, las ACL endurecidas de los binarios y la autenticación criptográfica del canal de administración se mantienen como trabajo posterior.
