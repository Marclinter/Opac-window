# Fixed113

## OPAC Guard: diagnóstico administrativo robusto

- Se añade un canal de diagnóstico de respaldo creado por el proceso no elevado antes de solicitar UAC.
- El helper elevado escribe el resultado en el almacenamiento administrativo protegido y, además, en el canal de respaldo.
- La GUI utiliza el resultado protegido primero y el de respaldo cuando el primero no existe o no es legible.
- El canal de respaldo solo transporta diagnóstico. La autoridad para instalar/desinstalar sigue siendo el código de salida del helper y el estado real del servicio de Windows.
- Se añade `--admin-result-fallback` al protocolo interno del helper.
