# UI Changes — Fixed115

- Added a warning to the OPAC Guard settings description explaining that deactivation may take some time because Windows must stop and remove the Guard service.
- Clarified that the OPAC interface remains responsive while the deactivation runs.
- No functional Guard logic, security policy, or purple theme colors were changed.
