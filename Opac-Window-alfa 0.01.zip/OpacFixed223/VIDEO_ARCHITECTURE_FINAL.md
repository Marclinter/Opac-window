# Opac Window — arquitectura final del preview de vídeo (Fixed204)

## Estado

Esta es la especificación de referencia del preview integrado de vídeo. El diseño separa Media Foundation, procesamiento de frames y scheduler de presentación. El Source Reader usa `MF_SOURCE_READER_ASYNC_CALLBACK`; no se permite que una espera de `ReadSample()` bloquee la GUI.

## Pipeline

1. La Caja Fuerte descifra el `.opac` una sola vez a un temporal privado de sesión. El archivo cifrado original nunca se entrega a Media Foundation.
2. Un coordinador dedicado posee el `IMFSourceReader`, inicializa COM/Media Foundation y mantiene como máximo una solicitud `ReadSample` pendiente por sesión.
3. `OnReadSample` valida generación/estado y convierte el sample recibido a un buffer Rust `Zeroizing<Vec<u8>>`. El callback no entrega `IMFSample` a otros hilos ni bloquea esperando a la GUI.
4. Un procesador independiente transforma BGRA empaquetado a RGBA en el propio buffer y mantiene el buffer decodificado de la generación actual.
5. El scheduler consume frames ya procesados y entrega como máximo 6 eventos en cola a egui.

## Cadencia máxima

El preview integrado tiene un máximo de **60 FPS**. Esto limita la cadencia de presentación/admisión, no reescribe artificialmente el frame rate del archivo fuente.

El intervalo base es `1 s / 60`. En VFR se conservan los timestamps del contenido y se omiten samples demasiado próximos entre sí. En fuentes de más de 60 FPS se admite como máximo una imagen por intervalo de presentación.

## Buffer y RAM

La memoria de frames se ajusta dinámicamente a la resolución de preview, con una resolución integrada máxima de 960×540. No existe un objetivo normal rígido de 256 MiB ni un límite fijo de 60 frames.

La capacidad crece mientras sea necesaria para mantener aproximadamente 1 segundo de vídeo listo y hasta unos 3 segundos de adelanto cuando el contenido y la RAM disponible lo permiten.

Existe únicamente un **límite de seguridad de 1 GiB de memoria privada del proceso**. Se reserva internamente margen para Media Foundation, egui y audio; ese margen es una barrera de seguridad, no un objetivo de consumo. El decoder deja de solicitar nuevos frames antes de cruzar el límite y la asignación de cada frame está protegida contra overflow.

## Sincronización A/V

Cuando existe audio reproducible, el reloj de audio es el maestro. El vídeo espera cuando se adelanta, descarta frames atrasados dentro de los umbrales definidos y solicita un resync mediante seek cuando la deriva es demasiado grande.

Durante seek/restart, `audio_clock_pending` impide que el vídeo avance con el reloj monotónico antes de que el audio vuelva a estar operativo. Sin audio compatible se utiliza el reloj monotónico como respaldo.

## Seek y generaciones

Cada seek/restart crea una nueva generación. El contexto anterior se desactiva y vacía, se llama a `Flush`, se espera `OnFlush`, se libera la sesión anterior y después se crea el `Source Reader` de la nueva generación.

Media Foundation puede reanudar desde un keyframe anterior. El preview conserva como máximo el último frame útil anterior al objetivo para poder promocionarlo en `EOS` si no aparece un sample posterior.

**Regla importante:** durante el paseo keyframe→objetivo no se deben copiar todos los samples. La admisión pre-objetivo está limitada a la cadencia máxima de 60 FPS para evitar trabajo inútil en GOP largos o fuentes de 120+ FPS.

Las órdenes de control llevan siempre generación + comando bajo el mismo mutex; los frames y señales llevan generación y la GUI ignora cualquier generación obsoleta.

## Media Foundation

- `MF_SOURCE_READER_ASYNC_CALLBACK` obligatorio.
- No cambiar modo síncrono/asíncrono después de crear el Source Reader.
- No ejecutar `SetCurrentMediaType`/`SetNativeMediaType` mientras exista una solicitud pendiente.
- Ante `CURRENTMEDIATYPECHANGED` o `NATIVEMEDIATYPECHANGED`, esperar la finalización de la lectura actual, reaplicar el layout esperado y solicitar el siguiente sample.
- `EOS` con `pSample == NULL` es un final normal de stream; solo es error si la generación nunca produjo ningún frame utilizable.
- En cierre/seek, `Flush` se confirma mediante `OnFlush` antes de liberar el reader/callback.

## Seguridad de memoria y buffers

Los buffers de frame se mantienen en `Zeroizing<Vec<u8>>`. Todas las copias desde Media Foundation validan dimensiones, stride, offsets, longitudes y overflow antes de construir slices desde punteros nativos.

La resolución, la contabilidad interna de colas y el backstop de memoria impiden asignaciones arbitrariamente grandes. La telemetría de memoria del proceso es un último cinturón de seguridad; el crecimiento normal depende de la capacidad dinámica del pipeline.

## Temporales

Los temporales se crean de forma exclusiva mediante nombres aleatorios y se validan como archivos normales. En Windows se rechazan reparse points/symlinks en los accesos gestionados. La limpieza se reintenta si un archivo sigue abierto por Media Foundation o el reproductor de audio.

## Reglas de mantenimiento

No reintroducir:

- `ReadSample()` síncrono dentro del scheduler o GUI.
- Buffers globales sin generación.
- Colas ilimitadas sin contabilidad de memoria.
- Límite fijo de 30 FPS si el requisito es 60 FPS.
- Conversión del frame rate del fichero cuando solo se necesita limitar presentación.
- Copia de todos los samples previos a un seek.
- `drop(&mut session)` esperando liberar una sesión propietaria: la función de shutdown debe recibir la sesión por valor.
