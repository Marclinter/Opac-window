# Import progress

Large file imports (more than one V2 content chunk) now show a thin progress bar under the temporary in-tree filename. Progress is based only on completed content chunks and never exposes plaintext data through the progress channel.

The import overlay was removed so the tree remains visible while encryption proceeds. Existing operation guards keep mutating actions disabled until the import finishes.

## Importación múltiple concurrente (fixed41)

Las importaciones manuales y por arrastre múltiple se ejecutan mediante un pool
acotado de hasta 8 trabajadores. Los trabajos se colocan primero por tamaño
ascendente, de modo que los archivos pequeños reciben prioridad de despacho y,
a medida que terminan, los huecos se reutilizan para los archivos grandes.

La clave de la Caja se comparte de forma inmutable entre los trabajadores dentro
de `Zeroizing`; no se duplican ni se registran claves o plaintext en los eventos
de progreso. El evento de progreso identifica el archivo, evitando mezclar los
contadores cuando varias cifrados avanzan simultáneamente.
