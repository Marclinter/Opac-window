# Revisión general de seguridad — Fixed125

Esta revisión es estática y está orientada a evitar regresiones. No constituye una auditoría criptográfica formal ni demuestra ausencia de vulnerabilidades.

## Superficies revisadas

- Aislamiento de Cajas Fuertes y límites del perfil mediante rutas canónicas.
- Rechazo de enlaces simbólicos y puntos de reanálisis en almacenamiento administrado.
- Cifrado autenticado V2, validación de metadata/chunks y rechazo de entradas truncadas o manipuladas.
- Escrituras a disco con temporales impredecibles, `create_new`, publicación final posterior a la autenticación y protección contra sobrescrituras implícitas.
- Rollback del Key Store ante fallos de persistencia y recuperación de candidatos autenticados.
- Importación/exportación, movimiento, renombrado y borrado dentro del ámbito de la Caja Fuerte.
- OPAC Guard: normalización de raíces, límites de rutas liberables, firma de comandos, nonce/sesión y secuenciación anti-replay.
- Ciclo de vida de plaintext temporal y limpieza diferida cuando Windows mantiene un fichero abierto.
- Previsualización de imagen/PDF en memoria y previsualización de vídeo con límites de tamaño/dimensiones.
- Nuevo audio integrado del vídeo: el decoder recibe exclusivamente la copia temporal ya autenticada/descifrada; nunca el `.opac` cifrado.

## Resultado

No se ha identificado durante esta revisión estática un bypass nuevo de aislamiento de perfil, autenticación de ciphertext o autorización del Guard que pueda describirse como una vulnerabilidad explotable con la información disponible.

Se han añadido pruebas de regresión que fijan dos límites de alto valor para el aislamiento de perfiles:

1. una ruta externa cuyo nombre solo comparte prefijo textual con el perfil no puede usarse para crear una Caja Fuerte;
2. un directorio presentado mediante un enlace simbólico/junction hacia fuera del perfil no puede usarse como padre de creación.

Estas pruebas cubren específicamente el comportamiento de `create_vault_in_parent`, que es una ruta sensible porque crea físicamente un nuevo árbol de almacenamiento.

## Endurecimiento multimedia

El reproductor de vídeo se inicia pausado mientras el proceso de GUI prepara el audio. Cuando la pista de audio es compatible, se crea un reproductor independiente para el vídeo y los controles de reproducir, pausa, reinicio, búsqueda y volumen actúan conjuntamente sobre vídeo y audio. Si la pista de audio no es compatible o no existe un dispositivo de salida, el vídeo continúa funcionando sin audio y el motivo se muestra en la interfaz.

La búsqueda pausa temporalmente el conjunto y reposiciona el audio y el vídeo antes de reanudar, evitando que la pista de audio continúe avanzando mientras el decodificador de Media Foundation procesa el salto.

## Riesgos residuales

La API de Windows Media Foundation y el stack de decodificación de audio siguen siendo código complejo de terceros/OS; la defensa aplicada en OPAC consiste principalmente en limitar tamaños y mantener los archivos de origen autenticados.

Las operaciones de filesystem basadas en rutas siguen teniendo límites inherentes de TOCTOU frente a un proceso del mismo usuario capaz de modificar simultáneamente el árbol. La aplicación reduce este riesgo validando repetidamente entradas sensibles y rechazando symlinks/reparse points, pero una eliminación completa de TOCTOU requeriría APIs de filesystem basadas en handles y comprobaciones adicionales específicas por plataforma.

El diseño del Key Store sigue suponiendo una única instancia escritora activa. Una segunda instancia concurrente no comparte un lock interproceso portable.

No se ha ejecutado `cargo audit` dentro del entorno de construcción de esta revisión porque el contenedor no dispone de `cargo`/`rustc`. La validación final debe ejecutarlo junto con Clippy, tests y formateo.

## Validación recomendada en Windows

```powershell
cargo fmt --check
cargo check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
cargo test -p opac_guard --all-targets
cargo audit
```
