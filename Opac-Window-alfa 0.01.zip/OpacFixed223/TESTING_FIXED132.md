# TESTING_FIXED132

Fixed132 endurece el ciclo de vida del plaintext sin cambiar el comportamiento visible de previsualización.

## Casos a validar

- Previsualización de texto desde un archivo precargado y desde el `.opac`.
- Previsualización de PDF e imagen desde memoria.
- Lectura V1 legacy dentro del límite.
- Audio cancelado antes de que el worker publique un evento: el temporal se elimina tras el `join`.
- Cierre/bloqueo mientras hay previews activos: no debe quedar ninguna tarea GUI sin join.
- PreloadAll sigue funcionando sin cambiar su semántica.
