# Testing Fixed213

Base: OpacFixed212.

Esta capa existe para diferenciar correcciones reales de simples relajaciones de pruebas.

Controles añadidos:
- `playback_simulation_large_audio_lead_triggers_hard_resync_instead_of_fake_history`: conserva explícitamente la cobertura del hard-resync a 2 s.
- `PlaybackSimulation::start`: exige el buffer máximo disponible hasta el final del vídeo, no un valor fijo ciego ni simplemente un único frame.

Validación en Windows:
```powershell
cargo fmt --check
cargo check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-targets --no-fail-fast
cargo build --release --locked
```
