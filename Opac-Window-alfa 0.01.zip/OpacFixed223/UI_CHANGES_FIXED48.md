# UI Changes — fixed48

- Added a small gear button (⚙) at the top-left of the authenticated main screen.
- It is only rendered on `Screen::Main`, so it is unavailable on setup, profile selection, and user unlock screens.
- Clicking it currently only reports “Ajustes: próximamente.”; no settings controls or new settings system were added.
- No cryptographic, profile, vault, or storage behavior was changed.
