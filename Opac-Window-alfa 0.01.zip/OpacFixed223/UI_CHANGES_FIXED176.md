# Opac Window — Fixed176

## Seek de vídeo coordinado con el buffer y el reloj de audio

- La barra de progreso existente ya era un control de seek real: conserva la posición solicitada mientras se arrastra y al soltar envía el salto al decodificador y al reproductor de audio.
- Tras un seek manual mientras el vídeo estaba reproduciéndose, el audio ya no se reanuda inmediatamente. Se mantiene pausado mientras Media Foundation busca la nueva posición y el worker vuelve a llenar el buffer con un segundo de adelanto + 12 frames de reserva.
- El audio vuelve a arrancar únicamente cuando llega a la GUI el primer frame de la nueva generación, tomando entonces su posición real como reloj maestro. Esto evita que un seek costoso haga que el audio se adelante al vídeo.
- Los seek hacia atrás aprovechan el nuevo buffer preparado desde la posición solicitada; no se fuerza una recarga especial de frames ya consumidos.
- Los seek hacia delante invalidan la generación anterior y preparan de nuevo el colchón desde el nuevo punto.
- Una resincronización automática dura no salta directamente al primer frame recién buscado: vuelve a entrar por la misma comparación de timestamps con el reloj de audio.
- Se mantiene la política de preview de Fixed175: máximo 720p, objetivo de 30 FPS, hasta 1 segundo adelantado + 12 frames de reserva y presupuesto total de 100 MiB.
