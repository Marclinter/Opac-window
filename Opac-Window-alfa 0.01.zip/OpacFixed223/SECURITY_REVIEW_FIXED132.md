# SECURITY_REVIEW_FIXED132

Fixed132 refuerza el ciclo de vida de plaintext. OPAC Guard no se modifica.

## Cambios

- `DecryptedOpacFile.content` se mantiene dentro de `Zeroizing<Vec<u8>>` hasta que el consumidor termina con el plaintext.
- `VaultSession::read_small_file` devuelve plaintext zeroizado, incluidos los archivos V1 legacy.
- La GUI convierte el contenido de texto a `String` desde una vista UTF-8 y conserva la copia final dentro de `Zeroizing<String>`.
- PDF e imagen reciben directamente el buffer zeroizado del core.
- Un `AudioPreviewTask` que termina sin publicar evento limpia su temporal después de hacer `join`.

## Limitaciones

La zeroización solo cubre los buffers bajo control de OPAC. Renderizadores, decodificadores del sistema, cachés del SO/GPU y aplicaciones externas pueden crear copias fuera de ese control.
