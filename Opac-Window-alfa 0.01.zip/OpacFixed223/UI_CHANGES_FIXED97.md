# Fixed97

- Recuperación explícita de una instalación original/legacy cuando un perfil dedicado no tiene Key Store propio pero aún existe el `keystore.opks` histórico.
- La recuperación exige seleccionar el usuario y proporcionar su contraseña; no sustituye automáticamente un Key Store dedicado existente.
- La migración copia únicamente ciphertext, conserva la Vault Key y elimina el almacenamiento legacy solo después de crear y persistir el Key Store dedicado.
- El selector identifica el almacenamiento legacy como `Usuario original` para evitar confundirlo con otro slot neutral.
- Los errores de autenticación, almacenamiento ausente y desajuste de perfil muestran mensajes específicos.
