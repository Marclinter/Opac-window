# Pruebas — Fixed131

## GUI / seguridad

- Crear una Caja Fuerte dentro de una carpeta existente y comprobar que la carpeta padre conserva sus permisos.
- Provocar un fallo de creación y comprobar que no se han cambiado los permisos de la carpeta padre.
- Copiar la Vault Key al portapapeles, dejar pasar el TTL y comprobar su limpieza.
- Reemplazar manualmente el contenido del portapapeles antes del TTL y comprobar que OPAC no lo sobrescribe.
- Probar el desbloqueo con PIN: un error en la Caja A no debe aplicar cooldown a la Caja B.
- Crear/desbloquear contraseñas con caracteres Unicode y comprobar que el límite coincide con el texto de la GUI.

## Comandos de validación en Windows

```powershell
cargo fmt --check
cargo clippy --all-targets --all-features -- -D warnings
cargo test
cargo check
```
