# Opac Window — arquitectura final del preview de vídeo (Fixed197)

## Flujo

1. El archivo cifrado se descifra una sola vez a un temporal privado de sesión.
2. Un hilo coordinador posee exclusivamente `IMFSourceReader`, COM y Media Foundation.
3. El Source Reader se crea en modo asíncrono mediante `MF_SOURCE_READER_ASYNC_CALLBACK`.
4. El callback no retiene interfaces Media Foundation para otros hilos: copia el sample RGB32 a un `Zeroizing<Vec<u8>>` empaquetado y publica solo datos Rust + timestamps.
5. Un hilo procesador convierte BGRA empaquetado a RGBA y llena el buffer de hasta 60 frames.
6. El hilo de reproducción/scheduler consume el buffer compartido y solo entrega como máximo 6 frames a la GUI.
7. El reloj de audio sigue siendo el maestro cuando hay audio. Sin audio se usa un reloj monotónico de respaldo.
8. Cada seek/restart crea una nueva generación. La generación anterior se desactiva, vacía sus colas, hace `Flush`, espera `OnFlush`, libera el reader anterior y después crea el reader nuevo.
9. Un seek conserva de forma acotada el último frame anterior al timestamp solicitado para poder mostrar un frame final si Media Foundation llega a EOS sin entregar uno posterior.
10. La memoria de frames activos se contabiliza como `raw + decoded + processing + fallback` y está limitada a 60 frames.

## Invariantes

- Ningún `IMFSourceReader` cruza hilos.
- Ningún `IMFSample` cruza hilos.
- Los callbacks antiguos no pueden contaminar la generación nueva.
- El callback de Media Foundation no bloquea esperando a la GUI.
- Los frames de vídeo se mantienen en memoria como buffers zeroizing.
- No se modifica el archivo cifrado original.
- El reproductor externo continúa recibiendo el temporal privado original sin reducir su resolución.
