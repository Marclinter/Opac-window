# Cambios de interfaz y multimedia — Fixed125

## Vídeo con audio integrado

La vista integrada de vídeo reproduce ahora también la pista de audio compatible contenida en el archivo multimedia.

Controles sincronizados:

- reproducir / pausa;
- reinicio;
- búsqueda en la barra de posición;
- volumen.

El vídeo se prepara primero con Media Foundation y el audio se abre desde la misma copia temporal autenticada. Si el audio no se puede decodificar, el vídeo sigue disponible y la interfaz muestra el motivo.

## Seguridad y regresión

Se añadieron dos pruebas de seguridad para impedir que futuras modificaciones permitan escapar del perfil mediante prefijos de ruta o directorios enlazados hacia fuera.

No se han cambiado los colores personalizados de OPAC; los morados permanecen sin modificaciones.


La sincronización robusta posterior se implementa en **Fixed126**.
