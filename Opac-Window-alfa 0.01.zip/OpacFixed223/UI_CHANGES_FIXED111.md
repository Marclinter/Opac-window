# Fixed111 — Correcciones de compilacion en OPAC Guard

- Importa `std::time::Instant` en el modulo Windows del Guard, requerido por el timeout por deadline del helper elevado.
- Evita mover `parsed.user_sid` antes de escribir el resultado administrativo; se clona el SID para la llamada de instalacion y se conserva el valor parseado para notificar el resultado.
- No cambia la logica de instalacion, elevacion, rutas, ACL ni desinstalacion.
