# Fixed89

Correccion de compilacion derivada de la adaptacion de tema de Fixed88.

- Corregido `theme_neutral(dark_mode, ...)` en el marco principal del arbol para usar `self.dark_mode`.
- Verificados los dos usos de `dark_mode` dentro de `paint_tree_connector`: esa funcion es asociada sin `self`, por lo que recibe `dark_mode` como parametro y mantiene esos usos correctamente.
- Verificadas las llamadas a `paint_tree_connector`, que ya transmiten `self.dark_mode`.
