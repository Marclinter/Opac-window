# Cambios multimedia — Fixed126

## Sincronización robusta de vídeo + audio

La vista integrada de vídeo usa ahora la posición real reportada por el reproductor de audio como **reloj maestro** cuando existe una pista de audio compatible.

El decodificador de vídeo no intenta mantener un segundo reloj independiente durante la reproducción con audio. Para cada fotograma:

- si el vídeo va ligeramente por delante, espera al audio;
- si el fotograma queda retrasado más allá del margen visible, se descarta para recuperar tiempo;
- si la deriva alcanza un umbral grande, el lector de Media Foundation hace un seek directo a la posición actual del audio;
- la interfaz actualiza el reloj multimedia con alta frecuencia para que el estado compartido no quede obsoleto.

Los márgenes actuales son 25 ms de tolerancia, 75 ms para descartar fotogramas atrasados y 300 ms para una resincronización fuerte.

## Reinicio y búsqueda

Se añadió un contador de generación de control. Cada reinicio o búsqueda invalida los fotogramas que estaban en vuelo antes de la operación, evitando que un fotograma viejo reaparezca después de un seek/restart.

Cuando el seek del audio falla, OPAC no continúa reproduciendo una pista de audio desfasada: detiene ese audio y deja el vídeo funcionando con su reloj local.

## Fin de la pista de audio

Si la pista de audio termina antes que el vídeo, se desactiva el reloj maestro de audio y el vídeo continúa sin bloquearse esperando una posición de audio que ya no avanza.

## Interfaz

La posición mostrada durante reproducción con audio procede del reloj maestro de audio para que la barra y la reproducción representen la misma línea temporal.

Los controles existentes de reproducir/pausa, reinicio, búsqueda y volumen se mantienen.

Los colores personalizados de OPAC, incluidos los morados, no se modifican.
