# Fixed218

Base: Fixed217 (manually validated by the project owner).

## Change

Windows/MSVC builds now request and enforce static linking of the Microsoft C runtime
via Cargo target-specific rustflags.

## Anti-regression enforcement

- Cargo target configuration enables `crt-static` for Windows/MSVC.
- `build.rs` fails early if a Windows/MSVC build does not expose `crt-static`.
- The main crate and `opac_guard` contain compile-time guards for the same invariant.
- No application logic, cryptography, Guard protocol, preview processing, or tests were
  otherwise changed in this layer.

## Validation note

Cargo/Rust was not available in the packaging environment used to assemble this ZIP, so
this archive must be validated on Windows before being considered a passing Fixed version.
