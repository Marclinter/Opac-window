# Fixed59 — importar manualmente con el selector nativo

- Se elimina la ventana propia de importación añadida en Fixed58.
- `+ → Importar archivos…` vuelve a abrir directamente el selector nativo de archivos de Windows.
- La selección manual de varios archivos conserva el flujo existente de importación.
- La importación de carpetas mediante arrastrar y soltar sobre la ventana principal de OPAC se mantiene sin cambios.
- Se conserva todo lo incorporado en Fixed56 y Fixed57, incluido el hardening de scope por perfil y la corrección del `NaN` de egui.
