# Fixed142 — Regresiones adicionales

Se amplía la suite sin modificar la lógica del OPAC Guard.

Cobertura añadida:

- Parser `.opac`: nombres de metadata peligrosos, reordenación de chunks,
  flags `is_last` inconsistentes y cabeceras malformadas sin panic.
- PIN: parámetros Argon2id manipulados no válidos se rechazan antes de derivar.
- Caja Fuerte: entradas plaintext no gestionadas son rechazadas; el marcador
  `.opac-folder` no puede transportar contenido; borrado y movimiento mantienen
  invariantes de integridad; renombrado idempotente no re-cifra sin necesidad.
- Persistencia: corrupción del cuerpo del Key Store y contraseña incorrecta no
  deben alterar el archivo válido.
- Claves: `create_vault_with_key` conserva exactamente la Vault Key suministrada.
- Catálogo de perfiles: UUID duplicados y más de un perfil legacy se consideran
  corrupción.
- Parsers: lecturas truncadas de metadata no deben provocar panic.
