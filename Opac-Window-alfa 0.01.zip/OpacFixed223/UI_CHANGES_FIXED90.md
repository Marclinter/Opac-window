# Fixed90 — correcciones detectadas por cargo test

- Corregida la validación de rutas liberables del Guard para comparar contra las raíces configuradas después de canonicalizarlas. Esto evita falsos rechazos por diferencias de representación de rutas de Windows (por ejemplo, prefijos de `canonicalize`).
- Endurecida la validación: si alguna raíz configurada no puede normalizarse de forma segura, la operación de liberación se rechaza.
- Corregido el test de distinción entre liberaciones de archivo y árbol: una liberación de árbol que engloba un archivo debe considerarse activa para sus descendientes; el test de "archivo no es árbol" se realiza ahora con una lista que solo contiene la liberación de archivo.
- Añadido un test de regresión para la canonicalización de la raíz configurada.
