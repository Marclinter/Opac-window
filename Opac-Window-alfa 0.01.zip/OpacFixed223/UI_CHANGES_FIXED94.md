# Fixed95

## Corrección del campo de contraseña del desbloqueo

- Se añadió un ID estable al campo de contraseña maestra de `Screen::Unlock`.
- Al entrar en desbloqueo desde selección de usuario o bloqueo de sesión se solicita el foco de teclado una sola vez.
- El foco no se fuerza continuamente: el botón Desbloquear y los demás controles siguen siendo interactivos.
- No se modifica el flujo criptográfico ni el contenido de la contraseña.
