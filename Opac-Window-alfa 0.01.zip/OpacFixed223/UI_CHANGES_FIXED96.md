# Fixed96 — Navegación de selección/desbloqueo de usuario

- Añadido `cancel_profile_unlock()` para volver desde la pantalla de contraseña a la selección de usuarios.
- El botón `← Volver a selección de usuarios` limpia la contraseña pendiente y el estado de foco.
- `Esc` produce la misma navegación, evitando dejar atrapado al usuario en el perfil equivocado.
- Se mantiene la sesión cerrada/bloqueada al volver: no se restaura ningún runtime ni se toca la identidad del Guard.
- El flujo cubre tanto el desbloqueo inicial como la pantalla de desbloqueo posterior a bloqueo manual/automático, porque ambos pasan por `Screen::Unlock`.
- Revisión adicional de rutas: todas las transiciones actuales a `Screen::Unlock` pasan por la misma pantalla y no dejan otro punto sin cancelación equivalente.
