# Fixed106 — Corrección de visibilidad de OPAC Guard

Se corrigió un error de compilación introducido en Fixed105: la función interna de Windows `guard_storage_exists` ahora es `pub(super)`, permitiendo que la función pública del crate `opac_guard::guard_storage_exists` delegue en ella correctamente. No cambia el comportamiento del Guard ni su política de protección.
