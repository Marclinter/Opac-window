# UI changes — Fixed61

## Manual import dialog

- Replaced the synchronous `FileDialog::pick_files()` call executed from a worker thread with `rfd::AsyncFileDialog`.
- The async dialog future is created from the GUI thread and awaited on a dedicated worker thread with `futures-executor`, following rfd 0.17.2's recommended model.
- This avoids using the native synchronous file picker from a background thread and reduces interference between the Windows file dialog and egui drag-and-drop/event processing.
- The existing import result path is unchanged: selected files are converted to `PathBuf` and passed to the existing `start_import_files()` pipeline.
- Main-window drag and drop remains unchanged and still accepts both files and folders.
