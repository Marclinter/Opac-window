# Testing — Fixed85

## Guard

```powershell
cargo test -p opac_guard --all-targets
cargo clippy -p opac_guard --all-targets --all-features -- -D warnings
```

La suite debe cubrir la autenticación IPC, firma de comandos, aislamiento por perfil, rechazo de rutas externas, rechazo de la raíz completa, política `FILE_SHARE_READ`, reparse points, fail-closed y la selección automática de archivo frente a subárbol.

## Workspace

```powershell
cargo test --workspace --all-targets
cargo clippy --workspace --all-targets --all-features -- -D warnings
```

## Prueba manual de movimiento

Con OPAC Guard activo, un `.opac` protegido no debe poder renombrarse, moverse, borrarse ni modificarse desde Explorer/PowerShell. Una operación equivalente iniciada desde OPAC debe liberar únicamente la ruta necesaria y volver a protegerla al finalizar.
