# Modelo de seguridad local-first

## Qué protege

Opac Window protege la confidencialidad e integridad de los archivos frente a
una persona que obtenga una copia de la carpeta de la Caja Fuerte o del Key Store
sin conocer la contraseña maestra. Las Vault Keys son aleatorias y cada `.opac`
se autentica con ChaCha20-Poly1305.

## Qué no protege

Un proceso que ya controla la cuenta de usuario y puede inspeccionar la memoria
del proceso mientras una Caja Fuerte está desbloqueada puede acceder al plaintext
y a las claves activas. Tampoco se garantiza el borrado físico de plaintext en SSDs
una vez que un archivo temporal ha sido creado.

## V1 y V2

V2 es el formato de escritura actual. V1 se conserva únicamente para lectura de
archivos antiguos. La migración V1 → V2 conserva la Vault Key, escribe primero un
nuevo archivo V2 y solo después intenta eliminar el V1 original.

## Serialización persistente

Las nuevas escrituras usan Postcard. Los formatos históricos que contenían la codificación anterior de bincode 1.x se leen con un decoder legacy acotado, pero nunca se vuelven a generar.

## Contraseña maestra

La contraseña se transforma en una Master Key mediante Argon2id. Los parámetros
se almacenan en claro porque son necesarios para la derivación, pero están
autenticados como AAD. Los parámetros recibidos desde archivos se limitan antes
de ejecutar Argon2id.

## PIN

El PIN/passcode es una segunda capa local sobre una Vault Key. Como la amenaza
principal es offline y no existe un servidor que pueda imponer rate limiting sobre
una copia del disco, el secreto debe aportar entropía por sí mismo. El núcleo exige
8 bytes como mínimo y 10 dígitos si es exclusivamente numérico.

Los intentos fallidos que implemente la GUI pueden añadir fricción durante una
sesión, pero no deben presentarse como defensa frente a un atacante que pueda
restaurar una copia anterior del Key Store.


## Integración con aplicaciones externas

La GUI usa temporales aleatorios para abrir archivos con aplicaciones externas y los elimina al cerrar cuando el sistema lo permite.


## Modo "Descifrar al abrir"

Es una comodidad opcional que mantiene copias plaintext de los archivos que requieren un fichero real en una carpeta temporal mientras la sesión permanece abierta. Las imágenes y PDF quedan excluidos de esa caché y sus vistas integradas se descifran directamente en memoria. El valor predeterminado es "Descifrar al usar", que minimiza la cantidad de plaintext simultáneamente presente. La aplicación elimina la carpeta temporal al bloquear o cerrarse normalmente, aunque ningún sistema puede garantizar el borrado físico del contenido de un SSD y una aplicación externa puede mantener un archivo abierto.

- La Vault Key no se expone ni se formatea para la interfaz hasta una accion explicita en el boton «Clave». La vista utiliza una copia transitoria `Zeroizing` para mostrarla y esa copia se elimina al cerrar el dialogo o salir de alcance. La Vault Key de la Caja sigue siendo necesaria en memoria para listar metadata cifrada, previsualizar y cifrar/descifrar archivos; por tanto, retrasar su **desbloqueo criptografico interno** hasta ese boton romperia la operativa normal. Esta distincion evita confundir «no mostrar/revelar» con «no disponer de la clave para operar».


### OPAC Guard

OPAC Guard protege por perfil de Opac Window, no como una preferencia global de la aplicación ni como una identidad lógica basada en el SID de Windows. Cada perfil que activa la función recibe una instancia de servicio y una configuración de protección separadas. La raíz autorizada coincide exactamente con `profiles/<profile-id>`, y la GUI no puede pedir al Guard que proteja la raíz de otro perfil. El SID de Windows se usa solo para autorizar el canal IPC local.

### Perfiles multiusuario

Los perfiles locales separan los Key Stores por usuario de la aplicación. La credencial del perfil desbloquea únicamente su propio Key Store; los nombres de las Cajas Fuertes y sus Vault Keys no se incluyen en el catálogo de perfiles. En las nuevas escrituras V2 del catálogo (`profiles.oprp`) tampoco se persiste el nombre real del perfil: se conservan únicamente el identificador opaco y el tipo de almacenamiento. El nombre se guarda dentro del Key Store cifrado y se muestra después de autenticar el perfil. Los catálogos legacy V1 pueden contener nombres hasta su migración.

Esta separación protege frente a otro usuario de Opac Window que no conozca la contraseña del perfil. No pretende aislar frente a un administrador local, malware con privilegios, depuración del proceso o acceso físico con control total del sistema operativo.


### Desactivacion autenticada
La desactivacion de OPAC Guard desde la GUI requiere volver a introducir la contrasena maestra del usuario de OPAC que tiene el `profile_id` asociado al Guard. La GUI vuelve a abrir el Key Store dedicado con `KeyStoreSession::open_scoped`, por lo que la contrasena se verifica reabriendo y autenticando criptograficamente el almacenamiento cifrado y nunca se envia al servicio Guard. Una cancelacion de UAC o un fallo del borrado del servicio mantiene la proteccion activa y restaura la conexion de la sesion GUI.

## Endurecimiento de aislamiento y runtime (2026-09-28)

Los Key Stores de perfiles dedicados nuevos usan la versión 4 del formato y pueden quedar vinculados
criptográficamente al UUID del perfil dentro del cuerpo autenticado. Una sesión `KeyStoreSession` con
alcance de perfil vuelve a validar las rutas de las Cajas contra la raíz canónica del perfil antes de
listar, abrir, crear, importar, eliminar o exportar. `export_vault()` realiza además una comprobación
explícita del scope antes de entregar una Vault Key para exportación.

La GUI mantiene un bloqueo automático tras 10 minutos de inactividad. Si una importación, precarga o
preparación de audio sigue en curso, el bloqueo se difiere hasta que finaliza la operación para evitar
interrumpir una escritura o worker a mitad.

## Selector manual de archivos en Windows

La importación manual utiliza `rfd` para abrir el selector nativo. Ese selector se ejecuta fuera del hilo
de egui y devuelve la selección mediante un canal `mpsc`. Esto permite que la interfaz principal siga
recibiendo y procesando drag & drop mientras el selector está abierto. Las rutas seleccionadas siguen
pasando por la validación segura y por el mismo camino de cifrado V2 que la importación por arrastre.


## OPAC Guard (Windows, experimental; Fixed71)
### Fixed71: identidad criptografica, configuracion autentica y fail-closed

Cada perfil puede generar una identidad Ed25519 una sola vez. La clave privada se almacena dentro del
Key Store autenticado del perfil; la clave publica se replica en la configuracion del servicio. Al activar
Guard, las rutas normalizadas se firman con esa identidad y el servicio rechaza cualquier configuracion
cuya firma, `profile_id` o raiz no coincidan.

El pipe de Guard exige primero autorizacion por ACL/SID de Windows y despues un desafio/respuesta Ed25519
ligado al `profile_id`. La ruta del ejecutable del cliente ya no se usa como factor de autenticacion porque
el Guard materializado vive en `%ProgramData%` y la GUI puede estar instalada en otra ubicacion.

La desactivacion usa un nonce aleatorio y una firma Ed25519 ligada al perfil. El servicio verifica la firma
antes de detenerse y eliminarse. Un administrador de Windows conserva la capacidad de administrar servicios
por las vias administrativas normales; esta proteccion esta pensada para impedir la desactivacion directa
por procesos que no poseen la identidad criptografica del perfil.

El almacenamiento administrativo del Guard recibe ACLs restrictivas para SYSTEM y Administradores. La
configuracion se publica de forma crash-safe mediante archivo temporal sincronizado y backups durante el
reemplazo. El servicio no declara proteccion activa si falla el preflight inicial o no puede crear todos
los workers requeridos.



OPAC Guard es un servicio opcional que añade una capa preventiva de filesystem independiente de la GUI. El ejecutable del servicio se construye en una caja auxiliar minima y queda embebido en `opac_window.exe`; no se materializa mientras Guard esta desactivado. Al activarlo mediante UAC, la propia GUI elevada extrae el PE a `%ProgramData%\\OpacWindow\\guard\\profiles\\<profile-id>\\opac_guard.exe`, crea el servicio y lo inicia. La ubicacion y las ACL definitivas se fijaran en el instalador futuro.

La frontera de proteccion es el **perfil de usuario de Opac Window** (`profile_id`). El servicio, la configuracion y el pipe son independientes por perfil. No se protege la raiz global de Opac Window ni el almacenamiento de otro perfil.

El Guard no descifra ni lee datos. Mantiene handles sobre los artefactos cifrados (`*.opac`, `.opac-folder`, `keystore.opks`) omitiendo `FILE_SHARE_WRITE` y `FILE_SHARE_DELETE`. La proteccion permanece armada incluso con OPAC desbloqueado: leer o previsualizar no necesita liberar el ciphertext. Las operaciones que cambian datos o la estructura solicitan unicamente la excepcion exacta necesaria (archivo, directorio o subarbol); el servicio vuelve a validar la ruta dentro del perfil y reconstruye la proteccion completa antes de enviar un ACK. No existe un comando IPC de desbloqueo global de la raiz.

La GUI autentica el usuario de OPAC para desactivar Guard antes de pedir UAC. El servicio no recibe secretos criptograficos. Esta capa no sustituye a un antimalware ni evita a un administrador del sistema que deshabilite manualmente un servicio.



### Fixed74 — estado de seguridad del Guard
OPAC Guard se asocia al `profile_id` del usuario de Opac Window que lo activa. La lista de rutas queda limitada a la raiz fisica completa de ese perfil; no se acepta otro directorio aunque comparta el mismo sufijo de nombre.

El servicio no confia en rutas de usuario para su propio ejecutable: al activarse materializa el binario embebido bajo `%ProgramData%\OpacWindow\guard\profiles\<profile-id>` y aplica ACL que dejan el almacenamiento administrativo en manos de SYSTEM y Administrators. El servicio usa `LocalSystem` en esta etapa de desarrollo porque necesita acceder a los perfiles administrados; el cambio a una cuenta de minimo privilegio queda pendiente de validar las ACL necesarias sobre los datos del usuario.

La configuracion se autentica con Ed25519 y se publica con un archivo temporal sincronizado, conservando `.new` y `.bak`. La identidad del Guard vive en el Key Store cifrado del perfil y se rota al desactivar correctamente. La desactivacion elevada exige una firma sobre un nonce fresco y el `profile_id`, despues de autenticar el Key Store en la GUI.

El Guard mantiene handles sin `FILE_SHARE_WRITE` ni `FILE_SHARE_DELETE` sobre los artefactos cifrados y tambien abre directorios con proteccion contra reparse points. La monitorizacion del arbol usa `ReadDirectoryChangesW` con E/S superpuesta; ante una condicion que pueda dejar objetos protegibles sin handle, el servicio se detiene en vez de continuar parcialmente.

Eliminar un perfil mientras exista su almacenamiento administrativo del Guard devuelve `GuardActive`, evitando un perfil huerfano. La limpieza del Guard es estricta y elimina solo los artefactos conocidos; no utiliza borrado recursivo.

Esta capa no constituye un antimalware ni impide que un administrador del sistema detenga o elimine manualmente un servicio con privilegios suficientes.


## Fixed86 — protección de capturas independiente

Se añade una protección opcional de la ventana principal mediante `WDA_EXCLUDEFROMCAPTURE`, separada del Guard. La API solo protege mecanismos de captura compatibles con Windows y no debe considerarse DRM o una protección absoluta.
