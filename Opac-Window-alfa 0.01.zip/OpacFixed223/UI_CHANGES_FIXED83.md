# Fixed84 — OPAC Guard: protección selectiva por operación

Fixed84 cambia el modelo de uso del OPAC Guard: la raíz protegida del perfil permanece armada mientras OPAC está abierto y desbloqueado. La GUI ya no envía una orden para excluir toda la raíz.

Cuando una operación necesita modificar el ciphertext o la estructura de una Caja Fuerte, la GUI solicita al Guard una excepción temporal y mínima:

- archivo: edición o borrado de un `.opac`;
- subárbol: borrado, movimiento o renombrado de una carpeta;
- Key Store: cambios administrativos que persisten en `keystore.opks`.

Las lecturas y las vistas previas no requieren excepción porque los handles del Guard permiten lectura mediante `FILE_SHARE_READ`.

Al terminar la operación, la GUI solicita explícitamente la reprotección y espera un ACK del servicio. Si el canal IPC se pierde, el servicio elimina todas las excepciones y vuelve a armar la raíz.

Cada orden IPC de liberación/reprotección está firmada con Ed25519 y queda ligada a:

1. el `profile_id`;
2. el desafío fresco de la sesión IPC;
3. el tipo de operación;
4. una secuencia monotónica por conexión;
5. la ruta exacta solicitada.

El servicio además valida que la ruta exista, no sea un reparse point, sea del tipo solicitado, sea un artefacto protegido por OPAC cuando corresponda y quede dentro de la raíz autorizada del perfil. Nunca se permite liberar la raíz completa del perfil.
